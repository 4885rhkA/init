<?php
/**
 * MIME Decoder
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Decoder
 */
class MimeDecoder
{
    /**
     * MIME解析結果構造
     *
     * @var array $aContentType
     */
    protected $aStructure = array();

    /**
     * ヘッダの生文字列
     *
     * @var string $sRawHeader
     */
    protected $sRawHeader = '';

    /**
     * ボディの生文字列
     *
     * @var string $sRawBody
     */
    protected $sRawBody = '';

    /**
     * 生文字列
     *
     * @var string $sInput
     */
    protected $sInput = '';

    /**
     * 生オプション
     *
     * @var array $aOptions
     */
    protected $aOptions = array();

    /**
     * EOL
     *
     * @var string $sEOL
     */
    protected $sEOL = "\r\n";

    /**
     * EOL長
     *
     * @var int $iEOLLen
     */
    protected $iEOLLen = 2;

    /**
     * ヘッダをデコードするか否か
     *
     * @var bool $bDecodeHeaders
     */
    protected $bDecodeHeaders = true;

    /**
     * ボディをデコードするか否か
     *
     * @var bool $bDecodeBodies
     */
    protected $bDecodeBodies = true;

    /**
     * デフォルトのContent-Type
     *
     * @var string $sDefaultContentType
     */
    protected $sDefaultContentType = 'application/octet-stream';

    /**
     * ボディを保持するか否か
     *
     * @var bool $bIncludeBodies
     */
    protected $bIncludeBodies = true;

    /**
     * 内部処理用文字コード
     *
     * @var string 内部文字コード
     */
    const INTERNAL_ENCODE = 'UTF-8';

    /**
     * トークンのタイプが値
     *
     * @var int TYPE_VALUE
     */
    const TYPE_VALUE = 0;

    /**
     * トークンのタイプがパラメータ名
     *
     * @var int TYPE_PARAM_NAME
     */
    const TYPE_PARAM_NAME = 1;

    /**
     * トークンのタイプがパラメータ値
     *
     * @var int TYPE_PARAM_VALUE
     */
    const TYPE_PARAM_VALUE = 2;

    /**
     * 境界の左文字
     *
     * @var string BOUNDARY_START
     */
    const BOUNDARY_START = '--';

    /**
     * 境界の右文字
     *
     * @var string BOUNDARY_END
     */
    const BOUNDARY_END = '--';

    /**
     * 境界の右文字長
     *
     * @var int BOUNDARY_END_LEN
     */
    const BOUNDARY_END_LEN = 2;

    /**
     * 初回のデコード処理か
     *
     * @var bool $bFirstDecode
     */
    protected $bFirstDecode = true;

    /**
     * コンストラクタ
     *
     * @param   string  $sInput     MIME解析する文字列
     * @param   array   $aOptions   MIME解析オプション
     */
    public function __construct($sInput, array $aOptions = array())
    {
        // 保持
        $this->sInput                   = (string) $sInput;
        $this->aOptions                 = (array)  $aOptions;
        // 入力チェック
        $bRetCode                       = Validate::isStringNotZero($sInput);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Input must be string');
        }
        $sCheck                         = trim($sInput);
        if ( $sCheck === '' ) {
            // 空白文字のみなら解析しない
            throw new \SC\exception\common\parameter\ZeroByteString('Input must be string');
        }
        // オプションチェック
        $this->sEOL                     = (string) ArrayUtil::getValue($this->aOptions, 'eof',              "\r\n");
        $this->iEOLLen                  = (int)    strlen($this->sEOL);
        $this->bDecodeHeaders           = (bool)   ArrayUtil::getValue($this->aOptions, 'decodeheaders',    true);
        $this->bDecodeBodies            = (bool)   ArrayUtil::getValue($this->aOptions, 'decodebodies',     true);
        $this->sDefaultContentType      = (string) ArrayUtil::getValue($this->aOptions, 'content-type',     '');
        $this->bIncludeBodies           = (bool)   ArrayUtil::getValue($this->aOptions, 'includebodies',    true);

        // MIME解析する
        $this->bFirstDecode             = true;
        $this->aStructure               = $this->_decode($this->sInput, $this->sDefaultContentType);
    }

    /**
     * 解析後の構造を返す
     *
     * @return  array   解析後の構造
     */
    public function getStructure()
    {
        return $this->aStructure;
    }

    /**
     * 生ヘッダを返す
     *
     * @return  string  生ヘッダ
     */
    public function getRawHeader()
    {
        return $this->sRawHeader;
    }

    /**
     * 生ボディを返す
     *
     * @return  string  生ボディ
     */
    public function getRawBody()
    {
        return $this->sRawBody;
    }

    /**
     * 解析前の入力文字列を返す
     *
     * @return  string  解析前の入力文字列
     */
    public function getInput()
    {
        return $this->sInput;
    }

    /**
     * 解析オプションを返す
     *
     * @return  string  解析オプション
     */
    public function getOptions()
    {
        return $this->aOptions;
    }

    /**
     * 解析オプションの改行コードを返す
     *
     * @return  string  改行コード
     */
    public function getEOL()
    {
        return $this->sEOL;
    }

    /**
     * 解析オプションのヘッダをデコードするか否かを返す
     *
     * @return  bool    ヘッダをデコードするか否か
     */
    public function getDecodeHeaders()
    {
        return $this->bDecodeHeaders;
    }

    /**
     * 解析オプションのボディをデコードするか否かを返す
     *
     * @return  bool    ボディをデコードするか否か
     */
    public function getDecodeBodies()
    {
        return $this->bDecodeBodies;
    }

    /**
     * 解析オプションのデフォルトのContent-Typeを返す
     *
     * @return  string  デフォルトのContent-Type
     */
    public function getDefaultContentType()
    {
        return $this->sDefaultContentType;
    }

    /**
     * 解析オプションのボディを保持するか否かを返す
     *
     * @return  string  ボディを保持するか否か
     */
    public function getIncludeBodies()
    {
        return $this->bIncludeBodies;
    }

    /**
     * MIMEデコードする
     *
     * @param   string  $sInput         MIME解析する文字列
     * @param   string  $sDefaultType   デフォルトのContent-Type
     * @return  array   解析後の構造
     */
    protected function _decode($sInput, $sDefaultType)
    {
        // 初回用の処理
        $bFirstDecode                       = $this->bFirstDecode;
        $this->bFirstDecode                 = false;
        // 分割
        $aSplited                           = $this->_splitHeaderAndBody($sInput);
        $sRawHeader                         = (string) $aSplited[0];
        $sRawBody                           = (string) $aSplited[1];
        if ( $bFirstDecode === true ) {
            // 初回のみ生ヘッダと生ボディを保持する
            $this->sRawHeader               = $sRawHeader;
            $this->sRawBody                 = $sRawBody;
        }

        // ヘッダの文法解析
        $aHeaders              = $this->_parseHeaders($sRawHeader);
        if ( $this->bDecodeHeaders === true ) {
            $aHeaders          = $this->_decodeHeaders($aHeaders);
        }
        // Content-Type/Content-Disposition/Content-Transfer-Encodingの抽出
        $aContentType                       = $this->_extractContentType($aHeaders, $sDefaultType);
        $aContentDisposition                = $this->_extractContentDisposition($aHeaders);
        $sContentTransferEncoding           = $this->_extractContentTransferEncoding($aHeaders);

        // ボディ解析
        $aBodyInfo                          = $this->_parseBody($sRawBody, $aContentType, $sContentTransferEncoding);
        // 構造の生成
        $aStructure                         = array(
            'content-type'                  => $aContentType,
            'content-disposition'           => $aContentDisposition,
            'content-transfer-encoding'     => $sContentTransferEncoding,
            'headers'                       => $this->_reformHeadersInfo($aHeaders),
            'body'                          => $aBodyInfo['body'],
            'parts'                         => $aBodyInfo['parts'],
        );
        return $aStructure;
    }

    /**
     * ヘッダとボディに分割
     *
     * @param   string  $sInput     MIME解析する文字列
     * @return  array   ヘッダとボディの配列
     * @throw   \SC\exception\libs\MimeDecoder\CantSplitHeaderAndBody
     */
    protected function _splitHeaderAndBody($sInput)
    {
        // 改行コードで分割
        $aSplited   = explode($this->sEOL . $this->sEOL, $sInput, 2);
        // 正常に分割できたか？
        $iCount     = count($aSplited);
        if ( $iCount < 2 ) {
            // 分割失敗
            throw new \SC\exception\libs\MimeDecoder\CantSplitHeaderAndBody("Can't split header and body");
        }
        return $aSplited;
    }

    /**
     * ヘッダを解析
     *
     * @param   string  $sRawHeader    解析対象ヘッダ
     * @return  array   ヘッダ情報配列
     */
    protected function _parseHeaders($sRawHeader)
    {
        // ヘッダが空行であれば次へ
        $sRawHeader               = trim($sRawHeader);
        if ( $sRawHeader === '' ) {
            return array();
        }
        // 変数初期化
        $aHeaders                 =  array();
        // 改行コード＋空白文字をまとめる
        $sHeaders                 = preg_replace("#[\t ]*{$this->sEOL}[\t ]+#S", ' ', $sRawHeader);
        // 改行で分割
        $aLines                   = explode($this->sEOL, $sHeaders);
        // 任意のフィールドをキーと配列に分割
        $aRawHeaders              =  array();
        foreach ( $aLines as $sLine ) {
            $aRawField            = explode(':', $sLine, 2);
            $iCount               = count($aRawField);
            if ( $iCount < 2 ) {
                $sRawName         = trim($sLine);
                $sRawValue        = $sRawName;
            } else {
                $sRawName         = trim($aRawField[0]);
                $sRawValue        = trim($aRawField[1]);
            }
            $sName                = strtolower($sRawName);
            $aHeaderValue         = $this->_parseHeaderValue($sRawName, $sRawValue);
            $bRetCode             = isset($aHeaders[$sName]);
            if ( $bRetCode !== true ) {
                $aHeaders[$sName] = array();
            }
            $aHeaders[$sName][]   = $aHeaderValue;
        }
        return $aHeaders;
    }

    /**
     * ヘッダフィールドの値を文法解析
     *
     *  戻り値配列の形式:
     *      array(
     *          'name'           => (string) 解析前ヘッダフィールド名
     *          'values'         => array(
     *              連番         => (string) 解析済みヘッダフィールド値
     *          ),
     *          'is_content'     => (bool)   Content-*か否かのフラグ
     *          'params'         => array(
     *              パラメータ名 => array(
     *                  'name'   => (string) 解析前パラメータ名
     *                  'values' => array(
     *                      連番 => (string) 解析済みパラメータ値
     *                  ),
     *              ),
     *          ),
     *          'noname'         => array(
     *              連番         => array(
     *                  'values' => array(
     *                      連番 => (string) 解析済みパラメータ値
     *                  ),
     *              ),
     *          ),
     *      )
     *
     * @param   string  $sRawName   生フィールド名
     * @param   string  $sRawValue  解析対象ヘッダフィールド値
     * @return  array   ヘッダフィールド情報配列
     */
    protected function _parseHeaderValue($sRawName, $sRawValue)
    {
        // 戻り値配列初期化
        $aRetValue                = array('name' => $sRawName );
        // フィールド名はContent-*か？
        $bIsContent               = ! (bool) strncasecmp('content-', $sRawName, 8);
        if ( $bIsContent === true ) {
            $aRetValue['values']  = array('');
        } else {
            $aRetValue['values']  = array($sRawValue);
        }
        $aRetValue['is_content']  = $bIsContent;
        $aRetValue['params']      = array();
        $aRetValue['noname']      = array();
        $aRetValue['raw']         = $sRawValue;
        $bIsCookie                = ! (bool) strcasecmp('cookie', $sRawName);
        // Content-*かCookieでなければパラメータ解析しない
        if ( $bIsContent === false && $bIsCookie === false) {
            return $aRetValue;
        }
        // ヘッダフィールドの値をトークンに分割
        $aTokenList               = $this->_splitHeaderValueToken($sRawValue);
        // 分割後に1つ以上の要素があるか？
        $iCount                   = count($aTokenList);
        if ( $iCount < 1 ) {
            return $aRetValue;
        }
        return $this->_parseHeaderValueContent($sRawName, $sRawValue, $aTokenList);
    }

    /**
     * ヘッダフィールドの値を文法解析 for Content-*
     *
     *  戻り値配列の形式:
     *      array(
     *          'name'           => (string) 解析前ヘッダフィールド名
     *          'values'         => array(
     *              連番         => (string) 解析済みヘッダフィールド値
     *          ),
     *          'is_content'     => (bool)   Content-*か否かのフラグ
     *          'params'         => array(
     *              パラメータ名 => array(
     *                  'name'   => (string) 解析前パラメータ名
     *                  'values' => array(
     *                      連番 => (string) 解析済みパラメータ値
     *                  ),
     *              ),
     *          ),
     *          'noname'         => array(
     *              連番         => array(
     *                  'values' => array(
     *                      連番 => (string) 解析済みパラメータ値
     *                  ),
     *              ),
     *          ),
     *      )
     *
     * @param   string  $sRawName   生フィールド名
     * @param   string  $sRawValue  解析対象ヘッダフィールド値
     * @param   array   $aTokenList トークン配列
     * @return  array   ヘッダフィールド情報配列
     * @throw   \SC\exception\libs\MimeDecoder\UnknownTokenType
     */
    protected function _parseHeaderValueContent($sRawName, $sRawValue, array $aTokenList)
    {
        // 要素が1つ以上ある
        // トークンを値と名前付きパラメータと名前なしパラメータに分類
        $aValues                                = array();
        $aParams                                = array();
        $aNoNames                               = array();
        $iLastIndex                             = -1;
        // トークンの数だけ繰り返し
        foreach ( $aTokenList as $aToken ) {
            // パラメータ番号を取得
            $iIndex                             = (int) $aToken['index'];
            // トークンタイプは値か？
            if ( $aToken['type'] === static::TYPE_VALUE ) {
                // 値であればストア
                $aValues[$iIndex]['values'][]   = $aToken['value'];
                continue;
            }
            // パラメータ番号が変化したか？
            if ( $iIndex !== $iLastIndex ) {
                // 変化した → 名前付き？
                if ( $aToken['type'] === static::TYPE_PARAM_NAME ) {
                    // 名前付きパラメータ
                    $sStore                     = 'aParams';
                } else {
                    // 名前なしパラメータ
                    $sStore                     = 'aNoNames';
                }
            }
            // トークンタイプはパラメータ名かパラメータ値か？
            if ( $aToken['type'] === static::TYPE_PARAM_NAME ) {
                // トークンタイプはパラメータ名
                ${$sStore}[$iIndex]['name']     = $aToken['value'];
            } else if ( $aToken['type'] === static::TYPE_PARAM_VALUE ) {
                // トークンタイプはパラメータ値
                ${$sStore}[$iIndex]['values'][] = $aToken['value'];
            } else {
                // その他のケースは存在しない
                throw new \SC\exception\libs\MimeDecoder\UnknownTokenType("Unknown token type: {$aToken['type']}");
            }
            $iLastIndex                         = $iIndex;
        }
        // 名前付きパラメータの値は引用符を除去する
        $iCount                                 = count($aParams);
        if ( $iCount > 0 ) {
            // 名前付きパラメータはRFC2231で再整形
            if ( $this->bDecodeHeaders === true ) {
                $aParams                        = $this->_reformHeaderParamsByRFC2231($aParams);
            } else {
                $aParams                        = $this->_stripQuoteForTokenParams($aParams);
            }
        }
        // フィールド値配列と名前なしパラメータは次元が多いので減らす
        $aValueList                             = array();
        foreach ( $aValues as $aEach ) {
            foreach ( $aEach['values'] as $sValue ) {
                $aValueList[]                   = $sValue;
            }
        }
        $aNoNameList                            = array();
        foreach ( $aNoNames as $aEach ) {
            foreach ( $aEach['values'] as $sNoNameValue ) {
                $aNoNameList[]                  = $sNoNameValue;
            }
        }
        // 戻り値を構成
        $aRetValue                              = array(
            'name'       => $sRawName,
            'values'     => $aValueList,
            'is_content' => true,
            'params'     => $aParams,
            'noname'     => $aNoNameList,
            'raw'        => $sRawValue,
        );
        return $aRetValue;
    }

    /**
     * ヘッダフィールドの値をトークンに分割
     *
     *  戻り値配列の形式:
     *      array(
     *          連番        => array(
     *              'type'  => (int)    static::TYPE_VALUE,
     *              'index' => (int)    0,
     *              'value' => (string) フィールド値など,
     *          ),
     *          連番        => array(
     *              'type'  => (int)    static::TYPE_PARAM_NAME,
     *              'index' => (int)    パラメータ番号(1～),
     *              'value' => (string) パラメータ名,
     *          ),
     *          連番        => array(
     *              'type'  => (int)    static::TYPE_PARAM_VALUE,
     *              'index' => (int)    パラメータ番号(1～),
     *              'value' => (string) パラメータ値など
     *          ),
     *      )
     *
     * @param   string  $sRawValue      解析対象ヘッダフィールド値
     * @return  array   分割された配列
     */
    protected function _splitHeaderValueToken($sRawValue)
    {
        // トークン分割するために特殊文字で分割
        $aRawSplited              = preg_split("#([\"();\\\\=]|[\t ]+)#S", $sRawValue, -1, PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
        // ループ終端用にパラメータ分割指定を追加
        $aRawSplited[]            = ';';
        // コメント中か判定用コメントネストレベル
        $iCommentLevel            = 0;
        // 文字列中か判定用フラグ
        $bInString                = false;
        $sSearchQuote             = '';
        // パラメータ番号
        $iParamNum                = 0;
        // トークンタイプ
        $iTokenType               = static::TYPE_VALUE;
        // ストア用
        $aTokenList               = array();
        $sString                  = '';
        $sLastChar                = '';
        // パートの数だけ繰り返し
        foreach ( $aRawSplited as $sPart ) {
            // 文字列中か否か？
            if ( $bInString === true ) {
                // 文字列終了か否か判定
                if ( $sPart === $sSearchQuote && $sLastChar !== '\\' ) {
                    // 文字列の終了
                    $bInString    = false;
                }
                // 文字列中は対応する文字が出てくるまで結合して次へ
                $sString         .= $sPart;
                $sLastChar        = $sPart;
                continue;
            }
            // コメント中か否か？
            if ( $iCommentLevel > 0 ) {
                // コメントレベルを判定
                if ( $sPart === '(' ) {
                    // 開き括弧ならレベルアップ
                    $iCommentLevel++;
                } else if ( $sPart === ')' ) {
                    // 閉じ括弧ならレベルダウン
                    $iCommentLevel--;
                }
                // コメント中は対応する閉じ括弧が出てくるまで結合して次へ
                $sString         .= $sPart;
                $sLastChar        = $sPart;
                continue;
            }
            // 文字列中でもコメント中でもない
            // 文字列開始か？
            if ( $sPart === '"' ) {
                // 文字列開始なら検索対象をセットして結合して次へ
                $bInString        = true;
                $sSearchQuote     = $sPart;
                $sString         .= $sPart;
                $sLastChar        = $sPart;
                continue;
            }
            // コメント開始か？
            if ( $sPart === '(' ) {
                // コメント開始ならレベルアップして結合して次へ
                $iCommentLevel++;
                $sString         .= $sPart;
                $sLastChar        = $sPart;
                continue;
            }
            // 先頭1文字を取得
            $sFirstChar           = substr($sPart, 0, 1);
            // 空白か？ = か？ ; か？
            if ( $sFirstChar === ' ' || $sFirstChar === "\t" ) {
                // 区切り候補 → パラメータ名中か？
                if ( $iTokenType === static::TYPE_PARAM_NAME ) {
                    // パラメータ名中の空白は区切りではない扱い
                    //   → 結合して次へ
                    $sString     .= $sPart;
                    $sLastChar    = $sPart;
                    continue;
                }
                // 空白は区切り文字
            } else if ( $sPart === '=' ) {
                // 区切り候補 → トークンタイプがパラメータ値か？
                if ( $iTokenType === static::TYPE_PARAM_VALUE ) {
                    // トークンタイプがパラメータ値である
                    //   → パラメータ名と値の区切りではない
                    //   → 結合して次へ
                    $sString     .= $sPart;
                    $sLastChar    = $sPart;
                    continue;
                }
                // パラメータ名と値の区切り
                $iTokenType = static::TYPE_PARAM_NAME;
            } else if ( $sPart === ';' ) {
                // パラメータの区切り → トークンタイプがパラメータ名か？
                if ( $iTokenType === static::TYPE_PARAM_NAME ) {
                    // パラメータ名ならパラメータ値に変更
                    $iTokenType   = static::TYPE_PARAM_VALUE;
                }
                // パラメータの区切り
            } else {
                // 区切りではない
                //   → 結合して次へ
                $sString         .= $sPart;
                $sLastChar        = $sPart;
                continue;
            }
            // 空文字であればリストしない
            if ( $sString !== '' ) {
                // トークンリストに追加
                $aTokenList[]     = array(
                    'type'  => $iTokenType,
                    'index' => $iParamNum,
                    'value' => trim($sString),
                );
            }
            // ストア文字列を初期z化
            $sString              = '';
            $sLastChar            = $sPart;
            // パラメータ区切りか？
            if ( $sPart === ';' ) {
                // 次のトークンタイプをパラメータ名に指定
                $iTokenType       = static::TYPE_PARAM_NAME;
                // パラメータ区切りならインクリメント
                $iParamNum++;
            } else {
                // トークンタイプがパラメータ名で = であるか？
                if ( $iTokenType === static::TYPE_PARAM_NAME && $sPart === '=' ) {
                    // 次のトークンタイプをパラメータ値に指定
                    $iTokenType   = static::TYPE_PARAM_VALUE;
                }
            }
        }
        return $aTokenList;
    }

    /**
     * ヘッダのパラメータをRFC2231に基づいて整形
     *
     * @param   array   整形前パラメータ
     * @return  array   整形済みパラメータ
     */
    protected function _reformHeaderParamsByRFC2231(array $aRawParams)
    {
        // パラメータの数だけ確認
        $aNormal                       = array();
        $aRFC2231                      = array();
        $aNameIndex                    = array();
        foreach ( $aRawParams as $iIndex => $aEach ) {
            // 生パラメータ名と小文字化パラメータ名を生成
            $sRawName                  = $aEach['name'];
            $sName                     = strtolower($sRawName);
            // パラメータ名をRFC2231フォーマットでマッチ
            $bRetCode                  = (bool) preg_match('#^(.+?)(\\*0|\\*[1-9][0-9]*)?(\\*)?$#S', $sRawName, $aMatches);
            $iCount                    = count($aMatches);
            if ( $bRetCode !== true || $iCount < 3 || 4 < $iCount ) {
                // マッチしない → そのまま
                $aNameIndex[$sName]    = array(
                    'index' => $iIndex,
                    'raw'   => $sRawName,
                );
                $bRetCode              = isset($aEach['values']);
                if ( $bRetCode !== true ) {
                    $aEach['values']   = array('');
                }
                $sValue                = array_shift($aEach['values']);
                $aNormal[$sName]       = array(
                    $this->_stripQuoteBothEnds($sValue),
                );
                foreach ( $aEach['values'] as $sValue ) {
                    $aNormal[$sName][] = $sValue;
                }
                continue;
            }
            // RFC2231形式
            $sRawName                  = $aMatches[1];
            $sName                     = strtolower($sRawName);
            // 番号を保持しているか？
            $bRetCode                  = isset($aNameIndex[$sName]);
            if ( $bRetCode !== true ) {
                // 保持していない → 保持
                $aNameIndex[$sName]    = array(
                    'index' => $iIndex,
                    'raw'   => $sRawName,
                );
            }
            // * 付きのシーケンスを取得
            $sNumAsterisk              = $aMatches[2];
            $iNum                      = intval(substr($sNumAsterisk, 1));
            // ヒットした数によって処理を分ける
            if ( $iCount === 3 ) {
                // RFC2231フォーマット(エンコードなし)
                $bDecode               = false;
            } else if ( $iCount === 4 ) {
                // RFC2231フォーマット(エンコードあり)
                $bDecode               = true;
            }
            // RFC2231用情報配列生成
            $bRetCode                  = isset($aRFC2231[$sName]);
            if ( $bRetCode !== true ) {
                $aRFC2231[$sName]      = array();
            }
            $aRFC2231[$sName][$iNum]   = array(
                'values' => $aEach['values'],
                'decode' => $bDecode,
            );
        }
        // RFC2231用に変換する必要がある場合にだけ変換
        $iCount                        = count($aRFC2231);
        if ( $iCount > 0 ) {
            $aRFC2231                  = $this->_reformHeaderParamByRFC2231Each($aRFC2231);
        }
        $aValues                       = array_merge($aNormal, $aRFC2231);
        $aNewParams                    = array();
        foreach ( $aNameIndex as $sName => $aEach ) {
            $iIndex                    = $aEach['index'];
            $sRawName                  = $aEach['raw'];
            $aNewParams[$sName]        = array(
                'name'   => $sRawName,
                'values' => $aValues[$sName],
            );
        }
        return $aNewParams;
    }

    /**
     * ヘッダのパラメータをRFC2231に基づいて整形(デコードなし／あり)
     *
     * @param   array   $aRFC2231   RFC2231で変換する対象の配列
     * @return  array   RFC2231で変換した配列
     */
    protected function _reformHeaderParamByRFC2231Each(array $aRFC2231)
    {
        // 各パラメータごとに繰返し
        $aNewRFC2231                         = array();
        foreach ( $aRFC2231 as $sName => $aParts ) {
            // 順番どおりになっている必要がある
            ksort($aParts);
            $sDecoded                        = '';
            $sCharset                        = '';
            // 最初のパーツはエンコード指定がある可能性あり
            $aPartKeys                       = array_keys($aParts);
            $iFirstKey                       = reset($aPartKeys);
            $paFirstValue                    = & $aParts[$iFirstKey]['values'];
            $aValueKeys                      = array_keys($paFirstValue);
            $iValueKey                       = reset($aValueKeys);
            $aValueParts                     = explode("'", $paFirstValue[$iValueKey], 3);
            $iCount                          = count($aValueParts);
            if ( $iCount === 3 ) {
                // 分割できた
                $sCharset                    = strtolower($aValueParts[0]);
                $paFirstValue[$iValueKey]    =            $aValueParts[2];
            }
            // パーツの数だけデコードしながら結合
            $aSubValues                      = array();
            foreach ( $aParts as $aEach ) {
                $sValue                      = array_shift($aEach['values']);
                $sValue                      = $this->_stripQuoteBothEnds($sValue);
                $iCount                      = count($aEach['values']);
                if ( $iCount > 0 ) {
                    $aSubValues              = array_merge($aSubValues, $aEach['values']);
                }
                if ( $aEach['decode'] === true ) {
                    $sDecoded               .= rawurldecode($sValue);
                } else {
                    $sDecoded               .= $sValue;
                }
            }
            // 文字コード指定があれば変換
            $sDecoded                        = $this->_convertMultiByteString($sDecoded, $sCharset);
            $aNewRFC2231[$sName]             = array_merge(array($sDecoded), $aSubValues);
        }
        return $aNewRFC2231;
    }

    /**
     * ヘッダのパラメータの値の両端の引用符を除去
     *
     * @param   array   整形前パラメータ
     * @return  array   整形済みパラメータ
     */
    protected function _stripQuoteForTokenParams(array $aRawParams)
    {
        // パラメータの数だけ確認
        $aValues                   = array();
        $aNameIndex                = array();
        foreach ( $aRawParams as $iIndex => $aEach ) {
            // 生パラメータ名と小文字化パラメータ名を生成
            $sRawName              = $aEach['name'];
            $sName                 = strtolower($sRawName);
            $aNameIndex[$sName]    = array(
                'index' => $iIndex,
                'raw'   => $sRawName,
            );
            $bRetCode              = isset($aEach['values']);
            if ( $bRetCode !== true ) {
                $aEach['values']   = array('');
            }
            $sValue                = array_shift($aEach['values']);
            $aValues[$sName]       = array(
                $this->_stripQuoteBothEnds($sValue),
            );
            foreach ( $aEach['values'] as $sValue ) {
                $aValues[$sName][] = $sValue;
            }
        }
        $aNewParams                = array();
        foreach ( $aNameIndex as $sName => $aEach ) {
            $iIndex                = $aEach['index'];
            $sRawName              = $aEach['raw'];
            $aNewParams[$sName]    = array(
                'name'   => $sRawName,
                'values' => $aValues[$sName],
            );
        }
        return $aNewParams;
    }


    /**
     * 両端の引用符を除去
     *
     * @param   string  $sRawValue  対象文字列
     * @return  string  除去済みの文字列
     */
    protected function _stripQuoteBothEnds($sRawValue)
    {
        // 正規表現で文字をチェック
        $bRetCode  = (bool) preg_match('#^(".*"|\'.*\')$#S', $sRawValue);
        if ( $bRetCode !== true ) {
            // ヒットしない → 除去不要
            return $sRawValue;
        }
        // 両端の引用符を除去
        $sNewValue = substr($sRawValue, 1, -1);
        // 2重引用符が含まれていたらエスケープを解除
        $sNewValue = str_replace('\"', '"', $sNewValue);

        return $sNewValue;
    }

    /**
     * ヘッダ情報をデコード
     *
     * @param   array   $aHeaders   デコード対象ヘッダ情報
     * @return  array   ヘッダ情報配列
     */
    protected function _decodeHeaders(array $aHeaders)
    {
        // ヘッダの数だけ繰返し
        $aNewHeaders                        = array();
        foreach ( $aHeaders as $sName => $aEachHeaders ) {
            $aNewHeaders[$sName]            = array();
            foreach ( $aEachHeaders as $iNum => $aEach ) {
                // 通常のヘッダのデコードを行う
                $aDecoded                   = $this->_decodeEachHeaderNormal($aEach);
                // Content-*か？
                if ( $aEach['is_content'] === true ) {
                    // Content-*のヘッダのデコードを行う
                    $aDecoded               = $this->_decodeEachHeaderContent($aDecoded);
                }
                $aNewHeaders[$sName][$iNum] = $aDecoded;
            }
        }
        return $aNewHeaders;
    }

    /**
     * ヘッダのContent-*の1フィールドをデコード
     *
     * @param   array   $aRawEachHeader     デコード対象ヘッダの1フィールド情報
     * @return  array   ヘッダの1フィールド情報配列
     */
    protected function _decodeEachHeaderContent(array $aEachHeader)
    {
        // 名前付きパラメータをデコード
        $aParams               = array();
        foreach ( $aEachHeader['params'] as $sName => $aEach ) {
            $aParams[$sName]   = $this->_decodeEachHeaderNormal($aEach);
        }
        $aEachHeader['params'] = $aParams;
        // 名前なしパラメータをデコード
        $aParams               = array( 'values' => $aEachHeader['noname'] );
        $aDecoded              = $this->_decodeEachHeaderNormal($aParams);
        $aEachHeader['noname'] = $aDecoded['values'];
        return $aEachHeader;
    }

    /**
     * ヘッダの通常の1フィールドをデコード
     *
     * @param   array   $aRawEachHeader     デコード対象ヘッダの1フィールド情報
     * @return  array   ヘッダの1フィールド情報配列
     */
    protected function _decodeEachHeaderNormal(array $aEachHeader)
    {
        // 値をデコード
        $aValues               = array();
        foreach ( $aEachHeader['values'] as $sValue ) {
            $aValues[]         = $this->_decodeHeaderValue($sValue);
        }
        $aEachHeader['values'] = $aValues;
        return $aEachHeader;
    }

    /**
     * ヘッダ値を分割してMIMEデコード
     *
     * @param   string  $sRawValue  デコード対象ヘッダ値
     * @return  string  MIMEデコード済みヘッダ値
     */
    protected function _decodeHeaderValue($sRawValue)
    {
        // デコード対象部分かどうかで分割
        $aRawSplited               = preg_split('#(=\?.*?\?=)#S', $sRawValue, -1, PREG_SPLIT_DELIM_CAPTURE|PREG_SPLIT_NO_EMPTY);
        // デコード対象文字列別に処理
        $aSplited                  = array();
        $aDecoded                  = array();
        $aFWSs                     = array();
        foreach ( $aRawSplited as $iIndex => $sPart ) {
            // デコード対象部分か判定
            $sLeftChars            = substr($sPart,  0, 2);
            $sRightChars           = substr($sPart, -2, 2);
            if ( $sLeftChars !== '=?' || $sRightChars !== '?=' ) {
                // デコード対象ではない
                $aSplited[$iIndex] = $sPart;
                $aDecoded[$iIndex] = false;
            } else {
                // デコード対象部分についてはデコードを行う
                $sEncodedWord      = substr($sPart, 2, -2);
                $aSplited[$iIndex] = $this->_decodeStringMIME($sEncodedWord);
                $aDecoded[$iIndex] = true;
            }
            // 空白パートかどうか判定
            if ( $sPart === ' ' ) {
                // 空白パートは無視対象の可能性あり
                // 先頭と末尾には空白は無い(＝trim済みであることを想定)
                $aFWSs[]           = $iIndex;
            }
        }
        // デコード対象部分間の空白は無視する必要があるため抹消
        foreach ( $aFWSs as $iIndex ) {
            // 先頭と末尾に空白は無い前提なので前後を判定
            if ( $aDecoded[$iIndex-1] !== true || $aDecoded[$iIndex+1] !== true ) {
                // 前または後がデコード対象文字列ではない → なにもしない
                continue;
            }
            // 前後がMIMEデコード対象の空白は除去
            unset($aSplited[$iIndex]);
        }
        // デコード済み文字列を結合
        $sNewValue = join('', $aSplited);
        return $sNewValue;
    }

    /**
     * MIMEデコード (encoded-word → 先頭の =? と末尾の ?= はない)
     *
     * @param   string  $sEncodedWord   MIMEデコード対象文字列
     * @return  string  MIMEデコード済み文字列
     * @throw   \SC\exception\libs\MimeDecoder\UnknownMIMEEncoding
     */
    protected function _decodeStringMIME($sEncodedWord)
    {
        // ? で分割
        $aRawSplited         = explode('?', $sEncodedWord, 3);
        // 情報収集
        $iCount              = count($aRawSplited);
        if ( $iCount !== 3 ) {
            // エンコード方式は不明 → 分割失敗
            throw new \SC\exception\libs\MimeDecoder\UnknownMIMEEncoding("Unknown encoding for '$sEncodedWord'");
        }
        $sCharset            = strtolower($aRawSplited[0]);
        $sEncoding           = strtolower($aRawSplited[1]);
        $sEncodedText        =            $aRawSplited[2];
        if ( $sEncoding === 'b' ) {
            // エンコード方式はBASE64
            $sDecodeFunction = 'base64_decode';
        } else if ( $sEncoding === 'q' ) {
            // エンコード方式はQuoted-Printable
            $sDecodeFunction = 'quoted_printable_decode';
        } else {
            // エンコード方式は不明 → 分割失敗
            throw new \SC\exception\libs\MimeDecoder\UnknownMIMEEncoding("Unknown encoding: '{$sEncoding}' for '$sEncodedWord'");
        }
        // デコード
        $sDecoded            = $sDecodeFunction($sEncodedText);
        // 文字コード変換
        $sDecoded            = $this->_convertMultiByteString($sDecoded, $sCharset);
        return $sDecoded;
    }

    /**
     * 文字コードを内部指定コードに揃える
     *
     * @param   string  $sRawValue      変換対象文字列
     * @param   string  $sCharset       文字コード
     * @return  string  変換済み文字列
     */
    protected function _convertMultiByteString($sRawValue, $sCharset)
    {
        // デコード済みの文字列の文字コードを変換(charsetパラメータは大文字小文字無視)
        $sInternalEncode  = strtolower(static::INTERNAL_ENCODE);
        switch ( $sCharset ) {
            case 'ascii':
            case 'us-ascii':
            case $sInternalEncode:
                // 文字コードはASCIIであるか，PHPの内部指定の文字コードと同じなので変換は行わない
                $sDecoded = $sRawValue;
                break;

            case 'euc-jp':
            case 'shift_jis':
            case 'iso-2022-jp':
            case 'jis':
            case 'utf-8':
            case 'utf-7':
            case 'sjis':
                // 日本語として可能な文字コードを内部指定の文字コードへ変換する
                $sDecoded = Util::mb_convert_encoding($sRawValue, $sInternalEncode, $sCharset);
                break;

            default:
                // 不明な文字コードなので変換しない
                $sDecoded = $sRawValue;
                break;
        }
        return $sDecoded;
    }

    /**
     * ボディを解析
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBody($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // See: RFC2046
        // Prmary    of Content-Type: text, image, audio, video, application, multipart, message
        $sPrimary     = ucfirst($aContentType['primary']);
        $sParser      = __FUNCTION__ . $sPrimary;
        $bRetCode     = method_exists($this, $sParser);
        if ( $bRetCode !== true || $sParser === __FUNCTION__ ) {
            // Content-Typeのパターンが想定外であればapplication/octet-streamとして扱うべき
            $sParser  = __FUNCTION__ . 'Application';
        }
        $aBodyInfo    = $this->$sParser($sRawBody, $aContentType, $sContentTransferEncoding);
        return $aBodyInfo;
    }

    /**
     * ボディを解析 for text/*
     *
     * See: RFC2046 Sec.4.1
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyText($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // ボディを含むか？
        if ( $this->bIncludeBodies !== true ) {
            return $this->_getEmptyBody();
        }
        // See: RFC2046 Sec.4.1.4
        // textタイプはcharsetパラメータが認識できなければapplication/octet-streamとして扱うべき
        // charsetの有効性を検証
        if ( $aContentType['charset'] === '' ) {
            // charsetの指定が無い → application/octet-stream
            return $this->_parseBodyApplication($sRawBody, $aContentType, $sContentTransferEncoding);
        }
        // テキストボディの文字コード指定(全て小文字)
        $aRecognizableCharset = array(
            'utf-8'       => true,
            'euc-jp'      => true,
            'shift_jis'   => true,
            'sjis'        => true,
            'ascii'       => true,
            'utf-7'       => true,
            'us-ascii'    => true,
            'iso-2022-jp' => true,
            'jis'         => true,
        );
        $sCharset      = strtolower($aContentType['charset']);
        $bRetCode      = isset($aRecognizableCharset[$sCharset]);
        if ( $bRetCode !== true ) {
            // 認識不可能なcharset → application/octet-stream
            return $this->_parseBodyApplication($sRawBody, $aContentType, $sContentTransferEncoding);
        }
        // charsetが有効であるならば text/plain として扱うべし
        // See: RFC2046 Sec.4.1.3
        return $this->_decodeBodyNormally($sRawBody, $aContentType, $sContentTransferEncoding);
    }

    /**
     * ボディを解析 for image/*
     *
     * See: RFC2046 Sec.4.2
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyImage($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // ボディを含むか？
        if ( $this->bIncludeBodies !== true ) {
            return $this->_getEmptyBody();
        }
        // 通常のボディとしてデコード
        return $this->_decodeBodyNormally($sRawBody, $aContentType, $sContentTransferEncoding);
    }

    /**
     * ボディを解析 for audio/*
     *
     * See: RFC2046 Sec.4.3
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyAudio($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // ボディを含むか？
        if ( $this->bIncludeBodies !== true ) {
            return $this->_getEmptyBody();
        }
        // 通常のボディとしてデコード
        return $this->_decodeBodyNormally($sRawBody, $aContentType, $sContentTransferEncoding);
    }

    /**
     * ボディを解析 for video/*
     *
     * See: RFC2046 Sec.4.4
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyVideo($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // ボディを含むか？
        if ( $this->bIncludeBodies !== true ) {
            return $this->_getEmptyBody();
        }
        // 通常のボディとしてデコード
        return $this->_decodeBodyNormally($sRawBody, $aContentType, $sContentTransferEncoding);
    }

    /**
     * ボディを解析 for application/*
     *
     * See: RFC2046 Sec.4.5
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyApplication($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // ボディを含むか？
        if ( $this->bIncludeBodies !== true ) {
            return $this->_getEmptyBody();
        }
        // 通常のボディとしてデコード
        return $this->_decodeBodyNormally($sRawBody, $aContentType, $sContentTransferEncoding);
    }

    /**
     * ボディを解析 for multipart/*
     *
     * See: RFC2046 Sec.5.1
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyMultipart($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // マルチパートはboundaryパラメータが必須
        if ( $aContentType['boundary'] === '' ) {
            // 境界がないもしくは空文字であれば分割不能 → application/octet-stream
            return $this->_parseBodyApplication($sRawBody, $aContentType, $sContentTransferEncoding);
        }
        // multipart/digest であればデフォルトのContent-Typeは message/rfc822
        // See: RFC2046 Sec.5.1.5
        if ( $aContentType['secondary'] === 'digest' ) {
            $sDefaultType     = 'message/rfc822';
        } else {
            $sDefaultType     = '';
        }
        // 境界で分割
        $aParts               = $this->_splitBodyByBoundary($sRawBody, $aContentType['boundary']);
        // 通常のボディとしてデコード
        $aNewParts            = array();
        foreach ( $aParts as $sNewPart ) {
            // ヘッダがあるかどうか判定
            if ( $sNewPart === '' ) {
                // ヘッダもボディも無い → 先頭に改行を追加
                $sNewPart     = $this->sEOL . $this->sEOL;
            } else {
                $iCmp         = strncmp($this->sEOL, $sNewPart, $this->iEOLLen);
                if ( $iCmp === 0 || $sNewPart === '' ) {
                    // ヘッダが無い → ボディのみ → 先頭に改行を追加
                    $sNewPart = $this->sEOL . $sNewPart;
                }
            }
            $aNewParts[]      = $this->_decode($sNewPart, $sDefaultType);
        }
        $aBodyInfo            = array(
            'body'  => '',
            'parts' => $aNewParts,
        );
        return $aBodyInfo;
    }

    /**
     * ボディを解析 for message/*
     *
     * See: RFC2046 Sec.5.2
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyMessage($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // セカンダリメディアタイプがrfc822かどうか？
        if ( $aContentType['secondary'] !== 'rfc822' ) {
            // rfc822でなければ認識不能なボディとして処理 → application/octet-stream
            return $this->_parseBodyApplication($sRawBody, $aContentType, $sContentTransferEncoding);
        }
        // rfc822であればmessage/rfc822としてパース
        return $this->_parseBodyMessageRfc822($sRawBody, $aContentType, $sContentTransferEncoding);
    }

    /**
     * ボディを解析 for message/rfc822
     *
     * See: RFC2046 Sec.5.2.1
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _parseBodyMessageRfc822($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        // 通常のボディとしてデコード
        $aBodyInfo = array(
            'body'  => '',
            'parts' => array( $this->_decode($sRawBody, '') ),
        );
        return $aBodyInfo;
    }

    /**
     * 生ボディを分割 for multipart/*
     *
     * See: RFC2046 Sec.5.1.1
     *
     * @param   string  $sRawBody       分割対象生ボディ
     * @param   string  $sRawBoundary   境界
     * @return  array   分割したボディ
     * @throw   \SC\exception\libs\MimeDecoder\CantFindEndOfLine
     */
    protected function _splitBodyByBoundary($sRawBody, $sRawBoundary)
    {
        // 境界候補の存在確認
        $aParts                   = array();
        // 生ボディの末尾に改行コードがなければ付加
        $sLastChar                = substr($sRawBody, -$this->iEOLLen);
        if ( $sLastChar !== $this->sEOL ) {
            // 改行コードが無い
            $sRawBody            .= $this->sEOL;
        }
        $sBoundary                = static::BOUNDARY_START . $sRawBoundary;
        $iLenBoundary             = strlen($sBoundary);
        $iBoundaryPos             = strpos($sRawBody, $sBoundary);
        // 最初の境界の前になにか文字があれば除去
        if ( $iBoundaryPos > 0 ) {
            $sRawBody             = substr($sRawBody, $iBoundaryPos);
            $iBoundaryPos         = strpos($sRawBody, $sBoundary);
        }
        // 境界があるまで繰返し
        $bGoodEnd                 = false;
        $iPlusPos                 = 0;
        while ( $iBoundaryPos !== false && $bGoodEnd !== true ) {
            $iNextPos             = $iBoundaryPos + $iLenBoundary;
            // 境界候補あり
            if ( 0 < $iBoundaryPos && $iBoundaryPos < $this->iEOLLen ) {
                // 境界候補の前に何か文字列がある → 境界ではない
                $iBoundaryPos     = strpos($sRawBody, $sBoundary, $iNextPos);
                continue;
            }
            // 先頭か？
            if ( $iBoundaryPos !== 0 ) {
                // 先頭でなければ前の文字チェック
                $sLeftChars       = substr($sRawBody, $iBoundaryPos-$this->iEOLLen, $this->iEOLLen);
                if ( $sLeftChars !== $this->sEOL ) {
                    // 境界候補が行頭から始まっていない → 境界ではない
                    $iBoundaryPos = strpos($sRawBody, $sBoundary, $iNextPos);
                    continue;
                }
            }
            // 改行検索
            $iLineEndPos          = strpos($sRawBody, $this->sEOL, $iNextPos);
            if ( $iLineEndPos === false ) {
                // 改行が発見されないケースは存在しないはず → エラー
                throw new \SC\exception\libs\MimeDecoder\CantFindEndOfLine("Can't find EOL in raw body");
            }
            $sRightChars          = substr($sRawBody, $iNextPos, $iLineEndPos-$iNextPos);
            $sTrimed              = rtrim($sRightChars, " \t");
            if ( $sTrimed === static::BOUNDARY_END ) {
                // 最後の境界候補は -- で終わる
                $bGoodEnd         = true;
                $iPlusPos         = static::BOUNDARY_END_LEN;
            } else if ( $sTrimed !== '' ) {
                // 境界候補の末尾は空白文字ではないなにか → 境界ではない
                $iBoundaryPos     = strpos($sRawBody, $sBoundary, $iNextPos);
                continue;
            }
            // 境界だった
            $sPrevPart            = substr($sRawBody, 0, $iBoundaryPos);
            if ( $sPrevPart !== '' ) {
                // 末尾に改行コードがあれば除去
                $sLastChar        = substr($sPrevPart, -$this->iEOLLen);
                if ( $sLastChar === $this->sEOL ) {
                    // 改行コードが無い
                    $sPrevPart    = substr($sPrevPart, 0, -$this->iEOLLen);
                }
                $aParts[]         = $sPrevPart;
            }
            $sRawBody             = substr($sRawBody, $iLineEndPos + $this->iEOLLen + $iPlusPos);
            // 次の境界を探す
            $iBoundaryPos         = strpos($sRawBody, $sBoundary);
        }
        if ( $bGoodEnd !== true && $sRawBody !== false ) {
            // 末尾に改行コードがあれば除去
            $sLastChar            = substr($sRawBody, -$this->iEOLLen);
            if ( $sLastChar === $this->sEOL ) {
                // 改行コードが無い
                $sRawBody         = substr($sRawBody, 0, -$this->iEOLLen);
            }
            $aParts[]             = $sRawBody;
        }
        return $aParts;
    }

    /**
     * ボディを含まない状態の情報配列
     *
     * @return  array   ボディを含まない情報配列
     */
    protected function _getEmptyBody()
    {
        // 結果配列を生成
        $aBodyInfo = array(
            'body'  => '',
            'parts' => array(),
        );
        return $aBodyInfo;
    }

    /**
     * ボディを解析 for 通常
     *
     * See: RFC2045 Sec.6
     *
     * @param   string  $sRawBody                   生ボディ
     * @param   array   $aContentType               Content-Type情報
     * @param   string  $sContentTransferEncoding   Content-Transfer-Encoding情報
     * @return  array   ボディ情報配列
     */
    protected function _decodeBodyNormally($sRawBody, array $aContentType, $sContentTransferEncoding)
    {
        $aBodyInfo                 = array();
        // デコードが不要ならそのまま
        if ( $this->bDecodeBodies !== true ) {
            // 結果配列を生成
            $aBodyInfo['body']     = $sRawBody;
        } else {
            // エンコード方式に基づいて本文をデコード
            // See: RFC2045 Sec.6.1
            // エンコード方式を判定
            $sEncoding             = strtolower($sContentTransferEncoding);
            if ( $sEncoding === 'base64' ) {
                // エンコード方式はBASE64
                $aBodyInfo['body'] = base64_decode($sRawBody);
            } else if ( $sEncoding === 'quoted-printable' ) {
                // エンコード方式はQuoted-Printable
                $aBodyInfo['body'] = quoted_printable_decode($sRawBody);
            } else {
                // エンコード方式はその他 → デコードしない
                $aBodyInfo['body'] = $sRawBody;
            }
        }
        // パーツを保持
        $aBodyInfo['parts']        = array();
        return $aBodyInfo;
    }

    /**
     * Content-Typeの情報を配列として取得
     *
     * @param   array   $aHeaders       解析済みヘッダ情報
     * @param   string  $sDefaultType   デフォルトのContent-Type
     * @return  array   Content-Typeの情報配列
     */
    protected function _extractContentType(array $aHeaders, $sDefaultType = '')
    {
        // Content-Typeのデフォルトメディアタイプの指定
        $aContentTypeSecondary = array(
            'text'        => 'plain',
            'image'       => 'jpeg',
            'audio'       => 'base',
            'video'       => 'mpeg',
            'application' => 'octet-stream',
            'multipart'   => 'mixed',
            'message'     => 'rfc822',
        );
        // Content-Typeを取得
        $sContentType               = '';
        $aAllParams                 = array();
        $aRawParams                 = array();
        $aParams                    = array(
            'boundary' => array( 'values' => array( '' )),
            'charset'  => array( 'values' => array( '' )),
            'name'     => array( 'values' => array( '' )),
        );
        $sRawContentType            = '';
        $bRetCode                   = isset($aHeaders['content-type'][0]['values'][0]);
        if ( $bRetCode === true ) {
            // ヘッダにContent-Typeがある → 上書き
            $sContentType           = trim($aHeaders['content-type'][0]['values'][0]);
            $aAllParams             = $aHeaders['content-type'];
            $aRawParams             = $aHeaders['content-type'][0]['params'];
            $aParams                = ArrayUtil::unite($aParams, $aRawParams, true);
            $sRawContentType        = $aHeaders['content-type'][0]['raw'];
        }
        if ( $sContentType === '' ) {
            // ヘッダにContent-Typeがない → デフォルトを仮定
            $sContentType           = trim($sDefaultType);
        }
        if ( $sContentType === '' ) {
            // それでもない → application/octet-stream
            $sContentType           = 'application/octet-stream';
        }
        // Content-Typeの有効化
        $aParts                     = explode('/', $sContentType, 2);
        $iCount                     = count($aParts);
        if ( $iCount === 2 ) {
            $sPrimary               = strtolower(trim($aParts[0]));
            $sSecondary             = strtolower(trim($aParts[1]));
        } else {
            $sPrimary               = strtolower($sContentType);
            $sSecondary             = '';
        }
        $bRetCode                   = isset($aContentTypeSecondary[$sPrimary]);
        if ( $bRetCode !== true ) {
            // 無効なタイプ → application/octet-stream
            $sContentType           = 'application/octet-stream';
            $sPrimary               = 'application';
            $sSecondary             = 'octet-stream';
        } else {
            if ( $sSecondary === '' ) {
                // サブタイプの指定が空 → 修正の必要あり
                $sSecondary         = $aContentTypeSecondary[$sPrimary];
            }
        }
        // プライマリ指定によって分岐
        if ( $sPrimary === 'text' ) {
            // text/*のみcharset補正を入れる
            if ( $aParams['charset']['values'][0] === '' ) {
                // See: RFC2046 Sec.4.1
                // Content-Typeのプライマリメディアタイプがtextの場合には，charsetパラメータが
                // あるべきで，ない場合にはデフォルトとしてUS-ASCIIを指定する．
                // → これによりcharsetが指定されていない状況は存在しない
                $aParams['charset'] = array(
                    'name'   => 'charset',
                    'values' => array(strtolower('us-ascii')),
                );
            }
        }
        // Content-Type情報
        $aContentType               = array(
            'value'             => $sContentType,
            'primary'           => $sPrimary,
            'secondary'         => $sSecondary,
            'boundary'          => $aParams['boundary']['values'][0],
            'charset'           => $aParams['charset']['values'][0],
            'name'              => $aParams['name']['values'][0],
            'parameters'        => $this->_reduceHeaderFieldsParametersRank($aAllParams),
            'raw'               => $sRawContentType,
        );
        return $aContentType;
    }

    /**
     * Content-Dispositionの情報を配列として取得
     *
     * @param   array   $aHeaders   解析済みヘッダ情報
     * @return  array   Content-Dispositionの情報配列
     */
    protected function _extractContentDisposition(array $aHeaders)
    {
        // 初期化
        $aDisposition                 = array(
            'value'      => '',
            'name'       => '',
            'filename'   => '',
            'parameters' => array(),
            'raw'        => '',
        );
        // ヘッダ中にContent-Dispositionフィールドがあるか否か
        $bRetCode                     = isset($aHeaders['content-disposition']);
        if ( $bRetCode !== true ) {
            // ヘッダ中に無い場合には指定なしを仮定
            return $aDisposition;
        }
        // ヘッダ中にある場合には解析
        $bRetCode                     = isset($aHeaders['content-disposition'][0]['values'][0]);
        if ( $bRetCode === true ) {
            $sDispositionValue        = trim(strtolower($aHeaders['content-disposition'][0]['values'][0]));
            unset($aHeaders['content-disposition'][0]['values'][0]);
        } else {
            $sDispositionValue        = '';
        }
        if ( $sDispositionValue === '' ) {
            // 指定があっても空文字ではなしと仮定
            return $aDisposition;
        }
        // アクセスしやすいように別名をつける
        $aAllParams                   = $aHeaders['content-disposition'];
        // ヘッダ中にある場合には解析
        $aDisposition['value']        = $sDispositionValue;
        // 名前があれば抽出
        $aValue                       = ArrayUtil::getValue($aAllParams[0]['params'], 'name',     array('values' => array('')));
        $aDisposition['name']         = $aValue['values'][0];
        // 添付ファイル名指定があれば抽出
        $aValue                       = ArrayUtil::getValue($aAllParams[0]['params'], 'filename', array('values' => array('')));
        $aDisposition['filename']     = $aValue['values'][0];
        // パラメータをマージ
        $aDisposition['parameters']   = $this->_reduceHeaderFieldsParametersRank($aAllParams);
        // 生データを保持
        $aDisposition['raw']          = $aAllParams[0]['raw'];
        return $aDisposition;
    }

    /**
     * Content-Transfer-Encodingの情報を文字列として取得
     *
     * @param   array   $aHeaders   解析済みヘッダ情報
     * @return  string  Content-Transfer-Encodingの情報文字列
     */
    protected function _extractContentTransferEncoding(array $aHeaders)
    {
        // ヘッダ中にContent-Dispositionフィールドがあるか否か
        $bRetCode          = isset($aHeaders['content-transfer-encoding'][0]['values'][0]);
        if ( $bRetCode !== true ) {
            // ヘッダ中に無い場合には 7bit と仮定
            // See: RFC2045 Sec.6.1
            return '7bit';
        }
        // ヘッダ中にある場合には解析
        $sTransferEncoding = trim($aHeaders['content-transfer-encoding'][0]['values'][0]);
        if ( $sTransferEncoding === '' ) {
            // ヘッダ中に無い場合には 7bit と仮定
            // See: RFC2045 Sec.6.1
            return '7bit';
        }
        return $sTransferEncoding;
    }

    /**
     * ヘッダフィールドの生パラメータ情報を1次元配列に変換
     *
     * @param   array   $aRawParameters     生パラメータ情報
     * @return  array   1次元パラメータ配列
     */
    protected function _reduceHeaderFieldsParametersRank(array $aRawParameters)
    {
        // パラメータをマージ
        $aAllParams                 = array();
        foreach ( $aRawParameters as $aEach ) {
            // 余剰の値は無名のパラメータ扱い
            foreach ( $aEach['values'] as $sValue ) {
                $aAllParams[]       = $sValue;
            }
            // 名前付きパラメータは生パラメータを使用して
            // 値の1つ目を引用符で括って，2つ目以降をFWSで単純結合
            foreach ( $aEach['params'] as $sName => $aParamInfo ) {
                $sRawName           = $aParamInfo['name'];
                $aAllParams[$sName] = $this->_joinWithQuote($aParamInfo['values'], false);
            }
            // 名前なしパラメータは単純増加
            foreach ( $aEach['noname'] as $sValue ) {
                $aAllParams[]       = $sValue;
            }
        }
        return $aAllParams;
    }

    /**
     * 出力の形式に変換
     *
     *  引数配列の形式:
     *      array(
     *          フィールド名                => array(
     *              連番                    => array(
     *                  'name'              => (string) 解析前ヘッダフィールド名
     *                  'values'            => array(
     *                      連番            => (string) 解析済みヘッダフィールド値
     *                  ),
     *                  'is_content'        => (bool)   Content-*か否かのフラグ
     *                  'params'            => array(
     *                      パラメータ名    => array(
     *                          'name'      => (string) 解析前パラメータ名
     *                          'values'    => array(
     *                              連番    => (string) 解析済みパラメータ値
     *                          ),
     *                      ),
     *                  ),
     *                  'noname'            => array(
     *                      連番            => array(
     *                          'values'    => array(
     *                              連番    => (string) 解析済みパラメータ値
     *                          ),
     *                      ),
     *                  ),
     *              ),
     *          ),
     *      );
     *
     *  戻り値配列の形式(フィールド名は小文字):
     *      array(
     *          フィールド名(単一)          => (string) 解析済み単一ヘッダフィールド値とパラメータ構成,
     *          フィールド名(複数)          => array(
     *              連番                    => (string) 解析済み複数ヘッダフィールド値とパラメータ構成,
     *          ),
     *      );
     *
     * @param   array   $aHeaders       解析済みヘッダ情報
     * @param   bool    $bUseLowerName  フィールド名として小文字を採用するか否か
     * @return  array   出力形式の配列
     */
    protected function _reformHeadersInfo(array $aHeaders, $bUseLowerName = true)
    {
        // フィールド名の指定として小文字を採用するか否か
        if ( $bUseLowerName !== false ) {
            // 採用する
            $sKeyName                    = 'sName';
        } else {
            // 採用しない → 生フィールド名を使用する
            $sKeyName                    = 'sRawName';
        }
        // フィールドの種類だけ繰返し
        $aNewHeaders                     = array();
        foreach ( $aHeaders as $sName => $aEachHeaders ) {
            // 生フィールド名を指定
            $sRawName                    = $sName;
            // 各指定の数だけ繰り返し
            $aInfo                       = array();
            foreach ( $aEachHeaders as $aEach ) {
                // 生フィールド名があれば取得
                $sRawName                = $aEach['name'];
                // 指定を文字列にパック
                if ( $aEach['is_content'] === true ) {
                    // Content-*はパック方式が特殊
                    $aInfo[]             = $this->_reformHeadersInfoContent($aEach);
                } else {
                    // その他のフィールドは必ず values に1つだけ入っている
                    $aInfo[]             = $aEach['values'][0];
                }
            }
            $iCount                      = count($aInfo);
            if ( $iCount < 2 ) {
                // 単数 → 文字列へ変換
                $aNewHeaders[$$sKeyName] = reset($aInfo);
            } else {
                // 複数 → 配列のまま
                $aNewHeaders[$$sKeyName] = $aInfo;
            }
        }
        return $aNewHeaders;
    }

    /**
     * 出力の形式に変換 for Content-*
     *
     *  引数配列の形式:
     *      array(
     *          'name'              => (string) 解析前ヘッダフィールド名
     *          'values'            => array(
     *              連番            => (string) 解析済みヘッダフィールド値
     *          ),
     *          'is_content'        => (bool)   Content-*か否かのフラグ
     *          'params'            => array(
     *              パラメータ名    => array(
     *                  'name'      => (string) 解析前パラメータ名
     *                  'values'    => array(
     *                      連番    => (string) 解析済みパラメータ値
     *                  ),
     *              ),
     *          ),
     *          'noname'            => array(
     *              連番            => array(
     *                  'values'    => array(
     *                      連番    => (string) 解析済みパラメータ値
     *                  ),
     *              ),
     *          ),
     *      );
     *
     * @param   array   $aEachHeader    解析済みヘッダフィールド情報
     * @return  string  ヘッダフィールド文字列
     */
    protected function _reformHeadersInfoContent(array $aEachHeader)
    {
        // パラメータ配列
        $aParams       = array();
        $aParams[]     = $this->_joinWithQuote($aEachHeader['values'], false);
        // 名前付きパラメータ情報
        foreach ( $aEachHeader['params'] as $aInfo ) {
            $sName     = $aInfo['name'];
            $sValue    = $this->_joinWithQuote($aInfo['values'], true);
            $aParams[] = "{$sName}={$sValue}";
        }
        // 名前なしパラメータは単純増加
        foreach ( $aEachHeader['noname'] as $sValue ) {
            $aParams[] = $sValue;
        }
        $sParamValue   = join('; ', $aParams);
        return $sParamValue;
    }

    /**
     * 第一引数のみ引用符を付加して全て結合
     *
     * @param   array   $aValues        結合対象配列
     * @param   bool    $bForceQuote    配列の要素が1つの場合でも引用符を付加するか否か
     * @param   string  $sGlue          グルー
     * @param   string  $sQuote         引用符
     * @return  string  結合済み文字列
     */
    protected function _joinWithQuote(array $aValues, $bForceQuote = false, $sGlue = ' ', $sQuote = '"')
    {
        // 要素が無ければ空文字を返す
        $iCount             = count($aValues);
        if ( $iCount < 1 ) {
            return '';
        }
        // 要素が一つの場合にはそのまま返す
        if ( $bForceQuote === false ) {
            if ( $iCount < 2 ) {
                $sRetString = reset($aValues);
                return $sRetString;
            }
        }
        // 値のパース
        $sValue         = array_shift($aValues);
        $aAllValues     = $aValues;
        if ( $sValue !== '' ) {
            $sValue     = str_replace('"', '\"', $sValue);
            array_unshift($aAllValues, "{$sQuote}{$sValue}{$sQuote}");
        }
        // パラメータ配列
        $sRetString     = join($sGlue, $aAllValues);
        return $sRetString;
    }
}
