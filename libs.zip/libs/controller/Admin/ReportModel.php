<?php
/**
 * レポートモデルコントローラ
 *
 * @copyright   (C) 2013 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * レポートモデルコントローラ
 */
class ReportModel extends StaticModel
{
    /**
     * ユーザ
     *
     * @var SC\model\user $oUser
     */
    protected $oUser = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        return parent::_process();
    }
}
