<?php
/**
 * ログインモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ログインモデルコントローラ
 */
class LoginModel extends AbstractJSONModel
{
    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログイン済みかどうか
        if ( $this->oLogin->isLogin() === true ) {
            // ログイン済みなら抜ける
            return parent::_process();
        }

        $sAccount  = $this->oRequest->getRequest('accountname', '');
        $sPassword = $this->oRequest->getRequest('accountpass', '');

        // validation
        if ( $sAccount === NULL || $sAccount === '' ) {
            $this->bHasError   = true;
            $this->sErrMessage = "アカウント名を入力してください。";
        } else if ( $sPassword === NULL || $sPassword === '' ) {
            $this->bHasError   = true;
            $this->sErrMessage = "パスワードを入力してください。";
        } else {
            $bRetCode = $this->oLogin->login($sAccount, $sPassword);
            if ( $bRetCode === false ) {
                $this->bHasError   = true;
                $this->sErrMessage = "アカウント名かパスワードが間違っています。";
            }
        }

        return parent::_process();
    }
}
