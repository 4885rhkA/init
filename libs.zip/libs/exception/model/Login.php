<?php
/**
 * Loginの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\model;

/**
 * Loginの例外
 */
class Login extends \SC\exception\model
{
}
