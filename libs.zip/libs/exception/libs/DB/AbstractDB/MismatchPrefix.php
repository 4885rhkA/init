<?php
/**
 * 接頭辞が誤っている場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\DB\AbstractDB;

/**
 * 接頭辞が誤っている場合の例外
 */
class MismatchPrefix extends \SC\exception\libs\DB\AbstractDB
{
}
