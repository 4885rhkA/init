<?php
/**
 * Http
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Http
 *
 * シングルトンではないが静的にコールした場合には常に同一のインスタンス
 */
class Http
{
    /**
     * 有効なHTTP接続メソッド
     *
     * @var array $aValidHTTPMethods
     */
    protected static $aValidHTTPMethods  = array(
        'GET',
        'POST',
        'PUT',
        'DELETE',
        'HEAD',
    );

    /**
     * ユーザエージェントヘッダフィールド
     *
     * @var string DEFAULT_UA
     */
    const DEFAULT_UA = 'Mozilla/5.0 (Linux; U; Android 1.5; ja-jp; HT-03A Build/CDB72) AppleWebKit/528.5+ (KHTML, like Gecko) Version/3.1.2 Mobile Safari/525.20.1';

    /**
     * 接続タイムアウト
     *
     * @var int TIMEOUT
     */
    const TIMEOUT = 60;

    /**
     * 接続タイムアウト最大値
     *
     * @var int TIMEOUT_MAX
     */
    const TIMEOUT_MAX = 600;

    /**
     * 接続タイムアウト
     *
     * @var int $iTimeout
     */
    protected $iTimeout = self::TIMEOUT;

    /**
     * ユーザエージェントヘッダフィールドを使用するか否か
     *
     * @var bool $bUserUserAgent
     */
    protected $bUseUserAgent = false;

    /**
     * ユーザエージェントヘッダフィールド
     *
     * @var string $sUserAgent
     */
    protected $sUserAgent = self::DEFAULT_UA;

    /**
     * HTTPプロキシバージョン
     *
     * @var string $sProxyProto
     */
    protected $sProxyProto = 'HTTP/1.0';

    /**
     * プロキシモードか否か
     *
     * @var bool $bProxyMode
     */
    protected $bProxyMode = false;

    /**
     * HTTP要求情報
     *
     * @var array $aRequest
     */
    protected $aRequest = array('', '');

    /**
     * HTTP応答情報
     *
     * @var array $aResponse
     */
    protected $aResponse = array('', '');

    /**
     * HTTPセッション情報
     *
     * @var array $aSessionInfo
     */
    protected $aSessionInfo = array();

    /**
     * HTTP応答ステータスコード
     *
     * @var int $iLastHttpStatus
     */
    protected $iLastHttpStatus = 200;

    /**
     * RFC3986方式のエンコード／デコードを行うか
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     *  このクラスのメソッド
     *      _urlencode          フラグにより判定
     *      _urldecode          フラグにより判定
     *      _http_build_query   フラグにより判定
     *
     * @var bool $bUseRFC3982
     */
    protected $bUseRFC3982 = false;

    /**
     * HTTPリクエスト直前のオプション処理用コールバック関数
     *
     * 主に認証情報をセットするために使用する
     * 基本認証やOAuth認証はここにコールバック指定する
     *
     * コールバック関数のパラメータ
     *      public function cOptional(
     *          $rCUrl,         //  resource    cURLリソースオブジェクト
     *          $sMethod,       //  string      HTTPリクエストメソッド名(GET/POST/PUT/DELETE/HEAD)
     *          $sUrl,          //  string      リクエストする正規化済みのURL
     *          array $aParams  //  array       リクエストパラメータ配列
     *      )
     * コールバック関数の戻り値は文字列の配列の形式で
     * リクエストヘッダとしてセットされる
     *
     * @var callback $cOptional
     */
    protected $cOptional = NULL;

    /**
     * HTTP接続のログを出力するか否か
     *
     * @var bool $bLogHTTP
     */
    protected $bLogHTTP = false;

    /**
     * HTTP接続のログを出力するか否か
     *
     * @var bool $bLogBody
     */
    protected $bLogBody = false;

    /**
     * HTTP接続のログを生で出力するか否か
     *
     * @var bool $bLogBodyRaw
     */
    protected $bLogBodyRaw = false;

    /**
     * HTTP接続のエラー時のログを出力するか否か
     *
     * @var bool $bLogError
     */
    protected $bLogError = false;

    /**
     * HTTP接続の時刻のログを出力するフラグ
     *
     * @var int $iLogTime
     */
    protected $iLogTime = 1;

    /**
     * リクエスト情報をログに残す場合の対象
     *
     * @var array $aLogRequest
     */
    protected $aLogRequest = array();

    /**
     * ログ出力時に値を除去するか否か
     *
     * @var bool $bLogStrippedValue
     */
    protected $bLogStrippedValue = true;

    /**
     * HTTP接続の時刻のキー
     *
     * @var array $aLogTimeKeys
     */
    protected $aLogTimeKeys  = array(
        1  => 'total_time',
        2  => 'namelookup_time',
        4  => 'connect_time',
        8  => 'pretransfer_time',
        16 => 'starttransfer_time',
        32 => 'redirect_time',
    );


    /**
     * インスタンス
     *
     * @var SC\libs\Http $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // リクエスト情報
        $this->_setSmartConvert(SC_PRODUCT_NAME, SC_PRODUCT_VERSION);
        $this->_setUserAgent(static::DEFAULT_UA);

        // タイムアウトの指定
        $iTimeout              = Request::getServer('SC_HTTP_TIMEOUT', static::TIMEOUT);
        $this->_setTimeout($iTimeout);
        // Use RFC3982
        $sUseRFC3982           = strtolower(Request::getServer('SC_USE_RFC3982', '0'));
        if ( $sUseRFC3982 === '0' || $sUseRFC3982 === 'false' || $sUseRFC3982 === 'off' || (bool)$sUseRFC3982 === false ) {
            $this->_setUseRFC3982(false);
        } else {
            $this->_setUseRFC3982(true);
        }

        // HTTPのログ
        $sLogHTTP              = strtolower(Request::getServer('SC_LOG_HTTP', '0'));
        if ( $sLogHTTP === '0' || $sLogHTTP === 'false' || $sLogHTTP === 'off' || (bool)$sLogHTTP === false) {
            $this->bLogHTTP    = false;
        } else {
            $this->bLogHTTP    = true;
        }
        $sLogBody              = strtolower(Request::getServer('SC_LOG_HTTP_BODY', '0'));
        if ( $sLogBody === '0' || $sLogBody === 'false' || $sLogBody === 'off' || (bool)$sLogBody === false) {
            $this->bLogBody    = false;
        } else {
            $this->bLogBody    = true;
        }
        $sLogBodyRaw           = strtolower(Request::getServer('SC_LOG_HTTP_BODY_RAW', '0'));
        if ( $sLogBodyRaw === '0' || $sLogBodyRaw === 'false' || $sLogBodyRaw === 'off' || (bool)$sLogBodyRaw === false) {
            $this->bLogBodyRaw = false;
        } else {
            $this->bLogBodyRaw = true;
        }
        $sLogError             = strtolower(Request::getServer('SC_LOG_HTTP_ERROR', '0'));
        if ( $sLogError === '0' || $sLogError === 'false' || $sLogError === 'off' || (bool)$sLogError === false) {
            $this->bLogError   = false;
        } else {
            $this->bLogError   = true;
        }
        $this->iLogTime        = (int) Request::getServer('SC_LOG_HTTP_TIME', 1);
        $sLogRequest           = strtolower(Request::getServer('SC_LOG_HTTP_REQUEST', 'get'));
        if ( $sLogRequest !== '' ) {
            $aLogRequest       = explode(',', $sLogRequest);
            foreach ( $aLogRequest as $sName ) {
                $sName         = trim($sName);
                switch ( $sName ) {
                    case 'get':   case 'post':   case 'cookie': case 'file': case 'header':
                        $this->aLogRequest[] = $sName;
                        break;
                    default:
                        break;
                }
            }
        }
        // 値をストリップするか
        $sLogStrippedValue           = strtolower(Request::getServer('SC_LOG_STRIPPED_VALUE', '1'));
        if ( $sLogStrippedValue === '0' || $sLogStrippedValue === 'false' || $sLogStrippedValue === 'off' ) {
            $this->bLogStrippedValue = false;
        } else {
            $this->bLogStrippedValue = true;
        }
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Http
     */
    protected static function _getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * RFC3982フラグゲッター
     *
     * @return  bool    RFC3982フラグ
     */
    public static function getUseRFC3982()
    {
        $oSelf = static::_getInstance();
        return $oSelf->_getUseRFC3982();
    }

    /**
     * RFC3982フラグセッター
     *
     * @param   bool    $bUseRFC3982
     * @return  bool    true
     */
    public static function setUseRFC3982($bUseRFC3982)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setUseRFC3982($bUseRFC3982);
    }

    /**
     * タイムアウトゲッター
     *
     * @return  int     タイムアウト
     */
    public static function getTimeout()
    {
        $oSelf = static::_getInstance();
        return $oSelf->_getTimeout();
    }

    /**
     * タイムアウトセッター
     *
     * @param   int     $iTimeout
     * @return  bool    true
     */
    public static function setTimeout($iTimeout)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setTimeout($iTimeout);
    }

    /**
     * ユーザーエージェントセッター
     *
     * @param   string  $sUserAgent
     * @return  bool    true
     */
    public static function setUserAgent($sUserAgent)
    {
        $oSelf                    = static::_getInstance();
        $bRetCode                 = $oSelf->_setUserAgent($sUserAgent);
        if ( $bRetCode === true ) {
            $oSelf->bUseUserAgent = true;
        }
        return true;
    }

    /**
     * プロキシモードセッター
     *
     * @param   bool    $bProxyMode
     * @return  bool    true
     */
    public static function setProxyMode($bProxyMode)
    {
        $oSelf                    = static::_getInstance();
        if ( $bProxyMode === true ) {
            $oSelf->bProxyMode = true;
        } else {
            $oSelf->bProxyMode = false;
        }
        return true;
    }

    /**
     * 製品名セッター
     *
     * @param   string  $sProductName
     * @param   string  $sProductVersion
     * @return  bool    true
     */
    public static function setSmartConvert($sProductName, $sProductVersion)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setSmartConvert($sProductName, $sProductVersion);
    }

    /**
     * RFC3982フラグゲッター
     *
     * @return  bool    RFC3982フラグ
     */
    protected function _getUseRFC3982()
    {
        return $this->bUseRFC3982;
    }

    /**
     * RFC3982フラグセッター
     *
     * @param   bool    $bUseRFC3982
     * @return  bool    true
     */
    protected function _setUseRFC3982($bUseRFC3982)
    {
        $this->bUseRFC3982 = (bool) $bUseRFC3982;
        return true;
    }

    /**
     * タイムアウトゲッター
     *
     * @return  int     タイムアウト
     */
    protected function _getTimeout()
    {
        return $this->iTimeout;
    }

    /**
     * タイムアウトセッター
     *
     * @param   int     $iTimeout
     * @return  bool    true
     * @throw   SC\exception\common\parameter\NotAnInt
     * @throw   SC\exception\common\parameter\OutOfRange
     */
    protected function _setTimeout($iTimeout)
    {
        // 入力チェック
        $bRetCode         = Validate::isInt($iTimeout);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt('Timeout must be integer');
        }
        if ( $iTimeout < 1 || static::TIMEOUT_MAX < $iTimeout ) {
            throw new \SC\exception\common\parameter\OutOfRange('Timeout must be in between 1 and TIMEOUT_MAX(' . static::TIMEOUT_MAX . ')');
        }
        // セット
        $this->iTimeout = $iTimeout;
        return true;
    }

    /**
     * ユーザーエージェントセッター
     *
     * @param   string  $sUserAgent
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _setUserAgent($sUserAgent)
    {
        // 入力チェック
        $bRetCode         = Validate::isStringNotZero($sUserAgent);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('User-Agent must be string');
        }
        // セット
        $this->sUserAgent = join(' ', array(
            $sUserAgent,
            $this->sSmartConvert,
        ));
        return true;
    }

    /**
     * 製品名セッター
     *
     * @param   string  $sProductName
     * @param   string  $sProductVersion
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _setSmartConvert($sProductName, $sProductVersion)
    {
        // 入力チェック
        $bRetCode            = Validate::isStringNotZero($sProductName);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Product name must be string');
        }
        $bRetCode            = Validate::isStringNotZero($sProductVersion);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Product version must be string');
        }
        // セット
        $this->sSmartConvert = join('/', array(
            $sProductName,
            $sProductVersion,
        ));
        return true;
    }

    /**
     * GET/POST/PUT/DELETE/HEADメソッドでHTTPアクセス
     *
     * @param   string  $sMethod
     * @param   array   $aParams
     * @return  mixed   戻り値
     */
    public static function __callStatic($sMethod, array $aParams)
    {
        // HTTPアクセスメソッドか？
        $bRetCode = in_array(strtoupper($sMethod), static::$aValidHTTPMethods);
        if ( $bRetCode !== true ) {
            // メソッドが正しくない → エラートリガーを引く (標準エラーと同様に見せる)
            trigger_error('Call to undefined method ' . __CLASS__ . '::' . $sMethod . '()', E_USER_ERROR);
        }
        // HTTPアクセスメソッドならコールする
        $oSelf = static::_getInstance();
        array_unshift($aParams, $sMethod);
        return forward_static_call_array(array($oSelf, '_httpMethod'), $aParams);
    }

    /**
     * HTTPアクセス
     *
     * @param   string  $sMethod        HTTP接続メソッド (GET, POST, PUT, DELETE, HEAD)
     * @param   string  $sUrl           アクセスURL
     * @param   array   $aOptions       オプション
     * @return  string  取得文字列
     */
    protected function _httpMethod($sMethod, $sUrl, array $aOptions = array())
    {
        // メソッドを大文字化
        $sMethod                = strtoupper($sMethod);
        // 入力チェック
        $this->_checkForHttpMethod($sMethod, $sUrl);
        // オプションの正規化
        $aOptions               = (array) $aOptions;
        $aOptions               = array(
            'params'        => (array)  ArrayUtil::getValue($aOptions, 'params',      array() ),
            'rawpostdata'   => (string) ArrayUtil::getValue($aOptions, 'rawpostdata', ''      ),
            'filtered'      => (bool)   ArrayUtil::getValue($aOptions, 'filtered',    false   ),
            'form-data'     => (bool)   ArrayUtil::getValue($aOptions, 'form-data',   false   ),
            'queryformat'   => (string) ArrayUtil::getValue($aOptions, 'queryformat', 'normal'),
            'headers'       => (array)  ArrayUtil::getValue($aOptions, 'headers',     array() ),
            'curloptions'   => (array)  ArrayUtil::getValue($aOptions, 'curloptions', array() ),
        );
        // URLを正規化
        if ( $sMethod === 'POST' ) {
            // POSTの場合のみ正規化にパラメータを付与しない
            $sUrl                                       = $this->_normalizeUrl($sUrl, array());
        } else {
            // その他の場合にはURLにマージして正規化
            $sUrl                                       = $this->_normalizeUrl($sUrl, $aOptions['params']);
        }
        // リクエストを取得
        $sResponse              = $this->_httpMethodExec($sMethod, $sUrl, $aOptions);
        return $sResponse;
    }

    /**
     * HTTPアクセス入力チェック
     *
     * @param   string  $sMethod    HTTP接続メソッド (GET, POST, PUT, DELETE, HEAD)
     * @param   string  $sUrl       アクセスURL
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\libs\Http\InvalidHTTPMethod
     */
    protected function _checkForHttpMethod($sMethod, $sUrl)
    {
        // 入力チェック
        $sMethod  = trim($sMethod);
        if ( $sMethod === '' ) {
            throw new \SC\exception\common\parameter\ZeroByteString('接続メソッドが指定されていません。');
        }
        $bRetCode = in_array($sMethod, static::$aValidHTTPMethods);
        if ( $bRetCode !== true ) {
            // メソッドが正しくない
            throw new \SC\exception\libs\Http\InvalidHTTPMethod('接続メソッドの指定が正しくありません。');
        }
        $sUrl     = trim($sUrl);
        if ( $sUrl === '' ) {
            throw new \SC\exception\common\parameter\ZeroByteString('接続URLが指定されていません。');
        }
        return true;
    }

    /**
     * URLの正規化 for GET
     *
     * @param   string  $sUrl       アクセスURL
     * @param   array   $aParams    パラメータ
     * @return  string  正規化したURL
     */
    public static function normalizeUrl($sUrl, array $aParams)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_normalizeUrl($sUrl, $aParams);
    }

    /**
     * URLの正規化 for GET
     *
     * @param   string  $sUrl       アクセスURL
     * @param   array   $aParams    パラメータ
     * @return  string  正規化したURL
     */
    protected function _normalizeUrl($sUrl, array $aParams)
    {
        // URLをパーツに分解してパラメータは生成しなおし
        $aParts                 = parse_url($sUrl);
        $bRetCode               = isset($aParts['path']);
        if ( $bRetCode === true ) {
            $aPathes            = explode('/', $aParts['path']);
            foreach ( $aPathes as $iKey => $sPart ) {
                $aPathes[$iKey] = $this->_urlencode($sPart);
            }
            $aParts['path']     = join('/', $aPathes);
        }
        $bRetCode               = isset($aParts['query']);
        if ( $bRetCode === true ) {
            $aUrlParamsRaw      = explode('&', $aParts['query']);
            $aUrlParams         = array();
            foreach ( $aUrlParamsRaw as $sPart ) {
                if ( $sPart === '' ) {
                    $sName      = '';
                    $sValue     = '';
                } else {
                    $bRetCode   = (bool) strpos($sPart, '=', 1);
                    if ( $bRetCode === true ) {
                        $aTmp   = explode('=', $sPart, 2);
                        $sName  = $this->_urldecode($aTmp[0]);
                        $sValue = $this->_urldecode($aTmp[1]);
                    } else {
                        $sName  = '';
                        $sValue = $this->_urldecode($sPart);
                    }
                }
                $aUrlParams[]   = array(
                    'name'  => $sName,
                    'value' => $sValue,
                );
            }
            foreach ( $aParams as $sName => $sValue ) {
                $aUrlParams[]   = array(
                    'name'  => $sName,
                    'value' => $sValue,
                );
            }
            $aParts['query']    = $this->_http_build_raw_query($aUrlParams);
        }
        $sUrl                   = $this->makeGetUrl($aParts, true);
        return $sUrl;
    }

    /**
     * HTTPアクセスの実行
     *
     * このメソッドをコールする時点で以下の条件を満たしていること
     *      ・有効なメソッド(大文字化済)
     *      ・GETの場合URLは正規化されている
     *
     * @param   string  $sMethod        HTTP接続メソッド (GET, POST, PUT, DELETE, HEAD)
     * @param   string  $sUrl           アクセスURL
     * @param   array   $aOptions       オプション
     * @return  string  取得文字列
     * @throw   SC\exception\libs\Http\InvalidReturnValueFromOptional
     * @throw   SC\exception\libs\Http\CantExecHTTP
     */
    protected function _httpMethodExec($sMethod, $sUrl, array $aOptions)
    {
        // ヘッダを取得
        $aHeaders                                       = array();
        foreach ( $aOptions['headers'] as $sName => $mValue ) {
            $sLower                                     = strtolower($sName);
            $aHeaders[$sLower]                          = array(
                'name'  => $sName,
                'value' => $mValue,
            );
        }
        // パラメータを保持
        $aParams                                        = $aOptions['params'];
        if ( $aOptions['queryformat'] === 'json' ) {
            $bJSONQuery                                 = true;
        } else {
            $bJSONQuery                                 = false;
        }
        // cURLオブジェクトを生成する
        $rCUrl                                          = curl_init();
        // 指定がある場合にはループ
        $aCUrlOptions                                   = (array) ArrayUtil::getValue($aOptions, 'curloptions', array());
        foreach ( $aCUrlOptions as $mOptKey => $mOptValue ) {
            $iOptKey                                    = 0;
            $bRetCode                                   = Validate::isInt($mOptKey);
            if ( $bRetCode === true ) {
                $iOptKey                                = (int) $mOptKey;
            } else {
                $bRetCode                               = defined($mOptKey);
                if ( $bRetCode === true ) {
                    $iOptKey                            = constant($mOptKey);
                }
            }
            if ( $iOptKey > 0 ) {
                curl_setopt($rCUrl, $iOptKey,           $mOptValue);
            }
        }
        curl_setopt    ($rCUrl, CURLOPT_URL,            $sUrl);
        // SSLを使用するか？ (0ならばSSL)
        $bRetCode                                       = (bool) strncmp('https:', $sUrl, 6);
        if ( $bRetCode === false ) {
            curl_setopt($rCUrl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($rCUrl, CURLOPT_SSL_VERIFYHOST, 0);
        }
        // POSTか否か？
        if ( $sMethod === 'POST' ) {
            // POSTの場合にはデータを生成してセット
            if ( $aOptions['rawpostdata'] !== '' ) {
                $mPostData                              = $aOptions['rawpostdata'];
                if ( $this->bLogStrippedValue === true ) {
                    // POSTの値を除去
                    $sPostNames                         = $this->_getStrippedRawPostData($mPostData, $aOptions['filtered']);
                } else {
                    // そのままセット
                    $sPostNames                         = $mPostData;
                }
            } else if ( $aOptions['form-data'] === true ) {
                $mPostData                              = array();
                $sPostNames                             = '';
            } else {
                $mPostData                              = $this->_http_build_raw_query($aParams, $bJSONQuery, false, '&', false);
                $sPostNames                             = $this->_http_build_raw_query($aParams, $bJSONQuery, false, '&', $this->bLogStrippedValue);
                if ( $mPostData === '' ) {
                    $mPostData                          = array();
                }
            }
            curl_setopt($rCUrl, CURLOPT_POST,           true);
            curl_setopt($rCUrl, CURLOPT_POSTFIELDS,     $mPostData);
        } else {
            $mPostData                                  = '';
            $sPostNames                                 = '';
        }
        // リクエストヘッダの指定
        $bRetCode                                       = isset($aHeaders['user-agent']);
        if ( $bRetCode !== true || $this->bUseUserAgent === true ) {
            // 指定があるかUAがなければ指定する
            $aHeaders['user-agent']                     = array(
                'name'  => 'User-Agent',
                'value' => join(' ', array($this->sUserAgent, $this->sSmartConvert)),
            );
            $this->bUseUserAgent                        = false;
        } else {
            // あれば付加
            $bRetCode                                   = is_array($aHeaders['user-agent']['value']);
            if ( $bRetCode === true ) {
                // 配列ならpush
                $aUserAgent                             = $aHeaders['user-agent']['value'];
                $aUserAgent[]                           = $this->sSmartConvert;
            } else {
                // 文字列なら配列にして
                $aUserAgent                             = array($aHeaders['user-agent']['value'], $this->sSmartConvert);
            }
            $aHeaders['user-agent']['value']            = join(' ', $aUserAgent);
            $this->bUseUserAgent                        = false;
        }
        $bRetCode                                       = isset($aHeaders['expect']);
        if ( $bRetCode === true ) {
            // 「Expect: 100-continue」は動作対象外 → あれば除去
            $aHeaders['expect']['value']                = preg_replace('#^\s*100-continue(?:\s+.*)?$#u', '', $aHeaders['expect']['value']);
        } else {
            $aHeaders['expect']                         = array(
                'name'  => 'Expect',
                'value' => '',
            );
        }
        // プロキシモードならX-Forwarded-Forなどのヘッダフィールドを付加
        if ( $this->bProxyMode === true ) {
            // Via
            $sThisVia                                   = $this->sProxyProto . ' ' . Request::getServer('HTTP_HOST', '127.0.0.1');
            $bRetCode                                   = isset($aHeaders['via']);
            if ( $bRetCode === true ) {
                $bRetCode                               = is_array($aHeaders['via']['value']);
                if ( $bRetCode === true ) {
                    $aVia                               = $aHeaders['via']['value'];
                } else {
                    $aVia                               = array($aHeaders['via']['value']);
                }
                $aVia[]                                 = $sThisVia;
                $aHeaders['via']['value']               = join(', ', $aVia);
            } else {
                $aHeaders['via']            = array(
                    'name'  => 'Via',
                    'value' => $sThisVia,
                );
            }
            // X-Forwarded-For
            $sRemoteAddr                                = Request::getServer('REMOTE_ADDR', '127.0.0.1');
            $bRetCode                                   = isset($aHeaders['x-forwarded-for']);
            if ( $bRetCode === true ) {
                $bRetCode                               = is_array($aHeaders['x-forwarded-for']['value']);
                if ( $bRetCode === true ) {
                    $aForwardedFor                      = $aHeaders['x-forwarded-for']['value'];
                } else {
                    $aForwardedFor                      = array($aHeaders['x-forwarded-for']['value']);
                }
                $aForwardedFor[]                        = $sRemoteAddr;
                $aHeaders['x-forwarded-for']['value']   = join(', ', $aForwardedFor);
            } else {
                $aHeaders['x-forwarded-for']            = array(
                    'name'  => 'X-Forwarded-For',
                    'value' => $sRemoteAddr,
                );
            }
            // X-Proxy
            $aHeaders['x-proxy-ua']                     = array(
                'name'  => 'X-Proxy-UA',
                'value' => $this->sSmartConvert,
            );
            $aHeaders['x-proxy-by']                     = array(
                'name'  => 'X-Proxy-By',
                'value' => $this->sSmartConvert,
            );
        }
        // オプショナルな処理
        $bRetCode                                       = is_callable($this->cOptional);
        if ( $bRetCode === true ) {
            // オプショナルな処理が指定されている場合にはコール
            $aOptionalHeaders                           = call_user_func($this->cOptional, $rCUrl, $sMethod, $sUrl, $aParams);
            $bRetCode                                   = is_array($aOptionalHeaders);
            if ( $bRetCode !== true ) {
                // 正常終了していないと判断
                throw new \SC\exception\libs\Http\InvalidReturnValueFromOptional('追加処理が正常に終了していません。');
            }
            // ヘッダをマージ
            $aHeaders                                   = array_merge_recursive($aHeaders, $aOptionalHeaders);
        }
        $aSendHeaders                                   = array();
        foreach ( $aHeaders as $sLower => $aEach ) {
            $bRetCode                                   = is_array($aEach['value']);
            if ( $bRetCode !== true ) {
                $aEach['value']                         = array($aEach['value']);
            }
            foreach ( $aEach['value'] as $sValue ) {
                $aSendHeaders[]                         = "{$aEach['name']}: {$sValue}";
            }
        }
        curl_setopt($rCUrl, CURLOPT_HTTPHEADER,         $aSendHeaders);
        // 戻りの指定
        curl_setopt($rCUrl, CURLINFO_HEADER_OUT,        true);
        curl_setopt($rCUrl, CURLOPT_HEADER,             true);
        curl_setopt($rCUrl, CURLOPT_RETURNTRANSFER,     true);
        curl_setopt($rCUrl, CURLOPT_BINARYTRANSFER,     true);
        curl_setopt($rCUrl, CURLOPT_CONNECTTIMEOUT,     10);
        curl_setopt($rCUrl, CURLOPT_TIMEOUT,            $this->iTimeout);
        $aRequestInfo                                   = array();
        $aUriInfo                                       = $this->_breakDownUri($sUrl);
        if ( $this->aLogRequest !== array() ) {
            $aUriInfo['post']                           = $sPostNames;
            $aUriInfo['cookie']                         = $this->_extractCookie($aHeaders);
            foreach ( $this->aLogRequest as $sFrom ) {
                if ( $sFrom === 'header' ) {
                    // headerはこの時点では出力できない
                    continue;
                }
                $aRequestInfo[$sFrom]                   = strtoupper($sFrom) . ":[{$aUriInfo[$sFrom]}]";
            }
            $sRequestValue                              = ' with ' . join(' ', $aRequestInfo);
        } else {
            $sRequestValue                              = '';
        }
        $sLogUrl                                        = $aUriInfo['uri'];
        \Log::info("cURL exec {$sMethod} {$sLogUrl}{$sRequestValue} (timeout={$this->iTimeout})");
        $mRetValue                                      = curl_exec($rCUrl);
        $this->aSessionInfo                             = curl_getinfo($rCUrl);
        $sErrNo                                         = curl_errno($rCUrl);
        if ( $sErrNo !== CURLE_OK ) {
            $sErrMessage                                = curl_error($rCUrl) . " ($sMethod)";
        } else {
            $sErrMessage                                = '';
        }
        // 毎回解放する
        curl_close($rCUrl);
        // cURL用ログストア
        LogRegistry::save('sc:request', 'CURL_ERROR',  $sErrMessage);
        LogRegistry::save('sc:recv',    'CURL_ERROR',  $sErrMessage);
        LogRegistry::save('sc:request', 'CURL_ERRNO',  $sErrNo);
        LogRegistry::save('sc:recv',    'CURL_ERRNO',  $sErrNo);
        LogRegistry::save('sc:request', 'CURL_METHOD', $sMethod);
        LogRegistry::save('sc:recv',    'CURL_METHOD', $sMethod);
        LogRegistry::save('sc:request', 'CURL_URL',    $sLogUrl);
        LogRegistry::save('sc:recv',    'CURL_URL',    $sLogUrl);
        $aLogSessionInfo                                = $this->aSessionInfo;
        unset($aLogSessionInfo['url'], $aLogSessionInfo['request_header']);
        foreach ( $aLogSessionInfo as $sKey => $mValue ) {
            $sKey = strtoupper($sKey);
            LogRegistry::save('sc:request', 'CURL_' . $sKey, $mValue);
            LogRegistry::save('sc:recv',    'CURL_' . $sKey, $mValue);
        }
        // 送出情報のハンドリング
        $bRetCode                                       = isset($this->aSessionInfo['request_header']);
        if ( $bRetCode === true ) {
            $sRequestHeader                             = trim($this->aSessionInfo['request_header']);
            unset($this->aSessionInfo['request_header']);
            $aRequestHeaders                            = explode("\r\n", $sRequestHeader);
            unset($aRequestHeaders[0]);
            $aUrlParams                                 = array();
            foreach ( $aRequestHeaders as $iKey => $sHeader ) {
                $aHeaderParts                           = explode(':', $sHeader, 2);
                $sNameLower                             = strtolower($aHeaderParts[0]);
                $sValue                                 = ltrim(ArrayUtil::getValue($aHeaderParts, 1, ''));
                $aUrlParams[]                           = array(
                    'name'  => $aHeaderParts[0],
                    'value' => $sValue,
                );
                LogRegistry::save('header:send', $aHeaderParts[0], $sValue);
                // cookieのみ解析
                if ( $sNameLower === 'cookie' ) {
                    $aCookies                           = explode(';', $sValue);
                    $aCookieNames[]                     = array();
                    foreach ( $aCookies as $sCookie ) {
                        $aCookieParts                   = explode('=', ltrim($sCookie), 2);
                        $aCookieNames[]                 = $aCookieParts[0] . '=';
                        LogRegistry::save('cookie:send', $aCookieParts[0], $aCookieParts[1]);
                    }
                }
            }
            $bRetCode                                   = in_array('header', $this->aLogRequest);
            if ( $bRetCode === true ) {
                $sSendHeaders                           = $this->_http_build_raw_query($aUrlParams, false, false, '&', false);
                \Log::info("cURL with header:[{$sSendHeaders}]");
            }
        } else {
            $sRequestHeader                             = '';
        }
        $this->aRequest                                 = array( $sRequestHeader, $mPostData );
        if ( $mRetValue === false ) {
            // 取得できない
            $this->aResponse                            = array( '', '' );
            $this->iLastHttpStatus                      = 500;
            // ログ出力
            if ( $this->bLogError === true ) {
                $aLogInfo                               = array();
                $aLogInfo[]                             = "cURL response for {$sMethod} {$sUrl}:";
                $aLogInfo[]                             = '----^ HTTP Request BEGIN ---------------';
                $aLogInfo[]                             = str_replace("\r\n", "\n", $this->aRequest[0]);
                if ( $sMethod === 'POST' ) {
                    $aLogInfo[]                         = '---- body is following:';
                    $aLogInfo[]                         = str_replace("\r\n", "\n", \Debug::dump($this->aRequest[1], '', false));
                }
                $aLogInfo[]                             = '----$ HTTP Request  END  ---------------';
                $aLogInfo[]                             = '----^ HTTP Response BEGIN --------------';
                $aLogInfo[]                             = str_replace("\r\n", "\n", $this->aResponse[0]);
                $aLogInfo[]                             = '----$ HTTP Response  END  --------------';
                $aLogInfo[]                             = '----^ HTTP Session BEGIN ---------------';
                $aLogInfo[]                             = \Debug::dump($this->aSessionInfo, '', false);
                $aLogInfo[]                             = '----$ HTTP Session  END  ---------------';
                \Log::warning(join("\n", $aLogInfo));
            }
            // 例外を投げる
            throw new \SC\exception\libs\Http\CantExecHTTP($sErrMessage, $sErrNo);
        }
        // ヘッダと値が取得されるので分割する
        $this->aResponse                                = explode("\r\n\r\n", $mRetValue, 2);
        $this->iLastHttpStatus                          = (int) $this->aSessionInfo['http_code'];
        // バイナリか？
        $bRetCode                                       = (bool) preg_match('#\bcontent-type:(.*?)(?:;|$)#im', $this->aResponse[0], $aMatches);
        if ( $bRetCode === true ) {
            $sMimeType                                  = strtolower(trim($aMatches[1]));
            $bRetCode                                   = (bool) preg_match('#^(?:text/|application/(?:(?:.+[-\+])?xml(?:[-\+].+)?|(?:x-)?javascript|jsonp?)$)#S', $sMimeType);
            if ( $bRetCode === true ) {
                $bBinary                                = false;
            } else {
                $bBinary                                = true;
            }
        } else {
            $bBinary                                    = 'application';
        }
        $this->aSessionInfo['binary']                   = $bBinary;
        $this->aSessionInfo['charset']                  = $this->_detectCharset($this->aResponse, $bBinary);
        LogRegistry::save('sc:request', 'CURL_BINARY',  $this->aSessionInfo['binary']);
        LogRegistry::save('sc:recv',    'CURL_BINARY',  $this->aSessionInfo['binary']);
        LogRegistry::save('sc:request', 'CURL_CHARSET', $this->aSessionInfo['charset']);
        LogRegistry::save('sc:recv',    'CURL_CHARSET', $this->aSessionInfo['charset']);
        if ( $this->bLogHTTP === true ) {
            $aLogInfo                                   = array();
            $aLogInfo[]                                 = "cURL response for {$sMethod} {$sUrl}:";
            $aLogInfo[]                                 = '----^ HTTP Request  BEGIN  ---------------';
            $aLogInfo[]                                 = str_replace("\r\n", "\n", $this->aRequest[0]);
            if ( $this->bLogBody === true || $sMethod === 'POST' ) {
                $aLogInfo[]                             = '---- body is following:';
                $aLogInfo[]                             = str_replace("\r\n", "\n", \Debug::dump($this->aRequest[1], '', false));
            }
            $aLogInfo[]                                 = '----$ HTTP Request  END    ---------------';
            $aLogInfo[]                                 = '----^ HTTP Response BEGIN  --------------';
            $aLogInfo[]                                 = str_replace("\r\n", "\n", $this->aResponse[0]);
            if ( $this->bLogBody === true ) {
                if ( $bBinary === false ) {
                    $aLogInfo[]                         = '---- body is following:';
                    if ( $this->bLogBodyRaw === true ) {
                        $aLogInfo[]                     = str_replace("\r\n", "\n", $this->aResponse[1]);
                    } else {
                        if ( $this->aSessionInfo['charset'] === '' ) {
                            $sSourceEnc                 = 'ASCII';
                        } else {
                            $sSourceEnc                 = $this->aSessionInfo['charset'];
                        }
                        $aLogInfo[]                     = str_replace("\r\n", "\n", Util::mb_convert_encoding($this->aResponse[1], 'UTF-8', $sSourceEnc));
                    }
                } else {
                    $aLogInfo[]                         = '---- body is binary [size=' . strlen($this->aResponse[1]) . 'bytes]';
                }
            }
            $aLogInfo[]                                 = '----$ HTTP Response  END   --------------';
            $aLogInfo[]                                 = '----^ HTTP Session   BEGIN ---------------';
            $aLogInfo[]                                 = \Debug::dump($this->aSessionInfo, '', false);
            $aLogInfo[]                                 = '----$ HTTP Session   END   ---------------';
            \Log::trace(join("\n", $aLogInfo));
        }
        foreach ( $this->aLogTimeKeys as $iKey => $sTimeName ) {
            if ( ( $this->iLogTime & $iKey ) === $iKey ) {
                \Log::info('cURL exec time of ' . sprintf('%-18s', $sTimeName) . ' = ' . sprintf('% 3.6f', $this->aSessionInfo[$sTimeName]));
            }
        }
        // 取得したデータを文字列に変換
        $sResponse                                      = (string) $this->aResponse[1];
        // ログレジストリ
        $aResponseHeaders                               = explode("\r\n", $this->aResponse[0]);
        if ( $aResponseHeaders !== array() ) {
            unset($aResponseHeaders[0]);
            $aCookies                                   = array();
            foreach ( $aResponseHeaders as $sHeader ) {
                $aHeaderParts                           = explode(':', $sHeader, 2);
                if ( $aHeaderParts === array() ) {
                    // ヘッダではない
                    continue;
                }
                $iCount                                 = count($aHeaderParts);
                if ( $iCount < 2 ) {
                    // ヘッダがおかしい → 空文字を保持させる
                    LogRegistry::save('header:recv', $aHeaderParts[0], '');
                    continue;
                }
                $sNameLower                             = strtolower($aHeaderParts[0]);
                $sValue                                 = ltrim($aHeaderParts[1]);
                if ( $sNameLower !== 'set-cookie' ) {
                    // Set-Cookieでなければそのまま保存して次へ
                    LogRegistry::save('header:recv', $aHeaderParts[0], $sValue);
                    continue;
                }
                // Set-Cookieのみ配列で保存
                $aCookies[]                             = $sValue;
                $aCookieParts                           = explode('=', $sValue, 2);
                if ( $aCookieParts === array() ) {
                    // Set-Cookieがおかしい
                    continue;
                }
                $iCount                                 = count($aCookieParts);
                if ( $iCount < 2 ) {
                    // Set-Cookieがおかしい → 空文字を保持させる
                    LogRegistry::save('cookie:recv', $aCookieParts[0], '');
                    continue;
                }
                LogRegistry::save('cookie:recv', $aCookieParts[0], $aCookieParts[1]);
            }
            if ( $aCookies !== array() ) {
                LogRegistry::save('header:recv', 'Set-Cookie', $aCookies);
            }
        }
        return $sResponse;
    }

    /**
     * レスポンスから文字コードを取得
     *
     * @param   array   $aResponse  レスポンス
     * @param   bool    $bBinary    ボディがバイナリか否か
     * @return  string  文字コード
     */
    protected function _detectCharset(array $aResponse, $bBinary)
    {
        // ヘッダから文字コードを取得
        $sHttpHead    = (string) ArrayUtil::getValue($aResponse, 0, '');
        $bRetCode     = (bool) preg_match('#\bcontent-type:.*?;\s*charset=("[^;\s"]+?"|[^;\s]+?)(?:[;\s]|$)#i', $sHttpHead, $aMatches);
        if ( $bRetCode === true ) {
            // 取得できたら返す
            $sCharset = trim($aMatches[1], '" ');
            return $sCharset;
        }
        if ( $bBinary === true ) {
            // ボディがバイナリなら文字コード指定はなし
            return '';
        }
        // ボディから文字コードを取得
        $sHttpBody    = (string) ArrayUtil::getValue($aResponse, 1, '');
        $bRetCode     = (bool) preg_match('#\bcharset=("[^;\s>"]+?"|[^;\s>"]+?)(?:[;\s>]|$)#i', $sHttpBody, $aMatches);
        if ( $bRetCode === true ) {
            // 取得できたら返す
            $sCharset = trim($aMatches[1], '" ');
            return $sCharset;
        }
        // ボディから文字コードを判定
        $sCharset     = mb_detect_encoding($sHttpBody, mb_detect_order(), false);
        if ( $sCharset !== false ) {
            // 取得できたら返す
            return $sCharset;
        }
        // 取得できなかったから空文字を返す
        return '';
    }

    /**
     * HTTP要求情報(ヘッダ)
     *
     * @return  array   HTTP要求情報(ヘッダ)
     */
    public static function getRequestHeader()
    {
        $oSelf = static::_getInstance();
        return $oSelf->aRequest[0];
    }

    /**
     * HTTP要求情報(ボディ)
     *
     * @return  array   HTTP要求情報(ボディ)
     */
    public static function getRequestBody()
    {
        $oSelf = static::_getInstance();
        return $oSelf->aRequest[1];
    }

    /**
     * HTTP応答情報(ヘッダ)
     *
     * @return  array   HTTP応答情報(ヘッダ)
     */
    public static function getResponseHeader()
    {
        $oSelf = static::_getInstance();
        return $oSelf->aResponse[0];
    }

    /**
     * HTTP応答情報(ボディ)
     *
     * @return  array   HTTP応答情報(ボディ)
     */
    public static function getResponseBody()
    {
        $oSelf = static::_getInstance();
        return $oSelf->aResponse[1];
    }

    /**
     * HTTPセッション情報
     *
     * @return  array   HTTPセッション情報
     */
    public static function getSessionInfo()
    {
        $oSelf = static::_getInstance();
        return $oSelf->aSessionInfo;
    }

    /**
     * HTTP応答ステータスコード
     *
     * @return  int     HTTP応答ステータスコード
     */
    public static function getLastHttpStatus()
    {
        $oSelf = static::_getInstance();
        return $oSelf->iLastHttpStatus;
    }

    /**
     * GETメソッド用のURLを生成
     *
     * @param   array   $aParts         URLパーツ
     * @param   bool    $bWithQueries   クエリパラメータとフラグメントを付与する
     * @return  string  生成されたURL
     */
    public static function makeGetUrl(array $aParts, $bWithQueries = true)
    {
        $aUrlParts       = array();
        // スキーマ指定があるか？
        $sRetStr         = static::validateKeyValue($aParts, 'scheme',   '',  '://');
        if ( $sRetStr !== '' ) {
            $aUrlParts[] = $sRetStr . trim($aParts['host']);
            $aUrlParts[] = static::validateKeyValue($aParts, 'port',     ':', '');
        }
        $aUrlParts[]     = static::validateKeyValue($aParts, 'path',     '',  '');
        if ( $bWithQueries !== false ) {
            $aUrlParts[] = static::validateKeyValue($aParts, 'query',    '?', '');
            $aUrlParts[] = static::validateKeyValue($aParts, 'fragment', '#', '');
        }
        $sUrl            = join('', $aUrlParts);
        return $sUrl;
    }

    /**
     * パラメータのキーをチェックして値を返す
     *
     * @param   array   $aParams    パラメータ
     * @param   string  $sKey       キー
     * @param   string  $sPrefix    接頭辞
     * @param   string  $sSuffix    接尾辞
     * @return  string  値もしくは空文字
     */
    public static function validateKeyValue(array $aParts, $sKey, $sPrefix = '', $sSuffix = '')
    {
        // キーがあるか？
        $bRetCode = isset($aParts["$sKey"]);
        if ( $bRetCode !== true ) {
            return '';
        }
        $sValue   = trim($aParts["$sKey"]);
        if ( $sValue === '' ) {
            return '';
        }
        $sValue   = $sPrefix . $sValue . $sSuffix;
        return $sValue;
    }

    /**
     * urlencode
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _urlencode($sInput)
    {
        if ( $this->bUseRFC3982 === false ) {
            $sOutput = urlencode($sInput);
        } else {
            $sOutput = rawurlencode($sInput);
        }
        return $sOutput;
    }

    /**
     * urldecode
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _urldecode($sInput)
    {
        if ( $this->bUseRFC3982 === false ) {
            $sOutput = urldecode($sInput);
        } else {
            $sOutput = rawurldecode($sInput);
        }
        return $sOutput;
    }

    /**
     * _http_build_raw_query
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   array   $aInput         パラメータ
     * @param   bool    $bJSONQuery     クエリをJSON形式でビルドするか否か
     * @param   bool    $bWithDQuote    クエリの値を2重引用符で括るか否か
     * @param   string  $sSep           パラメータ同士のセパレータ
     * @param   bool    $bStripValue    値を含めない
     * @return  string  $sOutput
     */
    protected function _http_build_raw_query(array $aInput, $bJSONQuery = false, $bDQuoteValue = false, $sSep = '&', $bStripValue = false)
    {
        $aParams           = array();
        $bStripValue       = (bool) $bStripValue;
        foreach ( $aInput as $aEach ) {
            $sName         = (string) ArrayUtil::getValue($aEach, 'name',  '');
            if ( $bStripValue === true ) {
                $sValue    = '';
            } else {
                $sValue    = (string) ArrayUtil::getValue($aEach, 'value', '');
            }
            if ( $sName === '' ) {
                // 名無し → エンコードのみ
                $aParams[] = $this->_urlencode($sValue);
            } else {
                // 名前付きは通常のクエリビルド
                $aParams[] = $this->_http_build_query(array($sName=>$sValue), $bJSONQuery, $bDQuoteValue, $sSep, $bStripValue);
            }
        }
        $sOutput           = join($sSep, $aParams);
        return $sOutput;
    }

    /**
     * http_build_query
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   array   $aInput         パラメータ
     * @param   bool    $bJSONQuery     クエリをJSON形式でビルドするか否か
     * @param   bool    $bWithDQuote    クエリの値を2重引用符で括るか否か
     * @param   string  $sSep           パラメータ同士のセパレータ
     * @param   bool    $bStripValue    値を含めない
     * @return  string  $sOutput
     */
    protected function _http_build_query(array $aInput, $bJSONQuery = false, $bDQuoteValue = false, $sSep = '&', $bStripValue = false)
    {
        // 値を除去する
        if ( (bool) $bStripValue === true ) {
            $aInput      = Util::stripValue($aInput, '');
        }
        if ( $bJSONQuery === true ) {
            $sOutput     = JSON::encode($aInput);
            return $sOutput;
        }
        if ( $bDQuoteValue !== true && $sSep === '&' ) {
            // 通常のhttp_build_query
            $sOutput     = http_build_query($aInput);
            if ( $this->bUseRFC3982 !== false ) {
                $sOutput = $this->_toRFC3982($sOutput);
            }
            return $sOutput;
        }
        // 2重引用符つきか？
        if ( $bWithDQuote === true ) {
            $sDQuote     = '"';
        } else {
            $sDQuote     = '';
        }
        $aParams         = array();
        foreach ( $aInput as $sName => $sValue ) {
            $aParams[]   = $this->_urlencode($sName) . '=' . $sDQuote . $this->_urlencode($sValue) . $sDQuote;
        }
        $sOutput         = join($sSep, $aParams);
        return $sOutput;
    }

    /**
     * URLエンコードされた文字列をRFC3986形式に修正
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _toRFC3982($sInput)
    {
        // 置換情報を生成
        $sOutput  = str_replace(array( '%7E', '+' ), array( '~', '%20' ), $sInput);
        return $sOutput;
    }

    /**
     * 生のPOSTデータから値のみ除去
     *
     * @param   string  $sInput
     * @param   string  $bFiltered
     * @return  string  $sOutput
     */
    protected function _getStrippedRawPostData($sInput, $bFiltered)
    {
        // multipart/form-dataか否か
        $bFormData           = Request::isFormData();
        if ( $bFormData !== true ) {
            // 通常のPOSTデータなので文字列を除去
            return Util::stripValueString($sInput);
        }
        // POSTデータを解析して構成
        $sRequests           = Request::getRawHeaderData() . "\r\n\r\n" . $sInput;
        $aOptions            = array(
            'eof'           => "\r\n",
            'decodeheaders' => false,
            'decodebodies'  => true,
            'content-type'  => 'applicateion/octet-stream',
            'includebodies' => false,
        );
        $oMimeDecoder        = new MimeDecoder($sRequests, $aOptions);
        $aStructure          = $oMimeDecoder->getStructure();
        // クエリ形式に変形
        $aParams             = array();
        foreach ( $aStructure['parts'] as $aPart ) {
            $bFormData       = ! (bool) strncasecmp('form-data', $aPart['content-disposition']['value'], 9);
            if ( $bFormData !== true ) {
                // フォームのデータではない → 処理しない
                continue;
            }
            $sName           = $aPart['content-disposition']['name'];
            $aParams[$sName] = '';
        }
        $sOutput             = $this->_http_build_query($aParams, false, false, '&', true);
        return $sOutput;
    }

    /**
     * URIを分解
     *
     * @param   string  $sUri   URI
     * @return  array   分解された情報
     */
    protected function _breakDownUri($sUri)
    {
        // パラメータからクエリ以降を取得
        $bRetCode        = (bool) preg_match('!^([^?#]+)(?:\\?([^#]*))?(?:#(.*))?$!', $sUri, $aMatches);
        $aUriInfo        = array();
        if ( $bRetCode !== true ) {
            // マッチしないURIはないはず
            $aUriInfo    = array(
                'uri'      => $sUri,
                'query'    => '',
                'fragment' => '',
            );
        } else if ( $this->bLogStrippedValue === true ) {
            // マッチしたが値を除去
            $aUriInfo    = array(
                'uri'      => ArrayUtil::getValue($aMatches, 1, ''),
                'query'    => Util::stripValueString(ArrayUtil::getValue($aMatches, 2, '')),
                'fragment' => Util::stripValueString(ArrayUtil::getValue($aMatches, 3, '')),
            );
        } else {
            // マッチした
            $aUriInfo    = array(
                'uri'      => ArrayUtil::getValue($aMatches, 1, ''),
                'query'    => ArrayUtil::getValue($aMatches, 2, ''),
                'fragment' => ArrayUtil::getValue($aMatches, 3, ''),
            );
        }
        $aUriInfo['get'] = $aUriInfo['query'];
        return $aUriInfo;
    }

    /**
     * ヘッダからクッキーだけ取り出す
     *
     * @param   array   $aHeaders
     * @return  string  Cookie
     */
    protected function _extractCookie(array $aHeaders)
    {
        $aInput              = ArrayUtil::getValue(ArrayUtil::getValue($aHeaders, 'cookie', array()), 'value', array());
        $aOutput             = array();
        foreach ( $aInput as $i => $sCookie ) {
            if ( $this->bLogStrippedValue === true ) {
                $aOutput[$i] = Util::stripValueString($sCookie, ';');
            } else {
                $aOutput[$i] = $sCookie;
            }
        }
        $sCookies            = join('; ', $aOutput);
        return $sCookies;
    }
}
