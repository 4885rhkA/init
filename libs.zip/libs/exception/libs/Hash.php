<?php
/**
 * Hashの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs;

/**
 * Hashの例外
 */
class Hash extends \SC\exception\libs
{
}
