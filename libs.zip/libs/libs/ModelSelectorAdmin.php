<?php
/**
 * ModelSelectorAdmin
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 */
namespace SC\libs;

/**
 * ModelSelectorAdmin
 */
class ModelSelectorAdmin extends ModelSelector
{
    /**
     * モデルタイプ
     *
     *  production, admin, live, verify, develop
     *
     * @var string TYPE
     */
    const TYPE = 'admin';

    /**
     * 設定ディレクトリのベース
     *
     * @var string BASE
     */
    const BASE = FW_DIR;

    /**
     * 環境ディレクトリの指定
     *
     * @var string ENV_DIR
     */
    const ENV_DIR = 'contents';
}
