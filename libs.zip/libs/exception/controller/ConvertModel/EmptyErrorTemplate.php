<?php
/**
 * エラー時のテンプレートファイルの指定がなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\ConvertModel;

/**
 * エラー時のテンプレートファイルの指定がなかった場合の例外
 */
class EmptyErrorTemplate extends \SC\exception\controller\ConvertModel
{
}
