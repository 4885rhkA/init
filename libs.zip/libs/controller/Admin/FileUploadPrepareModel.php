<?php
/**
 * ファイルアップロード準備モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイルアップロード準備モデルコントローラ
 */
class FileUploadPrepareModel extends AbstractJSONModel
{
    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage    = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();

        $sSiteId         = $this->oLogin->getSiteId();
        // PATH_INFOからステージ種別を取得
        $sPathInfo       = $this->oRequest->getPathInfo();
        $sStage          = $this->oStage->getStageName($sPathInfo);
        // リクエストパラメータからアップロード先相対パスとファイル名を取得
        $sPath           = $this->oRequest->getRequest('path');
        // 1ファイルのアップロードのみ対応
        $aFile           = \ArrayUtil::getValue($this->oRequest->getFiles('name'), 0);

        try {
            $this->oStage->prepareUploadFile($sSiteId, $sStage, $sPath, $aFile);
            $this->aValues   = array(
                'path' => $sPath,
                'name' => \ArrayUtil::getValue($aFile, 'name'),
            );
        } catch (\Exception $oException) {
            $this->bHasError   = true;
            $this->sErrMessage = $oException->getMessage();
        }

        return parent::_process();
    }
}
