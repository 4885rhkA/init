<?php
/**
 * ファイルツリーモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイルツリーモデルコントローラ
 */
class FileTreeModel extends AbstractJSONModel
{
    /**
     * 生データのJSONを使用するか否か
     *
     * @var bool RAW_DATA_JSON
     */
    const RAW_DATA_JSON = true;

    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();
        $this->oStage    = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();
        try {
            // PATH_INFOからステージ種別を取得
            // ex.) /stage/live/file/tree.json
            $sPathInfo       = $this->oRequest->getPathInfo();
            $sStage          = $this->oStage->getStageName($sPathInfo);
            // リクエストパラメータからディレクトリ名を取得
            $sDirname        = $this->oRequest->getRequest('dir');
            $aTree           = $this->oStage->getFileTree($sStage, $sDirname, true);
        } catch (\Exception $oException) {
            //$this->bHasError   = true;
            //$this->sErrMessage = $oException->getMessage();
            //return parent::_process();
            $sOutput = \SC\libs\JSON::encode(array());
            $this->oResponse->setResult($sOutput, 200);
            return true;
        }
        $this->aValues   = $aTree;
        return parent::_process();
    }
}
