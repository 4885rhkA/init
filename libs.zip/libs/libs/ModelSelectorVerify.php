<?php
/**
 * ModelSelectorVerify
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 */
namespace SC\libs;

/**
 * ModelSelectorVerify
 */
class ModelSelectorVerify extends ModelSelector
{
    /**
     * モデルタイプ
     *
     *  production, admin, live, verify, develop
     *
     * @var string TYPE
     */
    const TYPE = 'verify';

    /**
     * 環境ディレクトリの指定
     *
     * @var string ENV_DIR
     */
    const ENV_DIR = 'contents/stage.verify';
}
