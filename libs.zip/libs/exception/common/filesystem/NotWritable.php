<?php
/**
 * 書込可能属性がない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\filesystem;

/**
 * 書込可能属性がない場合の例外
 */
class NotWritable extends \SC\exception\common\filesystem
{
}
