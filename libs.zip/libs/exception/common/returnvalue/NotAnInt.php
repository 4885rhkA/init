<?php
/**
 * パラメータが整数型ではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\returnvalue;

/**
 * パラメータが整数型ではなかった場合の例外
 */
class NotAnInt extends \SC\exception\common\returnvalue
{
}
