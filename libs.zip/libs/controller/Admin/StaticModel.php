<?php
/**
 * 静的ページモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * 静的ページモデルコントローラ
 */
class StaticModel extends AbstractTemplateModel
{
    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        return parent::_process();
    }
}
