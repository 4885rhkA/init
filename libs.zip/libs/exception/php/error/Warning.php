<?php
/**
 * 警告例外 (E_WARNING)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * 警告例外 (E_WARNING)
 */
class Warning extends \SC\exception\php\error
{
}
