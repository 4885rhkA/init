<?php
/**
 * 抽象インプットコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * 抽象インプットコントローラクラス
 */
abstract class AbstractInput extends AbstractController
{
    /**
     * 通常画面処理
     *
     * @var int PROCESS_INDEX
     */
    const PROCESS_INDEX = 1;

    /**
     * 管理画面処理
     *
     * @var int PROCESS_ADMIN
     */
    const PROCESS_ADMIN = 2;

    /**
     * 画面処理
     *
     * @var bool PROCESS
     */
    const PROCESS = self::PROCESS_INDEX;

    /**
     * エラーハンドラ
     *
     * @var string ERRORHANDLER
     */
    const ERRORHANDLER = 'SC\libs\ErrorHandler::show';

    /**
     * インスタンス配列
     *
     * @var array(SC\controller\AbstractInput) $aInstances
     */
    protected static $aInstances = array();

    /**
     * 初期化済みフラグ
     *
     * @var bool $bInitialized
     */
    protected static $bInitialized = false;

    /**
     * 別名化するクラスリスト
     *
     * @var array $aClassesAlias
     */
    protected $aClassesAlias = array(
        'Util'        => 'SC\libs\Util',
        'ArrayUtil'   => 'SC\libs\ArrayUtil',
        'Debug'       => 'SC\libs\Debug',
        'Request'     => 'SC\libs\Request',
        'Response'    => 'SC\libs\Response',
        'LogRegistry' => 'SC\libs\LogRegistry',
        'Log'         => 'SC\libs\Log',
        'Session'     => 'SC\libs\Session',
    );

    /**
     * リクエスト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * レスポンス
     *
     * @var SC\libs\Response $oResponse
     */
    protected $oResponse = NULL;

    /**
     * セッション
     *
     * @var SC\libs\Session $oSession
     */
    protected $oSession = NULL;

    /**
     * execute
     *
     * @return true
     */
    final public static function execute()
    {
        try {
            // umaskは共通
            umask(0);
            // インスタンスの生成
            $oSelf = static::_getInstance();
            // 初期化
            $oSelf->_initialize();
            // コントローラの処理実行
            $oSelf->_preProcess();
            $oSelf->_process();
            $oSelf->_postProcess();
            // 終了化
            $oSelf->_finalize();
        } catch (\Exception $oException) {
            // ログを出力
            \SC\libs\Log::exception($oException, __METHOD__ . '::' . __LINE__);
            // 例外画面の出力
            call_user_func(static::ERRORHANDLER, $oException, 500);
        }
        return true;
    }

    /**
     * インスタンスの取得
     *
     * @return  SC\controller\AbstractInput
     */
    final protected static function _getInstance()
    {
        // クラス名の取得
        $sClassName = get_called_class();
        // インスタンスの存在チェック
        $bRetCode   = isset(self::$aInstances[$sClassName]);
        if ( $bRetCode !== true ) {
            // 存在しなければ生成する
            self::$aInstances[$sClassName] = new static();
        }
        return self::$aInstances[$sClassName];
    }

    /**
     * 初期化処理
     *
     * @return  true
     * @throws  SC\exception\controller\AbstractInput\AlreadyInitialized
     */
    final protected function _initialize()
    {
        // インプットコントローラの多重実行か？
        if ( static::$bInitialized !== false ) {
            // 多重実行は例外
            throw new \SC\exception\controller\AbstractInput\AlreadyInitialized('Input controller has already been initialized.');
        }

        // 親クラスの初期化処理をコール
        parent::_initialize();

        // クラス別名をセット
        \SC\libs\ClassAlias::set($this->aClassesAlias);

        // 設定の読み込み
        // @todo 将来の機能

        // 必須インスタンスを集約
        $this->oRequest  = \Request::getInstance();
        $this->oResponse = \Response::getInstance();
        $this->oSession  = \Session::getInstance();

        // エラーハンドラの登録
        \SC\libs\ErrorHandler::regist();
        $iLogOnlyLevel   = $this->oRequest->getServer('SC_LOG_ONLY_LEVEL', '');
        if ( $iLogOnlyLevel !== '' ) {
            \SC\libs\ErrorHandler::setLogOnlyLevel($iLogOnlyLevel);
        }

        // 初期化済みフラグを立てる
        static::$bInitialized = true;
        return true;
    }

    /**
     * 前処理
     *
     * @return true
     */
    protected function _preProcess()
    {
        // ログ出力情報
        $aServerKeys     = explode(',', $this->oRequest->getServer('SC_REQUEST_LOG', 'REMOTE_ADDRS'));
        // ログ出力する
        $sPathInfo       = $this->oRequest->getPathInfo();
        $aMessages       = array(
            'URI Info:',
            'PATH_INFO'                    . '=[' . $sPathInfo . ']',
        );
        foreach ( $aServerKeys as $sKey ) {
            $mValue      = $this->oRequest->getServer($sKey, '');
            $bRetCode    = is_array($mValue);
            if ( $bRetCode === true ) {
                $mValue  = join(',', $mValue);
            }
            $aMessages[] = $sKey . '=[' . $mValue . ']';
        }
        \Log::info(join(' ', $aMessages));
        // リクエスト情報を保持
        $sProto          = $this->oRequest->getProto();
        $sHost           = $this->oRequest->getHost();
        $sQuery          = $this->oRequest->getServer('QUERY_STRING',  '');
        $oUri            = new \SC\libs\Uri($sPathInfo);
        $oUri->setScheme($sProto);
        $oUri->setHost($sHost);
        $oUri->setQuery($sQuery);
        $sUrl            = $oUri->build();
        \LogRegistry::save('sc:request', 'URL',           $sUrl);
        \LogRegistry::save('sc:request', 'URI_PROTO',     $sProto);
        \LogRegistry::save('sc:request', 'URI_HOST',      $sHost);
        \LogRegistry::save('sc:request', 'URI_PATH',      $sPathInfo);
        \LogRegistry::save('sc:request', 'URI_QUERY',     $sQuery);
        \LogRegistry::save('sc:request', 'URI_FRAGMENT',  '');
        \LogRegistry::save('sc:request', 'URI_PORT',      $this->oRequest->getPort());
        \LogRegistry::save('sc:request', 'URI_AUTH_USER', $this->oRequest->getServer('PHP_AUTH_USER', ''));
        \LogRegistry::save('sc:request', 'URI_AUTH_PASS', $this->oRequest->getServer('PHP_AUTH_PW',   ''));
        $aHeaders         = $this->oRequest->getRequestHeaders();
        foreach ( $aHeaders as $sName => $sValue ) {
            \LogRegistry::save('header:request', $sName, $sValue);
        }
        // 環境変数チェック
        switch ( static::PROCESS ) {
            case static::PROCESS_INDEX:
                $sProcess = strtolower($this->oRequest->getServer('SC_PROCESS_INDEX', '1'));
                if ( $sProcess !== '1' && $sProcess !== 'on' && $sProcess !== 'true' ) {
                    throw new \SC\exception\controller\AbstractInput\ForbiddenProcess('Input controller process is not forbidden.');
                }
                break;

            case static::PROCESS_ADMIN:
                $sProcess = strtolower($this->oRequest->getServer('SC_PROCESS_ADMIN', '0'));
                if ( $sProcess !== '1' && $sProcess !== 'on' && $sProcess !== 'true' ) {
                    throw new \SC\exception\controller\AbstractInput\ForbiddenProcess('Admin controller process is not forbidden.');
                }
                break;

            default:
                throw new \SC\exception\controller\AbstractInput\ForbiddenProcess('Unknown controller process is not forbidden.');
                break;
        }
        return true;
    }

    /**
     * 後処理
     *
     * @return true
     */
    protected function _postProcess()
    {
        // レスポンス情報を保持
        \LogRegistry::save('sc:display', 'URI_PROTO',     $this->oRequest->getProto());
        \LogRegistry::save('sc:display', 'URI_HOST',      $this->oRequest->getHost());
        \LogRegistry::save('sc:display', 'URI_PORT',      $this->oRequest->getPort());
        \LogRegistry::save('sc:display', 'URI_PATH',      $this->oRequest->getPathInfo());
        \LogRegistry::save('sc:display', 'URI_QUERY',     $this->oRequest->getServer('QUERY_STRING',  ''));
        \LogRegistry::save('sc:display', 'URI_FRAGMENT',  '');
        \LogRegistry::save('sc:display', 'URI_AUTH_USER', $this->oRequest->getServer('PHP_AUTH_USER', ''));
        \LogRegistry::save('sc:display', 'URI_AUTH_PASS', $this->oRequest->getServer('PHP_AUTH_PW',   ''));
        return true;
    }

    /**
     * 終了化処理
     *
     * @return true
     */
    final protected function _finalize()
    {
        // レスポンスの出力
        $this->oResponse->out();
        // 出力してからヘッダを保持
        $aHeaders                 = $this->oResponse->getResponseHeaders();
        if ( $aHeaders !== array() ) {
            $aCookies             = array();
            foreach ( $aHeaders as $sNameLower => $aSet ) {
                foreach ( $aSet as $aEach ) {
                    if ( $sNameLower !== 'set-cookie' ) {
                        // Set-Cookieでなければそのまま保存して次へ
                        \LogRegistry::save('header:display', $aEach['name'], $aEach['value']);
                        continue;
                    }
                    // Set-Cookieのみ配列で保存
                    $aCookies[]   = $aEach['value'];
                    $aCookieParts = explode('=', $aEach['value'], 2);
                    \LogRegistry::save('cookie:display', $aCookieParts[0], $aCookieParts[1]);
                }
            }
            if ( $aCookies !== array() ) {
                \LogRegistry::save('header:display', 'Set-Cookie', $aCookies);
            }
        }
        return true;
    }
}
