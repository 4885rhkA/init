<?php
/**
 * ログイン
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\model;

/**
 * ログイン
 */
class Login
{
    /**
     * セッションに保存する際のネームスペース
     *
     * @var string SESS_NS
     */
    const SESS_NS = 'login';

    /**
     * インスタンス
     *
     * @var SC\model\Login $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * セッション
     *
     * @var SC\libs\Session
     */
    protected $oSession = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        $this->oSession = \Session::getInstance();
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Login
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * ログイン
     *
     * @param   string  アカウント名
     * @param   string  パスワード
     * @return  bool    true/false
     * @throw   SC\exception\model\Login\NotLogin
     */
    public static function login($account, $password)
    {
        $oSelf     = static::getInstance();
        // 一旦セッションをクリア
        $oSelf->_clearAllSession();
        // ユーザ情報の取得
        $aUserInfo = $oSelf->_getUserInfo($account, $password);
        if ( $aUserInfo === NULL ) {
            return false;
        }
        // ログインセッションの作成
        return $oSelf->_storeLoginSession($aUserInfo, true);
    }

    /**
     * ログイン for プレビュー
     *
     * @param   string  アカウント名
     * @return  bool    true/false
     * @throw   SC\exception\model\Login\NotLogin
     */
    public static function loginForPreview($account)
    {
        $oSelf     = static::getInstance();
        // ユーザ情報の取得
        $aUserInfo = $oSelf->_getUserInfoNoPassword($account);
        if ( $aUserInfo === NULL ) {
            return false;
        }
        $bIsLogin  = (bool) $oSelf->_getSession('isLogin');
        // ログインセッションの作成
        return $oSelf->_storeLoginSession($aUserInfo, $bIsLogin);
    }

    /**
     * ログインセッションの保存
     *
     * @param   array   $aUserInfo  ユーザ情報
     * @param   bool    $bIsLogin   ログインしているか否か
     * @return  bool    true
     */
    protected function _storeLoginSession($aUserInfo, $bIsLogin)
    {
        $this->_setSession('isLogin',     (bool) $bIsLogin);
        $this->_setSession('canPreview',  true);
        $this->_setSession('userId',      $aUserInfo['id']);
        $this->_setSession('userAccount', $aUserInfo['account']);
        $this->_setSession('userName',    $aUserInfo['name']);
        $this->_setSession('userMail',    $aUserInfo['mail']);
        $this->_setSession('siteId',      $aUserInfo['site_id']);
        $this->_setSession('authority',   $aUserInfo['authority']);
        return true;
    }

    /**
     * ユーザ情報を取得する
     *
     * @param   string  アカウント名
     * @param   string  パスワード
     * @return  array   ユーザ情報
     * @return  NULL
     */
    protected function _getUserInfo($account, $password)
    {
        $aRecord = $this->_getUserInfoSelect($account);
        if ( $aRecord['id'] === NULL || $aRecord['password'] !== md5($password) ) {
            return NULL;
        }
        return $aRecord;
    }

    /**
     * ユーザ情報を取得する
     *
     * @param   string  アカウント名
     * @return  array   ユーザ情報
     * @return  NULL
     */
    protected function _getUserInfoNoPassword($account)
    {
        $aRecord = $this->_getUserInfoSelect($account);
        if ( $aRecord['id'] === NULL ) {
            return NULL;
        }
        return $aRecord;
    }

    /**
     * ユーザ情報を取得する
     *
     * @param   string  アカウント名
     * @return  array   ユーザ情報
     * @return  NULL
     */
    protected function _getUserInfoSelect($account)
    {
        $aSelect = array(
            'fields' => array(
                'id'        => array( 'name' => 'U.id',         'type' => 'int',    ),
                'password'  => array( 'name' => 'U.password',   'type' => 'string', ),
                'account'   => array( 'name' => 'U.account',    'type' => 'string', ),
                'name'      => array( 'name' => 'U.name',       'type' => 'string', ),
                'mail'      => array( 'name' => 'U.mail',       'type' => 'string', ),
                'site_id'   => array( 'name' => 'R.site_id',    'type' => 'string', ),
                'authority' => array( 'name' => 'R.authority',  'type' => 'int',    ),
            ),
            'froms'         => array(
                'U'         => array( 'name' => 'userinfo', ),
                'R'         => array( 'name' => 'usersites', 'type' => 'join', 'condition' => 'on U.id=R.user_id', ),
            ),
            'conditions'    => array(
                'where'     => 'U.delflag = 0 AND U.account = :account',
            ),
            'binds'         => array(
                ':account'  => $account,
            ),
            'onerecord'     => true,
        );
        $aRecord = \SC\libs\DB\SQLite::select($aSelect);
        return $aRecord;
    }

    /**
     * ログアウト
     */
    public static function logout()
    {
        $oSelf = static::getInstance();
        $oSelf->_clearAllSession();
        $oSelf->_destorySession();
        return true;
    }

    /**
     * ログインチェック
     *
     * @param   bool    $bThrowException
     * @return  bool    true
     */
    public static function check($bThrowException = true)
    {
        $oSelf = static::getInstance();
        return $oSelf->_check((bool) $bThrowException);
    }

    /**
     * ログインチェック
     *
     * @param   bool    $bThrowException
     * @return  bool    true/false
     * @throw   SC\exception\model\Login\NotLogin
     */
    protected function _check($bThrowException = true)
    {
        // ログイン済みか？
        $bIsLogin = (bool) $this->_getSession('isLogin');
        if ( $bIsLogin === true ) {
            // ログイン済みなら抜ける
            return true;
        }
        // 未ログイン
        if ( $bThrowException !== false ) {
            // 例外を投げる
            throw new \SC\exception\model\Login\NotLogin('Not login');
        }
        return false;
    }

    /**
     * ログインしているか否か
     *
     * @return  bool    true/false
     */
    public static function isLogin()
    {
        $oSelf    = static::getInstance();
        return (bool) $oSelf->_getSession('isLogin');
    }

    /**
     * プレビューは可能か否か
     *
     * @return  bool    true/false
     */
    public static function canPreview()
    {
        $oSelf           = static::getInstance();
        $bCanPreview     = (bool) $oSelf->_getSession('isLogin');
        if ( $bCanPreview !== true ) {
            $bCanPreview = (bool) $oSelf->_getSession('canPreview');
        }
        return $bCanPreview;
    }

    /**
     * ログイン情報を取得
     *
     * @return  array
     */
    public static function getData()
    {
        $oSelf = static::getInstance();
        return $oSelf->_getAllSession();
    }

    /**
     * ログインユーザのIDを取得
     *
     * @return  int
     */
    public static function getUserId()
    {
        $oSelf = static::getInstance();
        return (int) $oSelf->_getSession('userId');
    }

    /**
     * ログインユーザのアカウント名を取得
     *
     * @return  string
     */
    public static function getUserAccount()
    {
        $oSelf = static::getInstance();
        return (string) $oSelf->_getSession('userAccount');
    }

    /**
     * ログインユーザのユーザ名を取得
     *
     * @return  string
     */
    public static function getUserName()
    {
        $oSelf = static::getInstance();
        return (string) $oSelf->_getSession('userName');
    }

    /**
     * ログインユーザのメールアドレスを取得
     *
     * @return  string
     */
    public static function getUserMail()
    {
        $oSelf = static::getInstance();
        return (string) $oSelf->_getSession('userMail');
    }

    /**
     * Git用のAuthor文字列を取得
     *
     * @return  string
     */
    public static function getAuthor()
    {
        $oSelf    = static::getInstance();
        $sAccount = (string) $oSelf->_getSession('userAccount');
        $sMail    = (string) $oSelf->_getSession('userMail');
        $sAuthor  = $sAccount . ' <' . $sMail . '>';
        return $sAuthor;
    }

    /**
     * ログインユーザのサイトIDを取得
     *
     * @return  string
     */
    public static function getSiteId()
    {
        $oSelf = static::getInstance();
        return (string) $oSelf->_getSession('siteId');
    }

    /**
     * セッション情報を取得
     *
     * @param   string  $sKey
     * @return  mixed
     */
    protected function _getSession($sKey)
    {
        return $this->oSession->get($sKey, static::SESS_NS);
    }

    /**
     * セッション情報をセット
     *
     * @param   string  $sKey
     * @param   mixed   $mValue
     * @return  bool
     */
    protected function _setSession($sKey, $mValue)
    {
        return $this->oSession->set($sKey, $mValue, static::SESS_NS);
    }

    /**
     * セッション情報を取得
     *
     * @return  array
     */
    protected function _getAllSession()
    {
        return $this->oSession->getAll(static::SESS_NS);
    }

    /**
     * セッション情報をクリア
     *
     * @return  bool
     */
    protected function _clearAllSession()
    {
        return $this->oSession->clearAll(static::SESS_NS);
    }

    /**
     * セッション情報を破壊
     *
     * @return  bool
     */
    protected function _destorySession()
    {
        return $this->oSession->destory();
    }
}
