<?php
/**
 * プレビューセッションがNGな場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\Admin\PreviewCheckModel;

/**
 * プレビューセッションがNGな場合の例外
 */
class PreviewSessionNG extends \SC\exception\controller\Admin\PreviewCheckModel
{
}
