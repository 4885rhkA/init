<?php
/**
 * ユーザ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\model;
use SC\libs\DB as DB;

/**
 * ユーザ
 */
class User
{
    /**
     * インスタンス
     *
     * @var SC\model\User $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\model\User
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * ユーザ一覧を取得する
     *
     * @param   string  サイトID
     * @return  array   ユーザ一覧
     */
    public function getList($id)
    {
        // @todo 権限による処理分岐
        $aSelect = array(
            'fields' => array(
                'id'        => array( 'name' => 'U.id',         'type' => 'int',      ),
                'account'   => array( 'name' => 'U.account',    'type' => 'string',   ),
                'name'      => array( 'name' => 'U.name',       'type' => 'string',   ),
                'mail'      => array( 'name' => 'U.mail',       'type' => 'string',   ),
                'authority' => array( 'name' => 'R.authority',  'type' => 'int',      ),
            ),
            'froms'         => array(
                'R'         => array( 'name' => 'userSites', ),
                'U'         => array( 'name' => 'userInfo', 'type' => 'join', 'condition' => 'on R.user_id = U.id', ),
            ),
            'conditions'    => array(
                'where'     => 'U.delflag = 0 AND R.site_id = :id',
                'orderby'   => 'U.orderno',
            ),
            'binds'         => array(
                ':id'       => $id,
            ),
        );
        $aRecord = DB\SQLite::select($aSelect);
        return $aRecord;
    }
}
