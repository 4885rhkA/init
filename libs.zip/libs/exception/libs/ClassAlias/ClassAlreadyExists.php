<?php
/**
 * クラスが既に存在して別名を付与できない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\ClassAlias;

/**
 * クラスが既に存在して別名を付与できない場合の例外
 */
class ClassAlreadyExists extends \SC\exception\libs\ClassAlias
{
}
