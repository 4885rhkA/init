<?php
/**
 * コアエラー例外 (E_CORE_ERROR)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * コアエラー例外 (E_CORE_ERROR)
 */
class CoreError extends \SC\exception\php\error
{
}
