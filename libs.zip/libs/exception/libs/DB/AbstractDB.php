<?php
/**
 * AbstractDBの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\DB;

/**
 * AbstractDBの例外
 */
class AbstractDB extends \SC\exception\libs\DB
{
}
