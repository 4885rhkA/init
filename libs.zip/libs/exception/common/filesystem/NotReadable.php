<?php
/**
 * 読込可能属性がない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\filesystem;

/**
 * 読込可能属性がない場合の例外
 */
class NotReadable extends \SC\exception\common\filesystem
{
}
