<?php
/**
 * フィールドリストが空だった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\DB\AbstractDB;

/**
 * フィールドリストが空だった場合の例外
 */
class EmptyFieldList extends \SC\exception\libs\DB\AbstractDB
{
}
