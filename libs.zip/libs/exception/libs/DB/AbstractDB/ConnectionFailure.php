<?php
/**
 * DB接続ができなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\DB\AbstractDB;

/**
 * DB接続ができなかった場合の例外
 */
class ConnectionFailure extends \SC\exception\libs\DB\AbstractDB
{
}
