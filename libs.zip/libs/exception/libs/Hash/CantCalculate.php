<?php
/**
 * ハッシュ値の計算ができなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\Hash;

/**
 * ハッシュ値の計算ができなかった場合の例外
 */
class CantCalculate extends \SC\exception\libs\Hash
{
}
