<?php
/**
 * URI
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * URI
 */
class Uri
{
    /**
     * タイプ: 絶対URI
     *
     * @var int TYPE_ABSOLUTE
     */
    const TYPE_ABSOLUTE = 1;

    /**
     * タイプ: 相対URI（ホストあり）
     *
     * @var int TYPE_RELATIVE_HOST
     */
    const TYPE_RELATIVE_HOST = 2;

    /**
     * タイプ: 相対URI（ホストなし）
     *
     * @var int TYPE_RELATIVE_NOHOST
     */
    const TYPE_RELATIVE_NOHOST = 3;

    /**
     * タイプ: 相対URI（相対パス）
     *
     * @var int TYPE_RELATIVE_PATH
     */
    const TYPE_RELATIVE_PATH = 4;

    /**
     * タイプ: 相対URI（ホストなし）
     *
     * @var int TYPE_RELATIVE
     */
    const TYPE_RELATIVE = self::TYPE_RELATIVE_NOHOST;

    /**
     * タイプ
     * URIのパターン → ホスト名かパスセグメントのいずれかは必ずある
     *  - 絶対パス
     *      - タイプ１  scheme ":" "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
     *  - 相対パス
     *      - タイプ２  "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
     *      - タイプ３  "/" path_seg [ "?" query ] [ "#" fragment ]
     *      - タイプ４  path_seg [ "?" query ] [ "#" fragment ]
     *
     *  - httpではないタイプ (mailtoやftpなど)
     *      - タイプ５  scheme ":" [ "//" ] [ userinfo "@" ] ( hostname | IPv4addr ) [ "/" path_seg ]
     *
     * @var int $iType
     */
    protected $iType = self::TYPE_ABSOLUTE;

    /**
     * URI構成パーツ
     *
     * @var array(string => string) $aUri
     */
    protected $aUri = array(
        'scheme'     => NULL,
        'host'       => NULL,
        'port'       => NULL,
        'user'       => NULL,
        'pass'       => NULL,
        'path'       => NULL,
        'query'      => NULL,
        'fragment'   => NULL,
        'hasscheme'  => false,
        'hostprefix' => false,
    );

    /**
     * URI構成パーツ(オリジナル)
     *
     * @var array(string => string) $aUriOriginal
     */
    protected $aUriOriginal = array(
        'scheme'     => NULL,
        'host'       => NULL,
        'port'       => NULL,
        'user'       => NULL,
        'pass'       => NULL,
        'path'       => NULL,
        'query'      => NULL,
        'fragment'   => NULL,
        'hasscheme'  => false,
        'hostprefix' => false,
    );

    /**
     * 生URI
     *
     * @var string $sRawURI
     */
    protected $sRawURI = '';

    /**
     * カレントディレクトリ
     *
     * @var string $sCWDir
     */
    protected $sCWDir = '';

    /**
     * スキームごとのホスト部分に指定する接頭辞(//)
     *
     * @var array $aHostPrefixes
     */
    protected $aHostPrefixes = array(
        'http'   => '//',
        'https'  => '//',
        'ftp'    => '//',
        'ftps'   => '//',
    );

    /**
     * ストリップ指定: 不明
     *
     * @var int STRIP_UNKNOWN
     */
    const STRIP_UNKNOWN = 0;

    /**
     * ストリップ指定: なし
     *
     * @var int STRIP_NONE
     */
    const STRIP_NONE = 1;

    /**
     * ストリップ指定: スキーム
     *
     * @var int STRIP_SCHEME
     */
    const STRIP_SCHEME = 2;

    /**
     * ストリップ指定: ホスト
     *
     * @var int STRIP_HOST
     */
    const STRIP_HOST = 4;

    /**
     * ストリップ指定: パス
     *
     * @var int STRIP_PATH
     */
    const STRIP_PATH = 8;

    /**
     * ストリップ指定: クエリ
     *
     * @var int STRIP_QUERY
     */
    const STRIP_QUERY = 16;

    /**
     * ストリップ指定: フラグメント
     *
     * @var int STRIP_FLAGUMENT
     */
    const STRIP_FLAGUMENT = 32;

    /**
     * ストリップ指定: パス(正規化不要)
     *
     * @var int STRIP_PATH_NORMALIZE
     */
    const STRIP_PATH_NORMALIZE = 256;

    /**
     * ストリップ指定: パス(カレントディレクトリを付加しない)
     *
     * @var int STRIP_PATH_ABSOLUTE
     */
    const STRIP_PATH_ABSOLUTE = 512;

    /**
     * ストリップ指定
     *
     * @var int $iStrip
     */
    protected $iStrip = self::STRIP_UNKNOWN;

    /**
     * パース直前にかけるフィルタ
     *
     * @var array $aInputFilters
     */
    protected static $aInputFilters = array(
    );

    /**
     * コンストラクタ
     *
     * @param   string  $sUri
     * @param   string  $bOrigPath
     */
    public function __construct($sUri, $bOrigPath = false)
    {
        // ストリップ指定
        // PHP5.5では定数式に対応していないため互換性のためにプロパティにしない
        // http://php.net/manual/ja/migration56.new-features.php#migration56.new-features.const-scalar-exprs
        $aStrips                    = array(
            'http'       => self::STRIP_NONE,
            'https'      => self::STRIP_NONE,
            'ftp'        => self::STRIP_NONE,
            'ftps'       => self::STRIP_NONE,
            'mailto'     => self::STRIP_HOST|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
            'tel'        => self::STRIP_HOST|self::STRIP_QUERY|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
            'javascript' => self::STRIP_HOST|self::STRIP_QUERY|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
            'vbscript'   => self::STRIP_HOST|self::STRIP_QUERY|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
            'script'     => self::STRIP_HOST|self::STRIP_QUERY|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
            'news'       => self::STRIP_HOST|self::STRIP_QUERY|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
            'urn'        => self::STRIP_HOST|self::STRIP_QUERY|self::STRIP_FLAGUMENT|self::STRIP_PATH_NORMALIZE,
        );

        // パース
        $aParts                     = $this->parse_url($sUri, true, $bOrigPath);
        $this->aUri                 = ArrayUtil::unite($this->aUri, $aParts, true);
        $this->aUriOriginal         = $this->aUri;
        $this->sRawURI              = $sUri;
        // カレントを保持しておく
        $this->sCWDir               = preg_replace('#/[^/]+$#', '/', Request::getPathInfo());
        if ( $this->aUri['scheme'] === NULL ) {
            $this->sHostPrefix      = $this->aHostPrefixes[Request::getProto()];
            $this->iStrip           = $aStrips            [Request::getProto()];
        } else {
            $this->sHostPrefix          = ArrayUtil::getValue($this->aHostPrefixes, (string) $this->aUri['scheme'], $this->aUri['hostprefix']);
            $this->iStrip               = ArrayUtil::getValue($aStrips,             (string) $this->aUri['scheme'], static::STRIP_UNKNOWN);
        }
        // URIのパターン → ホスト名かパスセグメントのいずれかは必ずある
        //  - 絶対パス
        //      - タイプ１  scheme ":" "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
        //  - 相対パス
        //      - タイプ２  "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
        //      - タイプ３  "/" path_seg [ "?" query ] [ "#" fragment ]
        //      - タイプ４  path_seg [ "?" query ] [ "#" fragment ]

        if ( $this->aUri['scheme'] !== NULL ) {
            // schemeがあれば絶対パス
            $this->iType            = static::TYPE_ABSOLUTE;
            if ( $this->aUri['host'] === NULL ) {
                if ( $this->iStrip !== static::STRIP_UNKNOWN && ( $this->iStrip & static::STRIP_HOST ) !== static::STRIP_HOST ) {
                    // ホストなしはNG → 取得して保持する
                    $this->aUri['host'] = Request::getHost();
                }
            }
        } else {
            // 相対パス
            if ( $this->aUri['path'] === NULL ) {
                // パスがなければ "/" と仮定する
                $this->aUri['path'] = Request::getPathInfo();
            }
            if ( $this->aUri['host'] !== NULL ) {
                // ホストあり
                $this->iType        = static::TYPE_RELATIVE_HOST;
                // 本来はパスなしがOKだが，実質的に "/" なのでなしには対応しない
            } else {
                $bIsRelativePath    = (bool) strncmp($this->aUri['path'], '/', 1);
                if ( $bIsRelativePath === true ) {
                    // "/"で始まっていない
                    $this->iType    = static::TYPE_RELATIVE_PATH;
                    // この場合のみパスの解決が必要
                } else {
                    // "/"で始まっている → 絶対パスの相対URI
                    $this->iType    = static::TYPE_RELATIVE_NOHOST;
                }
            }
        }
        // タイプ判定を終えてから先頭がカレントの場合のパスを補正する
        $this->aUri['path']         = preg_replace('#((?:^|/)\.{1,2})$#u', '$1/', $this->aUri['path']);
        $this->aUri['path']         = preg_replace('#^\./#u', $this->sCWDir, $this->aUri['path']);
    }

    /**
     * 絶対URIに変換する
     *
     * @param   string  $sUri
     * @param   int     $iType
     * @return  string  変換したURI
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function convAbsolute($sUri, $iType = self::TYPE_ABSOLUTE)
    {
        // 入力チェック
        $bRetCode = Validate::isStringNotZero($sUri);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Uri must be non-zero byte string.');
        }
        // 生成して返す
        $oSelf    = new static($sUri);
        return $oSelf->build($iType);
    }

    /**
     * 相対URIに変換する
     *
     * @param   string  $sUri
     * @param   int     $iType
     * @return  string  変換したURI
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function convRelative($sUri, $iType = self::TYPE_RELATIVE)
    {
        // 入力チェック
        $bRetCode = Validate::isStringNotZero($sUri);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Uri must be non-zero byte string.');
        }
        // 生成して返す
        $oSelf    = new static($sUri);
        return $oSelf->build($iType);
    }

    /**
     * URIをパース
     *
     * @param   string      $sUri
     * @param   bool        $bRefine
     * @param   bool        $bOrigPath
     * @return  array       parse_urlの結果
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\libs\Uri\CantParseUri
     */
    public static function parse_url($sUri, $bRefine = false, $bOrigPath = false)
    {
        // 入力チェック
        $bRetCode             = Validate::isStringNotZero($sUri);
        if ( $bRetCode !== true ) {
            // 空文字の場合はカレントと仮定
            $sUri             = Request::getPathInfo();
        }
        $sUri                 = trim($sUri);
        $bFound               = (bool) preg_match('#(?:^([A-Za-z][0-9A-Za-z\x2b\x2d\x2e]*):(//)?|^(//))(.)#usS', $sUri, $aMatches);
        $bHasScheme           = false;
        $sHostPrefix          = '//';
        if ( $bFound === true ) {
            if ( $aMatches[1] !== '' ) {
                $bHasScheme   = true;
            }
            $sHostPrefix      = $aMatches[2] . $aMatches[3];
        }
        $aFilterSearches      = array_keys(static::$aInputFilters);
        if ( $aFilterSearches !== array() ) {
            $aFilterReplaces  = array_values(static::$aInputFilters);
            $sUri             = preg_replace($aFilterSearches, $aFilterReplaces, $sUri);
        }
        if ( $bHasScheme !== true && $sHostPrefix !== '' ) {
            $sUri             = Request::getProto() . ':' . $sUri;
        }
        if ( $bRefine !== false ) {
            $sUri             = Util::refine($sUri, $bOrigPath);
        }
        $aParts               = parse_url($sUri);
        if ( $aParts === false ) {
            throw new \SC\exception\libs\Uri\CantParseUri("Can't parse URI for '{$sUri}'");
        }
        if ( $bHasScheme !== true ) {
            $aParts['scheme'] = NULL;
        }
        $aParts['hasscheme']  = $bHasScheme;
        $aParts['hostprefix'] = $sHostPrefix;
        return $aParts;
    }

    /**
     * URIをビルド
     *
     * @param   int     $iType
     * @param   bool    $bOriginal
     * @return  string
     */
    public function build($iType = NULL, $bOriginal = false)
    {
        // 取得
        if ( $bOriginal === true ) {
            $aUri                   = $this->aUriOriginal;
        } else {
            $aUri                   = $this->aUri;
        }
        switch ( $iType ) {
            case static::TYPE_ABSOLUTE:
            case static::TYPE_RELATIVE:
            case static::TYPE_RELATIVE_HOST:
            case static::TYPE_RELATIVE_NOHOST:
            case static::TYPE_RELATIVE_PATH:
                break;
            default:
                $iType              = $this->iType;
                break;
        }

        // URIのパターン
        //  - 絶対パス
        //      - TYPE_ABSOLUTE         scheme ":" "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
        //  - 相対パス
        //      - TYPE_RELATIVE_HOST    "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
        //      - TYPE_RELATIVE         "/" path_seg [ "?" query ] [ "#" fragment ]
        //      - TYPE_RELATIVE_PATH    path_seg [ "?" query ] [ "#" fragment ]

        $aParts                 = array();
        if ( ( $this->iStrip & static::STRIP_SCHEME ) !== static::STRIP_SCHEME ) {
            if ( $iType === static::TYPE_ABSOLUTE ) {
                if ( $aUri['scheme'] !== NULL ) {
                    $aParts[]       = $aUri['scheme'];
                } else {
                    // 絶対URIにschemeは必須
                    $aParts[]       = Request::getProto();
                }
                $aParts[]           = ':';
            }
        }
        if ( ( $this->iStrip & static::STRIP_HOST ) !== static::STRIP_HOST ) {
            if ( $iType === static::TYPE_ABSOLUTE || $iType === static::TYPE_RELATIVE_HOST ) {
                $aParts[]           = $this->sHostPrefix;
                if ( $aUri['user'] !== NULL ) {
                    $aParts[]       = $aUri['user'];
                    if ( $aUri['pass'] !== NULL ) {
                        $aParts[]   = ':' . $aUri['pass'];
                    }
                    $aParts[]       = '@';
                }
                if ( $aUri['host'] !== NULL || $this->iStrip === static::STRIP_UNKNOWN ) {
                    $aParts[]       = $aUri['host'];
                } else {
                    // ホストありで指定がなければ取得する
                    $aParts[]       = Request::getHost();
                }
                if ( $aUri['port'] !== NULL ) {
                    $aParts[]       = ':' . $aUri['port'];
                }
            }
        }
        // パス
        if ( ( $this->iStrip & static::STRIP_PATH ) !== static::STRIP_PATH ) {
            if ( ( $this->iStrip & static::STRIP_PATH_NORMALIZE ) === static::STRIP_PATH_NORMALIZE || $this->iStrip === static::STRIP_UNKNOWN ) {
                $sPath              = $aUri['path'];
            } else {
                $sPath              = $this->_getNormalizedPath($aUri['path'], $iType);
            }
            if ( $iType !== static::TYPE_RELATIVE_PATH ) {
                // 絶対パスにする
                if ( $this->iType !== static::TYPE_RELATIVE_PATH ) {
                    // 絶対パスを絶対パスで出力するのでそのままでOK
                    $aParts[]       = $sPath;
                } else {
                    // 相対パスを絶対パスで出力するので正規化する
                    $aParts[]       = $sPath;
                }
            } else {
                // 相対パスで出力する
                $iCmp               = strncmp($sPath, $this->sCWDir, strlen($this->sCWDir));
                if ( $iCmp !== 0 || $sPath === $this->sCWDir ) {
                    // カレントディレクトリではないもしくは完全一致なのでそのまま保持
                    $aParts[]       = $sPath;
                } else {
                    // カレントディレクトリであれば除去する
                    $aParts[]       = substr($sPath, strlen($this->sCWDir));
                }
            }
        }
        // クエリとフラグメント
        if ( ( $this->iStrip & static::STRIP_QUERY ) !== static::STRIP_QUERY ) {
            if ( $aUri['query'] !== NULL ) {
                $aParts[]           = '?' . $aUri['query'];
            }
        }
        if ( ( $this->iStrip & static::STRIP_FLAGUMENT ) !== static::STRIP_FLAGUMENT ) {
            if ( $aUri['fragment'] !== NULL ) {
                $aParts[]           = '#' . $aUri['fragment'];
            }
        }
        $sUri                       = join('', $aParts);
        return $sUri;
    }

    /**
     * パスを正規化
     *
     * @param   int     $iType
     * @return  bool    true
     */
    public function normalizePath($iType = self::TYPE_RELATIVE)
    {
        switch ( $iType ) {
            case static::TYPE_ABSOLUTE:
            case static::TYPE_RELATIVE:
            case static::TYPE_RELATIVE_HOST:
            case static::TYPE_RELATIVE_NOHOST:
            case static::TYPE_RELATIVE_PATH:
                break;
            default:
                $iType              = $this->iType;
                break;
        }
        // パスを正規化する
        $this->aUri['path'] = $this->_getNormalizedPath($this->aUri['path'], $iType);
        return true;
    }

    /**
     * パスを正規化
     *
     * @param   string  パス
     * @return  string  正規化済みのパス
     */
    protected function _getNormalizedPath($sRawPath, $iType = self::TYPE_RELATIVE)
    {
        // パスを正規化
        $sNormalized         = Util::normalizePath($sRawPath, $this->sCWDir, '/', false);
        if ( $sNormalized === '' ) {
            // 正規化して空文字が返ってきた場合には / になっているはず
            $sNormalized     = '/';
        }
        if ( $iType !== static::TYPE_RELATIVE_PATH ) {
            // URIのパターン
            //  - 絶対パス
            //      - TYPE_ABSOLUTE         scheme ":" "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
            //  - 相対パス
            //      - TYPE_RELATIVE_HOST    "//" [ userinfo "@" ] ( hostname | IPv4addr ) [ ":" port ] [ "/" path_seg ] [ "?" query ] [ "#" fragment ]
            //      - TYPE_RELATIVE         "/" path_seg [ "?" query ] [ "#" fragment ]
            //      - TYPE_RELATIVE_PATH    path_seg [ "?" query ] [ "#" fragment ]
            $iCmp            = strncmp('/', $sNormalized, 1);
            if ( $iCmp !== 0 ) {
                // パスは/で始まっていない
                $sNormalized = rtrim($this->sCWDir, '/')  . "/$sNormalized";
            }
        }
        return $sNormalized;
    }

    /**
     * URIのゲッター
     *
     * @param   string  $sKey
     * @param   bool    $bOriginal
     * @return  mixed
     * @throw   SC\exception\common\parameter\NotAString
     */
    public function get($sKey = '', $bOriginal = false)
    {
        // 無指定の場合にはすべて返す
        if ( $sKey === '' ) {
            if ( $bOriginal === true ) {
                return $this->aUriOriginal;
            } else {
                return $this->aUri;
            }
        }
        // 入力チェック
        $bRetCode = Validate::isString($sKey);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Key parameter is not a string.');
        }
        // 指定がある場合にはチェック
        $bRetCode = isset($this->aUri[$sKey]);
        if ( $bRetCode === true ) {
            // 指定あり → 返す
            if ( $bOriginal === true ) {
                return $this->aUriOriginal[$sKey];
            } else {
                return $this->aUri[$sKey];
            }
        }
        // ない → 空文字を返す
        return '';
    }

    /**
     * URIスキーマのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getScheme($bOriginal = false)
    {
        return $this->get('scheme', $bOriginal);
    }

    /**
     * URIホストのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getHost($bOriginal = false)
    {
        return $this->get('host', $bOriginal);
    }

    /**
     * URIポートのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getPort($bOriginal = false)
    {
        return $this->get('port', $bOriginal);
    }

    /**
     * URIユーザのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getUser($bOriginal = false)
    {
        return $this->get('user', $bOriginal);
    }

    /**
     * URIパスワードのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getPass($bOriginal = false)
    {
        return $this->get('pass', $bOriginal);
    }

    /**
     * URIパスのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getPath($bOriginal = false)
    {
        return $this->get('path', $bOriginal);
    }

    /**
     * URIクエリのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getQuery($bOriginal = false)
    {
        return $this->get('query', $bOriginal);
    }

    /**
     * URIクエリパラメータのゲッター
     *
     * @param   bool    $bOriginal
     * @return  array
     */
    public function getParams($bOriginal = false)
    {
        // クエリを取得
        $sQuery = $this->get('query', $bOriginal);
        if ( $sQuery === '' ) {
            // 空なら空配列
            return array();
        }
        // 配列にパースして返す
        parse_str($sQuery, $aParams);
        return $aParams;
    }

    /**
     * URIフラグメントのゲッター
     *
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getFragment($bOriginal = false)
    {
        return $this->get('fragment', $bOriginal);
    }

    /**
     * URIのゲッター
     *
     * @param   int     $iType
     * @param   bool    $bOriginal
     * @return  string
     */
    public function getUri($iType = self::TYPE_RELATIVE, $bOriginal = false)
    {
        return $this->build($iType, $bOriginal);
    }

    /**
     * URIのセッター
     *
     * @param   string          $sKey
     * @param   string|int|NULL $mValue
     * @return  bool            true
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\common\parameter\NotAString
     * @throw   SC\exception\common\parameter\NotAnInt
     * @throw   SC\exception\common\parameter\OutOfRange
     */
    public function set($sKey, $mValue)
    {
        // 入力チェック
        $bRetCode = Validate::isStringNotZero($sKey);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Key parameter is not a string or a zero byte string.');
        }
        // 入力チェック
        if ( $mValue !== NULL ) {
            // NULL以外ならチェック
            if ( $sKey !== 'port' ) {
                $bRetCode = Validate::isString($mValue);
                if ( $bRetCode !== true ) {
                    throw new \SC\exception\common\parameter\NotAString('Value parameter is not a string.');
                }
            } else {
                $bRetCode = Validate::isInt($mValue);
                if ( $bRetCode !== true ) {
                    throw new \SC\exception\common\parameter\NotAnInt('Value parameter is not an int.');
                }
                if ( $mValue < 1 || 65535 < $mValue ) {
                    throw new \SC\exception\common\parameter\OutOfRange('Value parameter must be in [1-65535].');
                }
                $mValue = (int) $mValue;
            }
        }
        // 指定がある場合にはキーをチェック
        $bRetCode = array_key_exists($sKey, $this->aUri);
        if ( $bRetCode !== true ) {
            // キーがない → セットしない
            return false;
        }

        // 指定あり → セット
        $this->aUri[$sKey] = $mValue;
        return true;
    }

    /**
     * URIスキーマのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setScheme($sValue)
    {
        return $this->set('scheme', $sValue);
    }

    /**
     * URIホストのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setHost($sValue)
    {
        return $this->set('host', $sValue);
    }

    /**
     * URIホストのセッター
     *
     * @param   int     $iValue
     * @return  bool    true
     */
    public function setPort($iValue)
    {
        return $this->set('port', $iValue);
    }

    /**
     * URIユーザのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setUser($sValue)
    {
        return $this->set('user', $sValue);
    }

    /**
     * URIパスワードのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setPass($sValue)
    {
        return $this->set('pass', $sValue);
    }

    /**
     * URIパスのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setPath($sValue)
    {
        return $this->set('path', $sValue);
    }

    /**
     * URIクエリのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setQuery($sValue)
    {
        return $this->set('query', $sValue);
    }

    /**
     * URIクエリパラメータのセッター
     *
     * @param   array   $aParams
     * @return  bool    true
     */
    public function setParams(array $aParams)
    {
        // 空配列か？
        $iCount = count($aParams);
        if ( $iCount < 1 ) {
            // 空配列なら空
            $sQuery = '';
        } else {
            // クエリを生成
            $sQuery = http_build_query($aParams, '', '&');
        }
        return $this->set('query', $sQuery);
    }

    /**
     * URIフラグメントのセッター
     *
     * @param   string  $sValue
     * @return  bool    true
     */
    public function setFragment($sValue)
    {
        return $this->set('fragment', $sValue);
    }

    /**
     * URIクエリパラメータの追加
     *
     * @param   string  $sValue
     * @param   bool    $bOverwrite
     * @return  bool    true
     */
    public function addQuery($sValue, $bOverwrite = true)
    {
        // 空文字なら終わり
        if ( $sValue === '' ) {
            return true;
        }
        // 入力チェック
        $bRetCode = Validate::isString($sValue);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Value parameter is not a string.');
        }
        parse_str($sValue, $aParams);
        return $this->addParams($aParams, $bOverwrite);
    }

    /**
     * URIクエリパラメータの追加
     *
     * @param   array   $aParams
     * @param   bool    $bOverwrite
     * @return  bool    true
     */
    public function addParams(array $aParams, $bOverwrite = true)
    {
        // 空配列か？
        $iCount = count($aParams);
        if ( $iCount < 1 ) {
            // 空配列なら終わり
            return true;
        }
        // 現在のパラメータに追加
        $aParams = ArrayUtil::unite($this->getParams(false), $aParams, $bOverwrite);
        return $this->setParams($aParams);
    }

    /**
     * 生URIのゲッター
     *
     * @param   string  $sUri
     * @return  bool    true
     */
    public function getRawUri()
    {
        return $this->sRawURI;
    }

    /**
     * ストリップ指定のセッター
     *
     * @param   int     $iStrip
     * @return  bool    true
     */
    public function setStrip($iStrip)
    {
        $this->iStrip = (int) $iStrip;
        return true;
    }

    /**
     * テスト
     *
     * @param   array   $aPatterns
     * @return  bool    true
     */
    public static function testPattern(array $aPatterns = array())
    {
        if ( $aPatterns === array() ) {
            $aPatterns = [
                // URLのパターン
                // 1    2    3        4        5   6        7           8
                'http://user:password@hostname:1234/path/to?query=query#fragment:path/to',      // 1,2,3,4,5,6,7,8
                'http://user:password@hostname:1234/path/to?query=query',                       // 1,2,3,4,5,6,7
                'http://user:password@hostname:1234/path/to#fragment:path/to',                  // 1,2,3,4,5,6,  8
                'http://user:password@hostname:1234/?query=query#fragment:path/to',             // 1,2,3,4,5,  7,8  only /
                'http://user:password@hostname:1234?query=query#fragment:path/to',              // 1,2,3,4,5,  7,8
                'http://user:password@hostname/path/to?query=query#fragment:path/to',           // 1,2,3,4,  6,7,8
                'http://user:password:1234/path/to?query=query#fragment:path/to',               // 1,2,3,  5,6,7,8
                'http://user@hostname:1234/path/to?query=query#fragment:path/to',               // 1,2,  4,5,6,7,8
                'http://:password@hostname:1234/path/to?query=query#fragment:path/to',          // 1,  3,4,5,6,7,8
                'http://hostname:1234/path/to?query=query#fragment:path/to',                    // 1,    4,5,6,7,8
                '//user:password@hostname:1234/path/to?query=query#fragment:path/to',           //   2,3,4,5,6,7,8

                // https
                'https://user:password@hostname:1234/path/to?query=query#fragment:path/to',     // 1,2,3,4,5,6,7,8

                // URLの典型的なパターン
                'http://hostname/path/to?query',
                '//hostname/path/to?query',
                'http:/path/to?query',
                'http://www.ietf.org/rfc/rfc2396.txt',

                // http/httpsではないパターン
                'javascript:void(0);',
                'void(0);',
                '../../../../void(0);',
                'ftp://user@domain/path/to',
                'ftp://ftp.is.co.za/rfc/rfc1808.txt',
                'ldap://[2001:db8::7]/c=GB?objectClass?one',
                'mailto:John.Doe@example.com',
                'mailto:John.Doe@example.com?subject=テスト&body=本文',
                'news:comp.infosystems.www.servers.unix',
                'tel:+1-816-555-1212',
                'telnet://192.0.2.16:80/',
                'urn:oasis:names:specification:docbook:dtd:xml:4.1.2',
                'foo://info.example.com?fred',

                // パスのパターン
                'g:h',                  // 'g:h'
                'g',                    // 'http://a/b/c/g'
                './g',                  // 'http://a/b/c/g'
                'g/',                   // 'http://a/b/c/g/'
                '/g',                   // 'http://a/g'
                '//g',                  // 'http://g'
                '?y',                   // 'http://a/b/c/d;p?y'
                'g?y',                  // 'http://a/b/c/g?y'
                '#s',                   // 'http://a/b/c/d;p?q#s'
                'g#s',                  // 'http://a/b/c/g#s'
                'g?y#s',                // 'http://a/b/c/g?y#s'
                ';x',                   // 'http://a/b/c/;x'
                'g;x',                  // 'http://a/b/c/g;x'
                'g;x?y#s',              // 'http://a/b/c/g;x?y#s'
                '',                     // 'http://a/b/c/d;p?q'
                '.',                    // 'http://a/b/c/'
                './',                   // 'http://a/b/c/'
                '..',                   // 'http://a/b/'
                '../',                  // 'http://a/b/'
                '../g',                 // 'http://a/b/g'
                '../..',                // 'http://a/'
                '../../',               // 'http://a/'
                '../../g',              // 'http://a/g'

                // パスのイレギュラーなパターン
                'path///to',
                'path///to' . preg_replace('#/[^/]+$#', '/', Request::getPathInfo()) . 'path/to///..///path/to?query=path/to///..///path/to#flagment:path/to///..///path/to',
                '/path///to' . preg_replace('#/[^/]+$#', '/', Request::getPathInfo()) . 'path/to///..///path/to?query=path/to///..///path/to#flagment:path/to///..///path/to',
            ];
        }
        $iLen    = max(array_map('strlen', $aPatterns));
        $aResult = [];
        foreach ( $aPatterns as $sEach ) {
            $oSelf = new static($sEach);
            $aResult[str_pad($sEach, $iLen)] = [
                'NULL                ' => $oSelf->build(),
                'TYPE_ABSOLUTE       ' => $oSelf->build(static::TYPE_ABSOLUTE),
                'TYPE_RELATIVE       ' => $oSelf->build(static::TYPE_RELATIVE),
                'TYPE_RELATIVE_HOST  ' => $oSelf->build(static::TYPE_RELATIVE_HOST),
                'TYPE_RELATIVE_NOHOST' => $oSelf->build(static::TYPE_RELATIVE_NOHOST),
                'TYPE_RELATIVE_PATH  ' => $oSelf->build(static::TYPE_RELATIVE_PATH),
            ];
        }
        \Debug::dump($aResult);
        return true;
    }
}
