<?php
/**
 * controllerの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception;

/**
 * controllerの例外
 */
class controller extends \SC\exception\AbstractException
{
}
