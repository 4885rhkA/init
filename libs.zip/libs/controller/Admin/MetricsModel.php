<?php
/**
 * メトリクスモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * メトリクスモデルコントローラ
 */
class MetricsModel extends AbstractJSONModel
{
    /**
     * メトリクスディレクトリ
     *
     * @var BASE
     */
    const BASE = 'tmp/metrics';

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        try {
            // ログインチェック
            $this->_checkLogin();
            // 期間を取得
            // 集計方法
            //  [common]
            //      string  type    集計タイプ      absolute, relative              default: relative
            //      int     period  集計単位        正の整数                        default: 86400
            //  [absolute]
            //      string  from    開始日時        Y/m/d   |   Y/m/d H:i           必須
            //      string  to      終了日時        Y/m/d   |   Y/m/d H:i           必須
            //  [relative]
            //      int     from    開始日時        正の整数                        default: 1
            //      int     to      終了日時        正の整数 or 0                   default: 0
            //      string  unit    期間単位        mon | day | hour | min          default: mon
            $sType             = (string) $this->oRequest->getRequest('type',   'relative');
            $iPeriod           = (int)    $this->oRequest->getRequest('period', 86400);
            if ( $sType === 'absolute' ) {
                $sFrom         = (string) $this->oRequest->getRequest('from',   '');
                $sTo           = (string) $this->oRequest->getRequest('to',     '');
                $this->aValues = $this->_getMetricsAbsolute($sFrom, $sTo, $iPeriod);
            } else {
                $iFrom         = (int)    $this->oRequest->getRequest('from',   1);
                $iTo           = (int)    $this->oRequest->getRequest('to',     0);
                $sUnit         = (string) $this->oRequest->getRequest('unit',   'mon');
                $this->aValues = $this->_getMetricsRelative($iFrom, $iTo, $sUnit, $iPeriod);
            }
        } catch (\Exception $oException) {
            $this->bHasError   = true;
            $this->sErrMessage = $oException->getMessage();
            return parent::_process();
        }
        return parent::_process();
    }

    /**
     * メトリクスを取得
     *
     * @param   string  $sFrom      開始日時    Y/m/d | Y/m/d H:i
     * @param   string  $sTo        終了日時    Y/m/d | Y/m/d H:i
     * @param   int     $iPeriod    集計単位    正の整数 default: 86400
     * @return  array   メトリクス情報
     * @throw   \SC\exception\common\parameter\ZeroByteString
     * @throw   \SC\exception\common\parameter\NotAnInt
     */
    protected function _getMetricsAbsolute($sFrom, $sTo, $iPeriod)
    {
        // 有効性チェック
        $bRetCode      = \SC\libs\Validate::isStringNotZero($sFrom);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString("Parameter 'from' is not a string.");
        }
        $bRetCode      = \SC\libs\Validate::isStringNotZero($sTo);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString("Parameter 'to' is not a string.");
        }
        $iTime         = strtotime($sFrom);
        if ( $iTime === false || $iTime < 1 ) {
            throw new \SC\exception\common\parameter\ZeroByteString("Parameter 'from' is not a date format.");
        }
        $iMin          = ( (int) floor((int) ltrim(date('i', $iTime), '0') / 10) ) * 10;
        $iFrom         = strtotime(date('Y/m/d H:', $iTime) . sprintf('%02d', $iMin));
        $iTime         = strtotime($sTo);
        if ( $iTime === false || $iTime < 1 ) {
            throw new \SC\exception\common\parameter\ZeroByteString("Parameter 'to' is not a date format.");
        }
        $iMin          = ( (int) floor((int) ltrim(date('i', $iTime), '0') / 10) ) * 10;
        $iTo           = strtotime(date('Y/m/d H:', $iTime) . sprintf('%02d', $iMin));
        // 期間
        $iTerm         = $iTo - $iFrom;
        if ( $iTerm <= 600 ) {
            // 期間が短すぎる
            throw new \SC\exception\common\parameter\ZeroByteString("Too small to get metrics between '$sFrom' and '$sTo'.");
        }
        $bRetCode      = \SC\libs\Validate::isInt($iPeriod);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt("Parameter 'period' is not an int.");
        }
        $iPeriod       = (int) $iPeriod;
        if ( $iPeriod < 1 ) {
            $iPeriod   = 86400;
        }
        // メトリクスを取得
        return $this->_getMetrics($iFrom, $iTo, $iPeriod);
    }

    /**
     * メトリクスを取得
     *
     * @param   int     $iFrom      開始日時    正の整数            default: 1
     * @param   int     $iTo        終了日時    正の整数 or 0       default: 0
     * @param   string  $sUnit      単位        mon | day | hour    default: mon
     * @param   int     $iPeriod    集計単位    正の整数            default: 86400
     * @return  array   メトリクス情報
     * @throw   \SC\exception\common\parameter\ZeroByteString
     * @throw   \SC\exception\common\parameter\NotAnInt
     */
    protected function _getMetricsRelative($iFrom, $iTo, $sUnit, $iPeriod)
    {
        // 有効性チェック
        $bRetCode            = \SC\libs\Validate::isInt($iFrom);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt("Parameter 'from' is not an int.");
        }
        $iFrom               = (int) $iFrom;
        if ( $iFrom < 1 ) {
            $iFrom           = 1;
        }
        $bRetCode            = \SC\libs\Validate::isInt($iTo);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt("Parameter 'to' is not an int.");
        }
        $iTo                 = (int) $iTo;
        if ( $iTo < 0 ) {
            $iTo             = 0;
        }
        $bRetCode      = \SC\libs\Validate::isInt($iPeriod);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt("Parameter 'period' is not an int.");
        }
        $iPeriod             = (int) $iPeriod;
        if ( $iPeriod < 1 ) {
            $iPeriod         = 86400;
        }
        $bRetCode            = \SC\libs\Validate::isStringNotZero($sUnit);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString("Parameter 'unit' is not a string.");
        }
        $aDate               = getdate();
        switch ( $sUnit ) {
            //
            case 'mon':
                $iFromTime   = mktime(0,       0, 0, $aDate['mon']-$iFrom, $aDate['mday'],        $aDate['year']);
                $iToTime     = mktime(0,       0, 0, $aDate['mon']-$iTo,   $aDate['mday'],        $aDate['year']);
                break;

            case 'day':
                $iFromTime   = mktime(0,       0, 0, $aDate['mon'],        $aDate['mday']-$iFrom, $aDate['year']);
                $iToTime     = mktime(0,       0, 0, $aDate['mon'],        $aDate['mday']-$iTo,   $aDate['year']);
                break;

            case 'hour':
                $iFromTime   = mktime(-$iFrom, 0, 0, $aDate['mon'],        $aDate['mday'],        $aDate['year']);
                $iToTime     = mktime(-$iTo,   0, 0, $aDate['mon'],        $aDate['mday'],        $aDate['year']);
                break;
            default:
                throw new \SC\exception\common\parameter\ZeroByteString("Parameter 'from' is not a date format.");
        }
        // メトリクスを取得
        return $this->_getMetrics($iFromTime, $iToTime, $iPeriod);
    }

    /**
     * メトリクスを取得(等間隔)
     *
     * @param   int     $iFrom      開始日時のタイムスタンプ
     * @param   int     $iTo        終了日時のタイムスタンプ
     * @param   int     $iPeriod    間隔
     * @return  array   メトリクス情報
     */
    protected function _getMetrics($iFrom, $iTo, $iPeriod)
    {
        $aMetrics = \SC\libs\Metrics::get($iFrom, $iTo, $iPeriod);
        return $aMetrics;
    }

    /**
     * メトリクスを取得(月別)
     *
     * @param   array   $aList      月のタイムスタンプリスト
     * @return  array   メトリクス情報
     */
    protected function _getMetricsByMonth(array $aList)
    {
        $aMetrics = \SC\libs\Metrics::getByMonth($aList);
        return $aMetrics;
    }
}
