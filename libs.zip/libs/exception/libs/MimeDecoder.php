<?php
/**
 * MimeDecoderの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs;

/**
 * MimeDecoderの例外
 */
class MimeDecoder extends \SC\exception\libs
{
}
