<?php
/**
 * コンパイルエラー例外 (E_COMPILE_ERROR)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * コンパイルエラー例外 (E_COMPILE_ERROR)
 */
class CompileError extends \SC\exception\php\error
{
}
