<?php
/**
 * Siteの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\model;

/**
 * Siteの例外
 */
class Site extends \SC\exception\model
{
}
