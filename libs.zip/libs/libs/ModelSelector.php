<?php
/**
 * ModelSelector
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ModelSelector
 */
class ModelSelector
{
    /**
     * モデルタイプ
     *
     *  production, admin, live, verify, develop
     *
     * @var string TYPE
     */
    const TYPE = 'production';

    /**
     * 設定ディレクトリのベース
     *
     * @var string BASE
     */
    const BASE = AP_DIR;

    /**
     * 環境ディレクトリの指定
     *
     * @var string ENV_DIR
     */
    const ENV_DIR = 'contents/production';

    /**
     * 設定ディレクトリの指定
     *
     * @var string CONFIG_DIR
     */
    const CONFIG_DIR = 'config';

    /**
     * テンプレートディレクトリの指定
     *
     * @var string TEMPLATE_DIR
     */
    const TEMPLATE_DIR = 'template';

    /**
     * 公開ディレクトリの指定
     *
     * @var string PUBLIC_DIR
     */
    const PUBLIC_DIR = 'public';

    /**
     * 全体設定の指定
     *
     * @var string CONFIG_GLOBAL
     */
    const CONFIG_GLOBAL = 'global';

    /**
     * ステージング環境設定の指定
     *
     * @var string CONFIG_STAGING
     */
    const CONFIG_STAGING = 'staging';

    /**
     * モデル設定の接頭辞の指定
     *
     * @var string CONFIG_PREFIX
     */
    const CONFIG_PREFIX = 'models-';

    /**
     * 設定ファイルの拡張子
     *
     * @var string CONFIG_EXT
     */
    const CONFIG_EXT = '.yaon';

    /**
     * 設定ファイルのディレクトリの指定
     *
     * @var string $sConfigPath
     */
    protected $sConfigPath = self::CONFIG_DIR;

    /**
     * 設定ファイル接頭辞
     *
     * @var string $sConfigPrefix
     */
    protected $sConfigPrefix = self::CONFIG_PREFIX;

    /**
     * 設定ファイルの拡張子
     *
     * @var string $sConfigExtent
     */
    protected $sConfigExtent = self::CONFIG_EXT;

    /**
     * ステージング設定ファイル名
     *
     * @var string $sConfigStaging
     */
    protected $sConfigStaging = self::CONFIG_STAGING;

    /**
     * リクエスト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * レスポンス
     *
     * @var SC\libs\Response $oResponse
     */
    protected $oResponse = NULL;

    /**
     * ユーティリティ
     *
     * @var SC\libs\Util $oUtil
     */
    protected $oUtil = NULL;

    /**
     * モデルマッチのログ出力レベル
     *
     * @var int $iLogMatch
     */
    protected $iLogMatch = 0;

    /**
     * 隠しページを表示するか否か
     *
     * @var bool $bShowHiddenPage
     */
    protected $bShowHiddenPage = false;

    /**
     * 環境別ディレクトリの指定を使うか否か
     *
     * @var string $sEnvDir
     */
    protected $sEnvDir = self::ENV_DIR;

    /**
     * キャッシュを使うか否か
     *
     * @var bool $bUseCache
     */
    protected $bUseCache = true;

    /**
     * 常にキャッシュを使うか否か
     *
     * @var bool $bUseCache
     */
    protected $bUseCacheForce = true;

    /**
     * モデルキャッシュクラス
     *
     * @var array $aModelCacher
     */
    protected $aModelCacher = array(
        'production' => 'ModelCacher',
        'admin'      => 'ModelCacherAdmin',
        'live'       => 'ModelCacherLive',
        'verify'     => 'ModelCacherVerify',
        'develop'    => 'ModelCacherDevelop',
    );

    /**
     * フォールバック用のデフォルトモデル
     *
     * @var array $aDefaultModel
     */
    protected $aDefaultModel = array();

    /**
     * セレクタランク
     *
     * @var int $iRank
     */
    protected $iRank = 0;

    /**
     * セレクトを開始した時刻
     *
     * @var float $fSelectStartTime
     */
    protected $fSelectStartTime = 0.0;

    /**
     * インスタンス
     *
     * @var array(SC\libs\ModelSelector) $aInstance
     */
    protected static $aInstance = array();

    /**
     * 条件対象
     *
     * @var array $aTarget
     */
    protected $aTarget = array(
        'HTTP_HOST'            => true,     // host
        'SERVER_PORT'          => true,     // port
        'PATH_INFO'            => true,     // path
        'QUERY_STRING'         => true,     // query
        'REQUEST_URI'          => true,     // request uri
        'HTTPS'                => true,     // on
        'HTTP_USER_AGENT'      => true,     // Android
        'HTTP_REFERER'         => true,     // Referer
        'REQUEST_METHOD'       => true,     // GET/POST
        'REMOTE_ADDR'          => true,     // 192.168.1.1
        'REMOTE_ADDRS'         => true,     // 192.168.1.1
        'HTTP_X_FORWARDED_FOR' => true,     // 192.168.1.1
        'REMOTE_PORT'          => true,     // 65457
        'REMOTE_USER'          => true,     // username
        'AUTH_TYPE'            => true,     // Basic , Digest
        'PHP_AUTH_USER'        => true,     // auth username
        'PHP_AUTH_PW'          => true,     // auth passowrd
        'PHP_AUTH_DIGEST'      => true,     // auth digest
        'SERVER_PROTOCOL'      => true,     // HTTP/1.1
        'GATEWAY_INTERFACE'    => true,     // CGI/1.1
        'REQUEST_TIME'         => true,     // UNIX Epoch
        'HOSTNAME'             => true,     // hostname
        // SmartConvert Environment Variables
        'SC_PRODUCT_NAME'      => true,     // SmartConvert
        'SC_PRODUCT_VERSION'   => true,     // version of SmartConvert
        'SC_SOURCE_HOST'       => true,     // source host
        'SC_STAGING'           => true,     // is staging for Source-site
        'SC_STAGING_SP'        => true,     // is staging for SP-site
        'SC_SHOW_HIDDEN_PAGE'  => true,     // hidden page
    );

    /**
     * 条件対象
     *
     * @var array $aTargetPrefix
     */
    protected $aTargetPrefix = array(
        // SmartConvert Environment Variables
        'SC_OPT_'              => true,     // optional
    );

    /**
     * コンストラクタ
     *
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function __construct()
    {
        // 必須インスタンスを集約
        $this->oRequest          = \Request::getInstance();
        $this->oResponse         = \Response::getInstance();
        $this->oUtil             = \Util::getInstance();
        // マッチ条件をログに出力するか否か
        $sLogMatch               = $this->oRequest->getServer('SC_LOG_MODELMATCHING', '');
        if ( $sLogMatch === 'true' || $sLogMatch === 'on' || $sLogMatch === '1' ) {
            $this->iLogMatch     = 1;
        } else {
            $bRetCode            = Validate::isInt($sLogMatch);
            if ( $bRetCode === true ) {
                $this->iLogMatch = (int) $sLogMatch;
            } else {
                $this->iLogMatch = 0;
            }
        }
        // 設定ファイルをキャッシュする
        $this->bUseCache         = (bool)   $this->oRequest->getServer('SC_MODEL_CACHE_USE',       true);
        $this->bUseCacheForce    = (bool)   $this->oRequest->getServer('SC_MODEL_CACHE_USE_FORCE', false);
        // 設定ファイルのディレクトリの指定
        $this->sConfigPath       = (string) $this->oRequest->getServer('SC_MODEL_CONFIG_DIR',     static::CONFIG_DIR);
        // 設定ファイル接頭辞
        $this->sConfigPrefix     = (string) $this->oRequest->getServer('SC_MODEL_CONFIG_PREFIX',  static::CONFIG_PREFIX);
        // 設定ファイル拡張子
        $this->sConfigExtent     = (string) $this->oRequest->getServer('SC_MODEL_CONFIG_EXTENT',  static::CONFIG_EXT);
        // ステージング設定ファイル名
        $this->sConfigStaging    = (string) $this->oRequest->getServer('SC_MODEL_CONFIG_STAGING', static::CONFIG_STAGING);
        // 隠しページを表示するか否か
        $this->bShowHiddenPage   = (bool)   $this->oRequest->getServer('SC_SHOW_HIDDEN_PAGE',     false);
        // 環境別ディレクトリの指定を使うか否か
        $iVersionCmp             = version_compare(SC_PRODUCT_VERSION, '2.0-dev');
        if ( $iVersionCmp < 0 ) {
            $sUseEnvDirDefault   = '0';
        } else {
            $sUseEnvDirDefault   = '1';
        }
        $sUseEnvDir              = strtolower($this->oRequest->getServer('SC_USE_ENV_DIR',        $sUseEnvDirDefault));
        if ( $sUseEnvDir === '0' || $sUseEnvDir === 'off' || $sUseEnvDir === 'false' ) {
            $this->sEnvDir       = 'contents';
        } else {
            $this->sEnvDir       = static::ENV_DIR;
        }
        $this->aDefaultModel     = array(
            'name'         => '__DEFAULT__',
            'description'  => 'default fall back model',
            'priority'     => -PHP_INT_MAX,
            'conditions'   => array(),
            'model'        => 'Error',
            'status'       => 404,
            'template'     => 'error.html',
            'mime'         => 'text/html',
            'charset'      => 'UTF-8',
            'session'      => false,
            'cachelimiter' => 'nocache',
            'type'         => static::TYPE,
            'env_dir'      => $this->sEnvDir,
            'preview'      => '',
        );
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\ModelSelector
     */
    public static function getInstance()
    {
        $sClass                         = get_called_class();
        $bRetCode                       = isset(self::$aInstance[$sClass]);
        if ( $bRetCode !== true ) {
            static::$aInstance[$sClass] = new static();
        }
        return static::$aInstance[$sClass];
    }

    /**
     * モデルをセレクト
     *
     * @param   string  $sConfigPath    モデルを保持しているパス
     * @param   string  $sPathInfo      パス情報
     * @return  array   モデル情報
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function select($sConfigPath = '', $sPathInfo = '')
    {
        // 入力チェック
        if ( $sConfigPath !== '' && $sConfigPath !== NULL ) {
            $bRetCode = Validate::isStringNotZero($sConfigPath);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\common\parameter\ZeroByteString('Config path must be non-zero byte string.');
            }
        }
        $oSelf        = static::getInstance();
        // セレクト開始時刻を取得
        return $oSelf->_select($sConfigPath, $sPathInfo);
    }

    /**
     * モデルをセレクト
     *
     * @param   string  $sConfigPath    モデルを保持しているパス
     * @param   string  $sPathInfo      パス情報
     * @return  array   モデル情報
     */
    protected function _select($sConfigPath = '', $sPathInfo = '')
    {
        // 入力チェック
        if ( $sConfigPath === '' || $sConfigPath === NULL ) {
            $sConfigPath     = $this->sConfigPath;
        }
        // 設定の読み込み
        $aConfig             = $this->_loadConfig($sConfigPath, $sPathInfo);
        // モデルのセレクト
        $aSelector           = $this->_selectModel($aConfig, $sPathInfo);
        $aSelector['config'] = $aConfig;
        // ステージング設定のセット
        Util::setAdjustURIConds($aConfig['global']['url-adjust']);
        // セレクトモデル
        \Log::info("Model name = {$aSelector['model']}");
        LogRegistry::save('sc:request', 'MODEL_NAME', $aSelector['model']);
        return $aSelector;
    }

    /**
     * モデル情報を構成
     *
     * @param   array   $aSelector      モデル情報
     * @param   array   $aConfig        設定情報
     * @param   string  $sFrom          チェーン時の元モデル名
     * @return  array   モデル情報
     */
    public static function makeSelector(array $aSelector, array $aConfig, $sFrom = '')
    {
        $oSelf = static::getInstance();
        return $oSelf->_makeSelector($aSelector, $aConfig, $sFrom);
    }

    /**
     * モデル情報を構成
     *
     * @param   array   $aSelector      モデル情報
     * @param   array   $aConfig        設定情報
     * @param   string  $sFrom          チェーン時の元モデル名
     * @return  array   モデル情報
     */
    protected function _makeSelector(array $aSelector, array $aConfig, $sFrom = '')
    {
        // 設定の読み込み
        $aSelector            = $this->mergeGlobalSelector($aSelector, $aConfig['global']);
        $aSelector['config']  = $aConfig;
        $sName                = $aSelector['name'];
        // チェーンモデル
        if ( $sFrom !== '' ) {
            $sFrom            = " <- {$sFrom} (model chain)";
            LogRegistry::save('sc:request', 'CHAINED_MODEL',  $sName);
        } else {
            LogRegistry::save('sc:request', 'SELECTED_MODEL', $sName);
        }
        \Log::info("Model selected [ $sName ] {$sFrom}" );
        LogRegistry::save('sc:request', 'SELECTED_RANK', $this->iRank);
        LogRegistry::save('sc:request', 'SELECTED_TIME', microtime(true) - $this->fSelectStartTime);
        // セレクタのpreviewをRequestに登録
        $this->oRequest->setPreview($aSelector['preview']);
        return $aSelector;
    }

    /**
     * 設定読み込み
     *
     * @param   string  $sConfigPath    モデルを保持しているパス
     * @param   string  $sPathInfo      パス情報
     * @return  array   設定情報
     */
    protected function _loadConfig($sConfigPath = '', $sPathInfo = '')
    {
        // 設定ファイルのディレクトリ
        $aConfigDir                     = array( static::BASE );
        $sEnvDir                        = trim($this->sEnvDir);
        if ( $sEnvDir !== '' ) {
            $aConfigDir[]               = $sEnvDir;
        }
        $sConfigPath                    = trim($sConfigPath);
        if ( $sConfigPath === '' ) {
            $sConfigPath                = trim($this->sConfigPath);
        }
        if ( $sConfigPath !== '' ) {
            $aConfigDir[]               = $sConfigPath;
        }
        $sConfigDir                     = str_replace(array('\\', '/'), array('/', '/'), join('/', $aConfigDir));
        // 設定キャッシュを使用するか？
        if ( $this->bUseCache === true ) {
            // 設定読み込み
            $aConfig                    = call_user_func(__NAMESPACE__ . '\\' . $this->aModelCacher[static::TYPE] . '::load');
            if ( $aConfig !== array() ) {
                if ( $this->bUseCacheForce === true ) {
                    // 常にキャッシュを使う
                    return $aConfig;
                }
                // ファイルのチェック
                $aFileMTimes            = ArrayUtil::getValue($aConfig, 'files', array());
                // 設定ファイルのリストを取得
                $aConfigFiles           = $this->_getConfigFiles($sConfigDir);
                $bRetCode               = $this->_checkConfigFiles($aConfigFiles, $aFileMTimes);
                if ( $bRetCode === true ) {
                    // キャッシュ読み込み成功
                    return $aConfig;
                }
            }
        }
        // 設定ファイルのリストを取得
        $aConfigFiles                   = $this->_getConfigFiles($sConfigDir);
        $aConfig                        = array();
        // 常時設定
        $sGlobalFile                    = $aConfigFiles['global']->getPathname();
        $bRetCode                       = $aConfigFiles['global']->isReadable();
        if ( $bRetCode === true ) {
            $sGlobalJSON                = $aConfigFiles['global']->read();
            $iGlobalMTime               = $aConfigFiles['global']->getMTime();
        } else {
            $sGlobalJSON                = '{}';
            $iGlobalMTime               = false;
        }
        $aConfig                        = array( 'global'  => YAON::decode($sGlobalJSON) );
        // ステージング条件
        $aAdjustConds                   = array(
            'url-adjust' => array(
            ),
        );
        // ステージング条件 (ソースサイト → ソースステージングサイト変換)
        $sStagingFile                   = $aConfigFiles['staging']->getPathname();
        $bRetCode                       = $aConfigFiles['staging']->isReadable();
        if ( $bRetCode === true ) {
            $sStagingJSON               = $aConfigFiles['staging']->read();
            $iStagingMTime              = $aConfigFiles['staging']->getMTime();
        } else {
            $sStagingJSON               = '{}';
            $iStagingMTime              = false;
        }
        $aStaging                       = YAON::decode($sStagingJSON);
        $iStagingCond                   = count($aStaging);
        if ( $iStagingCond > 0 ) {
            // ステージング条件がある
            $aAdjustConds['url-adjust']['staging-source'] = $aStaging;
        }
        // SPサイト条件 (ソースサイト → SPステージングサイト変換)
        $sStagingSPFile                 = $aConfigFiles['staging-sp']->getPathname();
        $bRetCode                       = $aConfigFiles['staging-sp']->isReadable();
        if ( $bRetCode === true ) {
            $sStagingSPJSON             = $aConfigFiles['staging-sp']->read();
            $iStagingSPMTime            = $aConfigFiles['staging-sp']->getMTime();
        } else {
            $sStagingSPJSON             = '{}';
            $iStagingSPMTime            = false;
        }
        $aStaging                       = YAON::decode($sStagingSPJSON);
        $iStagingCond                   = count($aStaging);
        if ( $iStagingCond > 0 ) {
            // ステージング条件がある
            $aAdjustConds['url-adjust']['staging-sp'] = $aStaging;
        }
        $aConfig['global']              = ArrayUtil::unite($aConfig['global'], $aAdjustConds, true);
        // preview対応 ※変更前パスから取得
        if ( $sPathInfo === '' ) {
            $sPathInfo                  = $this->oRequest->getPathInfo(true);
        }
        $bFound                         = (bool) preg_match('#^(/preview/(?:live|verify|develop))(?:/|$)#u', $sPathInfo, $aMatches);
        if ( $bFound === true ) {
            $sPreview                   = $aMatches[1];
        } else {
            $sPreview                   = '';
        }
        $aConfig['preview']             = $sPreview;

        // モデル設定
        $iConfigPathLen                 = strlen($sConfigDir)+1;
        $iConfigCounter                 = 0;
        $aStores                        = array();
        $aFileMTimes                    = array(
            $sGlobalFile    => $iGlobalMTime,
            $sStagingFile   => $iStagingMTime,
            $sStagingSPFile => $iStagingSPMTime,
        );
        foreach ( $aConfigFiles['models'] as $oFileInfo ) {
            // ファイル名を取得
            $sFilename                  = $oFileInfo->getPathname();
            $aFileMTimes[$sFilename]    = $oFileInfo->getMTime();
            $sJSON                      = $oFileInfo->read();
            try {
                $mDecoded               = YAON::decode($sJSON);
                if ( $this->iLogMatch > 0 ) {
                    \Log::trace("Load config for '$sFilename'");
                }
                $bRetCode               = is_array($mDecoded);
                if ( $bRetCode !== true ) {
                    // 設定が配列でなければ抜ける
                    \Log::warning("Config is not an array for '$sFilename'");
                    continue;
                }
            } catch (\SC\exception\libs\JSON\CantDecode $oException) {
                // 読めなくても処理を継続する
                \Log::warning("Can't decode JSON file '" . $oException->getMessage() . "' for '$sFilename'");
                continue;
            }
            // 無視設定 → 次へ
            $bRetCode                   = (bool) ArrayUtil::getValue($mDecoded, 'ignore', false);
            if ( $bRetCode === true ) {
                \Log::warning("Config is ignored for '$sFilename'");
                continue;
            }
            // 通常設定 → 優先度チェック
            $sModel                     = (string) ArrayUtil::getValue($mDecoded, 'model', '');
            if ( $sModel === '' ) {
                $iPriorityPrefix        = 0;
                $iPriority              = 0;
            } else {
                $iPriorityPrefix        = 1;
                $iPriority              = (int) ArrayUtil::getValue($mDecoded, 'priority', 0);
                $mDecoded['priority']   = $iPriority;
            }
            $sKey                       = sprintf('%d:%d:%d', $iPriorityPrefix, $iPriority, $iConfigCounter++);
            // ファイル名を保持しておく
            $mDecoded['json']           = $sFilename;
            // 環境ディレクトリを保持しておく
            $mDecoded['type']           = static::TYPE;
            $mDecoded['env_dir']        = $this->sEnvDir;
            $mDecoded['preview']        = $sPreview;
            $aStores[$sKey]             = $mDecoded;
        }
        uksort($aStores, 'strnatcmp');
        $aStores                        = array_reverse($aStores, true);
        $aConfig['models']              = array();
        foreach ( $aStores as $mDecoded ) {
            $sName                      = $mDecoded['name'];
            $bHiddenPage                = (bool) ArrayUtil::getValue($mDecoded, 'hidden', false);
            if ( $bHiddenPage === true && $this->bShowHiddenPage !== true ) {
                continue;
            }
            $bRetCode                   = isset($aConfig['models'][$sName]);
            if ( $bRetCode === true ) {
                // 存在しても上書きする
                $sAlreadyJSON           = substr($mDecoded['json'],                  $iConfigPathLen);
                $sOverwriteJSON         = substr($aConfig['models'][$sName]['json'], $iConfigPathLen);
                \Log::warning("Model '{$sName}' is already loaded. (JSON: {$sAlreadyJSON} => {$sOverwriteJSON} )");
            }
            $aConfig['models'][$sName]  = $mDecoded;
        }
        $aConfig['files']               = $aFileMTimes;
        // デフォルト設定
        $this->aDefaultModel['preview'] = $sPreview;
        $aConfig['__DEFAULT__']         = $this->aDefaultModel;
        if ( $this->bUseCache === true ) {
            // キャッシュするなら保持
            $bRetCode                   = call_user_func(__NAMESPACE__ . '\\' . $this->aModelCacher[static::TYPE] . '::set', $aConfig);
        }
        return $aConfig;
    }

    /**
     * 設定ファイルのリストアップ
     *
     * @param   string  $sConfigDir     モデルを保持しているディレクトリ
     * @return  array   設定ファイルのリスト
     */
    protected function _getConfigFiles($sConfigDir)
    {
        // リストの精査
        $aAllFiles         = Util::getFileList($sConfigDir, $this->sConfigPrefix . '*' . $this->sConfigExtent, true, false);
        $iPathLen          = strlen($sConfigDir) + 1;
        $aModelFiles       = array();
        $sConfigGlobal     = static::CONFIG_GLOBAL         . $this->sConfigExtent;
        $sConfigStaging    = $this->sConfigStaging         . $this->sConfigExtent;
        $sConfigStagingSP  = $this->sConfigStaging . '-sp' . $this->sConfigExtent;
        foreach ( $aAllFiles as $oFileInfo ) {
            // ディレクトリならリストしない
            $bRetCode                   = $oFileInfo->isDir();
            if ( $bRetCode === true ) {
                continue;
            }
            // ファイル名を取得
            $sFilename     = str_replace(array('/', '\\'), array('/', '/'), $oFileInfo->getPathname());
            $sFilenameBase = substr($sFilename, $iPathLen);
            if ( $sFilenameBase === $sConfigGlobal || $sFilenameBase === $sConfigStaging || $sFilenameBase === $sConfigStagingSP ) {
                // 常時設定は2重読み込みはしない
                continue;
            }
            $aModelFiles[] = $oFileInfo;
        }
        // モデルファイルのリストアップ
        $aFileList         = array(
            'global'     => FileBare::getInstance($sConfigDir . '/' . $sConfigGlobal),
            'staging'    => FileBare::getInstance($sConfigDir . '/' . $sConfigStaging),
            'staging-sp' => FileBare::getInstance($sConfigDir . '/' . $sConfigStagingSP),
            'models'     => $aModelFiles,
        );
        return $aFileList;
    }

    /**
     * ファイルのmtimeをチェック
     *
     * @param   array   $aConfigFiles   設定ディレクトリのファイルリスト
     * @param   array   $aFileMTimes    ファイルのmtimeを保持しているリスト
     * @return  bool    true/false
     */
    protected function _checkConfigFiles(array $aConfigFiles, array $aFileMTimes)
    {
        // チェック
        $bRetCode     = $this->_checkFimeMTime($aConfigFiles['global'],     $aFileMTimes);
        if ( $bRetCode !== true ) {
            return false;
        }
        $bRetCode     = $this->_checkFimeMTime($aConfigFiles['staging'],    $aFileMTimes);
        if ( $bRetCode !== true ) {
            return false;
        }
        $bRetCode     = $this->_checkFimeMTime($aConfigFiles['staging-sp'], $aFileMTimes);
        if ( $bRetCode !== true ) {
            return false;
        }
        // 各ファイルをチェック
        foreach ( $aConfigFiles['models'] as $oConfigFile ) {
            $bRetCode = $this->_checkFimeMTime($oConfigFile,                $aFileMTimes);
            if ( $bRetCode !== true ) {
                return false;
            }
        }
        return true;
    }

    /**
     * ファイルのmtimeをチェック
     *
     * @param   SC\libs\File    $oConfigFile    設定ファイル
     * @param   array           $aFileMTimes    ファイルのmtimeを保持しているリスト
     * @return  bool            true/false
     */
    protected function _checkFimeMTime(File $oConfigFile, array $aFileMTimes)
    {
        // ファイル名を取得する
        $sFilename  = $oConfigFile->getPathname();
        $iFileMTime = ArrayUtil::getValue($aFileMTimes, $sFilename, -1);
        if ( $iFileMTime < 0 ) {
            // 指定ファイルがないならキャッシュしない
            return false;
        }
        // ファイルが読めるか？
        $bRetCode   = $oConfigFile->isReadable();
        if ( $bRetCode !== true ) {
            // ファイルが読めない → falseで保持しているはず
            if ( $iFileMTime !== false ) {
                // 保持している値はfalseではないならキャッシュしない
                return false;
            }
            return true;
        }
        // 時刻のチェックが可能
        $iMTime     = $oConfigFile->getMTime();
        if ( $iMTime < 1 || $iMTime !== $iFileMTime ) {
            // 時刻が取得できないか違う時刻ならキャッシュしない
            return false;
        }
        return true;
    }

    /**
     * モデルセレクタ
     *
     * @param   array   $aConfig        設定情報
     * @param   string  $sPathInfo      パス情報
     * @return  array   セレクタ情報
     */
    protected function _selectModel(array $aConfig, $sPathInfo = '')
    {
        // セレクト開始時刻を保持
        $this->fSelectStartTime         = microtime(true);
        // プレビューモードの場合は，公開ディレクトリ内にファイルが存在すればダウンロードモデルを返す
        if ( $aConfig['preview'] !== '' ) {
            // preview対応 ※変更前パスから取得
            if ( $sPathInfo === '' ) {
                $sPathInfo              = $this->oRequest->getPathInfo();
            }
            $sFilePath                  = AP_DIR . '/' . $this->sEnvDir . '/public' . $sPathInfo;
            $oFile                      = File::getInstance($sFilePath);
            if ( $oFile->isFile() === true && $oFile->isReadable() === true ) {
                // 存在する → 公開モデル
                $aSelector              = array(
                    'name'         => '__DEFAULT_PUBLIC__',
                    'description'  => 'default fall back model for public',
                    'model'        => 'Public',
                    'status'       => 200,
                    'filename'     => $sPathInfo,
                    'mime'         => $oFile->getMimeType(),
                    'charset'      => NULL,
                    'session'      => false,
                    'cachelimiter' => 'private',
                    'type'         => static::TYPE,
                    'env_dir'      => $this->sEnvDir,
                    'preview'      => $aConfig['preview'],
                );
                return $this->_makeSelector($aSelector, $aConfig, '');
            }
        }

        // モデルセレクタ
        foreach ( $aConfig['models'] as $sName => $aSelector ) {
            // モデルの取得
            $sModel                     = ArrayUtil::getValue($aSelector, 'model', '');
            if ( $sModel === '' ) {
                // モデルの指定がなければマッチしない
                continue;
            }
            // マッチ判定を行うか否か
            $bSelectable                = (bool) ArrayUtil::getValue($aSelector, 'selectable', true);
            if ( $bSelectable !== true ) {
                // マッチ判定を行わないなら次へ
                continue;
            }
            // カウントアップ
            $this->iRank++;
            // 条件を取得
            $aConditions                = (array) ArrayUtil::getValue($aSelector, 'conditions', array());
            if ( $aConditions === array() ) {
                // 空配列はマッチを見なす
                return $this->_makeSelector($aSelector, $aConfig, '');
            }
            // マッチしたら処理する
            $bMatched                   = $this->_isSelectedModel($sName, $aConditions, $sPathInfo);
            if ( $bMatched === true ) {
                return $this->_makeSelector($aSelector, $aConfig, '');
            }
        }
        // マッチしていない → フォールバック
        // デフォルト設定
        $this->aDefaultModel['preview'] = '';
        $aSelector                      = $this->aDefaultModel;
        return $this->_makeSelector($aSelector, $aConfig, '');
    }

    /**
     * モデルセレクト条件判定
     *
     * @param   array   $sName          モデル名
     * @param   array   $aConditions    セレクト条件
     * @param   string  $sPathInfo      パス情報
     * @return  bool    マッチしたか否か
     */
    protected function _isSelectedModel($sName, array $aConditions, $sPathInfo = '')
    {
        return $this->_isSelected($sName, $aConditions, array(), '_getTargetForModel', $sPathInfo);
    }

    /**
     * チェーンセレクト条件判定
     *
     * @param   array   $sName          モデル名
     * @param   array   $aConditions    セレクト条件
     * @param   array   $aTargets       ターゲット情報
     * @return  bool    マッチしたか否か
     */
    public static function isSelectedChain($sName, array $aConditions, array $aTargets)
    {
        $oSelf = static::getInstance();
        return $oSelf->_isSelected($sName, $aConditions, $aTargets, '_getTargetForChain');
    }

    /**
     * セレクト条件判定
     *
     * @param   array   $sName          モデル名
     * @param   array   $aConditions    セレクト条件
     * @param   array   $aTargets       ターゲット情報
     * @param   string  $sTargetMethod  ターゲット取得メソッド名
     * @param   string  $sPathInfo      パス情報
     * @return  bool    条件がマッチしたか否か
     */
    protected function _isSelected($sName, array $aConditions, array $aTargets, $sTargetMethod, $sPathInfo = '')
    {
        // 条件がなければ一致
        $iCond                          = count($aConditions);
        if ( $iCond < 1 ) {
            return true;
        }
        $bRetCode                       = Validate::isString($sPathInfo);
        if ( $bRetCode === true  ) {
            $sPathInfo                  = trim($sPathInfo);
        } else {
            $sPathInfo                  = '';
        }
        if ( $sPathInfo === '' ) {
            $sPathInfo                  = $this->oRequest->getServer('PATH_INFO');
        }
        // 条件が多次元配列か？
        $aFirstCond                     = reset($aConditions);
        $bRetCode                       = isset($aFirstCond['target']);
        if ( $bRetCode !== true ) {
            // 2次元配列条件と想定
            $aConditionsSet             = $aConditions;
            $iCondLevel                 = 1;
        } else {
            // 1次元配列条件なので2次元化
            $aConditionsSet             = array($aConditions);
            $iCondLevel                 = 0;
        }
        // 条件マッチ
        $bMatched                       = false;
        $aCondNo                        = array();
        $sCondNo                        = '';
        foreach ( $aConditionsSet as $iCondNo => $aConditions ) {
            $bPrevOr                    = false;
            $aCondNo[0]                 = $iCondNo;
            foreach ( $aConditions as $iCondNo => $aCond ) {
                $aCondNo[$iCondLevel]   = $iCondNo;
                $sCondNo                = join(' :: ', $aCondNo);
                if ( $this->iLogMatch > 0 ) {
                    \Log::trace("Model selection [ $sName :: $sCondNo ] at line " . __LINE__ . ' in ' . __METHOD__);
                }
                // 前条件が，マッチしていてornext指定あり
                if ( $bMatched === true && $bPrevOr === true ) {
                    // ornext指定もしくはOR指定があれば次の条件へ
                    $bPrevOr            = $this->_checkCondOrNext($aCond);
                    continue;
                }
                // 条件判定
                $bMatched               = false;
                // ターゲットを取得
                $aTargetValues          = $this->$sTargetMethod($aCond, $aTargets, $sPathInfo);
                // ornext指定もしくはOR指定があれば次の条件で使用
                $bPrevOr                = $this->_checkCondOrNext($aCond);
                // 比較
                $bRetCode = $this->_compareConditions($aCond, $aTargetValues, "$sName :: $sCondNo");
                if ( $bRetCode === true ) {
                    // 見つかったら次の条件へ
                    $bMatched           = true;
                    continue;
                }
                // ornext指定もしくはOR指定があれば次の条件へ
                $bRetCode               = $this->_checkCondOrNext($aCond);
                if ( $bRetCode === true ) {
                    continue;
                }
                // マッチしないのでNG
                break;
            }
            // マッチしたら抜ける
            if ( $bMatched === true ) {
                break;
            }
        }
        return $bMatched;
    }

    /**
     * 比較対象文字列を取得する for モデルセレクト
     *
     * @param   array   $aCond          比較条件
     * @param   array   $aTargets       ターゲット情報
     * @param   string  $sPathInfo      パス情報
     * @return  array   比較対象文字列の配列
     */
    protected function _getTargetForModel(array $aCond, array $aTargets, $sPathInfo = '')
    {
        $aTargetKey                  = explode(':', (string) ArrayUtil::getValue($aCond, 'target', ''), 2);
        $iCount                      = count($aTargetKey);
        if ( $iCount === 1 ) {
            $sTargetKey              = $aTargetKey[0];
            $sTargetFrom             = 'server';
        } else {
            $sTargetKey              = $aTargetKey[1];
            $sTargetFrom             = strtolower($aTargetKey[0]);
        }
        switch ( $sTargetFrom ) {
            // サーバのチェック
            case 'server':
                if ( $sTargetKey === 'PATH_INFO' ) {
                    // PATH_INFOだけは指定のものを使う
                    $mTarget         = $sPathInfo;
                    break;
                }
                $bRetCode            = isset($this->aTarget[$sTargetKey]);
                if ( $bRetCode === true ) {
                    $mTarget         = $this->oRequest->getServer($sTargetKey, '');
                } else {
                    $bFound          = false;
                    foreach ( $this->aTargetPrefix as $sPrefix => $bRetCode ) {
                        $iCmp        = strncmp($sPrefix, $sTargetKey, strlen($sPrefix));
                        if ( $iCmp === 0 ) {
                            $bFound  = true;
                            $mTarget = $this->oRequest->getServer($sTargetKey, '');
                            break;
                        }
                    }
                    if ( $bFound !== true ) {
                        $mTarget     = '';
                    }
                }
                break;

            // その他のターゲット
            case 'cookie':
            case 'request':
            case 'post':
            case 'get':
                $sMethod             = 'get' . ucfirst($sTargetFrom);
                $mTarget             = $this->oRequest->$sMethod($sTargetKey, '');
                break;

            // その他
            default:
                $mTarget             = '';
                break;
        }
        return (array) $mTarget;
    }

    /**
     * 比較対象文字列を取得する for モデルチェーン
     *
     * @param   array   $aCond          比較条件
     * @param   array   $aTargets       ターゲット情報
     * @param   string  $sPathInfo      パス情報
     * @return  array   比較対象文字列の配列
     */
    protected function _getTargetForChain(array $aCond, array $aTargets, $sPathInfo = '')
    {
        $sTargetKey             = strtolower(ArrayUtil::getValue($aCond, 'target', ''));
        switch ( $sTargetKey ) {
            case 'header':
                $sName          = strtolower(ArrayUtil::getValue($aCond, 'header', ''));
                if ( $sName !== '' ) {
                    $mTarget    = join("\n", (array) ArrayUtil::getValue($aTargets['header'], $sName, array()));
                } else {
                    $mTarget    = '';
                }
                break;

            case 'body':
                $mTarget        = $aTargets['body'];
                break;

            case 'status':
                $mTarget        = (string) ArrayUtil::getValue($aCond, 'status', HttpStatus::NEVER_DONE);
                break;

            case 'parameter':
                $sName          = (string) ArrayUtil::getValue($aCond, 'parameter', '');
                if ( $sName !== '' ) {
                    $mTarget    = ArrayUtil::getValue($aTargets['parameter'], $sName, '');
                } else {
                    $mTarget    = '';
                }
                break;

            // その他
            default:
                $mTarget        = '';
                break;
        }
        return (array) $mTarget;
    }

    /**
     * 比較条件
     *
     * @param   array   $aCond      比較条件
     * @param   array   $aTargets   比較対象の配列
     * @param   string  $sLogLabel  ログ
     * @return  bool    条件にマッチしたか否か(true/false)
     */
    protected function _compareConditions(array $aCond, array $aTargets, $sLogLabel)
    {
        // 大文字小文字無視か？
        $bRetCode                   = isset($aCond['ignorecase']);
        $bIgnoreCase                = false;
        if ( $bRetCode === true && $aCond['ignorecase'] === true ) {
            $bIgnoreCase            = true;
        } else {
            $aCond['options']       = (array) ArrayUtil::getValue($aCond, 'options', array());
            $bRetCode               = in_array('nocase', $aCond['options']) || in_array('NC', $aCond['options']) || in_array('ignorecase', $aCond['options']);
            if ( $bRetCode === true ) {
                $bIgnoreCase        = true;
            }
        }
        // 比較処理
        $bCmpMatch                  = true;
        $sCmpValue                  = NULL;
        $sCompare                   = (string) ArrayUtil::getValue($aCond, 'compare', '');
        $sValue                     = (string) ArrayUtil::getValue($aCond, 'value',   '');
        $bMatched                   = false;
        $aLogMatch                  = array();
        foreach ( $aTargets as $iKey => $sTarget ) {
            $sLogLabelEach          = "$sLogLabel :: $iKey";
            switch ( $sCompare ) {
                // 正規表現で比較
                case '!~':
                    $bCmpMatch      = false;
                // 正規表現で比較
                case '~':
                    if ( $sTarget === '' ) {
                        // 正規表現で空文字にマッチはNG
                        break;
                    }
                    if ( $bIgnoreCase === true ) {
                        $sExtent    = 'ui';
                    } else {
                        $sExtent    = 'u';
                    }
                    $sCmpValue      = Util::validatePCRE($sValue, false, '#', $sExtent);
                    $bFound         = (bool) preg_match_all($sCmpValue, $sTarget, $aCaptures, PREG_PATTERN_ORDER);
                    if ( $bFound === $bCmpMatch ) {
                        $bMatched   = true;
                    }
                    // マッチログ
                    if ( $this->iLogMatch > 1 ) {
                        $aLogMatch  = array(
                            'regex'        => array(
                                'found'    => $bFound,
                                'valueorg' => $sValue,
                                'extent'   => $sExtent,
                            ),
                        );
                    }
                    break;

                // 完全不一致で比較
                case '!=': case '<>':
                    $bCmpMatch      = false;
                // 完全一致で比較
                case '=':
                    if ( $bIgnoreCase === true ) {
                        $sCmpFunc   = 'strcasecmp';
                    } else {
                        $sCmpFunc   = 'strcmp';
                    }
                    $sCmpValue      = $sValue;
                    $bCmp           = ! (bool) $sCmpFunc($sTarget, $sCmpValue);
                    if ( $bCmp === $bCmpMatch ) {
                        $bMatched   = true;
                    }
                    // マッチログ
                    if ( $this->iLogMatch > 1 ) {
                        $aLogMatch  = array(
                            'eq'           => array(
                                'cmpfunc'  => $sCmpFunc,
                                'cmp'      => $bCmp,
                                'cmpmatch' => $bCmpMatch,
                            ),
                        );
                    }
                    break;

                // その他
                default:
                    // マッチしない
                    break;
            }
            // マッチログ
            if ( $this->iLogMatch > 1 ) {
                $aLogMatch          = array_merge(array(
                    'matched'      => $bMatched,
                    'compare'      => $sCompare,
                    'ignorecase'   => $bIgnoreCase,
                    'target'       => $sTarget,
                    'value'        => $sCmpValue,
                ), $aLogMatch);
                \Log::dump($aLogMatch, "Model matching  [ $sLogLabelEach ]:", \Log::LEVEL_TRACE);
            }
            if ( $bMatched === true ) {
                break;
            }
        }
        return $bMatched;
    }

    /**
     * ornextオプションがあるか？
     *
     * @param   array   $aCond      条件情報
     * @return  bool    OR指定があるか否か
     */
    protected function _checkCondOrNext(array $aCond)
    {
        // オプション指定があるか？
        $bRetCode     = isset($aCond['options']);
        if ( $bRetCode !== true ) {
            // オプション指定なし
            return false;
        }
        // ornext指定があるか？
        $bRetCode     = in_array('ornext', $aCond['options']);
        if ( $bRetCode === true ) {
            // あればOR
            return true;
        }
        // OR指定があるか？
        $bRetCode     = in_array('OR', $aCond['options']);
        if ( $bRetCode === true ) {
            // あればOR
            return true;
        }
        // 無ければAND
        return false;
    }

    /**
     * 常時セレクタのマージ
     *
     * @param   array   $aSelector      セレクタ情報
     * @param   array   $aGlobal        常時セレクタ
     * @return  array   セレクタ情報
     */
    public static function mergeGlobalSelector(array $aSelector, array $aGlobal)
    {
        // モデルの取得
        $sModel                              = ArrayUtil::getValue($aSelector, 'model', '');
        if ( $sModel === '' ) {
            // モデルがなければマージしない
            return $aSelector;
        }
        // 常時セレクタチェック
        $bRetCode                            = isset($aGlobal[$sModel]);
        if ( $bRetCode !== true ) {
            // 常時セレクタなし
            return $aSelector;
        }

        // error-template設定があるか
        $bRetCode                            = isset($aGlobal[$sModel]['error-template']);
        if ( $bRetCode === true ) {
            $aErrorTemplate                  = $aGlobal[$sModel]['error-template'];
            // 設定があるか？
            $bRetCode                        = isset($aSelector['error-template']);
            if ( $bRetCode !== true ) {
                // なければセット
                $aSelector['error-template'] = $aErrorTemplate;
            }
            // 設定がある
            $aSelector['error-template']     = ArrayUtil::unite($aSelector['error-template'], $aErrorTemplate);
        }

        // replaces設定があるか
        $bRetCode                            = isset($aGlobal[$sModel]['replaces']);
        if ( $bRetCode === true ) {
            $aReplaces                       = $aGlobal[$sModel]['replaces'];
            // 設定があるか？
            $bRetCode                        = isset($aSelector['replaces']);
            if ( $bRetCode !== true ) {
                // なければセット
                $aSelector['replaces']       = $aReplaces;
            }
            // 設定がある
            $aSelector['replaces']           = ArrayUtil::unite($aSelector['replaces'], $aReplaces);
        }

        // マージ情報
        $aPlus                               = array();
        // MIME設定があるか？
        $bRetCode                            = isset($aGlobal[$sModel]['mime']);
        if ( $bRetCode === true ) {
            $aPlus['mime']                   = $aGlobal[$sModel]['mime'];
        }
        $bRetCode                            = isset($aGlobal[$sModel]['charset']);
        if ( $bRetCode === true ) {
            $aPlus['charset']                = $aGlobal[$sModel]['charset'];
        }
        $bRetCode                            = isset($aGlobal[$sModel]['session']);
        if ( $bRetCode === true ) {
            $aPlus['session']                = $aGlobal[$sModel]['session'];
        }
        $bRetCode                            = isset($aGlobal[$sModel]['cachelimiter']);
        if ( $bRetCode === true ) {
            $aPlus['cachelimiter']           = $aGlobal[$sModel]['cachelimiter'];
        }
        $bRetCode                            = isset($aGlobal[$sModel]['rfc3982']);
        if ( $bRetCode === true ) {
            $aPlus['rfc3982']                = $aGlobal[$sModel]['rfc3982'];
        }
        $aSelector                           = ArrayUtil::unite($aSelector, $aPlus);

        $bRetCode                            = isset($aSelector['sources']);
        if ( $bRetCode ) {
            // timeout
            $aDefaults['timeout']            = ArrayUtil::getValue($aGlobal[$sModel], 'timeout',       0);
            // RFC3982
            $aDefaults['rfc3982']            = ArrayUtil::getValue($aGlobal[$sModel], 'rfc3982',       false);
            // input-filter, header-filter
            $aDefaults['input-filter']       = ArrayUtil::getValue($aGlobal[$sModel], 'input-filter',  array());
            $aDefaults['header-filter']      = ArrayUtil::getValue($aGlobal[$sModel], 'header-filter', array());
            // tidy
            $aDefaults['tidy']               = array( 'enable' => false, 'options' => array() );
            $bRetCode                        = extension_loaded('tidy');
            if ( $bRetCode === true ) {
                $aDefaults['tidy']           = ArrayUtil::getValue($aGlobal[$sModel], 'tidy',          $aDefaults['tidy']);
            }
            // passheader
            $aDefaults['passheader']         = ArrayUtil::getValue($aGlobal[$sModel], 'passheader',    array());
            // マージ
            $aTarget                         = array(
                'timeout',
                'rfc3982',
                'input-filter',
                'header-filter',
                'tidy',
                'passheader',
            );
            foreach ( $aSelector['sources'] as $sSourceName => $aSource ) {
                foreach ( $aTarget as $sKey ) {
                    // 設定があるか？
                    $bRetCode                = isset($aSource[$sKey]);
                    if ( $bRetCode !== true ) {
                        // なければセットして次へ
                        $aSelector['sources'][$sSourceName][$sKey] = $aDefaults[$sKey];
                        continue;
                    }
                    // 設定がある
                    $bRetCode                = is_array($aSource[$sKey]);
                    if ( $bRetCode !== true ) {
                        // 配列でなければセレクタの値をそのまま使用
                        continue;
                    }
                    // 配列ならunite
                    $aSelector['sources'][$sSourceName][$sKey] = ArrayUtil::unite($aSelector['sources'][$sSourceName][$sKey], (array) $aDefaults[$sKey]);
                }
            }
        }
        return $aSelector;
    }
}
