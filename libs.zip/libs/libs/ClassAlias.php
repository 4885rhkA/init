<?php
/**
 * クラス別名付与
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * クラス別名付与
 */
class ClassAlias
{
    /**
     * 別名付与
     *
     * @param   array   $aClasses   別名付与したいクラスの配列
     * @return  bool    true
     * @throw   SC\exception\libs\ClassAlias\ClassAlreadyExists
     * @throw   SC\exception\libs\ClassAlias\CantClassAlias
     */
    public static function set(array $aClasses)
    {
        foreach ( $aClasses as $sAlias => $sClassName ) {
            // 別名指定がない場合には推定
            $bRetCode   = is_numeric($sAlias);
            if ( $bRetCode === true ) {
                $aParts = explode('\\', $sClassName);
                $sAlias = $sClassName;
            }
            // 既にクラスがある場合には次へ
            $bRetCode   = class_exists($sAlias, false);
            if ( $bRetCode === true ) {
                continue;
            }
            // 別名付与
            $bRetCode   = class_alias($sClassName, $sAlias);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\libs\ClassAlias\CantClassAlias("クラスの別名付与ができませんでした。[$sClassName => $sAlias]");
            }
        }
        return true;
    }
}
