<?php
/**
 * ユーザ警告例外 (E_USER_WARNING)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * ユーザ警告例外 (E_USER_WARNING)
 */
class UserWarning extends \SC\exception\php\error
{
}
