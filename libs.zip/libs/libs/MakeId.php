<?php
/**
 * MakeId
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * MakeId
 */
class MakeId
{
    /**
     * IDを生成するメソッドの指定
     *
     * @var string HASH
     */
    const HASH = 'md5';

    /**
     * ユニークIDの文字列長(25以上)
     *
     * @var string LENGTH
     */
    const LENGTH = 22;

    /**
     * 短いユニークIDの文字列長
     *
     * @var string LENGTH_SHORT
     */
    const LENGTH_SHORT = 6;

    /**
     * ユニークIDの埋め文字
     *
     * @var string PAD
     */
    const PAD = '0';

    /**
     * ユニークIDを取得する
     *
     * @return  string  ユニークID
     */
    public static function getUniq()
    {
        // ユニークIDを生成
        $sRawId  = call_user_func(static::HASH, uniqid(mt_rand(), true));
        $sUniqId = Hash::hex2base64url($sRawId);
        $sUniqId = str_pad($sUniqId, static::LENGTH, static::PAD, STR_PAD_RIGHT);
        return $sUniqId;
    }

    /**
     * 短いユニークIDを取得する
     *
     * @param   int     $iLength
     * @return  string  ユニークID
     */
    public static function getShortUniq()
    {
        // ユニークIDを生成
        $sRawId  = static::getUniq();
        $sUniqId = substr($sRawId, 0, static::LENGTH_SHORT);
        return $sUniqId;
    }
}
