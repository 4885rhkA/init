<?php
/**
 * AbstractModelの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller;

/**
 * AbstractModelの例外
 */
class AbstractModel extends \SC\exception\controller
{
}
