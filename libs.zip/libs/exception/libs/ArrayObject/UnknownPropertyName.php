<?php
/**
 * プロパティ名の指定が正しくない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\ArrayObject;

/**
 * プロパティ名の指定が正しくない場合の例外
 */
class UnknownPropertyName extends \SC\exception\libs\ArrayObject
{
}
