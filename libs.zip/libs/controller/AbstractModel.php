<?php
/**
 * 抽象モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * 抽象モデルコントローラ
 */
abstract class AbstractModel
{
    /**
     * モデルセレクタ
     *
     * @var array $aSelector
     */
    protected $aSelector = array();

    /**
     * モデルセレクタ(オリジナル)
     *
     * @var array $aSelectorOrig
     */
    protected $aSelectorOrig = array();

    /**
     * チェーンセレクタ
     *
     * @var array $aChain
     */
    protected $aChain = array();

    /**
     * リクエスト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * レスポンス
     *
     * @var SC\libs\Response $oResponse
     */
    protected $oResponse = NULL;

    /**
     * レスポンス状態
     *
     * @var array $aResState
     */
    protected $aResState = array();

    /**
     * セッション
     *
     * @var SC\libs\Session $oSession
     */
    protected $oSession = NULL;

    /**
     * ログイン
     *
     * @var SC\model\Login $oLogin
     */
    protected $oLogin = NULL;

    /**
     * テンプレート変数配列
     *
     * @var array $aTplValues
     */
    protected $aTplValues = array();

    /**
     * HTMLデータを保持する場合の値
     *
     * @var array $aStored
     */
    protected $aStored = array();

    /**
     * ログインエラー時にログイン画面を表示する
     *
     * @var bool SHOW_LOGIN
     */
    const SHOW_LOGIN = true;

    /**
     * PCREエラーログ
     *
     * @var bool $bLogPCREError
     */
    protected $bLogPCREError = false;

    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
    }

    /**
     * インスタンスの取得
     *
     * @return  SC\controller\AbstractModel
     */
    final public static function getInstance()
    {
        // インスタンスを生成する
        $oSelf = new static();
        return $oSelf;
    }

    /**
     * モデルセレクタのセッター
     *
     * @param   array   $aSelector
     * @return  true
     */
    final public function setSelector(array $aSelector)
    {
        $this->aSelector     = $aSelector;
        $this->aSelectorOrig = $aSelector;
        return true;
    }

    /**
     * execute
     *
     * @return  true
     */
    final public function execute()
    {
        // 初期化
        $this->_initialize();
        // コントローラの処理実行
        try {
            $this->_preProcess();
            $this->_process();
            $this->_postProcess();
            $this->_finalize();
            return true;
        } catch (\SC\exception\controller\ConvertModel\Chain $oException) {
            // チェーン → モデルセレクト
            $sModel             = "SC\\controller\\{$this->aChain['model']}Model";
        } catch (\SC\exception\controller\AbstractModel\LoginErrorChain $oException) {
            // チェーン → モデルセレクト (管理画面用)
            $sModel             = "SC\\controller\\Admin\\{$this->aChain['model']}Model";
        } catch (\SC\exception\AbstractException $oException) {
            // その他の場合はリスロー
            throw $oException;
        }
        // モデルコントローラを駆動
        $oModel                 = $sModel::getInstance();
        $oModel->setSelector($this->aChain);
        $bRetCode               = property_exists($this, 'aTplValues');
        if ( $bRetCode === true ) {
            $oModel->aTplValues = $this->aTplValues;
        }
        $bRetCode               = property_exists($this, 'aStored');
        if ( $bRetCode === true ) {
            $oModel->aStored    = $this->aStored;
        }
        $oModel->execute();
        $this->_finalize();
        return true;
    }

    /**
     * 初期化処理
     *
     * @return  true
     */
    final protected function _initialize()
    {
        // 必須インスタンスを集約
        $this->oRequest          = \Request::getInstance();
        $this->oResponse         = \Response::getInstance();
        $this->oSession          = \Session::getInstance();
        // PCREエラーログ
        $sLogPCREError           = strtolower($this->oRequest->getServer('SC_LOG_PCRE_ERROR', ''));
        if ( $sLogPCREError === '1' || $sLogPCREError === 'on' || $sLogPCREError === 'true' ) {
            $this->bLogPCREError = true;
        } else {
            $this->bLogPCREError = false;
        }
        return true;
    }

    /**
     * 終了化処理
     *
     * @return true
     */
    final protected function _finalize()
    {
        return true;
    }

    /**
     * プロセス
     *
     * @return true
     */
    abstract protected function _process();

    /**
     * プロセス前処理
     *
     * @return true
     */
    protected function _preProcess()
    {
        // セッション管理
        $bUseSession           = false;
        $sCacheLimiter         = '';
        // プレビューの場合には常にセッション開始
        if ( $this->aSelector['preview'] !== '' ) {
            $bUseSession       = true;
            $sCacheLimiter     = 'nocache';
        } else {
            // モデルがエラーでなければセッションを開始
            $sModel            = \ArrayUtil::getValue($this->aSelector, 'model', '');
            if ( $sModel !== 'Error' ) {
                $bUseSession   = \ArrayUtil::getValue($this->aSelector, 'session', true);
            } else {
                $bUseSession   = \ArrayUtil::getValue($this->aSelector, 'session', false);
            }
            if ( $bUseSession === true ) {
                $sCacheLimiter = trim(\ArrayUtil::getValue($this->aSelector, 'cachelimiter', ''));
            }
        }
        if ( $bUseSession === true ) {
            if ( $sCacheLimiter !== '' ) {
                $this->oSession->setCacheLimiter($sCacheLimiter);
            }
            $this->oSession->start();
        }
        // プレビューの場合にはログイン状態をチェック
        if ( $this->aSelector['preview'] !== '' ) {
            $bCanPreview       = \SC\model\Login::canPreview();
            if ( $bCanPreview !== true ) {
                // プレビューセッションクッキーは削除
                $this->_removeCookie($this->aSelector['type']);
                // プレビュー不可なら管理画面トップへ
                $this->_chainToAdminTop();
            }
        }
        return true;
    }

    /**
     * プロセス後処理
     *
     * @return true
     */
    protected function _postProcess()
    {
        return true;
    }

    /**
     * ログインチェック
     *
     * @return  bool    true
     * @throw   SC\exception\controller\AbstractModel\LoginErrorChain
     */
    protected function _checkLogin()
    {
        // ログインチェック
        try {
            \SC\model\Login::check(true);
        } catch (\SC\exception\model\Login\NotLogin $oException) {
            // 管理画面トップを表示するか？
            if ( static::SHOW_LOGIN !== true ) {
                // 表示しない → 例外を投げる
                throw $oException;
            }
            // 未ログインなら管理画面のトップへ
            $this->_chainToAdminTop();
        }
        return true;
    }

    /**
     * 管理画面のトップへ
     *
     * @return  bool    true
     * @throw   SC\exception\controller\AbstractModel\LoginErrorChain
     * @throw   SC\exception\controller\AbstractModel\EmptyLoginErrorConfig
     */
    protected function _chainToAdminTop()
    {
        // 未ログインなら管理画面のトップへ
        $sEntryPoint      = $this->oRequest->getEntryPoint(true);
        if ( $sEntryPoint === '' ) {
            $sEntryPoint  = '/';
        }
        $this->oRequest->setEntryPoint($sEntryPoint);
        $sWebRootPath     = $this->oRequest->getWebRootPath(true);
        if ( $sWebRootPath === '' ) {
            $sWebRootPath = '/';
        }
        $this->oRequest->setWebRootPath($sWebRootPath);
        $this->oRequest->setPathInfo('/');
        $this->oRequest->setOrigPathInfo('/');
        $aSelector        = \SC\libs\ModelSelectorAdmin::select('', '/');
        $sModel           = "SC\\controller\\Admin\\{$aSelector['model']}Model";
        // 未ログインならチェーン
        $sChain           = (string) 'error-login';
        $aChain           = (array)  \ArrayUtil::getValue($aSelector['config']['models'], $sChain, array());
        if ( $aChain === array() ) {
            throw new \SC\exception\controller\AbstractModel\EmptyLoginErrorConfig("There is no login error config as '$sChain'.");
        }
        // チェーンする場合にはチェーン情報を構成してリスロー
        $this->aChain     = \SC\libs\ModelSelectorAdmin::makeSelector($aChain, $aSelector['config'], $this->aSelector['name']);
        $this->aTplValues = (array) \ArrayUtil::unite($this->aTplValues, array(), true);
        throw new \SC\exception\controller\AbstractModel\LoginErrorChain("Do chain to '{$sChain}' < '{$this->aSelector['name']}'");
    }

    /**
     * クッキーに書き込み
     *
     * @return true
     */
    protected function _setCookie($sStage, $sPreviewSID, $iExpire = 0)
    {
        // クッキーに書き込み
        $sPrefix = 'SMARTCONVERT_PREVIEW';
        return setcookie(urlencode("{$sPrefix}SID#{$sStage}"), $sPreviewSID, $iExpire, '/', null, false, false);
    }

    /**
     * クッキーから削除
     *
     * @param   string  $sStage
     * @return  true
     */
    protected function _removeCookie($sStage)
    {
        $sPrefix = 'SMARTCONVERT_PREVIEW';
        $iExpire = time()-60*60*24*365;
        setcookie(urlencode("{$sPrefix}SID#{$sStage}"), 'deleted', $iExpire, '/', null, false, false);
        setcookie(urlencode("{$sPrefix}URL#{$sStage}"), 'deleted', $iExpire, '/', null, false, false);
        return true;
    }
}
