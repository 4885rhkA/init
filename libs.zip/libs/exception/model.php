<?php
/**
 * modelの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception;

/**
 * modelの例外
 */
class model extends \SC\exception\AbstractException
{
}
