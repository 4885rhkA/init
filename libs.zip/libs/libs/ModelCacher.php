<?php
/**
 * ModelCacher
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ModelCacher
 */
class ModelCacher
{
    /**
     * 設定ファイルのキャッシュ配置場所のベース
     *
     * @var string CONFIG_CACHE_BASE
     */
    const CONFIG_CACHE_BASE = AP_DIR;

    /**
     * 設定ファイルのキャッシュ配置場所
     *
     * @var string CONFIG_CACHE_DIR
     */
    const CONFIG_CACHE_DIR = 'tmp/config/cache';

    /**
     * 設定ファイルのキャッシュファイル
     *
     * @var string CONFIG_CACHE_NAME
     */
    const CONFIG_CACHE_NAME = 'models-cache.php';

    /**
     * 設定ファイルのキャッシュロック
     *
     * @var string CONFIG_CACHE_LOCK
     */
    const CONFIG_CACHE_LOCK = 'models-cache.lock';

    /**
     * キャッシュを使用しないロック
     *
     * @var string CACHE_NOUSE_LOCK
     */
    const CACHE_NOUSE_LOCK = 'tmp/cache-nouse.lock';

    /**
     * キャッシュID
     *
     * @var string CACHE_ID
     */
    const CACHE_ID = 'tmp/cache_id.txt';

    /**
     * モデル情報
     *
     * @var array $aConfig
     */
    protected $aConfig = array();

    /**
     * キャッシュファイル
     *
     * @var string $sFilename
     */
    protected $sFilename = '';

    /**
     * ロックディレクトリ
     *
     * @var string $sLock
     */
    protected $sLock = '';

    /**
     * ロックのログ
     *
     * @var bool $bLogLock
     */
    protected $bLogLock = true;

    /**
     * インスタンス
     *
     * @var array(SC\libs\ModelCacher) $aInstance
     */
    protected static $aInstance = array();

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // ロック状況をログ出力するか否か
        $sLogLock               = Request::getServer('SC_LOG_MODEL_CACHE_LOCK', '');
        if ( $sLogLock === 'true' || $sLogLock === 'on' || $sLogLock === '1' ) {
            $this->bLogLock     = true;
        }
        // キャッシュIDの指定があるか？
        $aCacheIdInfo           = array( 'SC', SC_PRODUCT_VERSION );
        $bRetCode               = file_exists(AP_DIR . '/' . static::CACHE_ID);
        if ( $bRetCode === true ) {
            $sCacheId           = file_get_contents(AP_DIR . '/' . static::CACHE_ID);
            if ( $sCacheId !== '' ) {
                $aCacheIdInfo[] = md5($sCacheId);
            }
        }
        $sCacheFilename         = join('-', $aCacheIdInfo) . '.' . static::CONFIG_CACHE_NAME;
        // キャッシュファイル
        $this->sFilename        = join('/', array(
            static::CONFIG_CACHE_BASE,
            static::CONFIG_CACHE_DIR,
            $sCacheFilename,
        ));
        // ロックファイル
        $this->sLock            = join('/', array(
            static::CONFIG_CACHE_BASE,
            static::CONFIG_CACHE_DIR,
            static::CONFIG_CACHE_LOCK,
        ));
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\ModelCacher
     */
    public static function getInstance()
    {
        $sClass                         = get_called_class();
        $bRetCode                       = isset(self::$aInstance[$sClass]);
        if ( $bRetCode !== true ) {
            static::$aInstance[$sClass] = new static();
        }
        return static::$aInstance[$sClass];
    }

    /**
     * モデル情報のゲット
     *
     * @return  array   モデル情報
     */
    public static function get()
    {
        $oSelf = static::getInstance();
        return $oSelf->aConfig;
    }

    /**
     * モデル情報のセット
     *
     * @param   array   $aConfig    モデル情報
     * @return  bool    true
     */
    public static function set(array $aConfig)
    {
        $oSelf              = static::getInstance();
        // キャッシュを使用しないロックファイル
        $bRetCode           = file_exists(AP_DIR . '/' . static::CACHE_NOUSE_LOCK);
        if ( $bRetCode === true ) {
            // キャッシュなし
            $oSelf->aConfig = array();
            return true;
        }
        $oSelf->aConfig     = $aConfig;
        return $oSelf->_save();
    }

    /**
     * プロパティ情報のセット
     *
     * @param   array   $aProps     プロパティ情報
     * @return  SC\libs\ModelCacher
     */
    public static function __set_state(array $aProps)
    {
        $oSelf          = static::getInstance();
        $oSelf->aConfig = ArrayUtil::getValue($aProps, 'aConfig', array());
        return $oSelf;
    }

    /**
     * モデル情報の読み込み
     *
     * @return  array   モデル情報
     */
    public static function load()
    {
        // インスタンスを取得
        $oSelf              = static::getInstance();
        // キャッシュを使用しないロックファイル
        $bRetCode           = file_exists(AP_DIR . '/' . static::CACHE_NOUSE_LOCK);
        if ( $bRetCode === true ) {
            // 再帰的にディレクトリを作成
            try {
                ErrorHandler::setThrowNextExceptionOn();
                $bRetCode   = unlink($oSelf->sFilename);
                ErrorHandler::setThrowNextExceptionOff();
            } catch (\SC\exception\php\error $oException) {
                // PHPエラー例外が発生したが無視する
            }
            // キャッシュなし
            return array();
        }
        $bRetCode           = $oSelf->_load();
        if ( $bRetCode !== true ) {
            $oSelf->aConfig = array();
        }
        return $oSelf->aConfig;
    }

    /**
     * モデル情報の読み込み
     *
     * @return  bool    true
     */
    protected function _load()
    {
        // 読めるか？
        $bRetCode = is_readable($this->sFilename);
        if ( $bRetCode !== true ) {
            // 読めない場合にはそのまま終わり
            return false;
        }
        // 読めるならPHPファイルとして読む
        require_once $this->sFilename;
        // ファイルのmtimeをチェック
        return $this->_checkFileMTime();
    }

    /**
     * ファイルのmtimeをチェック
     *
     * @return  bool    true/false
     */
    protected function _checkFileMTime()
    {
        // ファイルのチェック
        $aFileMTimes    = ArrayUtil::getValue($this->aConfig, 'files', array());
        foreach ( $aFileMTimes as $sFilename => $iMTime ) {
            // チェックしないファイル
            if ( $iMTime === false ) {
                continue;
            }
            // 読み込みチェック
            $bRetCode   = is_readable($sFilename);
            if ( $bRetCode !== true ) {
                // 読めないのでエラー
                return false;
            }
            // mtimeチェック
            $iFileMTime = filemtime($sFilename);
            if ( $iFileMTime !== $iMTime ) {
                // mtimeが等しくないのでエラー
                return false;
            }
        }
        return true;
    }

    /**
     * モデル情報の保存
     *
     * @return  bool    true
     */
    protected function _save()
    {
        // ロックする
        $bRetCode = $this->_lock();
        if ( $bRetCode !== true ) {
            // 既にロックされている → キャッシュしない
            return false;
        }
        // キャッシュデータ作成
        $sOutput  = '<?php \\' . var_export($this, true) . ';';

        // ファイルの書き込み
        $oFile    = File::getInstance($this->sFilename . '.tmp');
        $iLen     = strlen($sOutput);
        $iSize    = $oFile->write($sOutput, true, true);
        if ( $iLen !== $iSize ) {
            // 書き込み失敗
            throw new \Exception('writing error');
        }
        // 上書きで移動
        $bRetCode = $oFile->moveTo($this->sFilename, true, true);
        if ( $this->bLogLock === true ) {
            if ( $bRetCode === true ) {
                \Log::trace("Cached models: path=[{$this->sFilename}] (size=$iSize).");
            }
        }
        // ロック解除
        $this->_unlock();
        return $bRetCode;
    }

    /**
     * キャッシュ作成時のロック
     *
     * @return  bool    true
     */
    protected function _lock()
    {
        // ディレクトリを作成する
        try {
            // 再帰的にディレクトリを作成
            ErrorHandler::setThrowNextExceptionOn();
            $bRetCode = mkdir($this->sLock, 0777, true);
            ErrorHandler::setThrowNextExceptionOff();
            if ( $bRetCode !== true ) {
                // ディレクトリの作成失敗
                throw new \SC\exception\libs\ModelCacher\CantLock("Can't lock: path='{$this->sLock}'.");
            }
            // ロックした
            if ( $this->bLogLock === true ) {
                \Log::trace("Locked for models cache: path=[{$this->sLock}].");
            }
        } catch (\SC\exception\php\error\Warning $oException) {
            // 既にロックファイルがある
            if ( $this->bLogLock === true ) {
                \Log::trace("Already locked for models cache: path=[{$this->sLock}].");
            }
            return false;
        }
        return $bRetCode;
    }

    /**
     * キャッシュ作成時のアンロック
     *
     * @return  int     削除された数
     */
    protected function _unlock()
    {
        try {
            // 常に削除
            $oLock    = File::getInstance($this->sLock);
            $iRemoved = $oLock->remove(true, true);
            // ロックした
            if ( $this->bLogLock === true ) {
                \Log::trace("Unlocked for models cache: path=[{$this->sLock}].");
            }
        } catch (\SC\exception\libs\File\DoesNotExist $oException) {
            // 存在しない → 正常終了
            return 0;
        }
        return $iRemoved;
    }
}
