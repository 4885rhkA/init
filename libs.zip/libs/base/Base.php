<?php
/**
 * 基本クラス
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\base;

/**
 * 基本クラス
 */
final class Base
{
    /**
     * 初期化済みか否か
     *
     * @var array $aInitialized
     */
    protected static $aInitialized = array(
        'constants' => false,
    );

    /**
     * 製品情報
     *
     * @var string
     */
    const PRODUCT_INI = 'smartconvert.ini';

    /**
     * インスタンス
     *
     * @var SC\base\Loader $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // ファイル作成マスク指定
        umask(0);
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\base\Base
     */
    protected static function _getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new self();
        }
        return self::$oInstance;
    }

    /**
     * 初期化
     *
     * @return  bool    true
     */
    public static function initialize()
    {
        $oSelf        = self::_getInstance();
        $bRetCode     = true;
        foreach ( self::$aInitialized as $sMethod => $bInitialized ) {
            $bRetCode = $oSelf->{ '_' . $sMethod }();
            if ( $bRetCode !== true ) {
                return $bRetCode;
            }
        }
        return true;
    }

    /**
     * エラー発生
     *
     * @param   string  $sMethod
     * @param   array   $aBackTrace
     * @return  bool    true
     */
    protected function _raise($sMethod, array $aBackTrace)
    {
        // メソッド名
        $sCallee     = get_class($this) . '::' . $sMethod;
        $aCaller     = next($aBackTrace);
        if ( $aTrace === false ) {
            $aCaller = $aBackTrace[0];
        }
        return trigger_error("PHP Fatal error: Call to undefined method {$sCallee}() in {$aCaller['file']} on line {$aCaller['line']}", E_USER_ERROR);
    }

    /**
     * オーバーロードスタティックコール
     *
     * @param   string  $sMethod
     * @param   array   $aArgs
     * @return  bool    true
     */
    public static function __callStatic($sMethod, array $aArgs)
    {
        // 有効なメソッドがあるか？
        $oSelf      = self::_getInstance();
        $sProtected = '_' . $sMethod;
        // メソッドが有効か？
        $bRetCode   = method_exists($oSelf, $sProtected);
        if ( $bRetCode !== true ) {
            return $oSelf->_raise($sMethod, debug_backtrace(0));
        }
        $bRetCode   = isset(self::$aInitialized[$sMethod]);
        if ( $bRetCode !== true ) {
            return $oSelf->_raise($sMethod, debug_backtrace(0));
        }
        // 有効なメソッド
        if ( self::$aInitialized[$sMethod] === true ) {
            // 初期化済みなら処理しない
            return true;
        }
        // 初期化処理
        return forward_static_call_array(array($oSelf, $sProtected), $aArgs);
    }

    /**
     * 定数作成
     *
     * @return  bool    true
     */
    protected function _constants()
    {
        // 製品定数
        $aProductInfo = parse_ini_file(__DIR__ . '/' . static::PRODUCT_INI, true);
        $bRetCode = defined('SC_PRODUCT_NAME');
        if ( $bRetCode !== true ) {
            define('SC_PRODUCT_NAME',     $aProductInfo['product']['name']);
        }
        $bRetCode = defined('SC_PRODUCT_VERSION');
        if ( $bRetCode !== true ) {
            define('SC_PRODUCT_VERSION',  join('.', array($aProductInfo['product']['version'], $aProductInfo['product']['revision'])));
        }

        // フレームワークディレクトリ
        $bRetCode = defined('FW_DIR');
        if ( $bRetCode !== true ) {
            // 未定義なら取得
            define('FW_DIR', $this->_getFrameworkDirname());
        }

        // アプリケーションディレクトリ
        $bRetCode = defined('AP_DIR');
        if ( $bRetCode !== true ) {
            // 未定義なら取得
            define('AP_DIR', $this->_getAppDirname());
        }

        // WEBルート
        $bRetCode = defined('WEBROOT_PATH');
        if ( $bRetCode !== true ) {
            // 未定義なら取得
            define('WEBROOT_PATH', $this->_getWebRoot());
        }

        // エントリポイント
        $bRetCode = defined('ENTRY_POINT');
        if ( $bRetCode !== true ) {
            // 未定義なら取得
            define('ENTRY_POINT', $this->_getEntryPoint());
        }

        // 初期化済みフラグを立てる
        $sMethod  = substr(__FUNCTION__, 1);
        self::$aInitialized[$sMethod] = true;

        return true;
    }

    /**
     * フレームワークディレクトリ名の取得
     *
     * @return  string
     */
    protected function _getFrameworkDirname()
    {
        // 環境変数から取得
        $bRetCode     = isset($_SERVER['SC_FRAMEWORK_DIR']);
        if ( $bRetCode === true ) {
            return $_SERVER['SC_FRAMEWORK_DIR'];
        }
        // なければ現在位置から生成
        return realpath(__DIR__ . '/..');
    }

    /**
     * アプリケーションディレクトリ名の取得
     *
     * @return  string
     */
    protected function _getAppDirname()
    {
        // 環境変数から取得
        $bRetCode     = isset($_SERVER['SC_APPLICATION_DIR']);
        if ( $bRetCode === true ) {
            return $_SERVER['SC_APPLICATION_DIR'];
        }
        // トレースバック
        $aTrace       = debug_backtrace(0);
        $aTrace       = array_reverse($aTrace, true);
        foreach ( $aTrace as $aInfo ) {
            // 初期ディレクトリのチェック
            $sFile    = $aInfo['file'];
            clearstatcache();
            $bRetCode = file_exists($sFile);
            if ( $bRetCode === true ) {
                // 存在するファイルなら1つ上のディレクトリをアプリケーションディレクトリとする
                return realpath(dirname($sFile) . '/..');
            }
        }
        // なければフレームワークディレクトリとする
        return FW_DIR;
    }

    /**
     * WEBルートの取得
     *
     * @return  string
     */
    protected function _getWebRoot()
    {
        // 環境変数から取得
        $bRetCode     = isset($_SERVER['SC_ENTRY_POINT_SCRIPT_NAME']);
        if ( $bRetCode !== true ) {
            // 指定があれば使う
            $bRetCode = isset($_SERVER['SC_WEBROOT_PATH']);
            if ( $bRetCode === true ) {
                return $_SERVER['SC_WEBROOT_PATH'];
            }
            // デフォルトは「/」
            return '/';
        }
        // チェック
        $sCheck       = strtolower(trim($_SERVER['SC_ENTRY_POINT_SCRIPT_NAME']));
        if ( $sCheck !== '1' && $sCheck !== 'true' && $sCheck !== 'on' ) {
            // デフォルトは「/」
            return '/';
        }
        $bRetCode     = isset($_SERVER['SC_WEBROOT_PATH_IS_ENTRY_PARENT']);
        if ( $bRetCode !== true ) {
            // デフォルトは「/」
            return '/';
        }
        // チェック
        $aEntryFiles  = explode(PATH_SEPARATOR, trim($_SERVER['SC_WEBROOT_PATH_IS_ENTRY_PARENT']));
        $sFilename    = basename($_SERVER['SCRIPT_NAME']);
        foreach ( $aEntryFiles as $sEntryFile ) {
            if ( $sFilename === $sEntryFile ) {
                // スクリプト名の親ディレクトリを指定
                return dirname($_SERVER['SCRIPT_NAME']);
            }
        }
        // スクリプト名のまま
        return $_SERVER['SCRIPT_NAME'] . '/';
    }

    /**
     * エントリポイントの取得
     *
     * @return  string
     */
    protected function _getEntryPoint()
    {
        // 環境変数から取得
        $bRetCode     = isset($_SERVER['SC_ENTRY_POINT_SCRIPT_NAME']);
        if ( $bRetCode !== true ) {
            // 指定があれば使う
            $bRetCode = isset($_SERVER['SC_ENTRY_POINT']);
            if ( $bRetCode === true ) {
                return $_SERVER['SC_ENTRY_POINT'];
            }
            // デフォルトは「/」
            return WEBROOT_PATH;
        }
        // チェック
        $sCheck       = strtolower(trim($_SERVER['SC_ENTRY_POINT_SCRIPT_NAME']));
        if ( $sCheck !== '1' && $sCheck !== 'true' && $sCheck !== 'on' ) {
            // デフォルトは「/」
            return WEBROOT_PATH;
        }
        // スクリプト名を使用
        return $_SERVER['SCRIPT_NAME'] . '/';
    }
}
