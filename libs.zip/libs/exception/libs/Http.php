<?php
/**
 * Httpの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs;

/**
 * Httpの例外
 */
class Http extends \SC\exception\libs
{
}
