<?php
/**
 * SmartyConstants
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * SmartyContants
 */
class SmartyConstants
{
    /**
     * 定数リスト
     *
     * @var array $aConstants
     */
    protected $aConstants = array();

    /**
     * 条件対象
     *
     * @var array $aTarget
     */
    protected $aTarget = array(
        // SmartConvert Environment Variables
        'SC_SHOW_HIDDEN_PAGE'  => '__SHOW_HIDDEN_PAGE__',   // hidden page
    );

    /**
     * 条件対象
     *
     * @var array $aTargetPrefix
     */
    protected $aTargetPrefix = array(
        // SmartConvert Environment Variables
        'SC_OPT_'              => 'OPT_',                   // optional
    );

    /**
     * インスタンス
     *
     * @var SC\libs\SmartyConstants $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\SmartyConstants
     */
    public static function getInstance()
    {
        if ( static::$oInstance === NULL ) {
            static::$oInstance = new static();
            static::$oInstance->_initialize();
        }
        return static::$oInstance;
    }

    /**
     * 定数を取得
     *
     * @return  array   定数配列
     */
    public static function get()
    {
        $oSelf = static::getInstance();
        return $oSelf->aConstants;
    }

    /**
     * 定数をセット
     *
     * @return  array   定数配列
     */
    protected function _initialize()
    {
        // オブジェクトを取得
        $oRequest                   = Request::getInstance();
        $oResponse                  = Response::getInstance();
        $iHTTPStatus                = -1;
        // プレビュー情報
        $sDisables                  = ',' . strtolower(trim($oRequest->getServer('SC_DISABLES_STAGE', 'verify,develop'))) . ',';
        $aStages                    = array(
            'live'    => true,
            'verify'  => true,
            'develop' => true,
        );
        foreach ( $aStages as $sStage => $bEnabled ) {
            $bRetCode               = strpos($sDisables, ",$sStage,");
            if ( $bRetCode !== false ) {
                $aStages[$sStage]   = false;
            }
        }
        // 予約変数の処理
        $aConstants                 = array(
            '__SC_NAME__'          => SC_PRODUCT_NAME,
            '__SC_VERSION__'       => SC_PRODUCT_VERSION,
            '__ENTRY_POINT__'      => $oRequest->getEntryPoint(),
            '__WEBROOT_PATH__'     => $oRequest->getWebRootPath(),
            '__WEB_ROOT__'         => $oRequest->getEntryPoint(),
            '__CONTENTS_ROOT__'    => $oRequest->getWebRootPath(),
            '__SC_SOURCE_HOST__'   => $oRequest->getServer('SC_SOURCE_HOST', '127.0.0.1'),
            '__HTTP_HOST__'        => $oRequest->getHost(),
            '__HTTP_PORT__'        => $oRequest->getPort(),
            '__HTTP_PROTO__'       => $oRequest->getProto(),
            '__STAGING__'          => Util::getUseStaging(),
            '__STAGING_SP__'       => Util::getUseStagingSP(),
            '__HTTPS__'            => $oRequest->getProto(),
            '__HTTP_PATH__'        => $oRequest->getPathInfo(),
            '__PATH_INFO__'        => $oRequest->getPathInfo(),
            '__ORIG_PATH_INFO__'   => $oRequest->getServer('ORIG_PATH_INFO', '/'),
            '__HTTP_METHOD__'      => $oRequest->getServer('REQUEST_METHOD'),
            '__HTTP_QUERY__'       => $oRequest->getServer('QUERY_STRING'),
            '__QUERY_STRING__'     => $oRequest->getServer('QUERY_STRING'),
            '__POST__'             => $oRequest->getPostAll(),
            '__GET__'              => $oRequest->getGetAll(),
            '__COOKIE__'           => $oRequest->getCookieAll(),
            '__REQUEST__'          => $oRequest->getRequestAll(),
            '__SESSION_ID__'       => Session::getSessId(),
            '__ACCESS_KEY__'       => Log::getAccessKey(),
            '__ACCESS_ID__'        => Log::getAccessId(),
            '__UNIQUE_ID__'        => Log::getUniqId(),
            '__ACCESS_TIME__'      => Log::getAccessTime(),
            '__HTTP_CODE__'        => $iHTTPStatus,
            '__HTTP_MESSAGE__'     => HttpStatus::getMessage($iHTTPStatus),
            '__MIME_TYPE__'        => $oResponse->getMimeType(),
            '__CHARSET__'          => $oResponse->getOutputEncoding(),
            '__UA__'               => UA::get(),
            '__UA_INFO__'          => UA::getInfo(),
            '__UA_VERSION__'       => UA::getVersion(),
            '__UA_IOS__'           => UA::isIOS(),
            '__UA_ANDROID__'       => UA::isAndroid(),
            '__UA_WINDOWS_PHONE__' => UA::isWindowsPhone(),
            '__UA_BLACKBERRY__'    => UA::isBlackBerry(),
            '__UA_IS_SMARTPHONE__' => UA::isSmartPhone(),
            '__UA_IS_TABLET__'     => UA::isTablet(),
            '__STAGES__'           => $aStages,
            '__USE_AUTOSCALE__'    => (bool) $oRequest->getServer('SC_USE_AUTOSACLE', '0'),
            '__DC_AMAZON_WS__'     => (bool) $oRequest->getServer('SC_DC_AMAZON_WS',  '1'),
        );
        // SC_OPTs
        $aServers                  = $oRequest->getServerAll();
        foreach ( $aServers as $sName => $mValue ) {
            $bFound                = false;
            $bRetCode              = isset($this->aTarget[$sName]);
            if ( $bRetCode === true ) {
                // 指定キーがあれば保持
                $bFound            = true;
                $sKey              = $this->aTarget[$sName];
            } else {
                foreach ( $this->aTargetPrefix as $sPrefix => $sKeyPrefix ) {
                    $iLen          = strlen($sPrefix);
                    $iCmp          = strncmp($sPrefix, $sName, $iLen);
                    if ( $iCmp === 0 ) {
                        // 指定キーの接頭辞があれば保持
                        $bFound    = true;
                        $sKey      = '__' . $sKeyPrefix . substr($sName, $iLen) . '__';
                        break;
                    }
                }
            }
            if ( $bFound !== true ) {
                // 保持しないなら次へ
                continue;
            }
            $bRetCode              = isset($aConstants[$sKey]);
            if ( $bRetCode === true ) {
                // 予約変数は上書きしない
                continue;
            }
            $aConstants[$sKey]     = $mValue;
        }
        // deprecated
        $sReservedValue             = strtolower(trim($oRequest->getServer('SC_USE_DEPRECATED_RESERVED_VALUE', '1')));
        if ( $sReservedValue === '1' || $sReservedValue === 'true' || $sReservedValue === 'on' ) {
            $aDeprecated            = array(
                'sWebRoot'      => $aConstants['__WEB_ROOT__'],
                'sContentsRoot' => $aConstants['__CONTENTS_ROOT__'],
                'sHost'         => $aConstants['__HTTP_HOST__'],
                'sProto'        => $aConstants['__HTTP_PROTO__'],
                'sAccessKey'    => $aConstants['__ACCESS_KEY__'],
                'sAccessTime'   => $aConstants['__ACCESS_TIME__'],
            );
            $aConstants             = ArrayUtil::unite($aConstants, $aDeprecated, false);
        }
        $this->aConstants           = $aConstants;
        return true;
    }
}
