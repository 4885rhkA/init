<?php
/**
 * 抽象AO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * 抽象AO
 */
abstract class AbstractAO extends \SC\libs\ArrayObject
{
    /**
     * プロパティ型指定があるもののみ保持できる
     *
     * $this->aPropTypesにて指定があるプロパティのみ保持するか否かを判定する
     *
     * @var bool CAN_STORE_ONLY_RESERVED_KEY
     */
    const CAN_STORE_ONLY_RESERVED_KEY = true;

    /**
     * プロパティキー名指定があるもののみ保持できる
     *
     * インクリメント方式(キー名無指定)で値を保持するか否かを判定する
     * true:  キー名の指定が必須
     * false: キー名の指定がない→インクリメント方式
     *
     *  (ex) true: $arr[] = value; → 例外 \SC\exception\libs\ArrayObject\EmptyPropertyName
     *
     * @var bool CAN_STORE_ONLY_SPECIFIED_KEY
     */
    const CAN_STORE_ONLY_SPECIFIED_KEY = true;

    /**
     * ArrayObjectクラス名をリセットするか
     *
     * @var bool RESET_ARRAY_CLASS
     */
    const RESET_ARRAY_CLASS = true;
}
