<?php
/**
 * パラメータがNULL型ではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\parameter;

/**
 * パラメータがNULL型ではなかった場合の例外
 */
class NotANull extends \SC\exception\common\parameter
{
}
