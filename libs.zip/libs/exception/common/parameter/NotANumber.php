<?php
/**
 * パラメータが数値型(疑似型)ではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\parameter;

/**
 * パラメータが数値型(疑似型)ではなかった場合の例外
 */
class NotANumber extends \SC\exception\common\parameter
{
}
