<?php
/**
 * サイト管理モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * サイト管理モデルコントローラ
 */
class SiteModel extends StaticModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * ユーザ
     *
     * @var SC\model\user $oUser
     */
    protected $oUser = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oSite  = \SC\model\Site::getInstance();
        $this->oStage = \SC\model\Stage::getInstance();
        $this->oUser  = \SC\model\User::getInstance();

        // サイト情報を取得
        $siteId       = $this->oLogin->getSiteId();
        $siteInfo     = $this->oSite->getData($siteId);
        $isReserved   = $this->oSite->isReserved($siteId);
        $reserveTime  = $this->oSite->getReserveTime($siteId);
        if ( $isReserved !== false ) {
            $siteInfo['isReserved']  = true;
            $siteInfo['reserveTime'] = substr($reserveTime, 0, 4) . '/' . substr($reserveTime, 4, 2) . '/' . substr($reserveTime, 6, 2) . ' ' . substr($reserveTime, 8, 2) . ':' . substr($reserveTime, 10, 2) ;
        } else {
            $siteInfo['isReserved']  = false;
            $siteInfo['reserveTime'] = false;
        }

        // ステージ情報を取得
        $stageInfo = array(
            'live'    => array(),
            'verify'  => array(),
            'develop' => array(),
        );
        $this->oStage->setNoWarningOn();
        if ( $siteInfo['stglive'] === true ) {
            $stageInfo['live']    = $this->oStage->getData('live');
        }
        if ( $siteInfo['stgverify'] === true ) {
            $stageInfo['verify']  = $this->oStage->getData('verify');
        }
        if ( $siteInfo['stgdevelop'] === true ) {
            $stageInfo['develop'] = $this->oStage->getData('develop');
        }
        $this->oStage->setNoWarningOff();

        // サイトIDの有効性チェック
        //      ・サイトIDの存在チェック
        //      ・サイトのView権限チェック

        // ユーザ一覧を取得
        $userList = $this->oUser->getList($siteId);

        // リリース対象のファイル一覧を取得
        $unreleaseedFiles = $this->oStage->getUnreleasedFiles('live');

        // ステージングの現在のブランチ名を取得
        $branchName = $this->oStage->getCurrentBranchName();

        // ステージングの変換元の一覧を取得
        $stagingSources = $this->oStage->getStagingSources();

        $this->aTplValues = array(
            'login'           => $this->oLogin->getData(),
            'site'            => $siteInfo,
            'stages'          => $stageInfo,
            'users'           => $userList,
            'unreleasedfiles' => $unreleaseedFiles,
            'branch'          => $branchName,
            'sources'         => $stagingSources,
            // @todo サーバリソース
            // @todo サイトレポート
            // @todo 作業履歴
        );

        return parent::_process();
    }
}
