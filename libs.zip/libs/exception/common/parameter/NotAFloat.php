<?php
/**
 * パラメータが浮動小数点型ではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\parameter;

/**
 * パラメータが浮動小数点型ではなかった場合の例外
 */
class NotAFloat extends \SC\exception\common\parameter
{
}
