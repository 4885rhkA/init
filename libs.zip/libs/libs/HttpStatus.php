<?php
/**
 * HTTPステータスを取得
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * HTTPステータスを取得
 */
final class HttpStatus
{
    /**
     * HTTPステータスコード初期
     *
     * @var int NEVER_DONE
     */
    const NEVER_DONE = -1;

    /**
     * HTTPステータスコード不明
     *
     * @var int UNKNOWN
     */
    const UNKNOWN = 0;

    /**
     * HTTPステータスコードOK
     *
     * @var int OK
     */
    const OK = 200;

    /**
     * HTTPステータスコードサーバーエラー
     *
     * @var int INTERNAL_SERVER_ERROR
     */
    const INTERNAL_SERVER_ERROR = 500;

    /**
     * HTTPステータスコードリスト
     *
     * @var array $aHttpStatus
     */
    protected static $aHttpStatus = array(
        // 初期 or 異常
        -1  => 'Never Done',
        0   => 'Unknown',

        // 1xx Informational
        100 => 'Continue',
        101 => 'Switching Protocols',
        102 => 'Processing',
        // 2xx Success
        200 => 'OK',
        201 => 'Created',
        202 => 'Accepted',
        203 => 'Non-Authoritative Information',
        204 => 'No Content',
        205 => 'Reset Content',
        206 => 'Partial Content',
        207 => 'Multi-Status',
        226 => 'IM Used',
        // 3xx Redirection
        300 => 'Multiple Choices',
        301 => 'Moved Permanently',
        302 => 'Found',
        303 => 'See Other',
        304 => 'Not Modified',
        305 => 'Use Proxy',
        306 => '(Unused)',
        307 => 'Temporary Redirect',
        // 4xx Client Error
        400 => 'Bad Request',
        401 => 'Unauthorized',
        402 => 'Payment Required',
        403 => 'Forbidden',
        404 => 'Not Found',
        405 => 'Method Not Allowed',
        406 => 'Not Acceptable',
        407 => 'Proxy Authentication Required',
        408 => 'Request Timeout',
        409 => 'Conflict',
        410 => 'Gone',
        411 => 'Length Required',
        412 => 'Precondition Failed',
        413 => 'Request Entity Too Large',
        414 => 'Request-URI Too Long',
        415 => 'Unsupported Media Type',
        416 => 'Requested Range Not Satisfiable',
        417 => 'Expectation Failed',
        418 => 'I\'m a teapot',
        422 => 'Unprocessable Entity',
        423 => 'Locked',
        424 => 'Failed Dependency',
        426 => 'Upgrade Required',
        // 5xx Server Error
        500 => 'Internal Server Error',
        501 => 'Not Implemented',
        502 => 'Bad Gateway',
        503 => 'Service Unavailable',
        504 => 'Gateway Timeout',
        505 => 'HTTP Version Not Supported',
        506 => 'Variant Also Negotiates',
        507 => 'Insufficient Storage',
        509 => 'Bandwidth Limit Exceeded',
        510 => 'Not Extended',
    );

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * HTTPステータスコード配列を取得
     *
     * @return  array
     */
    public static function getList()
    {
        return self::$aHttpStatus;
    }

    /**
     * HTTPステータスメッセージを取得
     *
     * @return  int     $iStatus
     * @return  string  HTTPステータスメッセージ
     */
    public static function getMessage($iStatus)
    {
        // 数値か
        $bRetCode    = is_numeric($iStatus);
        if ( $bRetCode !== true ) {
            // 数値以外はNG
            throw new \SC\exception\common\parameter\NotAScalar('Status code is not an integer.');
        }
        $bRetCode    = array_key_exists($iStatus, self::$aHttpStatus);
        if ( $bRetCode !== true ) {
            // 不明なステータスコード
            $iStatus = 0;
        }
        return self::$aHttpStatus[$iStatus];
    }
}
