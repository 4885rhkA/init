<?php
/**
 * ファイルが通常のファイルではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\filesystem;

/**
 * ファイルが通常のファイルではなかった場合の例外
 */
class NotAFile extends \SC\exception\common\filesystem
{
}
