<?php
/**
 * FieldAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * FieldAO
 */
class FieldAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'name'       => 'string',   // フィールド名
        'type'       => 'string',   // フィールドの型
        'value'      => 'mixed',    // フィールドの値
        'expr'       => 'bool',     // trueでvalueを式として扱いバインドしない
        'key'        => 'bool',     // RecordListAOのキーとして使うか否か
    );
}
