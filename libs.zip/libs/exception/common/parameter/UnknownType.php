<?php
/**
 * パラメータの型が不明な場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\parameter;

/**
 * パラメータの型が不明な場合の例外
 */
class UnknownType extends \SC\exception\common\parameter
{
}
