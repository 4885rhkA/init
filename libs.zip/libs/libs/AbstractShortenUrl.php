<?php
/**
 * 抽象ShortenUrl
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * 抽象ShortenUrl
 *
 * シングルトンではないが静的にコールした場合には常に同一のインスタンス
 */
abstract class AbstractShortenUrl
{
    /**
     * 短縮URL生成サービスURL
     *
     * @var string SHORTENER
     */
    const SHORTENER = 'https://';

    /**
     * 接続タイムアウト
     *
     * @var int TIMEOUT
     */
    const TIMEOUT = 10;

    /**
     * インスタンス
     *
     * @var SC\libs\AbstractShortenUrl $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\AbstractShortenUrl
     */
    protected static function _getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * 短縮URLの取得
     *
     * @param   string  $sLongUrl   短縮前URL
     * @return  string  短縮後URL
     */
    public static function shorten($sLongUrl)
    {
        trigger_error('Abstract function ' . get_called_class() . '::' . __FUNCTION__ . '() cannot contain body', E_USER_ERROR);
    }

    /**
     * 短縮URLの取得
     *
     * @param   array   $aOptions   短縮に必要な情報
     * @return  string  短縮後URL
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _shorten(array $aOptions)
    {
        // タイムアウト
        Http::setTimeout(static::TIMEOUT);
        try {
            // ソースを取得
            $sResponse   = Http::POST(static::SHORTENER, $aOptions);
            // 取得できない場合には例外が発生
        } catch (\SC\exception\libs\Http\CantExecHTTP $oException) {
            // 取得できない場合には空文字をセット
            $sResponse   = '';
        }
        return $sResponse;
    }
}
