<?php
/**
 * 抽象例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception;

/**
 * 抽象例外
 */
abstract class AbstractException extends \Exception
{
    /**
     * 例外の追加情報
     *
     * @var     array   $aErrInfo
     */
    protected $aErrInfo = array();

    /**
     * 呼び出し元インスタンス
     *
     * @var     object  $oCaller
     */
    protected $oCaller = NULL;

    /**
     * コンストラクタ
     *
     * @param   string      $sMessage
     * @param   int         $iCode
     * @param   Exception   $oPrevious
     *
     *
     */
    final public function __construct($sMessage='', $iCode=0, \Exception $oPrevious=NULL)
    {
        // 親クラスのコンストラクタコール
        parent::__construct($sMessage, 0, $oPrevious);
        // コードが文字列ではない場合用の対策
        $this->code        = $iCode;
        // 呼び出し元インスタンス
        $aBackTrace        = debug_backtrace(true);
        $iMax              = count($aBackTrace);
        for ( $i=1 ; $i<$iMax ; $i++ ) {
            $bRetCode      = isset($aBackTrace[$i]['object']);
            if ( $bRetCode !== true ) {
                // オブジェクト以外は除外
                continue;
            }
            $bRetCode      = is_a($aBackTrace[$i]['object'], __CLASS__);
            if ( $bRetCode === true ) {
                // 例外のインスタンスは除外
                continue;
            }
            // 最近接オブジェクトあり
            $this->oCaller = $aBackTrace[$i]['object'];
            break;
        }
    }

    /**
     * 例外の追加情報をセット
     *
     * @param   array   $aErrInfo
     * @return  bool    true
     */
    final public function setErrInfo(array $aErrInfo)
    {
        $this->aErrInfo = $aErrInfo;
        return true;
    }

    /**
     * 例外の追加情報をゲット
     *
     * @return  array   追加情報
     */
    final public function getErrInfo()
    {
        return $this->aErrInfo;
    }

    /**
     * 呼び出し元インスタンスを取得
     *
     * @return  object  $oCaller
     */
    final public function getCaller()
    {
        return $this->oCaller;
    }
}
