<?php
/**
 * ログインしていない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\model\Login;

/**
 * ログインしていない場合の例外
 */
class NotLogin extends \SC\exception\model\Login
{
}
