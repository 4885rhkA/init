<?php
/**
 * インプットコントローラがすでに初期化済みである場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\AbstractInput;

/**
 * インプットコントローラがすでに初期化済みである場合の例外
 */
class AlreadyInitialized extends \SC\exception\controller\AbstractInput
{
}
