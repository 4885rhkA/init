<?php
/**
 * XPathを使用したHTML用の抽出装置
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * XPathを使用したHTML用の抽出装置
 */
class XPathExtractor extends AbstractExtractor
{
    /**
     * ログXMLエラー
     *
     * @var bool $bLogLIBXMLError
     */
    protected $bLogLIBXMLError = false;

    /**
     * PCREエラーログ
     *
     * @var bool $bLogPCREError
     */
    protected $bLogPCREError = false;

    /**
     * DOMドキュメントに応じたXPathオブジェクト
     *
     * @var DOMXPath $oXPath
     */
    protected $oXPath = NULL;

    /**
     * HTMLかXMLか？
     *
     * @var bool $bHTML
     */
    protected $bHTML = true;

    /**
     * ローダー
     *
     * @var string $sLoader
     */
    protected $sLoader = 'loadHTML';

    /**
     * セーバー
     *
     * @var string $sSaver
     */
    protected $sSaver = 'saveHTML';

    /**
     * ノード処理メソッド指定
     *
     * @var array $aProcessNodeMethods
     */
    protected $aProcessNodeMethods = array(
        XML_ELEMENT_NODE        => '_extractValueFromDOMElement',
        XML_ATTRIBUTE_NODE      => '_extractValueFromDOMAttr',
        XML_CDATA_SECTION_NODE  => '_extractValueFromDOMText',
        XML_COMMENT_NODE        => '_extractValueFromDOMText',
        XML_TEXT_NODE           => '_extractValueFromDOMText',
        '__DEFAULT__'           => '_extractValueFromDOMNode',
    );

    /**
     * 有効な型指定
     *
     * @var array $aValidTypes
     */
    protected $aValidTypes = array(
        'i'         => 'int',
        'int'       => 'int',
        'integer'   => 'int',
        'long'      => 'int',
        'short'     => 'int',
        'f'         => 'float',
        'float'     => 'float',
        'double'    => 'float',
        'real'      => 'float',
        'number'    => 'float',
        's'         => 'string',
        'str'       => 'string',
        'string'    => 'string',
        'c'         => 'string',
        'char'      => 'string',
        'text'      => 'string',
        'bool'      => 'bool',
        'boolean'   => 'bool',
    );

    /**
     * テキスト修飾子
     *
     * @var array $aTextModifiers
     */
    protected $aTextModifiers = array(
        'trim'      => '_textModifierTrim',
        'rtrim'     => '_textModifierRTrim',
        'ltrim'     => '_textModifierLTrim',
        'join'      => '_textModifierJoin',
        'implode'   => '_textModifierJoin',
    );

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // LIBXMLエラーログ
        $sLogLIBXMLError           = strtolower(Request::getServer('SC_LOG_LIBXML_ERROR', ''));
        if ( $sLogLIBXMLError === '1' || $sLogLIBXMLError === 'on' || $sLogLIBXMLError === 'true' ) {
            $this->bLogLIBXMLError = true;
        } else {
            $this->bLogLIBXMLError = false;
        }
        // PCREエラーログ
        $sLogPCREError             = strtolower(Request::getServer('SC_LOG_PCRE_ERROR', ''));
        if ( $sLogPCREError === '1' || $sLogPCREError === 'on' || $sLogPCREError === 'true' ) {
            $this->bLogPCREError   = true;
        } else {
            $this->bLogPCREError   = false;
        }
        return parent::__construct();
    }

    /**
     * HTMLから変数を抽出する
     *
     * @param   array   $aParams        パラメータ指定
     * @param   string  $sHTML          ソース
     * @param   array   $aOptions       オプション指定
     * @return  array   テンプレート変数値リスト
     */
    protected function _extract(array $aParams, $sHTML, array $aOptions = array())
    {
        // HTMLエンティティがあるか？
        $sSourceBody       = trim($sHTML);
        if ( $sSourceBody === '' ) {
            // ない場合には空の変数値リストを返す
            return array();
        }
        // 書式チェック
        $sFormat           = ArrayUtil::getValue($aOptions, 'format', 'HTML');
        if ( $sFormat === 'HTML' ) {
            $this->bHTML   = true;
            $this->sLoader = 'loadHTML';
            $this->sSaver  = 'saveHTML';
        } else if ( $sFormat === 'XML' ) {
            $this->bHTML   = false;
            $this->sLoader = 'loadXML';
            $this->sSaver  = 'saveXML';
        } else {
            // XPathによる抽出が不可 → 空の変数値リストを返す
            return array();
        }
        // libxmlエラーを内部処理に変更
        $bIError           = libxml_use_internal_errors(true);
        libxml_clear_errors();
        $this->oXPath      = $this->_createXPath($sHTML, $this->sLoader);
        $aValues           = $this->_extractValueWithXPath($aParams);
        // libxmlエラー処理を元に戻す
        libxml_use_internal_errors($bIError);
        return $aValues;
    }

    /**
     * DOMNodeListに応じたテンプレート変数値を返す
     *
     * @param   array   $aParams        パラメータ指定
     * @param   DOMNode $oNode          DOMNode
     * @param   string  $sParentXPath   親XPath
     * @return  array   テンプレート変数値リスト
     */
    protected function _extractValueWithXPath(array $aParams, \DOMNode $oNode = NULL, $sParentXPath = '')
    {
        if ( $oNode === NULL ) {
            $sParentXPath         = '';
        } else {
            $sParentXPath         = " in '$sParentXPath'";
        }
        // テンプレート用の値の抽出
        $aValues                  = array();
        // 要素を取得
        foreach ( $aParams as $sName => $mParams ) {
            // パラメータの形式を整える
            $aParams              = array(
                'xpath'      => '',
                'get'        => array( '_' ),        // _, text, @attr, node, line, <NESTED>
                'parameters' => NULL,
                'type'       => array(
                    '_'      => 'auto',              // キー：getの値
                    'text'   => 'auto',              // 値：auto, string, bool, int, float
                ),
                'forcelist'  => false,
                'unescape'   => false,
                'options'    => array(),                // trim, join
            );
            $bRetCode             = is_array($mParams);
            if ( $bRetCode === true ) {
                $aParams          = \ArrayUtil::unite($aParams, $mParams, true);
            } else {
                $aParams['xpath'] = (string) $mParams;
            }
            // XPath式がなければ次へ
            if ( $aParams['xpath'] === '' ) {
                $aValues[$sName]  = NULL;
                continue;
            }
            // DOMツリーからテンプレート変数を取得してマージ
            $aValues[$sName]      = $this->_extractValueFromDOMWithXPath($aParams, $oNode);
            if ( $this->bLogExtractValue === true ) {
                \Log::dump($aValues[$sName], "XPath of element [$sName]: '{$aParams['xpath']}'{$sParentXPath} =>", \Log::LEVEL_TRACE);
            }
        }
        return $aValues;
    }

    /**
     * HTMLソースからDOMドキュメントに応じたXPathオブジェクトを返す
     *
     * @param   string  $sSourceBody    ソース
     * @param   string  $sLoader        loadHTML
     * @return  DOMXPath
     */
    protected function _createXPath($sSourceBody, $sLoader = 'loadHTML')
    {
        // HTMLを読み込んでDOMツリーに変換
        $oDOM        = new \DOMDocument('1.0', 'UTF-8');
        $bRetCode    = $oDOM->$sLoader($sSourceBody);
        $this->_logLibXMLErrorIfExists('Loading HTML');
        // DOMツリーの操作用のXPathを生成
        $oXPath      = new \DOMXPath($oDOM);
        $this->_logLibXMLErrorIfExists('Creating XPath');
        return $oXPath;
    }

    /**
     * DOMNodeListに応じたテンプレート変数値を返す
     *
     * @param   array       $aParams    抽出パラメータ
     * @param   DOMNode     $oNode      DOMNode
     * @return  array       テンプレート変数値リスト
     */
    protected function _extractValueFromDOMWithXPath(array $aParams, \DOMNode $oNode = NULL)
    {
        // XPath式を評価
        if ( $oNode === NULL ) {
            $mRetValue                 = $this->oXPath->evaluate($aParams['xpath']);
        } else {
            $mRetValue                 = $this->oXPath->evaluate($aParams['xpath'], $oNode);
        }
        $this->_logLibXMLErrorIfExists("Evaluate XPath for '{$aParams['xpath']}'");
        // XPath式の評価が失敗したか？
        if ( $mRetValue === false ) {
            // エラー時にはfalse
            return false;
        }
        // スカラー値が取得されたか？
        $bRetCode                  = is_scalar($mRetValue);
        if ( $bRetCode === true ) {
            // XPath式がスカラー値を返した
            $mRetValue             = $this->_extractValueFromScalar($aParams, $mRetValue);
            return $mRetValue;
        }
        // DOMNodeListが取得された
        $oNodeList                 = $mRetValue;
        if ( $oNodeList->length < 1 ) {
            // 0件の抽出 → NULLを返す
            return NULL;
        }
        // DOMNodeListを処理
        $aValues                   = $this->_extractValueFromDOMNodeList($aParams, $oNodeList);
        if ( $aParams['forcelist'] === true ) {
            // 必ずリストで返す指定 → そのまま
            return $aValues;
        }
        // ２階層目を必要に応じて平屋建てに
        $aNewValues                = array();
        foreach ( $aValues as $iKey => $aVals ) {
            $iCount                = count($aVals);
            if ( $iCount > 1 ) {
                $aNewValues[$iKey] = $aVals;
            } else {
                $aNewValues[$iKey] = reset($aVals);
            }
        }
        // １階層目を必要に応じて平屋建てに
        if ( $oNodeList->length > 1 ) {
            // 複数 → そのまま
            return $aNewValues;
        }
        // 単数 → 先頭を取得
        $mValue                    = reset($aNewValues);
        return $mValue;
    }

    /**
     * DOMNodeListに応じたテンプレート変数値を返す
     *
     * @param   array       $aParams        パラメータ指定
     * @param   DOMNodeList $oNodeList      DOMNodeList
     * @return  array       テンプレート変数値リスト
     */
    protected function _extractValueFromDOMNodeList(array $aParams, \DOMNodeList $oNodeList)
    {
        // 少なくとも１件以上あるはず
        $aValues                       = array();
        $bAllText                      = true;
        foreach ( $oNodeList as $iKey => $oNode ) {
            // パラメータ方式か？
            $bRetCode                  = is_array($aParams['parameters']);
            if ( $bRetCode === true ) {
                // パラメータ方式ならネスト
                $iXPathKey             = $iKey+1;
                $sParentXPath          = "({$aParams['xpath']})[{$iXPathKey}]";
                $aValues[$iKey]        = $this->_extractValueWithXPath($aParams['parameters'], $oNode, $sParentXPath);
                $bAllText              = false;
                continue;
            }

            // 処理メソッドの特定
            $bRetCode                  = isset($this->aProcessNodeMethods[$oNode->nodeType]);
            if ( $bRetCode === true ) {
                $sMethod               = $this->aProcessNodeMethods[$oNode->nodeType];
            } else {
                $sMethod               = $this->aProcessNodeMethods['__DEFAULT__'];
            }
            if ( $oNode->nodeType !== XML_TEXT_NODE ) {
                $bAllText              = false;
            }
            $mRetValue                 = $this->$sMethod($aParams, $oNode);
            $bRetCode                  = is_array($mRetValue);
            if ( $bRetCode === true ) {
                $bAllText              = false;
                foreach ( $mRetValue as $sName => $mValue ) {
                    // スカラー値が取得されたか？
                    $bRetCode          = is_scalar($mValue);
                    if ( $bRetCode !== true ) {
                        // スカラー値でなければ変換しない
                        continue;
                    }
                    // 型指定があるか？
                    $bRetCode          = isset($aParams['type'][$sName]);
                    if ( $bRetCode !== true ) {
                        // 型指定がなければ変換しない
                        continue;
                    }
                    $mRetValue[$sName] = $this->_setTypeOfValue($aParams['type'], $sName, $mValue);
                }
            }
            $aValues[$iKey]            = $mRetValue;
        }
        // 全てテキストだったか？
        if ( $bAllText === true ) {
            foreach ( $aParams['options'] as $sModifier ) {
                $sMethod               = ArrayUtil::getValue($this->aTextModifiers, $sModifier, '');
                if ( $sMethod === '' ) {
                    continue;
                }
                $aValues               = $this->$sMethod($aParams, $aValues);
            }
        }
        return $aValues;
    }

    /**
     * DOMElementに応じたテンプレート変数値を返す
     *
     *  有効な取得対象
     *      _       :   textContent
     *      text    :   textContent
     *      tag     :   tagName
     *      @attr   :   hasAttribute() / getAttribute()
     *      line    :   getLineNo()
     *      node    :   オブジェクトそのもの
     *
     * @param   array               $aParams        パラメータ指定
     * @param   DOMElement          $oNode          DOMElement
     * @return  array       テンプレート変数値
     */
    protected function _extractValueFromDOMElement(array $aParams, \DOMElement $oNode)
    {
        // 値の取得指定がなければデフォルトにする
        $iCount                             = count($aParams['get']);
        if ( $iCount < 1 ) {
            $aParams['get']                 = array( '_' );
        } else {
            // 全取得？
            $bRetCode                       = in_array('*', $aParams['get']);
            if ( $bRetCode === true ) {
                $aParams['get'][]           = 'text';
                $aParams['get'][]           = 'tag';
                $aParams['get'][]           = '@*';
                $aParams['get'][]           = 'innerhtml';
                $aParams['get']             = array_unique($aParams['get']);
            }
        }
        $aValues                            = array();
        foreach ( $aParams['get'] as $sKey ) {
            // 取得指定は文字列
            $sKey                           = strtolower($sKey);
            $bTag                           = true;
            switch ( $sKey ) {
                // テキスト
                case '_': case 'text':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->textContent);
                    break;

                // タグ名
                case 'tag': case 'tagname':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->tagName);
                    break;

                // 行番号
                case 'line':
                    $aValues[$sKey]         = $oNode->getLineNo();
                    break;

                // ノードオブジェクトそのもの
                case 'node':
                    $aValues[$sKey]         = $oNode;
                    break;

                // HTML表現
                case 'innerhtml':
                case 'innerxml':
                    $bTag                   = false;
                // HTML表現
                case 'html':
                case 'outerhtml':
                case 'xml':
                case 'outerxml':
                    $sHTML                  = $oNode->ownerDocument->{$this->sSaver}($oNode);
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $aParams['unescape'] === true ) {
                        $sHTML              = $this->_unescape($sHTML);
                    }
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $bTag === false ) {
                        $sHTML              = \Util::stripTagBothEnds($sHTML);
                    }
                    $aValues[$sKey]         = $sHTML;
                    break;

                // 全属性
                case '@*':
                    if ( $oNode->attributes !== NULL ) {
                        foreach ( $oNode->attributes as $sName => $oAttrNode ) {
                            $sKey           = '_' . $sName;
                            $aValues[$sKey] = \Util::fixUTF8($oAttrNode->value);
                        }
                    }
                    break;

                // その他
                default:
                    $bRetCode               = (bool) preg_match('#^@([a-z0-9_]+([-:][a-z0-9_]+)*)$#uS', $sKey, $aMatches);
                    if ( $bRetCode === true ) {
                        // 属性名の指定
                        $sAttrName          = $aMatches[1];
                        $sKey               = strtr($sKey, '@:-', '___');
                        $bRetCode           = $oNode->hasAttribute($sAttrName);
                        if ( $bRetCode === true ) {
                            $aValues[$sKey] = \Util::fixUTF8($oNode->getAttribute($sAttrName));
                        } else {
                            $aValues[$sKey] = NULL;
                        }
                    }
                    break;
            }
        }
        return $aValues;
    }

    /**
     * DOMAttrに応じたテンプレート変数値を返す
     *
     *  有効な取得対象
     *      _       :   textContent
     *      text    :   textContent
     *      name    :   name
     *      value   :   value (=textContent)
     *      line    :   getLineNo()
     *      node    :   オブジェクトそのもの
     *
     * @param   array               $aParams        パラメータ指定
     * @param   DOMAttr             $oNode          DOMAttr
     * @return  array       テンプレート変数値
     */
    protected function _extractValueFromDOMAttr(array $aParams, \DOMAttr $oNode)
    {
        // 値の取得指定がなければデフォルトにする
        $iCount                             = count($aParams['get']);
        if ( $iCount < 1 ) {
            $aParams['get']                 = array( '_' );
        } else {
            // 全取得？
            $bRetCode                       = in_array('*', $aParams['get']);
            if ( $bRetCode === true ) {
                $aParams['get'][]           = 'name';
                $aParams['get'][]           = 'text';
                $aParams['get'][]           = 'value';
                $aParams['get']             = array_unique($aParams['get']);
            }
        }
        $aValues                            = array();
        foreach ( $aParams['get'] as $sKey ) {
            $sKey                           = strtolower($sKey);
            $bTag                           = true;
            switch ( $sKey ) {
                // テキスト
                case '_': case 'text':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->textContent);
                    break;

                // 属性名
                case 'name':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->name);
                    break;

                // 属性値
                case 'value':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->value);
                    break;

                // 行番号
                case 'line':
                    $aValues[$sKey]         = $oNode->getLineNo();
                    break;

                // ノードオブジェクトそのもの
                case 'node':
                    $aValues[$sKey]         = $oNode;
                    break;

                // HTML表現
                case 'innerhtml':
                case 'innerxml':
                    $bTag                   = false;
                // HTML表現
                case 'html':
                case 'outerhtml':
                case 'xml':
                case 'outerxml':
                    $sHTML                  = $oNode->ownerDocument->{$this->sSaver}($oNode);
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $aParams['unescape'] === true ) {
                        $sHTML              = $this->_unescape($sHTML);
                    }
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $bTag === false ) {
                        $sHTML              = \Util::stripTagBothEnds($sHTML);
                    }
                    $aValues[$sKey]         = $sHTML;
                    break;

                // その他
                default:
                    // その他はない
                    break;
            }
        }
        return $aValues;
    }

    /**
     * DOMTextに応じたテンプレート変数値を返す
     *
     *  有効な取得対象
     *      _       :   textContent
     *      text    :   textContent
     *      data    :   data (=textContent)
     *      length  :   length
     *      line    :   getLineNo()
     *      node    :   オブジェクトそのもの
     *
     * @param   array               $aParams        パラメータ指定
     * @param   DOMCharacterData    $oNode          DOMText
     * @return  array               テンプレート変数値
     */
    protected function _extractValueFromDOMText(array $aParams, \DOMCharacterData $oNode)
    {
        // 値の取得指定がなければデフォルトにする
        $iCount                             = count($aParams['get']);
        if ( $iCount < 1 ) {
            $aParams['get']                 = array( '_' );
        } else {
            // 全取得？
            $bRetCode                       = in_array('*', $aParams['get']);
            if ( $bRetCode === true ) {
                $aParams['get'][]           = 'text';
                $aParams['get'][]           = 'data';
                $aParams['get'][]           = 'length';
                $aParams['get']             = array_unique($aParams['get']);
            }
        }
        $aValues                            = array();
        foreach ( $aParams['get'] as $sKey ) {
            $sKey                           = strtolower($sKey);
            $bTag                           = true;
            switch ( $sKey ) {
                // テキスト
                case '_': case 'text':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->textContent);
                    break;

                // データ
                case 'data':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->data);
                    break;

                // データ長
                case 'length':
                    $aValues[$sKey]         = $oNode->length;
                    break;

                // 行番号
                case 'line':
                    $aValues[$sKey]         = $oNode->getLineNo();
                    break;

                // ノードオブジェクトそのもの
                case 'node':
                    $aValues[$sKey]         = $oNode;
                    break;

                // HTML表現
                case 'innerhtml':
                case 'innerxml':
                    $bTag                   = false;
                // HTML表現
                case 'html':
                case 'outerhtml':
                case 'xml':
                case 'outerxml':
                    $sHTML                  = $oNode->ownerDocument->{$this->sSaver}($oNode);
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $aParams['unescape'] === true ) {
                        $sHTML              = $this->_unescape($sHTML);
                    }
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $bTag === false ) {
                        $sHTML              = \Util::stripTagBothEnds($sHTML);
                    }
                    $aValues[$sKey]         = $sHTML;
                    break;

                // その他
                default:
                    // その他はない
                    break;
            }
        }
        return $aValues;
    }

    /**
     * DOMNodeに応じたテンプレート変数値を返す
     *
     *  有効な取得対象
     *      _       :   textContent
     *      text    :   textContent
     *      line    :   getLineNo()
     *      node    :   オブジェクトそのもの
     *
     * @param   array               $aParams        パラメータ指定
     * @param   DOMNode             $oNode          DOMNode
     * @return  array   テンプレート変数値
     */
    protected function _extractValueFromDOMNode(array $aParams, \DOMNode $oNode)
    {
        // 値の取得指定がなければデフォルトにする
        $iCount                             = count($aParams['get']);
        if ( $iCount < 1 ) {
            $aParams['get']                 = array( '_' );
        } else {
            // 全取得？
            $bRetCode                       = in_array('*', $aParams['get']);
            if ( $bRetCode === true ) {
                $aParams['get'][]           = 'text';
                $aParams['get'][]           = 'innerhtml';
                $aParams['get']             = array_unique($aParams['get']);
            }
        }
        $aValues                            = array();
        foreach ( $aParams['get'] as $sKey ) {
            $sKey                           = strtolower($sKey);
            $bTag                           = true;
            switch ( $sKey ) {
                // テキスト
                case '_': case 'text':
                    $aValues[$sKey]         = \Util::fixUTF8($oNode->textContent);
                    break;

                // 行番号
                case 'line':
                    $aValues[$sKey]         = $oNode->getLineNo();
                    break;

                // ノードオブジェクトそのもの
                case 'node':
                    $aValues[$sKey]         = $oNode;
                    break;

                // HTML表現
                case 'innerhtml':
                case 'innerxml':
                    $bTag                   = false;
                // HTML表現
                case 'html':
                case 'outerhtml':
                case 'xml':
                case 'outerxml':
                    $sHTML                  = $oNode->ownerDocument->{$this->sSaver}($oNode);
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $aParams['unescape'] === true ) {
                        $sHTML              = $this->_unescape($sHTML);
                    }
                    $sHTML                  = \Util::fixUTF8($sHTML);
                    if ( $bTag === false ) {
                        $sHTML              = \Util::stripTagBothEnds($sHTML);
                    }
                    $aValues[$sKey]         = $sHTML;
                    break;

                // その他
                default:
                    // その他はない
                    break;
            }
        }
        return $aValues;
    }

    /**
     * スカラー値に応じたテンプレート変数値を返す
     *
     * @param   array   $aParams        パラメータ指定
     * @param   mixed   $mInput         スカラー値
     * @return  mixed   テンプレート変数値
     */
    protected function _extractValueFromScalar(array $aParams, $mInput)
    {
        // 取得対象
        $iCount                    = count($aParams['get']);
        $bRetCode                  = in_array('_', $aParams['get']);
        if ( $iCount === 1 || $iCount === 0 ) {
            // 取得対象が１つもしくは指定なし
            if ( $bRetCode === true ) {
                // 取得指定
                $mValue            = $this->_setTypeOfValue($aParams['type'], '_', $mInput);
            } else {
                // 取得しない
                $mValue            = NULL;
            }
            return $mValue;
        }
        // 取得対象が複数ある
        $aValues                   = array();
        foreach ( $aParams['get'] as $sTarget ) {
            if ( $sTarget === '_' ) {
                $aValues[$sTarget] = $this->_setTypeOfValue($aParams['type'], '_', $mInput);
            } else {
                $aValues[$sTarget] = NULL;
            }
        }
        return $aValues;
    }

    /**
     * 型を変換
     *
     * @param   array   $aTypes     型指定
     * @param   string  $sKey       キー値
     * @param   mixed   $mInput     スカラー値
     * @return  mixed   テンプレート変数値
     */
    protected function _setTypeOfValue(array $aTypes, $sKey, $mInput)
    {
        // 指定があるか？
        $bRetCode = isset($aTypes[$sKey]);
        if ( $bRetCode !== true || $aTypes[$sKey] === 'auto' ) {
            // 自動型指定 → そのまま
            return $mInput;
        }
        // 型指定がある
        $sType    = strtolower($aTypes[$sKey]);
        $bRetCode = isset($this->aValidTypes[$sType]);
        if ( $bRetCode !== true ) {
            // 型指定無効 → そのまま
            return $mInput;
        }
        // 型指定有効
        $sType    = $this->aValidTypes[$sType];
        settype($mInput, $sType);
        return $mInput;
    }

    /**
     * trimテキスト変換
     *
     * @param   array   $aParams    パラメータ指定
     * @param   array   $aValues    値の配列
     * @return  array   値の配列
     */
    protected function _textModifierTrim(array $aParams, array $aValues)
    {
        return array_map('trim', $aValues);
    }

    /**
     * rtrimテキスト変換
     *
     * @param   array   $aParams    パラメータ指定
     * @param   array   $aValues    値の配列
     * @return  array   値の配列
     */
    protected function _textModifierRTrim(array $aParams, array $aValues)
    {
        return array_map('rtrim', $aValues);
    }

    /**
     * ltrimテキスト変換
     *
     * @param   array   $aParams    パラメータ指定
     * @param   array   $aValues    値の配列
     * @return  array   値の配列
     */
    protected function _textModifierLTrim(array $aParams, array $aValues)
    {
        return array_map('ltrim', $aValues);
    }

    /**
     * joinテキスト変換
     *
     * @param   array   $aParams    パラメータ指定
     * @param   array   $aValues    値の配列
     * @return  array   値の配列
     */
    protected function _textModifierLJoin(array $aParams, array $aValues)
    {
        $sGlue = (string) $aParams['options']['join'];
        return array(join($sGlue, $aValues));
    }

    /**
     * libxmlのエラーが発生していた場合にログを出力する
     *
     * @param   string  $sTitle         ログ出力タイトル
     * @return  bool    true
     */
    protected function _logLibXMLErrorIfExists($sTitle)
    {
        if ( $this->bLogLIBXMLError !== true ) {
            return true;
        }
        // libxmlのエラーを取得して消去
        $aErrors   = libxml_get_errors();
        libxml_clear_errors();
        // カウントしてなければ抜ける
        $iCount    = count($aErrors);
        if ( $iCount < 1 ) {
            return true;
        }
        // エラーがあるのでログとして出力
        \Log::warning("{$sTitle}: libxml error has occured [count={$iCount}]");
        foreach ( $aErrors as $oError ) {
            switch ( $oError->level ) {
                case LIBXML_ERR_WARNING:
                    $sLevel = 'Warning';
                    break;
                case LIBXML_ERR_ERROR:
                    $sLevel = 'Error';
                    break;
                case LIBXML_ERR_FATAL:
                    $sLevel = 'Fatal error';
                    break;
                default:
                    $sLevel = 'Unknown error';
                    break;
            }
            $sMessage = trim($oError->message);
            $sMessage = "LibXML {$sLevel}: {$sMessage} [code={$oError->code}] on line {$oError->line} at column {$oError->column}.";
            \Log::warning($sMessage);
        }
        return true;
    }

    /**
     * HTML-ENTITIESをデコード
     *
     * @param   array   $mTextValue     文字列
     * @return  array   HTML-ENTITIESをデコードした文字列
     */
    protected function _unescape($mTextValue)
    {
        // 有効長文字列か？
        $bRetCode           = Validate::isStringNotZero($mTextValue);
        if ( $bRetCode !== true ) {
            // 文字列でなけば次へ
            return $mTextValue;
        }
        // JavaScript/コメントのHTML-ENTITIES対応
        $sSearch        = '#(<script[^>]*>)((?:(?>[^<]+)|(?:<[^/A-Za-z]+)|(?:<(?>[^>]+)(?<!/script)>))+)(</script>)#uisSm';
        $sReplace       = get_class($this) . '::' . '_unescapeHTMLEntites';
        $mRetValue      = preg_replace_callback($sSearch, array(&$this, '_unescapeHTMLEntites'), $mTextValue);
        if ( $mRetValue !== NULL ) {
            $mTextValue = $mRetValue;
        } else {
            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for unescape HTML-ENTITIES of SCRIPT.');
            if ( $this->bLogPCREError === true ) {
                \Log::dump(array(
                    'func'    => 'preg_replace_callback',
                    'search'  => $sSearch,
                    'replace' => $sReplace,
                    'subject' => $mTextValue,
                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
            }
        }
        $sSearch        = '#(<!--)(.+?)(-->)#uisSm';
        $sReplace       = get_class($this) . '::' . '_unescapeHTMLEntites';
        $mRetValue      = preg_replace_callback($sSearch, array(&$this, '_unescapeHTMLEntites'), $mTextValue);
        if ( $mRetValue !== NULL ) {
            $mTextValue = $mRetValue;
        } else {
            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for unescape HTML-ENTITIES of COMMENT.');
            if ( $this->bLogPCREError === true ) {
                \Log::dump(array(
                    'func'    => 'preg_replace_callback',
                    'search'  => $sSearch,
                    'replace' => $sReplace,
                    'subject' => $mTextValue,
                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
            }
        }
        return $mTextValue;
    }

    /**
     * HTML-ENTITIESをデコード
     *
     * @param   array   $aMatches
     * @return  string  置換後の文字列
     */
    protected function _unescapeHTMLEntites(array $aMatches)
    {
        // 参照数
        $iCount         = count($aMatches);
        if ( $iCount === 4 ) {
            // エンティティがあるか？
            $bFound     = (bool) preg_match('#&(?:\x23(?:[0-9]+|x[0-9A-Fa-f]+)|[A-Za-z][0-9A-Za-z]+);#uisSm', $aMatches[2]);
            if ( $bFound !== true ) {
                // エンティティがなければそのまま抜ける
                return $aMatches[0];
            }
            // エンティティはデコードする
            $sContents  = \Util::mb_convert_encoding($aMatches[2], 'UTF-8', 'HTML-ENTITIES');
            $sContents  = $aMatches[1] . $sContents . $aMatches[3];
        } else {
            // その他
            return $aMatches[0];
        }
        return $sContents;
    }
}
