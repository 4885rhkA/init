<?php
/**
 * レスポンス
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * レスポンス
 */
class Response
{
    /**
     * インスタンス
     *
     * @var SC\libs\Response $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * HTTPステータス
     *
     * @var int $iStatus
     */
    protected $iStatus = 200;

    /**
     * HTTPステータスメッセージ
     *
     * @var string $sHTTPStatus
     */
    protected $sHTTPStatus = 'OK';

    /**
     * 通常出力モード
     *
     * @var int MODE_NORMAL
     */
    const MODE_NORMAL = 1;

    /**
     * ダウンロード出力モード
     *
     * @var int MODE_DOWNLOAD
     */
    const MODE_DOWNLOAD = 2;

    /**
     * リダイレクトモード
     *
     * @var int MODE_REDIRECT
     */
    const MODE_REDIRECT = 3;

    /**
     * 出力モード
     *
     * @var int
     */
    protected $iMode = self::MODE_NORMAL;

    /**
     * 通常出力内容
     *
     * @var string $sContent
     */
    protected $sContent = '';

    /**
     * リダイレクト先
     *
     * @var string $sUrl
     */
    protected $sUrl = '';

    /**
     * ダウンロードファイル
     *
     * @var string $sFilename
     */
    protected $sFilename = '';

    /**
     * MIME-Type
     *
     * @var string $sMimeType
     */
    protected $sMimeType = 'text/html';

    /**
     * 内部エンコード
     *
     * @var string $sEncodeInternal
     */
    protected $sEncodeInternal = 'UTF-8';

    /**
     * 出力エンコード
     *
     * @var string $sEncodeOutput
     */
    protected $sEncodeOutput = 'UTF-8';

    /**
     * エンコード配列
     *
     * @var array $aEncodeList
     */
    protected $aEncodeList = array(
        'UTF8'        => 'UTF-8',
        'UTF-8'       => 'UTF-8',
        'EUC-JP'      => 'EUC-JP',
        'EUC_JP'      => 'EUC-JP',
        'EUCJP'       => 'EUC-JP',
        'EUCJP-WIN'   => 'EUC-JP',
        'SHIFT_JIS'   => 'Shift_JIS',
        'SHIFT-JIS'   => 'Shift_JIS',
        'SJIS'        => 'Shift_JIS',
        'SJIS-WIN'    => 'Shift_JIS',
        'XSJIS'       => 'Shift_JIS',
        'X-SJIS'      => 'Shift_JIS',
        'MS_KANJI'    => 'Shift_JIS',
        'WINDOWS-31J' => 'Shift_JIS',
        'CP932'       => 'Shift_JIS',
        'MS932'       => 'Shift_JIS',
        'JIS'         => 'JIS',
        'ISO-2022-JP' => 'ISO-2022-JP',
        'ASCII'       => 'ASCII',
        'US-ASCII'    => 'ASCII',
    );

    /**
     * HTTPヘッダ
     *
     * @var array $aHeaders
     */
    protected $aHeaders = array();

    /**
     * リクエスト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * バッファリングレベル
     *
     * @var int $iOBLevel
     */
    protected $iOBLevel = -1;

    /**
     * ログ出力指定
     *
     * @var int $iLogOutput
     */
    protected $iLogOutput = 0;

    /**
     * エラーテンプレートファイル
     *
     * @var string $sErrorTempalte
     */
    protected $sErrorTempalte = 'error.html';

    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
        $this->oRequest               = \Request::getInstance();

        // バッファリング開始
        $this->iOBLevel               = ob_get_level();
        ob_start();

        // ヘッダクリア
        $this->clearHeaders();

        // ログ出力
        $sLogOutput                   = $this->oRequest->getServer('SC_LOG_OUTPUT', '');
        if ( $sLogOutput !== '' ) {
            $bRetCode                 = is_numeric($sLogOutput);
            if ( $bRetCode === true ) {
                $this->iLogOutput     = (int) $sLogOutput;
            } else {
                $sLogOutput           = strtolower($sLogOutput);
                if ( $sLogOutput === 'true' || $sLogOutput === 'on' ) {
                    $this->iLogOutput = 1;
                } else {
                    $this->iLogOutput = 0;
                }
            }
        }
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Response
     */
    final public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * HTTPステータスをセットする
     *
     * @param   int     $iStatus
     * @return  bool    true
     * @throws  SC\exception\common\parameter\NotAnInt
     * @throws  SC\exception\common\parameter\OutOfRange
     */
    public function setStatus($iStatus)
    {
        // HTTPステータスが数値か？
        $bRetCode          = Validate::isInt($iStatus);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt('HTTP Status must be int');
        }
        // リスト
        $aList             = HttpStatus::getList();
        $bRetCode          = isset($aList[$iStatus]);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\OutOfRange("HTTP Status '$iStatus' must be inside between 100 and 999");
        }
        // ステータスを保持
        $this->iStatus     = $iStatus;
        $this->sHTTPStatus = $aList[$iStatus];

        return true;
    }

    /**
     * HTTPステータスをゲットする
     *
     * @return  int     $iStatus
     */
    public function getStatus()
    {
        return $this->iStatus;
    }

    /**
     * HTTPステータスメッセージをゲットする
     *
     * @return  string  $sHTTPStatus
     */
    public function getHTTPStatus()
    {
        return $this->sHTTPStatus;
    }

    /**
     * 出力セット
     *
     * @param   string  $sReulst
     * @param   int     $iStatus
     * @return  bool    true
     * @throws  SC\exception\common\parameter\NotAString
     * @throws  SC\exception\common\parameter\OutOfRange
     */
    public function setResult($sContent, $iStatus=200)
    {
        // 出力
        $bRetCode       = Validate::isString($sContent);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('HTTP contents must be string');
        }
        // ステータス
        if ( $iStatus < 100 || 999 < $iStatus ) {
            throw new \SC\exception\common\parameter\OutOfRange("HTTP Status '$iStatus' must be inside between 100 and 999");
        }
        // 通常出力の指定
        $this->iMode    = static::MODE_NORMAL;
        $this->setStatus($iStatus);
        $this->sContent = "$sContent";
        return true;
    }

    /**
     * リダイレクトセット
     *
     * @param   string  $sUrl
     * @param   int     $iStatus
     * @return  bool    true
     * @throws  SC\exception\common\parameter\ZeroByteString
     * @throws  SC\exception\common\parameter\OutOfRange
     */
    public function setRedirect($sUrl, $iStatus=302)
    {
        // リダイレクト先
        $bRetCode    = Validate::isStringNotZero($sUrl);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Redirect URL must be string');
        }
        // ステータス
        if ( $iStatus < 300 || 399 < $iStatus ) {
            throw new \SC\exception\common\parameter\OutOfRange("HTTP Status '$iStatus' must be inside between 300 and 399");
        }
        // リダイレクトの指定
        $this->iMode = static::MODE_REDIRECT;
        $this->setStatus($iStatus);
        $this->addHeader('Location', $sUrl, true, NULL, NULL);
        $this->sUrl  = "$sUrl";
        return true;
    }

    /**
     * ダウンロードセット
     *
     * @param   string  $sFilename
     * @param   int     $iStatus
     * @param   string  $sMimeType
     * @param   string  $sCharset
     * @return  bool    true
     * @throws  SC\exception\common\parameter\NotAString
     * @throws  SC\exception\common\parameter\ZeroByteString
     * @throws  SC\exception\common\parameter\OutOfRange
     */
    public function setDownload($sFilename, $iStatus = 200, $sMimeType = NULL, $sCharset = NULL)
    {
        // ダウンロードファイル
        $bRetCode        = Validate::isString($sFilename);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Download filename must be string');
        }
        // MIME-Type
        $bRetCode        = Validate::isStringNotZero($sFilename);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Download filename must be string');
        }
        // ステータス
        if ( $iStatus < 100 || 999 < $iStatus ) {
            throw new \SC\exception\common\parameter\OutOfRange("HTTP Status '$iStatus' must be inside between 100 and 999");
        }
        // 通常出力の指定
        $this->iMode     = static::MODE_DOWNLOAD;
        $this->setStatus($iStatus);
        $this->sFilename = "$sFilename";
        // MIME
        $sMimeType       = trim($sMimeType);
        $this->sMimeType = "$sMimeType";
        return true;
    }

    /**
     * エラー表示をセット
     *
     * @param   string  $sContent
     * @param   int     $iStatus
     * @return  bool    true
     * @throws  SC\exception\common\parameter\OutOfRange
     */
    public function setError($sContent='', $iStatus=500)
    {
        // ステータス
        if ( $iStatus < 400 || 999 < $iStatus ) {
            throw new \SC\exception\common\parameter\OutOfRange("HTTP Status '$iStatus' must be inside between 400 and 999");
        }
        return $this->setResult($sContent, $iStatus);
    }

    /**
     * 400エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError400($sContent='')
    {
        return $this->setError($sContent, 400);
    }

    /**
     * 401エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError401($sContent='')
    {
        return $this->setError($sContent, 401);
    }

    /**
     * 403エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError403($sContent='')
    {
        return $this->setError($sContent, 403);
    }

    /**
     * 404エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError404($sContent='')
    {
        return $this->setError($sContent, 404);
    }

    /**
     * 500エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError500($sContent='')
    {
        return $this->setError($sContent, 500);
    }

    /**
     * 501エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError501($sContent='')
    {
        return $this->setError($sContent, 501);
    }

    /**
     * 502エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError502($sContent='')
    {
        return $this->setError($sContent, 502);
    }

    /**
     * 503エラー表示をセット
     *
     * @param   string  $sContent
     * @return  bool    true
     */
    public function setError503($sContent='')
    {
        return $this->setError($sContent, 503);
    }

    /**
     * 内部エンコードの指定
     *
     * @param   string  $sEncode
     * @return  bool    true
     * @throws  SC\exception\common\parameter\ZeroByteString
     */
    public function setInternalEncoding($sEncode)
    {
        // 内部エンコード
        $bRetCode              = Validate::isStringNotZero($sEncode);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Encode must be string');
        }
        $sEncode               = "$sEncode";
        $this->sEncodeInternal = $sEncode;
        return true;
    }

    /**
     * 出力エンコードの指定
     *
     * @param   string  $sEncode
     * @return  bool    true
     * @throws  SC\exception\common\parameter\ZeroByteString
     */
    public function setOutputEncoding($sEncode)
    {
        // 出力エンコード
        $bRetCode            = Validate::isString($sEncode);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Encode must be string');
        }
        $sEncode             = trim($sEncode);
        $this->sEncodeOutput = $sEncode;
        return true;
    }

    /**
     * 出力エンコードの取得
     *
     * @param   bool    $bRawEncode     指定したものをそのまま返す
     * @return  string  出力エンコード
     */
    public function getOutputEncoding($bRawEncode = false)
    {
        if ( $bRawEncode === true ) {
            return $this->sEncodeOutput;
        }
        if ( $this->sEncodeOutput === 'pass' ) {
            $sValidEncodeOutput = 'pass';
        } else if ( $this->sEncodeOutput === '' ) {
            $sValidEncodeOutput = '';
        } else {
            $sValidEncodeOutput = ArrayUtil::getValue($this->aEncodeList, strtoupper($this->sEncodeOutput),   'UTF-8');
        }
        return $sValidEncodeOutput;
    }

    /**
     * 出力エンコードの取得
     *
     * @param   bool    $bRawEncode     指定したものをそのまま返す
     * @return  string  出力エンコード
     */
    public function getRawOutputEncoding()
    {
        return $this->sEncodeOutput;
    }

    /**
     * MIME-TYPEの指定
     *
     * @return  string
     * @throws  SC\exception\common\parameter\ZeroByteString
     */
    public function setMimeType($sMimeType)
    {
        // MIME-Type
        $bRetCode        = Validate::isStringNotZero($sMimeType);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('MIME-Type must be string');
        }
        $sMimeType       = "$sMimeType";
        $this->sMimeType = $sMimeType;
        return true;
    }

    /**
     * MIME-TYPEの取得
     *
     * @return  string
     */
    public function getMimeType()
    {
        return $this->sMimeType;
    }

    /**
     * ヘッダの指定
     *
     * @param   string   $sName
     * @param   string   $sValue
     * @param   bool     $bReplace
     * @param   callable $cbEncodeName
     * @param   callable $cbEncodeValue
     * @return  bool     true
     * @throws  SC\exception\common\parameter\ZeroByteString
     * @throws  SC\exception\common\parameter\NotACallback
     */
    public function addHeader($sName, $sValue, $bReplace=true, $cbEncodeName='urlencode', $cbEncodeValue='urlencode')
    {
        // フィールド名
        $bRetCode                             = Validate::isStringNotZero($sName);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('HTTP header requires field name');
        }
        // フィールド値
        $bRetCode                             = Validate::isStringNotZero($sValue);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('HTTP header requires field value');
        }
        // 同一フィールド名のヘッダを置換するか否か
        if ( $bReplace !== false ) {
            $bReplace                         = true;
        }
        // フィールド名をエンコードするか？
        if ( $cbEncodeName !== NULL ) {
            $bRetCode                         = is_callable($cbEncodeName, false, $sMethod);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\common\parameter\NotACallback("Encode function '$sMethod' is not callable");
            }
            $sName                            = call_user_func($cbEncodeName, $sName);
        }
        // フィールド値をエンコードするか？
        if ( $cbEncodeValue !== NULL ) {
            $bRetCode                         = is_callable($cbEncodeValue, false, $sMethod);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\common\parameter\NotACallback("Encode function '$sMethod' is not callable");
            }
            $sValue                           = call_user_func($cbEncodeValue, $sValue);
        }
        // 置換か？
        if ( $bReplace === true ) {
            $this->aHeaders[$sName]           = $sValue;
        } else {
            $bRetCode                         = isset($this->aHeaders[$sName]);
            if ( $bRetCode === true ) {
                $bRetCode                     = is_array($this->aHeaders[$sName]);
                if ( $bRetCode === true ) {
                    $this->aHeaders[$sName][] = $sValue;
                } else {
                    $this->aHeaders[$sName]   = array($this->aHeaders[$sName], $sValue);
                }
            } else {
                $this->aHeaders[$sName]       = $sValue;
            }
        }
        return true;
    }

    /**
     * 送出予定ヘッダをクリアする
     *
     * @return  bool    true
     */
    public function clearHeaders()
    {
        // 送出ヘッダのリストを除去
        $aHeaders   = headers_list();
        foreach ($aHeaders as $sHeader) {
            $aParts = explode(':', $sHeader, 2);
            header_remove($aParts[0]);
        }
        return true;
    }

    /**
     * ヘッダ出力する
     *
     * @return  bool    true
     */
    public function sendHeader()
    {
        // すでにヘッダ送出済みか否か
        $bRetCode         = headers_sent($sPosFile, $iPosLine);
        if ( $bRetCode === true ) {
            // すでにヘッダ送出済み
            \Log::warning("Cannot modify header information - headers already sent by (output started at {$sPosFile}:{$iPosLine})");
            return false;
        }
        // デフォルトの指定を除去
        ini_set('default_mimetype', NULL);
        ini_set('default_charset', NULL);
        // ヘッダ出力
        foreach ( $this->aHeaders as $sName => $mValue ) {
            $bRetCode     = is_array($mValue);
            if ( $bRetCode !== true ) {
                $mValue   = array($mValue);
            }
            $sLower       = strtolower($sName);
            if ( $sLower === 'set-cookie' ) {
                $bReplace = false;
            } else {
                $bReplace = true;
            }
            foreach ( $mValue as $sValue ) {
                if ( $sValue !== '' ) {
                    // ヘッダを出力する
                    header("{$sName}: {$sValue}", $bReplace);
                }
            }
        }
        // HTTPステータスは必ず上書き
        $sProto           = $this->oRequest->getServer('SERVER_PROTOCOL', 'HTTP/1.1');
        header("{$sProto} {$this->iStatus} {$this->sHTTPStatus}", true, $this->iStatus);
        // アクセスキーを出力
        header('X-' . SC_PRODUCT_NAME . '-AccessKey: ' . \Log::getAccessKey(), true);
        // ログ出力
        if ( $this->iLogOutput > 0 ) {
            $aHeaders     = headers_list();
            \Log::dump($aHeaders, 'Output data:', \Log::LEVEL_TRACE);
        }
        return true;
    }

    /**
     * レスポンスヘッダの値を取得
     *
     * @return  array   レスポンスヘッダ配列
     */
    public static function getResponseHeaders()
    {
        $aRawHeaders                   = headers_list();
        $aHeaders                      = array();
        foreach ( $aRawHeaders as $sHeader ) {
            $aHeaderParts              = explode(':', $sHeader, 2);
            $sNameLower                = strtolower($aHeaderParts[0]);
            $sValue                    = ltrim($aHeaderParts[1]);
            $bRetCode                  = isset($aHeaders[$sNameLower]);
            if ( $bRetCode !== true ) {
                $aHeaders[$sNameLower] = array();
            }
            $aHeaders[$sNameLower][]   = array(
                'name'  => $aHeaderParts[0],
                'value' => $sValue,
            );
        }
        return $aHeaders;
    }

    /**
     * 出力する
     *
     * @param   int     $iOBLevel
     * @param   bool    $bReturnString
     * @return  string  出力文字列
     */
    public function out($iOBLevel = -1, $bReturnString = false)
    {
        // モードに応じて出力を切り替える
        switch ($this->iMode) {
            case static::MODE_REDIRECT:
                $sMethod = '_redirect';
                break;

            case static::MODE_DOWNLOAD:
                $sMethod = '_download';
                break;

            case static::MODE_NORMAL:
            default:
                $sMethod = '_display';
                break;
        }
        $sOutput         = $this->$sMethod($iOBLevel, $bReturnString);
        return $sOutput;
    }

    /**
     * リダイレクト出力
     *
     * @param   int     $iOBLevel
     * @param   bool    $bReturnString
     * @return  string  ''
     */
    protected function _redirect($iOBLevel = -1, $bReturnString = false)
    {
        // ヘッダ出力しないケースはない
        $bRetCode = headers_sent($sPosFile, $iPosLine);
        if ( $bRetCode === false ) {
            $this->addHeader('Content-Type', 'text/html', true, NULL, NULL);
            $this->sendHeader();
        }
        // リダイレクトではボディはない
        LogRegistry::save('sc:request', 'CONTENT_LENGTH', 0);
        LogRegistry::save('sc:display', 'CONTENT_LENGTH', 0);
        return '';
    }

    /**
     * ファイル出力
     *
     * @param   int     $iOBLevel
     * @param   bool    $bReturnString
     * @return  string  ''
     * @throws  SC\exception\common\filesystem\NotReadable
     */
    protected function _download($iOBLevel = -1, $bReturnString = false)
    {
        // ファイルの読み込みチェック
        clearstatcache();
        $bRetCode            = is_readable($this->sFilename);
        if ( $bRetCode !== true ) {
            // ファイルが読めない → 404 Not Found
            $this->setError404();
            throw new \SC\exception\common\filesystem\NotReadable("Can't read file '{$this->sFilename}'");
        }
        // ファイルの時刻をチェック
        $iTime               = filemtime($this->sFilename);
        $sLastModified       = gmdate('D, d M Y H:i:s e', $iTime); // Sun, 06 Nov 1994 08:49:37 GMT
        $sETag               = Hash::hash($iTime, $this->sFilename, 'hmac-sha1');
        // キャッシュチェック
        $bCached             = false;
        $sNoneMatch          = trim($this->oRequest->getServer('HTTP_IF_NONE_MATCH', ''), ' "');
        if ( $sNoneMatch === '*' ) {
            $bCached         = true;
        } else if ( $sNoneMatch === '' ) {
            $bCached         = false;
        } else {
            $sModified       = $this->oRequest->getServer('HTTP_IF_MODIFIED_SINCE', '');
            if ( $sModified !== '' ) {
                // 指定があればチェック
                if ( $sModified === $sLastModified && $sNoneMatch === $sETag ) {
                    // キャッシュされている
                    $bCached = true;
                }
            }
        }
        if ( $bCached === true ) {
            // キャッシュされているので304 Not Modified
            return $this->_fileNotModified();
        }
        $this->addHeader('Etag',          $sETag,         true, NULL, NULL);
        $this->addHeader('Last-Modified', $sLastModified, true, NULL, NULL);

        // Content-Typeはエンコードしない
        $sContentType        = $this->_getContentType('');
        $this->addHeader('Content-Type', $sContentType, true, NULL, NULL);
        // ヘッダ出力しないケースはない
        $bRetCode            = headers_sent($sPosFile, $iPosLine);
        if ( $bRetCode === false ) {
            $this->sendHeader();
        }
        // 全バッファリング解除
        $iOBLevel            = ob_get_level();
        $iContentLength      = 0;
        for ( $i=$iOBLevel ; $i>0 ; $i-- ) {
            $sOBContents     = ob_get_flush();
            $iContentLength += strlen($sOBContents);
        }
        // 出力は4096bytes毎にフラッシュ
        ob_start(NULL, 4096);
        $iFileSize           = readfile($this->sFilename, false);
        $iContentLength     += $iFileSize;
        \Log::trace("Download file '{$this->sFilename}' [size={$iFileSize}]");
        // ファイル出力ではホディは返さない
        LogRegistry::save('sc:request', 'CONTENT_LENGTH', $iContentLength);
        LogRegistry::save('sc:display', 'CONTENT_LENGTH', $iContentLength);
        return '';
    }

    /**
     * 304 Not Modified
     *
     * @return  string  ''
     */
    protected function _fileNotModified()
    {
        // ヘッダ出力しないケースはない
        $bRetCode            = headers_sent($sPosFile, $iPosLine);
        if ( $bRetCode === false ) {
            // 304 Not Modified
            $this->setStatus(304);
            $this->sendHeader();
        }
        LogRegistry::save('sc:request', 'CONTENT_LENGTH', 0);
        LogRegistry::save('sc:display', 'CONTENT_LENGTH', 0);
        return '';
    }

    /**
     * 表示出力
     *
     * @param   int     $iOBLevel
     * @param   bool    $bReturnString
     * @return  string  ''
     */
    protected function _display($iOBLevel = -1, $bReturnString = false)
    {
        if ( $this->sEncodeInternal !== 'pass' ) {
            $sValidEncodeInternal = ArrayUtil::getValue($this->aEncodeList, strtoupper($this->sEncodeInternal), 'UTF-8');
        } else {
            $sValidEncodeInternal = 'pass';
        }
        if ( $this->sEncodeOutput === 'pass' ) {
            $sValidEncodeOutput   = 'pass';
        } else if ( $this->sEncodeOutput === '' ) {
            $sValidEncodeOutput   = '';
        } else {
            $sValidEncodeOutput   = ArrayUtil::getValue($this->aEncodeList, strtoupper($this->sEncodeOutput),   'UTF-8');
        }
        // ヘッダ出力しないケースはない
        $bRetCode                 = headers_sent($sPosFile, $iPosLine);
        if ( $bRetCode === false ) {
            // Content-Typeを明示的に指定
            $sContentType         = $this->_getContentType($sValidEncodeOutput);
            $this->addHeader('Content-Type', $sContentType, true, NULL, NULL);
            $this->sendHeader();
        }
        // 初期までバッファリング解除
        if ( $iOBLevel < 0 ) {
            $iOBLevel             = ob_get_level();
        }
        $iContentLength           = 0;
        for ( $i=$iOBLevel ; $i>$this->iOBLevel ; $i-- ) {
            $sOBContents          = ob_get_flush();
            $iContentLength      += strlen($sOBContents);
        }
        // 必要なら文字コード変換を行う
        if ( $sValidEncodeInternal === 'pass' || $sValidEncodeOutput === 'pass' || $sValidEncodeOutput === '' || $sValidEncodeOutput === $sValidEncodeInternal ) {
            $sOutput              = $this->sContent;
        } else {
            $sOutput              = \Util::mb_convert_encoding($this->sContent, $this->sEncodeOutput, $this->sEncodeInternal);
        }
        if ( $bReturnString !== true ) {
            echo $sOutput;
            $iContentLength      += strlen($sOutput);
        }
        LogRegistry::save('sc:request', 'CONTENT_LENGTH', $iContentLength);
        LogRegistry::save('sc:display', 'CONTENT_LENGTH', $iContentLength);
        // ログ出力
        if ( $this->iLogOutput > 1 ) {
            $aHeaders             = headers_list();
            \Log::dump($sOutput, 'Output data:', \Log::LEVEL_TRACE);
        }
        return $sOutput;
    }

    /**
     * Content-Typeを取得
     *
     * @param   string  $sEncode    出力する文字エンコードの指定
     * @return  string  エラーテンプレートファイル名
     */
    protected function _getContentType($sEncode)
    {
        // MIMEを解析
        $aParts                   = preg_split('#\s*;\s*#u', trim($this->sMimeType));
        $iCount                   = count($aParts);
        $sMimeType                = 'text/html';
        $sCharset                 = '';
        $aPlus                    = array();
        switch ( $iCount ) {
            // 指定がなかった
            case 0:
                break;

            // 指定が１つだけ
            case 1:
                $sMimeType        = strtolower($aParts[0]);
                break;

            // 複数指定あり
            default:
                $sMimeType        = strtolower($aParts[0]);
                for ( $i=1 ; $i<$iCount ; $i++ ) {
                    $bFound       = (bool) preg_match('#^charset\s*=\s*("[^"]+"|[^\s]+)$#ui', $aParts[$i], $aMatches);
                    if ( $bFound === true && $sCharset === '' ) {
                        $sCharset = trim($aMatches[1], "\x22");
                    } else {
                        $aPlus[]  = $aParts[$i];
                    }
                }
                break;
        }
        // 文字コード付与対象か？
        $bRetCode                 = $this->_isMimeTypeText($sMimeType);
        $aParts                   = array($sMimeType);
        if ( $bRetCode === true ) {
            // 文字コード付与対象
            $sCharset             = ArrayUtil::getValue($this->aEncodeList, strtoupper($sCharset), '');
            $sCharsetLower        = strtolower($sCharset);
            if ( $sCharset === '' || $sCharsetLower === 'pass' || $sCharsetLower === 'auto' ) {
                // 文字コード指定なし → 明示指定を確認
                $sEncode          = trim($sEncode);
                $sEncodeLower     = strtolower($sEncode);
                if ( $sEncodeLower === 'auto' ) {
                    // 文字コード自動設定 → 内部コードを使用
                    $sEncode      = $this->sEncodeOutput;
                }
                $sEncode          = ArrayUtil::getValue($this->aEncodeList, strtoupper($sEncode), '');
                $sEncodeLower     = strtolower($sEncode);
                if ( $sEncode === '' || $sEncodeLower === 'pass' || $sEncodeLower === 'auto' ) {
                    // 内部コードも無効 → 空
                    $sCharset     = '';
                } else {
                    // 明示指定もしくは内部コードを採用
                    $sCharset     = $sEncode;
                }
            }
            // 文字コードの指定があれば
            if ( $sCharset !== '' ) {
                $aParts[]         = "charset={$sCharset}";
            }
        }
        $sContentType             = join('; ', array_merge($aParts, $aPlus));
        return $sContentType;
    }

    /**
     * エラーテンプレートファイル名のゲッタ
     *
     * @return  string  エラーテンプレートファイル名
     */
    public function getErrorTempalte()
    {
        return $this->sErrorTempalte;
    }

    /**
     * エラーテンプレートファイル名をセットする
     *
     * @param   string  $sErrorTempalte
     * @return  bool    true
     * @throws  SC\exception\common\parameter\ZeroByteString
     */
    public function setErrorTempalte($sErrorTempalte)
    {
        // テンプレートファイル名は文字列か？
        $bRetCode             = Validate::isStringNotZero($sErrorTempalte);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Template filename must be string');
        }
        $this->sErrorTempalte = trim($sErrorTempalte);
        return true;
    }

    /**
     * 現在設定されているMIME-Typeがテキストか否か
     *
     * @return  bool    true/false
     */
    public function isMimeTypeText()
    {
        // Content-Typeを取得して判定
        $sContentType = $this->_getContentType('');
        return $this->_isMimeTypeText($sContentType);
    }

    /**
     * MIME-Typeがテキストか否か
     *
     * @param   string  $sMimeType  MIME-Typeがテキストか否か
     * @return  bool    true/false
     */
    protected function _isMimeTypeText($sMimeType)
    {
        // テキストか否か
        $bRetCode = (bool) preg_match('#^(?:text/|application/(?:(?:.+[-\+])?xml(?:[-\+].+)?|(?:x-)?javascript|jsonp?)$)#S', $sMimeType);
        return $bRetCode;
    }
}
