<?php
/**
 * エンコーディングが変換できなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\ConvertModel;

/**
 * エンコーディングが変換できなかった場合の例外
 */
class CantConvertEncoding extends \SC\exception\controller\ConvertModel
{
}
