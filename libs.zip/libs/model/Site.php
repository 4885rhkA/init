<?php
/**
 * サイト
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\model;
use SC\libs\DB as DB;

/**
 * サイト
 */
class Site
{
    /**
     * インスタンス
     *
     * @var SC\model\Site $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * サイトリリース予約ベースディレクトリ
     *
     * @var string RELEASE_BASE
     */
    const RELEASE_BASE = 'tmp/release';

    /**
     * 予約済ディレクトリの指定
     *
     * @var string RESERVED_DIR
     */
    const RESERVED_DIR = 'reserved';

    /**
     * 予約中ディレクトリの指定
     *
     * @var string RESERVING_DIR
     */
    const RESERVING_DIR = 'reserving';

    /**
     * Git作業ディレクトリの指定
     *
     * @var string GIT_DIR
     */
    const GIT_DIR = 'git/contents';

    /**
     * リリースブランチ名
     *
     * @var string RELEASE_BRANCH
     */
    const RELEASE_BRANCH = 'release';

    /**
     * 警告をログ出力しないフラグ
     *
     * @var bool $bNoWarning
     */
    protected $bNoWarning = false;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\model\Site
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * サイト情報を取得する
     *
     * @param   string  サイトID
     * @return  array   サイト情報
     */
    public function getData($sSiteId)
    {
        $aSelect = array(
            'fields' => array(
                'id'        => array( 'type' => 'int',    ),
                'name'      => array( 'type' => 'string', ),
                'domain'    => array( 'type' => 'string', ),
                'summary'   => array( 'type' => 'string', ),
                'stglive'   => array( 'type' => 'bool',   ),
                'stgverify' => array( 'type' => 'bool',   ),
                'stgdevelop'=> array( 'type' => 'bool',   ),
            ),
            'from'          => 'site',
            'conditions'    => array(
                'where'     => 'delflag = 0 AND id = :id',
            ),
            'binds'         => array(
                ':id'       => $sSiteId,
            ),
            'onerecord'     => true,
        );
        $aRecord = DB\SQLite::select($aSelect);
        if ( $aRecord['id'] === NULL ) {
            return NULL;
        }
        return $aRecord;
    }

    /**
     * サイトリリース予約
     *
     * @param   string      サイトID
     * @param   string      リリースユーザ
     * @param   DateTime    リリース日時
     * @return  bool  予約が成功したかどうか
     */
    public function reserveRelease($sSiteId, $sAuthor, $oTimestamp = NULL)
    {
        $bRetCode = $this->_releaseGitFlow($sSiteId, $sAuthor, $oTimestamp);
        if ( $bRetCode === false ) {
            return false;
        }
        $bRetCode = $this->_createReserveDir($sSiteId, $oTimestamp);

        // @todo エラー処理
        return true;
    }

    /**
     * サイトリリース予約のGit処理
     *
     * @param   string      サイトID
     * @param   string      リリースユーザ
     * @param   DateTime    リリース日時
     * @return  bool  予約が成功したかどうか
     */
    private function _releaseGitFlow($sSiteId, $sAuthor, $oTimestamp)
    {
        $sWorkDir  = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::GIT_DIR;
        $this->oGit = \SC\libs\Git::getInstance($sWorkDir);
        $this->oGit->setNoWarning($this->bNoWarning);

        // ローカルのリポジトリを最新化
        $this->oGit->checkout('master');
        $this->oGit->pull();
        $this->oGit->checkout('live');
        $this->oGit->pull();

        // releaseブランチでリリース作業
        $this->oGit->checkout(static::RELEASE_BRANCH);
        $this->oGit->pull();
        // @todo js minify
        // $this->oGit->commit($sAuthor, "work js minify");
        // @todo css minify
        // $this->oGit->commit($sAuthor, "work css minify");
        $aArgs = array('merge', '--no-ff', 'live');
        $this->oGit->exec($aArgs);
        // 変更があるかどうか
        $sOutput = $this->oGit->status();
        if ( strpos($sOutput, 'nothing to commit') === false ) {
            // 変更あり → addしてcommit
            $this->oGit->add();
            $this->oGit->commit($sAuthor, 'work release.');
        }

        // masterブランチにリリース作業をマージ
        $this->oGit->checkout('master');
        $aArgs = array('merge', '--no-ff', static::RELEASE_BRANCH);
        $this->oGit->exec($aArgs);
        $this->oGit->checkout('master');

        // 既にタグが存在する場合は削除
        $this->_deleteGitTag($sSiteId, $oTimestamp);
        // リリースタグ付け ex. release-201206010000
        $sTag = 'release-' . date('YmdHi', $oTimestamp);
        $aArgs = array('tag', '-a', $sTag, '-m', 'add release tag.');
        $this->oGit->exec($aArgs);
        // remoteリポジトリに反映
        $this->oGit->push();
        $aArgs = array('push', 'origin', $sTag);
        $this->oGit->exec($aArgs);

        return true;
    }

    /**
     * サイトリリース予約の予約ディレクトリ処理
     *
     * @param   string      サイトID
     * @param   DateTime    リリース日時
     * @return  bool  予約が成功したかどうか
     */
    private function _createReserveDir($sSiteId, $oTimestamp)
    {
        $sReservingDir = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::RESERVING_DIR;
        $sReservedDir  = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::RESERVED_DIR;
        $oFile     = \SC\libs\File::getInstance($sReservedDir);
        $bRetCode  = $oFile->isWritable();
        if ( $bRetCode === true ) {
            $oFile->remove(true);
        }
        mkdir($sReservingDir, 0777, true);

        // デプロイ先のホスト名一覧を取得
        $aSelect   = array(
            'fields' => array(
                'name'      => array( 'name' => 'H.name',       'type' => 'string', ),
            ),
            'froms'         => array(
                'H'         => array( 'name' => 'host', ),
            ),
            'conditions'    => array(
                'where'     => 'H.delflag = 0 AND H.site_id = :site_id',
            ),
            'binds'         => array(
                ':site_id'  => $sSiteId,
            ),
        );

        $aRecords  = \SC\libs\DB\SQLite::select($aSelect);
        foreach ( $aRecords as $aRecord ) {
            $sHost = $aRecord['name'];
            if ( $oTimestamp === NULL ) {
                $sDate = date('YmdHi');
            } else {
                $sDate = date('YmdHi', $oTimestamp);
            }
            // 予約ディレクトリを作成
            $sHostDir = $sReservingDir . '/' . $sHost . '_' . $sDate . '.lock';
            $bRetCode = mkdir($sHostDir, 0777, true);
        }

        // 予約中から予約済に変更
        rename($sReservingDir, $sReservedDir);

        return true;
    }

    /**
     * サイトリリース予約取消
     *
     * @param   string  サイトID
     * @return  bool    リリース予約取消が成功したかどうか
     */
    public function cancelRelease($sSiteId)
    {
        $sReservedDir = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::RESERVED_DIR;
        $bRetCode = file_exists($sReservedDir);
        if ( $bRetCode !== true ) {
            // ベースディレクトリが存在しない → そもそも予約されていなかったが，取消失敗と見なす
            throw new \SC\exception\model\Site\CantCancelReserve("Reserve lock dir is not exist for {$sReservedDir}.");
        }

        $mTimestamp = $this->getReserveTime($sSiteId);

        // validation
        $releaseDate = new \DateTime($mTimestamp);
        $now         = new \DateTime();
        $now->modify('+5 minutes'); // 5分前まで取り消し可能

        if ( $now > $releaseDate ) {
            throw new \SC\exception\model\Site\CantCancelReserve("リリース直前のため予約は取り消せません。");
        }

        // tag 削除
        if ( $mTimestamp !== false ) {
            $this->_deleteGitTag($sSiteId, $mTimestamp);
        }

        // ディレクトリを削除
        $oFile     = \SC\libs\File::getInstance($sReservedDir);
        $bRetCode  = $oFile->isWritable();
        if ( $bRetCode === false ) {
            throw new \SC\exception\model\Site\CantCancelReserve("Reserve lock dir is not writable for {$sReservedDir}.");
        }

        $oFile->remove(true);

        return true;
    }

    /**
     * リリースタグを削除
     *
     * @param   string  サイトID
     * @param   string  リリース日時
     * @return  bool    タグ削除が成功したかどうか
     */
    private function _deleteGitTag($sSiteId, $sTimestamp)
    {
        $sWorkDir  = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::GIT_DIR;
        $bRetCode  = file_exists($sWorkDir);
        if ( $bRetCode === false ) {
            // gitリポジトリが存在しない
            return false;
        }

        $this->oGit = \SC\libs\Git::getInstance($sWorkDir);
        $this->oGit->setNoWarning($this->bNoWarning);
        // リリースブランチ・タグ名はリリース日時にする
        $sTag = 'release-' . $sTimestamp;

        // リリースタグの存在チェック
        $aArgs = array('tag', '-l', $sTag);
        $output = $this->oGit->exec($aArgs);
        if ( $output !== '' ) {
            // リリースタグ有 → 削除
            $aArgs = array('tag', '-d', $sTag);
            $this->oGit->exec($aArgs);
            $aArgs = array('push', 'origin', ':' . $sTag);
            $this->oGit->exec($aArgs);
        } else {
            // リリースタグ無 → 何もしない
        }

        return true;
    }

    /**
     * サイトリリース予約されている状態か？
     *
     * @param   string  サイトID
     * @return  bool    true/false
     */
    public function isReserved($sSiteId)
    {
        // 予約時間を取得してみる
        $sReserveTime = $this->getReserveTime($sSiteId);
        if ( $sReserveTime === false ) {
            // 予約なし
            return false;
        }

        // デプロイ先のホスト名一覧を取得
        $aSelect      = array(
            'fields' => array(
                'name'      => array( 'name' => 'H.name',       'type' => 'string', ),
            ),
            'froms'         => array(
                'H'         => array( 'name' => 'host', ),
            ),
            'conditions'    => array(
                'where'     => 'H.delflag = 0 AND H.site_id = :site_id',
            ),
            'binds'         => array(
                ':site_id'  => $sSiteId,
            ),
        );

        $sReservedDir = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::RESERVED_DIR;
        $aRecords     = \SC\libs\DB\SQLite::select($aSelect);
        foreach ( $aRecords as $aRecord ) {
            $sHost = $aRecord['name'];
            // 予約ディレクトリを作成
            $sHostDir = $sReservedDir . '/' . $sHost . '_' . $sReserveTime . '.lock';
            $bRetCode = is_dir($sHostDir);
            if ( $bRetCode === false ) {
                // 予約がリリースされた → リリース済 ＝ 予約なし
                return false;
            }
        }

        // 予約済み
        return true;
    }

    /**
     * サイトリリース予約日時を取得
     *
     * @param   string  サイトID
     * @return  string  yyyymmddHi
     * @return  bool    false
     */
    public function getReserveTime($sSiteId)
    {
        if ( $sSiteId === NULL || $sSiteId === '' ) {
            return false;
        }

        // 予約用ディレクトリを探す
        $sLockDir     = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::RESERVED_DIR . '/*.lock';
        $matchDirs    = glob($sLockDir);
        if ( $matchDirs === false || count($matchDirs) < 1 ) {
            // \Log::debug('not reserved. dir:' . $sLockDir);
            return false;
        }

        // 予約日時をチェックする
        foreach ( $matchDirs as $sLockDir ) {
            $sTime           = substr($sLockDir, -17, 12);
            $aDirs[$sTime][] = $sLockDir;
        }
        krsort($aDirs);
        $aTimes              = array_keys($aDirs);
        $sReserveTime        = $aTimes[0];
        unset($aDirs[$sReserveTime]);
        foreach ( $aDirs as $sTime => $aEachTimes ) {
            foreach ( $aEachTimes as $sLockDir ) {
                // 古いディレクトリは削除する
                rmdir($sLockDir);
            }
        }

        return $sReserveTime;
    }

    /**
     * サイトリリース確認
     *
     * @param   string  サイトID
     * @param   string  ホスト名
     * @return  bool    リリースするかどうか
     */
    public function checkRelease($sSiteId, $sHostName)
    {
        if ( $sSiteId === NULL || $sSiteId === '' || $sHostName === NULL || $sHostName === '' ) {
            return false;
        }

        // 予約日時をチェックする
        $sReserveTime = $this->getReserveTime($sSiteId);
        if ( strtotime($sReserveTime) > time() ) {
            // \Log::debug('Time is not yet released: reserve:' . date($reserveTime) . ' current:' . date('Y-m-d H:i'));
            return false;
        }

        // 予約用ディレクトリを探す
        $sLockDir     = AP_DIR . '/' . static::RELEASE_BASE . '/' . $sSiteId . '/' . static::RESERVED_DIR . '/' . $sHostName . '_*.lock';
        $matchDirs    = glob($sLockDir);
        if ( $matchDirs === false || count($matchDirs) < 1 ) {
            // \Log::debug('not reserved. dir:' . $sLockDir);
            return false;
        }

        // ディレクトリを削除する
        foreach ( $matchDirs as $filename ) {
            $bRetCode = rmdir($filename);
        }
        return true;
    }

    /**
     * 警告をログ出力しないフラグを立てる
     *
     * @return  bool    true
     */
    public static function setNoWarningOn()
    {
        $oSelf = static::getInstance();
        return $oSelf->setNoWarning(true);
    }

    /**
     * 警告をログ出力しないフラグを折る
     *
     * @return  bool    true
     */
    public static function setNoWarningOff()
    {
        $oSelf = static::getInstance();
        return $oSelf->setNoWarning(false);
    }

    /**
     * 警告をログ出力しないフラグ
     *
     * @param   bool    $bNoWarning
     * @return  bool    true
     */
    public static function setNoWarning($bNoWarning)
    {
        $oSelf             = static::getInstance();
        $oSelf->bNoWarning = (bool) $bNoWarning;
        return true;
    }
}
