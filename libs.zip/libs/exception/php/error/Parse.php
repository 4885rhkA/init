<?php
/**
 * 文法エラー例外 (E_PARSE)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * 文法エラー例外 (E_PARSE)
 */
class Parse extends \SC\exception\php\error
{
}
