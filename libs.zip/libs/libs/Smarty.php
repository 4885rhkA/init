<?php
/**
 * Smarty
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Smarty
 */
class Smarty
{
    /**
     * Smartyオブジェクト
     *
     * @var Smarty $oSmarty
     */
    protected $oSmarty = NULL;

    /**
     * セキュリティポリシー
     *
     * @var array $aPolicy
     */
    protected $aPolicy = array(
        // テンプレートに埋め込まれた PHP のコードを Smarty がどのように処理するか
        //      0 Smarty::PHP_PASSTHRU → php タグをそのまま表示する
        //      1 Smarty::PHP_QUOTE    → タグをエンティティとしてエスケープする
        //      2 Smarty::PHP_REMOVE   → php タグを削除する
        //      3 Smarty::PHP_ALLOW    → php タグを実行する
        'php_handling'          => 2,

        // 安全だとみなされるテンプレートディレクトリの配列
        //      コンストラクタで指定
        //          AP_DIR/contents
        'secure_dir'            => array(),

        // 信頼済みとみなされるすべてのディレクトリの配列
        //      空配列  →  指定なし
        'trusted_dir'           => array(),

        // 信頼済みとみなされるすべての定数
        'trusted_constants'     => array(
            'TRUE',
            'FALSE',
            'NULL',
        ),

        // 信頼済みとみなされるクラスの配列
        //      空配列  →  全てのクラス
        //      NULL    →  指定なし
        'static_classes'        => NULL,

        // 信頼済みとみなされるPHP関数の配列
        //      空配列  →  全てのPHP関数
        //      NULL    →  指定なし
        'php_functions'         => array(
            // 制御構造
            'array',
            'isset',
            'empty',
            'list',
            'true',
            'false',
            'null',

            // 文字列操作系
            'strlen',
            'strcmp',
            'strncmp',
            'strcasecmp',
            'strncasecmp',
            'strtotime',
            'strnatcmp',
            'strnatcasecmp',
            'substr_count',
            'strspn',
            'strcspn',
            'strtok',
            'strtoupper',
            'strtolower',
            'strpos',
            'stripos',
            'strrpos',
            'strripos',
            'strrev',
            'strstr',
            'stristr',
            'strrchr',
            'str_shuffle',
            'str_word_count',
            'substr',
            'substr_replace',
            'ucfirst',
            'lcfirst',
            'ucwords',
            'strtr',
            'rtrim',
            'str_replace',
            'str_ireplace',
            'str_repeat',
            'count_chars',
            'chunk_split',
            'trim',
            'ltrim',
            'strip_tags',
            'wordwrap',
            'nl2br',
            'str_getcsv',
            'str_pad',
            'strchr',
            'sprintf',
            'number_format',
            'highlight_string',
            'parse_ini_string',
            'pack',
            'unpack',
            'chr',
            'ord',
            'htmlspecialchars',
            'htmlentities',
            'html_entity_decode',
            'htmlspecialchars_decode',
            'http_build_query',
            'http_date',

            // PCRE
            'preg_ grep',
            'preg_ last_ error',
            'preg_ match_ all',
            'preg_ match',
            'preg_ quote',
            'preg_ split',

            // 日付操作系
            'date',
            'idate',
            'gmdate',
            'mktime',
            'gmmktime',
            'checkdate',
            'strftime',
            'gmstrftime',
            'time',
            'localtime',
            'getdate',
            'microtime',
            'uniqid',

            // 配列操作系
            'split',
            'spliti',
            'explode',
            'implode',
            'join',
            'ksort',
            'krsort',
            'natsort',
            'natcasesort',
            'asort',
            'arsort',
            'sort',
            'rsort',
            'shuffle',
            'count',
            'end',
            'reset',
            'min',
            'max',
            'in_array',
            'array_search',
            'array_push',
            'array_pop',
            'array_shift',
            'array_unshift',
            'array_splice',
            'array_slice',
            'array_merge',
            'array_keys',
            'array_values',
            'array_reverse',
            'array_change_key_case',
            'array_key_exists',

            // ハッシュ系
            'hash',
            'hash_hmac',
            'sha1',
            'md5',
            'crc32',
            'crypt',
            'mt_rand',
            'mt_srand',
            'mt_getrandmax',

            // エンーディング処理系
            'mb_check_encoding',
            'mb_convert_case',
            'mb_convert_kana',
            'mb_split',
            'mb_strcut',
            'mb_strimwidth',
            'mb_stripos',
            'mb_stristr',
            'mb_strlen',
            'mb_strpos',
            'mb_strrchr',
            'mb_strrichr',
            'mb_strripos',
            'mb_strrpos',
            'mb_strstr',
            'mb_strtolower',
            'mb_strtoupper',
            'mb_strwidth',
            'mb_substr',
            'mb_substr_count',
            'iconv',
            'iconv_strlen',
            'iconv_strpos',
            'iconv_strrpos',
            'iconv_substr',

            // 暗号化・復号化系
            'base64_decode',
            'base64_encode',
            'urlencode',
            'urldecode',
            'rawurlencode',
            'rawurldecode',
            'json_encode',
            'json_decode',
            'quoted_printable_decode',
            'quoted_printable_encode',

            // 数学系
            'abs',
            'ceil',
            'floor',
            'round',
            'sin',
            'cos',
            'tan',
            'asin',
            'acos',
            'atan',
            'atanh',
            'atan2',
            'sinh',
            'cosh',
            'tanh',
            'asinh',
            'acosh',
            'expm1',
            'log1p',
            'pi',
            'is_finite',
            'is_nan',
            'is_infinite',
            'pow',
            'exp',
            'log',
            'log10',
            'sqrt',
            'hypot',
            'deg2rad',
            'rad2deg',

            // 基数変換・型系
            'bindec',
            'hexdec',
            'octdec',
            'decbin',
            'decoct',
            'dechex',
            'base_convert',
            'ctype_alnum',
            'ctype_alpha',
            'ctype_cntrl',
            'ctype_digit',
            'ctype_lower',
            'ctype_graph',
            'ctype_print',
            'ctype_punct',
            'ctype_space',
            'ctype_upper',
            'ctype_xdigit',
            'intval',
            'floatval',
            'doubleval',
            'strval',
            'gettype',
            'is_null',
            'is_resource',
            'is_bool',
            'is_long',
            'is_float',
            'is_int',
            'is_integer',
            'is_double',
            'is_real',
            'is_numeric',
            'is_string',
            'is_array',
            'is_object',
            'is_scalar',
            'is_callable',
        ),

        // 信頼済みとみなされるPHP関数の配列
        //      空配列  →  全てのPHP関数
        //      NULL    →  指定なし
        'php_modifiers'         => array(),

        // 信頼済みとみなされるストリームの配列
        //      空配列  →  全てのストリーム
        //      NULL    →  指定なし
        'streams'               => NULL,

        // テンプレートから定数にアクセスできるかどうか
        'allow_constants'       => false,

        // テンプレートからPHPのスーパーグローバル変数にアクセスできるかどうか
        'allow_super_globals'   => false,

        // テンプレートから {php} タグや {include_php} タグを使えるかどうか
        'allow_php_tag'         => false,
    );

    /**
     * Smarty_Securityオブジェクト
     *
     * @var Smarty_Security $oSmarty_Security
     */
    protected $oSmarty_Security = NULL;

    /**
     * Smartyバージョン
     *
     * @var string $sVersion
     */
    protected $sVersion = '';

    /**
     * Smartyがバージョン3系か否か
     *
     * @var bool $bVersion3
     */
    protected $bVersion3 = false;

    /**
     * 環境ディレクトリの指定
     *
     * @var string ENVIRONMENT_DIR
     */
    const ENVIRONMENT_DIR = 'contents/production';

    /**
     * テンプレートディレクトリの指定
     *
     * @var string TEMPLATE_DIR
     */
    const TEMPLATE_DIR = 'template';

    /**
     * コンパイルディレクトリの指定
     *
     * @var string COMPILE_DIR
     */
    const COMPILE_DIR = 'tmp/smarty/compile';

    /**
     * キャッシュディレクトリの指定
     *
     * @var string CACHE_DIR
     */
    const CACHE_DIR = 'tmp/smarty/cache';

    /**
     * キャッシュを使用しないロック
     *
     * @var string CACHE_NOUSE_LOCK
     */
    const CACHE_NOUSE_LOCK = 'tmp/cache-nouse.lock';

    /**
     * キャッシュID
     *
     * @var string CACHE_ID
     */
    const CACHE_ID = 'tmp/cache_id.txt';

    /**
     * デバッグモードか否か
     *
     * @var bool $bDebugging
     */
    protected $bDebugging = false;

    /**
     * コンストラクタ
     */
    public function __construct()
    {
        // 初期化
        $this->_initialize();
    }

    /**
     * 初期化
     *
     * @return  bool    true
     */
    protected function _initialize()
    {
        // 生成前に必ずSmartyDebugをロード
        SmartyDebug::load();
        // 生成時に必ずSmartyオブジェクトを生成
        $this->oSmarty                            = new \Smarty();
        // バージョンチェック
        $bRetCode                                 = defined('Smarty::SMARTY_VERSION');
        if ( $bRetCode === true ) {
            $this->sVersion                       = preg_replace('#^Smarty[- ]#', '', \Smarty::SMARTY_VERSION);
            $this->bVersion3                      = true;
        } else {
            $this->sVersion                       = $this->oSmarty->_version;
            $this->bVersion3                      = false;
        }
        // セキュリティセット
        $this->_setSecurity();

        // 決め打ち定数
        $this->oSmarty->error_reporting           = E_ALL & ~E_WARNING & ~E_NOTICE;
        $this->oSmarty->auto_literal              = false;

        // 環境別ディレクトリの指定を使うか否か
        $iVersionCmp                              = version_compare(SC_PRODUCT_VERSION, '2.0-dev');
        if ( $iVersionCmp < 0 ) {
            $sUseEnvDirDefault                    = '0';
        } else {
            $sUseEnvDirDefault                    = '1';
        }
        $sUseEnvDir                               = strtolower(\Request::getServer('SC_USE_ENV_DIR', $sUseEnvDirDefault));
        if ( $sUseEnvDir === '0' || $sUseEnvDir === 'off' || $sUseEnvDir === 'false' ) {
            $sEnvironmentDir                      = 'contents';
        } else {
            $sEnvironmentDir                      = static::ENVIRONMENT_DIR;
        }
        // テンプレートディレクトリ
        clearstatcache();
        $this->setTemplateDir(AP_DIR, $sEnvironmentDir, static::TEMPLATE_DIR);
        $aTemplateDirs                            = (array) $this->oSmarty->template_dir;
        $aTemplateDirs                            = array_merge($aTemplateDirs, explode(PATH_SEPARATOR, get_include_path()));
        SmartyDebug::setTemplateDir($aTemplateDirs);
        $this->oSmarty->compile_dir               = str_replace(array('/', '\\'), array(DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR), AP_DIR . DIRECTORY_SEPARATOR . static::COMPILE_DIR);
        $bRetCode                                 = file_exists($this->oSmarty->compile_dir);
        if ( $bRetCode !== true ) {
            $bRetCode                             = mkdir($this->oSmarty->compile_dir, 0777, true);
        }
        $this->oSmarty->cache_dir                 = str_replace(array('/', '\\'), array(DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR), AP_DIR . DIRECTORY_SEPARATOR . static::CACHE_DIR);
        $bRetCode                                 = file_exists($this->oSmarty->cache_dir);
        if ( $bRetCode !== true ) {
            $bRetCode                             = mkdir($this->oSmarty->cache_dir, 0777, true);
        }

        // デリミタ指定
        $this->oSmarty->left_delimiter            = '<!--{';
        $this->oSmarty->right_delimiter           = '}-->';

        // キャッシュIDの指定があるか？
        $aCacheIdInfo                             = array( 'SC', SC_PRODUCT_VERSION );
        $bRetCode                                 = file_exists(AP_DIR . '/' . static::CACHE_ID);
        if ( $bRetCode === true ) {
            $sCacheId                             = file_get_contents(AP_DIR . '/' . static::CACHE_ID);
            if ( $sCacheId !== '' ) {
                $aCacheIdInfo[]                   = md5($sCacheId);
            }
        }
        $this->oSmarty->compile_id                = join('-', $aCacheIdInfo);
        // 出力内容はキャッシュさせない
        $this->oSmarty->caching                   = 0;
        // コンパイルはチェックする
        $sCompileCheck                            = strtolower(\Request::getServer('SC_SMARTY_COMPILE_CHECK', '1'));
        if ( $sCompileCheck === '0' || $sCompileCheck === 'false' || $sCompileCheck === 'off' || (bool) $sCompileCheck === false ) {
            $this->oSmarty->compile_check         = false;
        } else {
            $this->oSmarty->compile_check         = true;
        }
        // キャッシュを使用しないロックファイル
        $bRetCode                                 = file_exists(AP_DIR . '/' . static::CACHE_NOUSE_LOCK);
        if ( $bRetCode === true ) {
            // キャッシュなし
            $this->oSmarty->force_compile         = 1;
        } else {
            // 強制的に毎回コンパイルするか？
            $sForceCompile                        = strtolower(\Request::getServer('SC_SMARTY_FORCE_COMPILE', '0'));
            if ( $sForceCompile === '1' || $sForceCompile === 'true' || $sForceCompile === 'on' || (bool)$sForceCompile === true) {
                $this->oSmarty->force_compile     = 1;
            } else {
                $this->oSmarty->force_compile     = 0;
            }
        }

        // 修飾子を取得
        $aModifiers                               = SmartyPlugins::getModifiers();
        // デフォルト修飾子に内部文字コードを指定してエスケープ指定を追加
        if ( $this->bVersion3 === true ) {
            $this->oSmarty->escape_html           = true;
            $aModifiers['smarty']                 = array( 'SC\libs\SmartyPlugins', 'smarty_nodefaults' );
        } else {
            $bRetCode                             = is_array($this->oSmarty->default_modifiers);
            if ( $bRetCode !== true ) {
                $this->oSmarty->default_modifiers = array();
            }
            $this->oSmarty->default_modifiers[]   = 'escape:"html":"' . mb_internal_encoding() . '"';
        }
        // 修飾子の登録
        foreach ( $aModifiers as $sModifier => $aCallback ) {
            $this->register_modifier($sModifier, $aCallback);
        }

        // 関数を取得
        $aFunctions                               = SmartyPlugins::getFunctions();
        // 関数の登録
        foreach ( $aFunctions as $sFunction => $aCallback ) {
            $this->register_function($sFunction, $aCallback);
        }

        // デバッグフラグ
        $sDebugging                               = strtolower(\Request::getServer('SC_SMARTY_DEBUGGING', '0'));
        if ( $sDebugging === '1' || $sDebugging === 'on' || $sUseEnvDir === 'true' ) {
            $this->bDebugging                     = true;
        } else {
            $this->bDebugging                     = false;
        }
        return true;
    }

    /**
     * 修飾子の登録
     *
     * @param   string  $sModifier
     * @param   array   $aCallback
     * @return  mixed
     */
    public function register_modifier($sModifier, array $aCallback)
    {
        // バージョン3系はプラグインの登録
        if ( $this->bVersion3 === true ) {
            return $this->oSmarty->registerPlugin('modifier', $sModifier, $aCallback);
        }
        // バージョン2系はそのまま
        return $this->oSmarty->register_modifier($sModifier, $aCallback);
    }

    /**
     * 関数の登録
     *
     * @param   string  $sFunction
     * @param   array   $aCallback
     * @return  mixed
     */
    public function register_function($sFunction, array $aCallback)
    {
        // バージョン3系はプラグインの登録
        if ( $this->bVersion3 === true ) {
            return $this->oSmarty->registerPlugin('function', $sFunction, $aCallback);
        }
        // バージョン2系はそのまま
        return $this->oSmarty->register_function($sFunction, $aCallback);
    }

    /**
     * 移譲
     *
     * @param   string  $sMethod
     * @param   array   $aArgs
     * @return  mixed
     */
    public function __call($sMethod, array $aArgs)
    {
        // 移譲コール
        $aCallback = array(&$this->oSmarty, $sMethod);
        $mRetValue = call_user_func_array($aCallback, $aArgs);
        return $mRetValue;
    }

    /**
     * テンプレートディレクトリを取得
     *
     * @return  string
     */
    public function getTemplateDir()
    {
        return $this->oSmarty->template_dir;
    }

    /**
     * テンプレートディレクトリをセット
     *
     * @param   string  $sTemplateBase
     * @param   string  $sEnvironmentDir
     * @param   string  $sTemplateDir
     * @return  bool    true
     */
    public function setTemplateDir($sTemplateBase = AP_DIR, $sEnvironmentDir = self::ENVIRONMENT_DIR, $sTemplateDir = self::TEMPLATE_DIR)
    {
        $this->oSmarty->template_dir     = str_replace(array('/', '\\'), array(DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR), $sTemplateBase . DIRECTORY_SEPARATOR . $sEnvironmentDir . DIRECTORY_SEPARATOR . $sTemplateDir);
        $aTemplateDirs                   = (array) $this->oSmarty->template_dir;
        $aValidList                      = array();
        foreach ( $aTemplateDirs as $sTemplateDir ) {
            $bRetCode                    = file_exists($sTemplateDir);
            if ( $bRetCode !== true ) {
                continue;
            }
            $aValidList[]                = $sTemplateDir;
        }
        if ( $this->bVersion3 === true ) {
            $this->oSmarty->template_dir = $aValidList;
        } else {
            $this->oSmarty->template_dir = reset($aValidList);
        }
        return true;
    }

    /**
     * セキュリティをセットする
     *
     * @return  bool    true
     */
    protected function _setSecurity()
    {
        if ( $this->bVersion3 === true ) {
            // セキュリティオブジェクトのセット
            $this->oSmarty->enableSecurity();
            $this->oSmarty_Security               = $this->oSmarty->security_policy;
            foreach ( $this->aPolicy as $sProp => $mValue ) {
                $this->oSmarty_Security->{$sProp} = $mValue;
            }
        } else {
            // セキュリティ情報のセット
            $this->oSmarty->security              = true;
            foreach ( $this->aPolicy as $sProp => $mValue ) {
                $this->oSmarty->{$sProp}          = $mValue;
            }
            $this->oSmarty->security_settings     = array(
                'PHP_HANDLING'        => $this->aPolicy['php_handling'],
                'IF_FUNCS'            => $this->aPolicy['php_functions'],
                'INCLUDE_ANY'         => false,
                'PHP_TAGS'            => $this->aPolicy['allow_php_tag'],
                'MODIFIER_FUNCS'      => $this->aPolicy['php_modifiers'],
                'ALLOW_CONSTANTS'     => $this->aPolicy['allow_constants'],
                'ALLOW_SUPER_GLOBALS' => $this->aPolicy['allow_super_globals'],
            );
        }
        return true;
    }

    /**
     * addSecureDir
     *
     * @param   string  $sDir
     * @return  bool    true
     */
    public function addSecureDir($sDir)
    {
        // 入力チェック
        $bRetCode                                 = Validate::isStringNotZero($sDir);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Secure directory must be non-zero byte string.');
        }
        // 安全だとみなされるテンプレートディレクトリの配列
        $this->aPolicy['secure_dir'][]            = $sDir;
        if ( $this->bVersion3 === true ) {
            $this->oSmarty_Security->secure_dir[] = $sDir;
        } else {
            $this->oSmarty->secure_dir[]          = $sDir;
        }
        return true;
    }
}
