<?php
/**
 * Util
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Util
 */
class Util
{
    /**
     * インスタンス
     *
     * @var SC\libs\Util $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * UTF-8の半角空白をどう表示するか
     *
     * @var string $sUTF8NBSPAlter
     */
    protected $sUTF8NBSPAlter = "\x20";

    /**
     * UTF-8の半角空白をどう表示するかの選択肢
     *
     * @var array $aUTF8NBSPAlterMap
     */
    protected $aUTF8NBSPAlterMap = array(
        0 => NULL,
        1 => "\x20",
        2 => "&nbsp;",
        3 => "\xC2\xA0",
    );

    /**
     * UTF-8の半角円記号をどう表示するか
     *
     * @var string $sUTF8YenAlter
     */
    protected $sUTF8YenAlter = "\x5C";

    /**
     * UTF-8の半角円記号をどう表示するかの選択肢
     *
     * @var array $aUTF8YenAlterMap
     */
    protected $aUTF8YenAlterMap = array(
        0 => NULL,
        1 => "\x5C",
        2 => "&yen;",
        3 => "\xC2\xA5",
    );

    /**
     * 文字実体参照の代わりに数値実体参照を使用するか否か
     *
     * @var bool $bPreferToNumericReference
     */
    protected $bUseNumericRef = true;

    /**
     * 実体参照マップ
     *
     * @var array $aNumericRefMap
     */
    protected $aNumericRefMap = array(
        '&iexcl;'       => '&#161;',
        '&cent;'        => '&#162;',
        '&pound;'       => '&#163;',
        '&curren;'      => '&#164;',
        '&yen;'         => '&#165;',
        '&brvbar;'      => '&#166;',
        '&sect;'        => '&#167;',
        '&uml;'         => '&#168;',
        '&copy;'        => '&#169;',
        '&ordf;'        => '&#170;',
        '&laquo;'       => '&#171;',
        '&not;'         => '&#172;',
        '&shy;'         => '&#173;',
        '&reg;'         => '&#174;',
        '&macr;'        => '&#175;',
        '&deg;'         => '&#176;',
        '&plusmn;'      => '&#177;',
        '&sup2;'        => '&#178;',
        '&sup3;'        => '&#179;',
        '&acute;'       => '&#180;',
        '&micro;'       => '&#181;',
        '&para;'        => '&#182;',
        '&middot;'      => '&#183;',
        '&cedil;'       => '&#184;',
        '&sup1;'        => '&#185;',
        '&ordm;'        => '&#186;',
        '&raquo;'       => '&#187;',
        '&frac14;'      => '&#188;',
        '&frac12;'      => '&#189;',
        '&frac34;'      => '&#190;',
        '&iquest;'      => '&#191;',
        '&Agrave;'      => '&#192;',
        '&Aacute;'      => '&#193;',
        '&Acirc;'       => '&#194;',
        '&Atilde;'      => '&#195;',
        '&Auml;'        => '&#196;',
        '&Aring;'       => '&#197;',
        '&AElig;'       => '&#198;',
        '&Ccedil;'      => '&#199;',
        '&Egrave;'      => '&#200;',
        '&Eacute;'      => '&#201;',
        '&Ecirc;'       => '&#202;',
        '&Euml;'        => '&#203;',
        '&Igrave;'      => '&#204;',
        '&Iacute;'      => '&#205;',
        '&Icirc;'       => '&#206;',
        '&Iuml;'        => '&#207;',
        '&ETH;'         => '&#208;',
        '&Ntilde;'      => '&#209;',
        '&Ograve;'      => '&#210;',
        '&Oacute;'      => '&#211;',
        '&Ocirc;'       => '&#212;',
        '&Otilde;'      => '&#213;',
        '&Ouml;'        => '&#214;',
        '&times;'       => '&#215;',
        '&Oslash;'      => '&#216;',
        '&Ugrave;'      => '&#217;',
        '&Uacute;'      => '&#218;',
        '&Ucirc;'       => '&#219;',
        '&Uuml;'        => '&#220;',
        '&Yacute;'      => '&#221;',
        '&THORN;'       => '&#222;',
        '&szlig;'       => '&#223;',
        '&agrave;'      => '&#224;',
        '&aacute;'      => '&#225;',
        '&acirc;'       => '&#226;',
        '&atilde;'      => '&#227;',
        '&auml;'        => '&#228;',
        '&aring;'       => '&#229;',
        '&aelig;'       => '&#230;',
        '&ccedil;'      => '&#231;',
        '&egrave;'      => '&#232;',
        '&eacute;'      => '&#233;',
        '&ecirc;'       => '&#234;',
        '&euml;'        => '&#235;',
        '&igrave;'      => '&#236;',
        '&iacute;'      => '&#237;',
        '&icirc;'       => '&#238;',
        '&iuml;'        => '&#239;',
        '&eth;'         => '&#240;',
        '&ntilde;'      => '&#241;',
        '&ograve;'      => '&#242;',
        '&oacute;'      => '&#243;',
        '&ocirc;'       => '&#244;',
        '&otilde;'      => '&#245;',
        '&ouml;'        => '&#246;',
        '&divide;'      => '&#247;',
        '&oslash;'      => '&#248;',
        '&ugrave;'      => '&#249;',
        '&uacute;'      => '&#250;',
        '&ucirc;'       => '&#251;',
        '&uuml;'        => '&#252;',
        '&yacute;'      => '&#253;',
        '&thorn;'       => '&#254;',
        '&yuml;'        => '&#255;',
        '&OElig;'       => '&#338;',
        '&oelig;'       => '&#339;',
        '&Scaron;'      => '&#352;',
        '&scaron;'      => '&#353;',
        '&Yuml;'        => '&#376;',
        '&fnof;'        => '&#402;',
        '&circ;'        => '&#710;',
        '&tilde;'       => '&#732;',
        '&Alpha;'       => '&#913;',
        '&Beta;'        => '&#914;',
        '&Gamma;'       => '&#915;',
        '&Delta;'       => '&#916;',
        '&Epsilon;'     => '&#917;',
        '&Zeta;'        => '&#918;',
        '&Eta;'         => '&#919;',
        '&Theta;'       => '&#920;',
        '&Iota;'        => '&#921;',
        '&Kappa;'       => '&#922;',
        '&Lambda;'      => '&#923;',
        '&Mu;'          => '&#924;',
        '&Nu;'          => '&#925;',
        '&Xi;'          => '&#926;',
        '&Omicron;'     => '&#927;',
        '&Pi;'          => '&#928;',
        '&Rho;'         => '&#929;',
        '&Sigma;'       => '&#931;',
        '&Tau;'         => '&#932;',
        '&Upsilon;'     => '&#933;',
        '&Phi;'         => '&#934;',
        '&Chi;'         => '&#935;',
        '&Psi;'         => '&#936;',
        '&Omega;'       => '&#937;',
        '&alpha;'       => '&#945;',
        '&beta;'        => '&#946;',
        '&gamma;'       => '&#947;',
        '&delta;'       => '&#948;',
        '&epsilon;'     => '&#949;',
        '&zeta;'        => '&#950;',
        '&eta;'         => '&#951;',
        '&theta;'       => '&#952;',
        '&iota;'        => '&#953;',
        '&kappa;'       => '&#954;',
        '&lambda;'      => '&#955;',
        '&mu;'          => '&#956;',
        '&nu;'          => '&#957;',
        '&xi;'          => '&#958;',
        '&omicron;'     => '&#959;',
        '&pi;'          => '&#960;',
        '&rho;'         => '&#961;',
        '&sigmaf;'      => '&#962;',
        '&sigma;'       => '&#963;',
        '&tau;'         => '&#964;',
        '&upsilon;'     => '&#965;',
        '&phi;'         => '&#966;',
        '&chi;'         => '&#967;',
        '&psi;'         => '&#968;',
        '&omega;'       => '&#969;',
        '&thetasym;'    => '&#977;',
        '&upsih;'       => '&#978;',
        '&piv;'         => '&#982;',
        '&ensp;'        => '&#8194;',
        '&emsp;'        => '&#8195;',
        '&thinsp;'      => '&#8201;',
        '&zwnj;'        => '&#8204;',
        '&zwj;'         => '&#8205;',
        '&lrm;'         => '&#8206;',
        '&rlm;'         => '&#8207;',
        '&ndash;'       => '&#8211;',
        '&mdash;'       => '&#8212;',
        '&lsquo;'       => '&#8216;',
        '&rsquo;'       => '&#8217;',
        '&sbquo;'       => '&#8218;',
        '&ldquo;'       => '&#8220;',
        '&rdquo;'       => '&#8221;',
        '&bdquo;'       => '&#8222;',
        '&dagger;'      => '&#8224;',
        '&Dagger;'      => '&#8225;',
        '&bull;'        => '&#8226;',
        '&hellip;'      => '&#8230;',
        '&permil;'      => '&#8240;',
        '&prime;'       => '&#8242;',
        '&Prime;'       => '&#8243;',
        '&lsaquo;'      => '&#8249;',
        '&rsaquo;'      => '&#8250;',
        '&oline;'       => '&#8254;',
        '&frasl;'       => '&#8260;',
        '&euro;'        => '&#8364;',
        '&weierp;'      => '&#8472;',
        '&image;'       => '&#8465;',
        '&real;'        => '&#8476;',
        '&trade;'       => '&#8482;',
        '&alefsym;'     => '&#8501;',
        '&larr;'        => '&#8592;',
        '&uarr;'        => '&#8593;',
        '&rarr;'        => '&#8594;',
        '&darr;'        => '&#8595;',
        '&harr;'        => '&#8596;',
        '&crarr;'       => '&#8629;',
        '&lArr;'        => '&#8656;',
        '&uArr;'        => '&#8657;',
        '&rArr;'        => '&#8658;',
        '&dArr;'        => '&#8659;',
        '&hArr;'        => '&#8660;',
        '&forall;'      => '&#8704;',
        '&part;'        => '&#8706;',
        '&exist;'       => '&#8707;',
        '&empty;'       => '&#8709;',
        '&nabla;'       => '&#8711;',
        '&isin;'        => '&#8712;',
        '&notin;'       => '&#8713;',
        '&ni;'          => '&#8715;',
        '&prod;'        => '&#8719;',
        '&sum;'         => '&#8721;',
        '&minus;'       => '&#8722;',
        '&lowast;'      => '&#8727;',
        '&radic;'       => '&#8730;',
        '&prop;'        => '&#8733;',
        '&infin;'       => '&#8734;',
        '&ang;'         => '&#8736;',
        '&and;'         => '&#8743;',
        '&or;'          => '&#8744;',
        '&cap;'         => '&#8745;',
        '&cup;'         => '&#8746;',
        '&int;'         => '&#8747;',
        '&there4;'      => '&#8756;',
        '&sim;'         => '&#8764;',
        '&cong;'        => '&#8773;',
        '&asymp;'       => '&#8776;',
        '&ne;'          => '&#8800;',
        '&equiv;'       => '&#8801;',
        '&le;'          => '&#8804;',
        '&ge;'          => '&#8805;',
        '&sub;'         => '&#8834;',
        '&sup;'         => '&#8835;',
        '&nsub;'        => '&#8836;',
        '&sube;'        => '&#8838;',
        '&supe;'        => '&#8839;',
        '&oplus;'       => '&#8853;',
        '&otimes;'      => '&#8855;',
        '&perp;'        => '&#8869;',
        '&sdot;'        => '&#8901;',
        '&lceil;'       => '&#8968;',
        '&rceil;'       => '&#8969;',
        '&lfloor;'      => '&#8970;',
        '&rfloor;'      => '&#8971;',
        '&lang;'        => '&#9001;',
        '&rang;'        => '&#9002;',
        '&loz;'         => '&#9674;',
        '&spades;'      => '&#9824;',
        '&clubs;'       => '&#9827;',
        '&hearts;'      => '&#9829;',
        '&diams;'       => '&#9830;',
    );

    /**
     * 文字コード変換の際にMSCP932を考慮するか否か
     *
     * @var bool $bEncodeMSCP932
     */
    protected $bEncodeMSCP932 = true;

    /**
     * 文字コードマップ for MSCP932
     *
     * @var array $aEncodeMapMSCP932
     */
    protected $aEncodeMapMSCP932 = array(
        // IBM              MS
        "\xE2\x88\x92"  => "\xEF\xBC\x8D",      // －(全角マイナス)
        "\xE2\x80\x94"  => "\xE2\x80\x95",      // ―(全角ダッシュ)
        "\xE3\x80\x9C"  => "\xEF\xBD\x9E",      // ～
        "\xE2\x80\x96"  => "\xE2\x88\xA5",      // ∥
        "\xC2\xA2"      => "\xEF\xBF\xA0",      // ￠
        "\xC2\xA3"      => "\xEF\xBF\xA1",      // ￡
        "\xC2\xAC"      => "\xEF\xBF\xA2",      // ￢
    );

    /**
     * 16進数2進数基数変換テーブル
     *
     * @var array $aHexBinTable
     */
    protected $aHexBinTable = array(
        '0' => '0000',
        '1' => '0001',
        '2' => '0010',
        '3' => '0011',
        '4' => '0100',
        '5' => '0101',
        '6' => '0110',
        '7' => '0111',
        '8' => '1000',
        '9' => '1001',
        'a' => '1010',
        'b' => '1011',
        'c' => '1100',
        'd' => '1101',
        'e' => '1110',
        'f' => '1111',
    );

    /**
     * Base64Urlテーブル
     *
     * @var array $aBase64UrlTable
     */
    protected $aBase64UrlTable = array(
        0  => 'A',
        1  => 'B',
        2  => 'C',
        3  => 'D',
        4  => 'E',
        5  => 'F',
        6  => 'G',
        7  => 'H',
        8  => 'I',
        9  => 'J',
        10 => 'K',
        11 => 'L',
        12 => 'M',
        13 => 'N',
        14 => 'O',
        15 => 'P',
        16 => 'Q',
        17 => 'R',
        18 => 'S',
        19 => 'T',
        20 => 'U',
        21 => 'V',
        22 => 'W',
        23 => 'X',
        24 => 'Y',
        25 => 'Z',
        26 => 'a',
        27 => 'b',
        28 => 'c',
        29 => 'd',
        30 => 'e',
        31 => 'f',
        32 => 'g',
        33 => 'h',
        34 => 'i',
        35 => 'j',
        36 => 'k',
        37 => 'l',
        38 => 'm',
        39 => 'n',
        40 => 'o',
        41 => 'p',
        42 => 'q',
        43 => 'r',
        44 => 's',
        45 => 't',
        46 => 'u',
        47 => 'v',
        48 => 'w',
        49 => 'x',
        50 => 'y',
        51 => 'z',
        52 => '0',
        53 => '1',
        54 => '2',
        55 => '3',
        56 => '4',
        57 => '5',
        58 => '6',
        59 => '7',
        60 => '8',
        61 => '9',
        62 => '-',
        63 => '_',
    );

    /**
     * エンコード配列
     *
     * @var array $aEncodeList
     */
    protected $aEncodeList = array(
        'UTF8'          => 'UTF-8',
        'UTF-8'         => 'UTF-8',
        'EUC-JP'        => 'EUC-JP',
        'EUC_JP'        => 'EUC-JP',
        'EUCJP'         => 'EUC-JP',
        'EUCJP-WIN'     => 'EUCJP-WIN',
        'SHIFT_JIS'     => 'Shift_JIS',
        'SHIFT-JIS'     => 'Shift_JIS',
        'SJIS'          => 'Shift_JIS',
        'SJIS-WIN'      => 'SJIS-WIN',
        'XSJIS'         => 'SJIS-WIN',
        'X-SJIS'        => 'SJIS-WIN',
        'MS_KANJI'      => 'SJIS-WIN',
        'WINDOWS-31J'   => 'SJIS-WIN',
        'CP932'         => 'SJIS-WIN',
        'MS932'         => 'SJIS-WIN',
        'JIS'           => 'JIS',
        'ISO-2022-JP'   => 'ISO-2022-JP',
        'ASCII'         => 'ASCII',
        'US-ASCII'      => 'ASCII',
        'HTML-ENTITIES' => 'HTML-ENTITIES',
    );

    /**
     * ソースサイトのステージングを使用するか否か
     *
     * @var array $bUseStaging
     */
    protected $bUseStaging = false;

    /**
     * SPサイトのステージングを使用するか否か
     *
     * @var array $bUseStagingSP
     */
    protected $bUseStagingSP = false;

    /**
     * URIの調整情報
     *
     * @var array $aAdjustConds
     */
    protected $aAdjustConds = array();

    /**
     * refine時のキーワード置換用配列
     *
     * @var array $aRefineKeywords
     */
    protected $aRefineKeywords = array();

    /**
     * refine時のキーワード置換修飾
     *
     * @var array $aRefineModifiers
     */
    protected $aRefineModifiers = array(
        ':'  => '_replaceKeyrowdsSubstr',
        '|'  => '_replaceKeyrowdsPregReplace',
        '|~' => '_replaceKeyrowdsPregReplace',
        '|=' => '_replaceKeyrowdsStrReplace',
    );

    /**
     * リクエストオブジェクト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * URIを調整用の条件対象
     *
     * @var array $aAdjustURITarget
     */
    protected $aAdjustURITarget = array(
        'HTTP_HOST'            => true,     // host
        'SERVER_PORT'          => true,     // port
        'PATH_INFO'            => true,     // path
        'QUERY_STRING'         => true,     // query
        'REQUEST_URI'          => true,     // request uri
        'HTTPS'                => true,     // on
        'HTTP_USER_AGENT'      => true,     // Android
        'HTTP_REFERER'         => true,     // Referer
        'REQUEST_METHOD'       => true,     // GET/POST
        'REMOTE_ADDR'          => true,     // 192.168.1.1
        'REMOTE_ADDRS'         => true,     // 192.168.1.1
        'HTTP_X_FORWARDED_FOR' => true,     // 192.168.1.1
        'REMOTE_PORT'          => true,     // 65457
        'REMOTE_USER'          => true,     // username
        'AUTH_TYPE'            => true,     // Basic , Digest
        'PHP_AUTH_USER'        => true,     // auth username
        'PHP_AUTH_PW'          => true,     // auth passowrd
        'PHP_AUTH_DIGEST'      => true,     // auth digest
        'SERVER_PROTOCOL'      => true,     // HTTP/1.1
        'GATEWAY_INTERFACE'    => true,     // CGI/1.1
        'REQUEST_TIME'         => true,     // UNIX Epoch
        'HOSTNAME'             => true,     // hostname
        // SmartConvert Environment Variables
        'SC_PRODUCT_NAME'      => true,     // SmartConvert
        'SC_PRODUCT_VERSION'   => true,     // version of SmartConvert
        'SC_SOURCE_HOST'       => true,     // source host
        'SC_STAGING'           => true,     // is staging for Source-site
        'SC_STAGING_SP'        => true,     // is staging for SP-site
        'SC_SHOW_HIDDEN_PAGE'  => true,     // hidden page
    );

    /**
     * URIを調整用の条件対象
     *
     * @var array $aAdjustURITargetPrefix
     */
    protected $aAdjustURITargetPrefix = array(
        // SmartConvert Environment Variables
        'SC_OPT_'              => true,     // optional
    );

    /**
     * URIを調整用のマッチングのログ出力レベル
     *
     * @var int $iLogMatch
     */
    protected $iLogMatch = 0;

    /**
     * URI抽出用の正規表現
     *
     * @var string $sUriRE
     */
    protected $sUriRE = '';

    /**
     * PCREエラーログ
     *
     * @var bool $bLogPCREError
     */
    protected $bLogPCREError = false;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Util
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
            self::$oInstance->_load();
        }
        return self::$oInstance;
    }

    /**
     * 設定の読み込み
     *
     * @return bool true
     */
    protected function _load()
    {
        // リクエスト
        $this->oRequest           = Request::getInstance();
        // 文字コード問題
        $iUTF8NBSPAlter           = trim($this->oRequest->getServer('SC_MB_UTF8_NBSP_ALTER', ''));
        $bIsInt                   = Validate::isInt($iUTF8NBSPAlter);
        if ( $bIsInt === true ) {
            $iUTF8NBSPAlter       = (int) $iUTF8NBSPAlter;
            $this->sUTF8NBSPAlter = ArrayUtil::getValue($this->aUTF8NBSPAlterMap, $iUTF8NBSPAlter, $this->aUTF8NBSPAlterMap[1]);
            \Log::info("Replace UTF-8 nbsp as '{$this->sUTF8NBSPAlter}'.");
        } else {
            $iUTF8NBSPAlter       = 1;
            $this->sUTF8NBSPAlter = $this->aUTF8NBSPAlterMap[1];
        }
        $this->sUTF8NBSPAlter     = ArrayUtil::getValue($this->aUTF8NBSPAlterMap, $iUTF8NBSPAlter, $this->aUTF8NBSPAlterMap[1]);
        $iUTF8YenAlter            = trim($this->oRequest->getServer('SC_MB_UTF8_YEN_ALTER', ''));
        $bIsInt                   = Validate::isInt($iUTF8YenAlter);
        if ( $bIsInt === true ) {
            $iUTF8YenAlter        = (int) $iUTF8YenAlter;
            $this->sUTF8YenAlter  = ArrayUtil::getValue($this->aUTF8YenAlterMap, $iUTF8YenAlter, $this->aUTF8YenAlterMap[1]);
            \Log::info("Replace UTF-8 yen as '{$this->sUTF8YenAlter}'.");
        } else {
            $iUTF8YenAlter        = 1;
            $this->sUTF8YenAlter  = $this->aUTF8YenAlterMap[1];
        }
        $sUseNumericRef           = strtolower($this->oRequest->getServer('SC_MB_ENCODE_NUMREF', '1'));
        if ( $sUseNumericRef === '0' || $sUseNumericRef === 'false' || $sUseNumericRef === 'off' || (bool)$sUseNumericRef === false ) {
            $this->bUseNumericRef = false;
            \Log::info('No use numeric references.');
        } else {
            $this->bUseNumericRef = true;
        }
        $sEncodeMSCP932           = strtolower($this->oRequest->getServer('SC_MB_ENCODE_MSCP932', '1'));
        if ( $sEncodeMSCP932 === '0' || $sEncodeMSCP932 === 'false' || $sEncodeMSCP932 === 'off' || (bool)$sEncodeMSCP932 === false ) {
            $this->bEncodeMSCP932 = false;
            \Log::info('No use MSCP932.');
        } else {
            $this->bEncodeMSCP932 = true;
        }

        // PCサイトのステージング設定
        $sUseStaging              = strtolower($this->oRequest->getServer('SC_STAGING', ''));
        if ( $sUseStaging === 'on' || $sUseStaging === 'true' || $sUseStaging === '1' ) {
            $this->bUseStaging    = true;
            \Log::info('Going down into staging-source mode.');
        } else {
            $this->bUseStaging    = false;
        }
        $this->define('SC_STAGING', $this->bUseStaging);
        // SPサイトのステージング設定
        $sUseStagingSP            = strtolower($this->oRequest->getServer('SC_STAGING_SP', ''));
        if ( $sUseStagingSP === 'on' || $sUseStagingSP === 'true' || $sUseStagingSP === '1' ) {
            $this->bUseStagingSP  = true;
            \Log::info('Going down into staging-sp mode.');
        } else {
            $this->bUseStagingSP  = false;
        }
        $this->define('SC_STAGING_SP', $this->bUseStagingSP);
        // マッチ条件をログに出力するか否か
        $sLogMatch                = strtolower($this->oRequest->getServer('SC_LOG_ADJUSTURIMATCHING', ''));
        if ( $sLogMatch === 'true' || $sLogMatch === 'on' || $sLogMatch === '1' ) {
            $this->iLogMatch      = 1;
        } else {
            $bRetCode             = Validate::isInt($sLogMatch);
            if ( $bRetCode === true ) {
                $this->iLogMatch  = (int) $sLogMatch;
            } else {
                $this->iLogMatch  = 0;
            }
        }
        // URI調整用の正規表現
        $sURIChars                = '(?:[0-9A-Za-z_\x21\x24\x26-\x29\x2a-\x2f\x3a\x3b\x3d\x3f\x40\x7e]|%[0-9A-Fa-f][0-9A-Fa-f])*';
        $sREHost                  = '(?:(?:[0-9A-Za-z](?:(?:[0-9A-Za-z\x2d])*[0-9A-Za-z])?\.)*[A-Za-z](?:(?:[0-9A-Za-z\x2d])*[0-9A-Za-z])?\.?)|(?:(?:\d+\.){3}\d)';
        $sREPath                  = '/(?:[0-9A-Za-z_\x21\x24\x26-\x29\x2a-\x2e\x3a\x3d\x40\x7e]|%[0-9A-Fa-f][0-9A-Fa-f])*(?:;(?:[0-9A-Za-z_\x21\x24\x26-\x29\x2a-\x2e\x3a\x3d\x40\x7e]|%[0-9A-Fa-f][0-9A-Fa-f])*)*';
        $sREQuery                 = '\?' . $sURIChars;
        $sREFragment              = '#'  . $sURIChars;
        $aUriREs                  = array(
            //1                                2      3
            "(\\s(?:href|src|action)\\s*=\\s*)(\\x22)(/[^\\x22]+)\\x22",
            //4                                5      6
            "(\\s(?:href|src|action)\\s*=\\s*)(\\x27)(/[^\\x27]+)\\x27",
            //7                                8
            "(\\s(?:href|src|action)\\s*=\\s*)(/\\S*)",
            //9      10
            "(\\x22)((?:https?:)?//(?:$sREHost)(?:\\d+)?(?:/[^\\x22]+)?)\\x22",
            //11     12
            "(\\x27)((?:https?:)?//(?:$sREHost)(?:\\d+)?(?:/[^\\x27]+)?)\\x27",
            //13
            "(https?://(?:$sREHost)(?:\\d+)?(?:$sREPath)?(?:$sREQuery)?(?:$sREFragment)?)",
        );
        $this->sUriRE             = $this->validatePCRE('(?:' . join('|', $aUriREs) . ')', false, '#', 'smx');
        // PCREエラーログ
        $sLogPCREError            = strtolower($this->oRequest->getServer('SC_LOG_PCRE_ERROR', ''));
        if ( $sLogPCREError === '1' || $sLogPCREError === 'on' || $sLogPCREError === 'true' ) {
            $this->bLogPCREError  = true;
        } else {
            $this->bLogPCREError  = false;
        }
        $this->define('SC_LOG_PCRE_ERROR', $this->bLogPCREError);
        return true;
    }

    /**
     * 設定の再読み込み
     *
     * @return bool true
     */
    public static function reload()
    {
        // 設定の読み込み
        $oSelf = static::getInstance();
        return $oSelf->_load();
    }

    /**
     * 継承チェック
     *
     * インスタンスの場合にはインターフェースもチェックする
     *
     * @param   mixed   $mInput         インスタンスもしくはクラス名
     * @param   string  $sClassName     クラス名もしくはインターフェース名
     * @param   bool    $bAutoLoad      オートロードを使用する
     * @param   bool    $bClassOnly     インターフェースをチェックしない
     * @return  bool    true/false
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function is_a($mInput, $sClassName, $bAutoLoad = true, $bClassOnly = false)
    {
        // インスタンスか？
        $bRetCode    = is_object($mInput);
        if ( $bRetCode === true ) {
            // インスタンスならPHPの機能を使う
            return $mInput instanceof $sClassName;
        }
        // 文字列か？
        $bRetCode    = Validate::isStringNotZero($mInput);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Argument 1 must be an instance or a non-zero byte string.');
        }
        $bRetCode    = Validate::isStringNotZero($sClassName);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Argument 2 must be a non-zero byte string.');
        }
        $sSubClass   = (string) $mInput;
        $sClassName  = (string) $sClassName;
        // 一致ならOK
        if ( $sSubClass === $sClassName ) {
            return true;
        }
        // サブクラスか？
        $aParents    = class_parents($sSubClass, (bool)$bAutoLoad);
        if ( $aParents === false ) {
            // クラスなし → 継承も何もない
            return false;
        }
        $bRetCode    = in_array($sClassName, $aParents);
        if ( $bRetCode === true ) {
            // 継承
            return true;
        }
        if ( (bool) $bClassOnly === true ) {
            // インターフェースはチェックしない
            return false;
        }
        // 実装か？
        $aImplements = class_implements($sSubClass, (bool)$bAutoLoad);
        if ( $aImplements === false ) {
            // クラスなし → 実装も何もない
            return false;
        }
        $bRetCode    = in_array($sClassName, $aImplements);
        // 継承かどうか返す
        return $bRetCode;
    }

    /**
     * 型名をスカラー型名で正規化
     *
     * @param   string  $sType
     * @return  string  有効なスカラー型名もしくは'unknown type'
     */
    public static function normalizeTypeNameScalar($sType)
    {
        // 型名で型チェック
        $sType         = static::normalizeTypeName($sType);
        switch ( $sType ) {
            // スカラー型ならそのまま
            case 'int':
            case 'bool':
            case 'float':
            case 'string':
            case 'numeric':
            case 'scalar':
                break;

            // スカラー型ではない
            default:
                $sType = 'unknown type';
                break;
        }
        // 型を返す
        return $sType;
    }

    /**
     * 型名を型名で正規化
     *
     *  PHPに存在する型チェッカ
     *      型
     *          is_bool
     *          is_int      is_integer  is_long
     *          is_float    is_double   is_real
     *          is_string
     *          is_array
     *          is_object
     *          is_resource
     *          is_null
     *      疑似型
     *          is_numeric
     *          is_scalar
     *          is_callable
     *
     *  settypeで指定可能な型
     *      →  bool, boolean, int, integer, float, string, array, object, null
     *
     * @param   string  $sType
     * @return  string  有効な型名もしくは'unknown type'
     */
    public static function normalizeTypeName($sType)
    {
        // 型名で型チェック
        $sType         = strtolower($sType);
        switch ( $sType ) {
            case 'bool': case 'boolean': case 'b':
                $sType = 'bool';
                break;

            case 'int':   case 'integer': case 'i':
            case 'long':  case 'long int':
            case 'short': case 'short int':
                $sType = 'int';
                break;

            case 'float':  case 'f':
            case 'double': case 'd':
            case 'real': case 'complex': case 'number':
                $sType = 'float';
                break;

            case 'string': case 'str': case 's':
            case 'char': case 'c':
            case 'date': case 'datetime': case 'time': case 'timestamp':
                $sType = 'string';
                break;

            case 'array': case 'arr': case 'a':
                $sType = 'array';
                break;

            case 'object': case 'obj': case 'o':
            case 'class': case 'instance':
                $sType = 'object';
                break;

            case 'resource': case 'res': case 'r':
                $sType = 'resource';
                break;

            case 'null': case 'void': case 'n': case 'v':
                $sType = 'null';
                break;

            // 例外疑似型
            case 'numeric':
            case 'scalar':
            case 'callable':
                // 疑似型はそのまま
                break;

            default:
                $sType = 'unknown type';
                break;
        }
        // 型を返す
        return $sType;
    }

    /**
     * 値を型で正規化
     *
     *  PHPに存在する型チェッカ
     *      型
     *          is_bool
     *          is_int      is_integer  is_long
     *          is_float    is_double   is_real
     *          is_string
     *          is_array
     *          is_object
     *          is_resource
     *          is_null
     *      疑似型
     *          is_numeric
     *          is_scalar
     *          is_callable
     *
     *  settypeで指定可能な型
     *      →  bool, boolean, int, integer, float, string, array, object, null
     *
     * @param   string  $sType
     * @param   mixed   $mValue
     * @return  mixed   正規化後の値
     * @throw   SC\exception\common\parameter\UnknownType
     * @throw   SC\exception\common\parameter\InvalidType
     */
    public static function normalizeType($sType, $mValue)
    {
        // 型名で型チェック
        $sType    = static::normalizeTypeName($sType);
        if ( $sType === 'unknown type' ) {
            // 不明な型
            throw new \SC\exception\common\parameter\UnknownType('Unknown type for normalize');
        }
        $sChecker = 'is_' . $sType;
        $bRetCode = $sChecker($mValue);
        if ( $bRetCode === true ) {
            // チェックOK
            return $mValue;
        }
        // 型が違う → 正規化
        switch ( $sType ) {
            // そのまま
            case 'bool':
            case 'int':
            case 'float':
            case 'array':
            case 'object':
            case 'null':
                break;

            // 文字列へ
            case 'string':
            case 'numeric':
            case 'scalar':
                $sType = 'string';
                break;

            // 正規化不能
            default:
                throw new \SC\exception\common\parameter\InvalidType('Invalid type for normalize');
        }
        // チェックNG → 変換
        $bRetCode = settype($mValue, $sType);
        if ( $bRetCode !== true ) {
            // 変換NG
            throw new \SC\exception\common\parameter\InvalidType("Can't convert to type '$sType'");
        }
        // 変換OK
        return $mValue;
    }

    /**
     * キーワード置換する
     *
     * @param   string  $sUri
     * @param   string  $bOrigPath
     * @param   array   $aPlus
     * @return  string
     */
    public static function refine($sUri, $bOrigPath = false, array $aPlus = array())
    {
        // 設定の読み込み
        $oSelf = static::getInstance();
        return $oSelf->_refine($sUri, $bOrigPath, $aPlus);
    }

    /**
     * キーワード置換する
     *
     * @param   string  $sUri
     * @param   string  $bOrigPath
     * @param   array   $aPlus
     * @return  string
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _refine($sUri, $bOrigPath = false, array $aPlus = array())
    {
        // 入力チェック
        $bRetCode   = Validate::isStringNotZero($sUri);
        if ( $bRetCode !== true ) {
            return $sUri;
        }
        $bFound     = (bool) preg_match('#{{__[A-Z].*}}#uS', $sUri);
        if ( $bFound === true ) {
            $sUri   = $this->_replaceKeyrowds($sUri, $bOrigPath, $aPlus);
        }
        return $sUri;
    }

    /**
     * キーワード置換する
     *
     * @param   string  $sUri
     * @param   string  $bOrigPath
     * @param   array   $aPlus
     * @return  string
     */
    protected function _replaceKeyrowds($sUri, $bOrigPath = false, array $aPlus)
    {
        // パスはオリジナルか？
        $sOrigPath             = $this->oRequest->getServer('ORIG_PATH_INFO', '/');
        if ( $bOrigPath === true ) {
            $sPath             = $sOrigPath;
        } else {
            $sPath             = $this->oRequest->getServer('PATH_INFO', '/');
        }
        // リダイレクトのキーワード置換
        $sQuery                = $this->oRequest->getServer('QUERY_STRING', '');
        if ( $sQuery !== '' ) {
            $sQuery            = '?'. $sQuery;
        }
        $this->aRefineKeywords = array(
            '__HTTP_PROTO__'     => $this->oRequest->getProto(),
            '__HTTP_HOST__'      => $this->oRequest->getServer('HTTP_HOST', '127.0.0.1'),
            '__ENTRY_POINT__'    => $this->oRequest->getEntryPoint(),
            '__WEBROOT_PATH__'   => $this->oRequest->getWebRootPath(),
            '__WEB_ROOT__'       => $this->oRequest->getEntryPoint(),
            '__CONTENTS_ROOT__'  => $this->oRequest->getWebRootPath(),
            '__PATH_INFO__'      => $sPath,
            '__ORIG_PATH_INFO__' => $sOrigPath,
            '__QUERY_STRING__'   => $sQuery,
            '__SESSION_ID__'     => Session::getSessId(),
            '__SOURCE_HOST__'    => $this->oRequest->getServer('SC_SOURCE_HOST', '127.0.0.1'),
        );
        $this->aRefineKeywords = ArrayUtil::unite($this->aRefineKeywords, $aPlus, false);
        // 置換する
        $sRE                   = '#{{(__[A-Z]+(?:_[A-Z]+)*__)(?:(?:(:|\\|[=~]?)(?:([^\\x22\\x3a\\x7d]+)|\\x22([^\\x22]+)\\x22)(?:(:)(?:([^\\x22\\x3a\\x7d]+)|\\x22([^\\x22]*)\\x22)?)?)|([^\\x7d]+))?}}#uS';
        //                           1                             2              3                          4                   5     6                          7                     8
        // count=2  →  修飾なし        1のみ
        // count=7  →  修飾指定あり    1,2,3,5,6   or  1,2,4,5,6
        // count=8  →  修飾指定あり    1,2,3,4,7   or  1,2,4,5,7
        // count=9  →  不明な修飾指定  1,8
        $mValue                = preg_replace_callback($sRE, array(&$this, '_replaceKeyrowdsCallback'), $sUri);
        if ( $mValue !== NULL ) {
            $sUri = $mValue;
        }
        return $sUri;
    }

    /**
     * キーワード置換する
     *
     * @param   array   $aMatches
     * @return  string
     */
    protected function _replaceKeyrowdsCallback(array $aMatches)
    {
        // 正規表現
        // '#{{(__[A-Z]+(?:_[A-Z]+)*__)(?:(?:(:|\\|[=~]?)(?:([^\\x22\\x3a\\x7d]+)|\\x22([^\\x22]+)\\x22)(?:(:)(?:([^\\x22\\x3a\\x7d]+)|\\x22([^\\x22]*)\\x22)?)?)|([^\\x7d]+))?}}#uS'
        //     1                             2              3                          4                   5     6                          7                     8
        // count=2  →  修飾なし                        1のみ
        // count=4  →  修飾指定あり(第2引数なし)       1,2,3
        // count=5  →  修飾指定あり(第2引数なし)       1,2,4
        // count=6  →  修飾指定あり(第2引数は空文字)   1,2,3       or  1,2,4
        // count=7  →  修飾指定あり                    1,2,3,5,6   or  1,2,4,5,6
        // count=8  →  修飾指定あり                    1,2,3,5,7   or  1,2,4,5,7
        // count=9  →  不明な修飾指定                  1,8
        $sKeywords          = (string) ArrayUtil::getValue($this->aRefineKeywords, $aMatches[1], NULL);
        if ( $sKeywords === NULL ) {
            // キーワードが存在しない → そのまま返す
            return $aMatches[0];
        }
        $iCount             = count($aMatches);
        switch ( $iCount ) {
            // 修飾指定なし
            case 2:
                // キーワードを返す
                return $sKeywords;

            // 修飾指定あり(第2引数なし)
            case 4:
                $sOperator  = $aMatches[2];
                $sSearch    = $aMatches[3];
                $sSeparator = '';
                $sReplace   = NULL;
                break;

            // 修飾指定あり(第2引数なし)
            case 5:
                $sOperator  = $aMatches[2];
                $sSearch    = $aMatches[3] . $aMatches[4];
                $sSeparator = '';
                $sReplace   = NULL;
                break;

            // 修飾指定あり(第2引数は空文字)
            case 6:
                $sOperator  = $aMatches[2];
                $sSearch    = $aMatches[3] . $aMatches[4];
                $sSeparator = $aMatches[5];
                $sReplace   = '';
                break;

            // 修飾指定あり
            case 7:
                $sOperator  = $aMatches[2];
                $sSearch    = $aMatches[3] . $aMatches[4];
                $sSeparator = $aMatches[5];
                $sReplace   = $aMatches[6];
                break;

            // 修飾指定あり
            case 8:
                $sOperator  = $aMatches[2];
                $sSearch    = $aMatches[3] . $aMatches[4];
                $sSeparator = $aMatches[5];
                $sReplace   = $aMatches[7];
                break;

            // 修飾指定なし
            case 9:
                // キーワードを返す
                return $sKeywords;

            // その他
            default:
                // そのまま
                return $aMatches[0];
        }
        $sMethod            = trim(ArrayUtil::getValue($this->aRefineModifiers, $sOperator, ''));
        if ( $sMethod === '' ) {
            // 修飾処理なし
            return $sKeywords;
        }
        // 修飾子による処理
        return $this->$sMethod($sKeywords, $sSearch, $sReplace);
    }

    /**
     * キーワード修飾処理する by substr
     *
     * @param   string  $sKeyword   キーワード
     * @param   string  $sStart     開始位置
     * @param   string  $sLength    文字列超
     * @return  string
     */
    protected function _replaceKeyrowdsSubstr($sKeyword, $sStart, $sLength)
    {
        // 文字列の切りだし
        $iStart     = (int) $sStart;
        $bRetCode   = Validate::isInt($sLength);
        if ( $bRetCode !== true ) {
            $mValue = substr($sKeyword, $iStart);
        } else {
            $mValue = substr($sKeyword, $iStart, $iLength);
        }
        if ( $mValue === false ) {
            // 切り出しが失敗
            return $sKeyword;
        }
        return (string) $mValue;
    }

    /**
     * キーワード修飾処理する by preg_replace
     *
     * @param   string  $sKeyword   キーワード
     * @param   string  $sSearch    検索文字
     * @param   string  $sReplace   置換文字
     * @return  string
     */
    protected function _replaceKeyrowdsPregReplace($sKeyword, $sSearch, $sReplace)
    {
        // 文字列の正規表現置換
        $sSearch  = $this->validatePCRE((string) $sSearch, false, '#', 'u');
        $sReplace = (string) $sReplace;
        $mValue   = preg_replace($sSearch, $sReplace, $sKeyword);
        if ( $mValue === NULL ) {
            // 置換に失敗 → そのまま
            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for refine.');
            if ( $this->bLogPCREError === true ) {
                \Log::dump(array(
                    'func'    => 'preg_replace',
                    'search'  => $sSearch,
                    'replace' => $sReplace,
                    'subject' => $sKeyword,
                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
            }
            return $sKeyword;
        }
        return (string) $mValue;
    }

    /**
     * キーワード修飾処理する by str_replace
     *
     * @param   string  $sKeyword   キーワード
     * @param   string  $sSearch    検索文字
     * @param   string  $sReplace   置換文字
     * @return  string
     */
    protected function _replaceKeyrowdsStrReplace($sKeyword, $sSearch, $sReplace)
    {
        // 文字列の単純置換
        $sSearch  = (string) $sSearch;
        $sReplace = (string) $sReplace;
        return str_replace($sSearch, $sReplace, $sKeyword);
    }

    /**
     * 文字コード変換
     *
     * @param   string  $sInput
     * @param   string  $sEncTo
     * @param   string  $sEncFrom
     * @return  string  変換後の文字列
     */
    public static function mb_convert_encoding($sInput, $sEncTo, $sEncFrom = '')
    {
        $oSelf = static::getInstance();
        return $oSelf->_mb_convert_encoding($sInput, $sEncTo, $sEncFrom);
    }

    /**
     * 文字コード変換
     *
     * @param   string  $sInput
     * @param   string  $sEncTo
     * @param   string  $sEncFrom
     * @return  string  変換後の文字列
     */
    protected function _mb_convert_encoding($sInput, $sEncTo, $sEncFrom = '')
    {
        // 同じなら変換しない
        $sEncTo       = strtoupper(trim($sEncTo));
        $sEncTo       = (string) ArrayUtil::getValue($this->aEncodeList, $sEncTo,   $sEncTo);
        $sEncFrom     = strtoupper(trim($sEncFrom));
        $sEncFrom     = (string) ArrayUtil::getValue($this->aEncodeList, $sEncFrom, $sEncFrom);
        if ( $sEncTo === $sEncFrom || $sEncTo === '' || $sEncTo === 'PASS' || $sEncTo === 'ASCII' || $sEncTo === 'US-ASCII' ) {
            return $sInput;
        }
        // 文字コード変換
        $aArgs        = array($sInput, $sEncTo);
        if ( $sEncFrom !== '' ) {
            $aArgs[]  = $sEncFrom;
        }
        $sOutput      = call_user_func_array('mb_convert_encoding', $aArgs);
        if ( $sEncTo === 'UTF-8' ) {
            return $this->_fixUTF8($sOutput);
        }
        if ( $sEncTo === 'HTML-ENTITIES' ) {
            return $this->_fixNumericReferences($sOutput);
        }
        return $sOutput;
    }

    /**
     * UTF-8文字コード変換修正
     *
     * @param   string  $sInput
     * @return  string  変換後の文字列
     */
    public static function fixUTF8($sInput)
    {
        $oSelf = static::getInstance();
        return $oSelf->_fixUTF8($sInput);
    }

    /**
     * UTF-8文字コード変換修正
     *
     * @param   string  $sInput
     * @return  string  変換後の文字列
     */
    protected function _fixUTF8($sInput)
    {
        // UTF-8マップ
        $aMap                 = array();
        // &nbsp;問題
        if ( $this->sUTF8NBSPAlter !== NULL ) {
            $aMap["\xC2\xA0"] = $this->sUTF8NBSPAlter;
        }
        // 半角Yen問題
        if ( $this->sUTF8YenAlter !== NULL ) {
            $aMap["\xC2\xA5"] = $this->sUTF8YenAlter;
        }
        if ( $this->bEncodeMSCP932 === true ) {
            // MSCP932問題対応
            $aMap             = array_merge($aMap, $this->aEncodeMapMSCP932);
        }
        // 常時置換
        $sOutput              = str_replace(array_keys($aMap), array_values($aMap), $sInput);
        return $sOutput;
    }

    /**
     * HTML-ENTITIES文字コード変換修正
     *
     * @param   string  $sInput
     * @return  string  変換後の文字列
     */
    public static function fixNumericReferences($sInput)
    {
        $oSelf = static::getInstance();
        return $oSelf->_fixNumericReferences($sInput);
    }

    /**
     * HTML-ENTITIES文字コード変換修正
     *
     * @param   string  $sInput
     * @return  string  変換後の文字列
     */
    protected function _fixNumericReferences($sInput)
    {
        // そのまま
        if ( $this->bUseNumericRef !== true ) {
            return $sInput;
        }
        // 文字実体参照を数値実体参照に変換
        return str_replace(array_keys($this->aNumericRefMap), array_values($this->aNumericRefMap), $sInput);
    }

    /**
     * 定数定義
     *
     * @param   string  $sName
     * @param   mixed   $mValue
     * @param   bool    $bIgnoreCase
     * @return  bool    true
     */
    public static function define($sName, $mValue, $bIgnoreCase = false)
    {
        // 定義済みか否か
        $bDefined = defined($sName);
        if ( $bDefined === true ) {
            // 定義済みなら抜ける
            return false;
        }
        // 大文字小文字無視か否か
        if ( $bIgnoreCase !== true ) {
            $bIgnoreCase = false;
        }
        // 定数定義する
        return define($sName, $mValue, $bIgnoreCase);
    }

    /**
     * ファイルリストを取得
     *
     *  RecursiveDirectoryIteratorのフラグ指定のデフォルト
     *      \FilesystemIterator::KEY_AS_PATHNAME
     *      \FilesystemIterator::CURRENT_AS_FILEINFO
     *      \FilesystemIterator::SKIP_DOTS
     *      \FilesystemIterator::UNIX_PATHS
     *      \FilesystemIterator::FOLLOW_SYMLINKS
     *
     * @param   string  $sDirName               取得するディレクトリパス
     * @param   string  $sPattern               ファイル名のパターン指定
     * @param   bool    $bRecursively           再帰的に検索してリストするか否か
     * @param   bool    $bDirOnly               ディレクトリのみを返す
     * @param   int     $iFlags                 RecursiveDirectoryIteratorのフラグ指定
     * @param   bool    $bPatternIsPCRE         ファイル名のパターン指定にPCREを使う
     * @param   bool    $bThrowException        エラーが発生した際に空配列を返す
     * @return  array   SplFileInfo配列
     * @throw   \UnexpectedValueException
     */
    public static function getFileList($sDirName, $sPattern = '', $bRecursively = true, $bDirOnly = false, $iFlags = NULL, $bPatternIsPCRE = false, $bThrowException = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getFileList($sDirName, $sPattern, $bRecursively, $bDirOnly, $iFlags, $bPatternIsPCRE, $bThrowException);
    }

    /**
     * ファイルリストを取得
     *
     *  RecursiveDirectoryIteratorのフラグ指定のデフォルト
     *      \FilesystemIterator::KEY_AS_PATHNAME
     *      \FilesystemIterator::CURRENT_AS_FILEINFO
     *      \FilesystemIterator::SKIP_DOTS
     *      \FilesystemIterator::UNIX_PATHS
     *      \FilesystemIterator::FOLLOW_SYMLINKS
     *
     * @param   string  $sDirName               取得するディレクトリパス
     * @param   string  $sPattern               ファイル名のパターン指定
     * @param   bool    $bRecursively           再帰的に検索してリストするか否か
     * @param   bool    $bDirOnly               ディレクトリのみを返す
     * @param   int     $iFlags                 RecursiveDirectoryIteratorのフラグ指定
     * @param   bool    $bPatternIsPCRE         ファイル名のパターン指定にPCREを使う
     * @param   bool    $bThrowException        エラーが発生した際に空配列を返す
     * @return  array   SplFileInfo配列
     * @throw   \UnexpectedValueException
     */
    protected function _getFileList($sDirName, $sPattern = '', $bRecursively = true, $bDirOnly = false, $iFlags = NULL, $bPatternIsPCRE = false, $bThrowException = false)
    {
        // オプションチェック
        if ( $iFlags === NULL || (int) $iFlags < 0 ) {
            $iFlags                        = \FilesystemIterator::KEY_AS_PATHNAME | \FilesystemIterator::CURRENT_AS_FILEINFO | \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::UNIX_PATHS | \FilesystemIterator::FOLLOW_SYMLINKS;
        } else {
            $iFlags                        = (int) $iFlags;
        }
        // 変数初期化
        $aFileList                         = array();
        try {
            // イテレータ取得
            $oIterator                     = new RecursiveDirectoryIterator($sDirName,  $iFlags);
            if ( $bRecursively !== false ) {
                // 再帰なら再帰イテレータ
                $oIterator                 = new \RecursiveIteratorIterator($oIterator, \RecursiveIteratorIterator::SELF_FIRST);
            }
            // ループ
            foreach ( $oIterator as $sPathname => $oFileInfo ) {
                // ファイルを取得
                $oFileInfo                 = FileBare::getInstanceFrom($oFileInfo);
                // ディレクトリチェック
                if ( $bDirOnly === true ) {
                    $bRetCode              = $oFileInfo->isDir();
                    if ( $bRetCode !== true ) {
                        // ディレクトリのみでディレクトリでなければ次へ
                        continue;
                    }
                }
                // パターンチェックするか？
                $sPattern                  = trim($sPattern);
                if ( $sPattern === '' ) {
                    // チェック不要
                    $aFileList[$sPathname] = $oFileInfo;
                    continue;
                }
                // チェックする
                if ( $bPatternIsPCRE === true ) {
                    $bRetCode              = (bool) preg_match($sPattern, $oFileInfo->getFilename());
                } else {
                    $bRetCode              = (bool) fnmatch($sPattern, $oFileInfo->getFilename());
                }
                if ( $bRetCode === true ) {
                    // マッチしたものだけ保持
                    $aFileList[$sPathname] = $oFileInfo;
                }
            }
            // キーソートする
            ArrayUtil::natksort($aFileList);
        } catch(\UnexpectedValueException $oException) {
            // ディレクトリがオープンできなかった場合に例外を返すか？
            if ( $bThrowException === true ) {
                // リスロー
                throw $oException;
            }
        }
        return $aFileList;
    }

    /**
     * ファイルサイズを整形
     *
     * @param   float   $fSize          ファイルサイズ
     * @param   string  $sFormat        表示フォーマット
     * @return  string  整形済みファイルサイズ
     */
    public static function formatFileSize($fSize, $sFormat = '%.0f')
    {
        $aUnits = array('', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y');
        $iMax   = count($aUnits) - 1;
        for ( $i = 0 ; $i < $iMax && $fSize >= 1024.0 ; $i++ ) {
            $fSize /= 1024.0;
        }
        return sprintf($sFormat, $fSize) . $aUnits[$i] . 'B';
    }

    /**
     * ソースサイトのステージングを使用するか否か
     *
     * @return  bool    true
     */
    public static function getUseStaging()
    {
        $oSelf = static::getInstance();
        return $oSelf->bUseStaging;
    }

    /**
     * SPサイトのステージングを使用するか否か
     *
     * @return  bool    true
     */
    public static function getUseStagingSP()
    {
        $oSelf = static::getInstance();
        return $oSelf->bUseStagingSP;
    }

    /**
     * URIを調整用の設定を保持
     *
     * @param   array   $aAdjustConds   調整条件
     * @return  bool    true
     */
    public static function setAdjustURIConds(array $aAdjustConds)
    {
        $oSelf               = static::getInstance();
        $aCondTypes          = array(
            'production',
            'staging-source',
            'staging-sp',
        );
        $aConds              = array();
        foreach ( $aCondTypes as $sType ) {
            $aInput          = (array) ArrayUtil::getValue($aAdjustConds, $sType, array());
            $aCond[$sType]   = $oSelf->_validateAdjustURIConds($aInput);
        }
        $oSelf->aAdjustConds = $aCond;
        return true;
    }

    /**
     * URIを調整用の設定を有効な形に整形
     *
     * @param   array   $aAdjustConds   調整条件配列
     * @return  array   調整条件配列
     */
    protected function _validateAdjustURIConds(array $aAdjustConds)
    {
        // 生成
        $aConds                             = array();
        foreach ( $aAdjustConds as $sSetName => $aSetCond ) {
            $aConds[$sSetName]              = array();
            $aSetCond                       = (array) $aSetCond;
            foreach ( $aSetCond as $sName => $aCond ) {
                $aCond                      = (array) $aCond;
                // 置換ターゲットを取得
                $sTarget                    = strtolower(trim(ArrayUtil::getValue($aCond, 'target', 'uri:host')));
                $bURIPart                   = true;
                $bIgnoreCase                = false;
                switch ($sTarget) {
                    // 指定なし or host → 大小文字無視がデフォルト
                    case '': case 'host': case 'uri:host': case 'url:host':
                        $sTarget            = 'host';
                        $bIgnoreCase        = true;
                        $bURIPart           = true;
                        break;

                    // url or uri → uri
                    case     'uri': case     'url':
                    case 'uri:uri': case 'uri:url':
                    case 'url:uri': case 'url:url':
                        $sTarget            = 'uri';
                        $bURIPart           = false;
                        break;

                    // Uriクラス系ターゲット
                    case     'scheme': case     'port': case     'user': case     'pass': case     'path': case     'query': case     'fragment':
                        $bURIPart           = true;
                        break;
                    case 'uri:scheme': case 'uri:port': case 'uri:user': case 'uri:pass': case 'uri:path': case 'uri:query': case 'uri:fragment':
                    case 'url:scheme': case 'url:port': case 'url:user': case 'url:pass': case 'url:path': case 'url:query': case 'url:fragment':
                        $aTarget            = explode(':', $sTarget);
                        $sTarget            = $aTarget[1];
                        $bURIPart           = true;
                        break;

                    // その他のターゲット
                    default:
                        // 置換しない
                        continue;
                }
                // オプション
                $aOptions                    = (array) ArrayUtil::getValue($aCond,    'options', array());
                // 大文字小文字無視？
                $bRetCode                    = in_array('nocase', $aOptions) || in_array('NC', $aOptions) || in_array('ignorecase', $aOptions);
                if ( $bRetCode === true ) {
                    $bIgnoreCase             = true;
                }
                $bIgnoreCase                 = (bool)  ArrayUtil::getValue($aCond,    'ignorecase', $bIgnoreCase);
                // 演算子チェック
                $sCompare                    = trim(ArrayUtil::getValue($aCond, 'compare', '='));
                $sSearch                     = (string) ArrayUtil::getValue($aCond, 'search',  '');
                $sReplace                    = (string) ArrayUtil::getValue($aCond, 'replace', '');
                switch ( $sCompare ) {
                    // 正規表現(preg_replace)
                    case '~': case '!~':
                        if ( $sSearch === '' ) {
                            // 正規表現は空文字で置換しない
                            continue;
                        }
                        if ( $bIgnoreCase === true ) {
                            $sExtent         = 'ui';
                        } else {
                            $sExtent         = 'u';
                        }
                        // キーワード
                        $sRefinedSearch      = $this->validatePCRE($this->_refine($sSearch, false), false, '#', $sExtent);
                        break;
                    // 完全一致(str*cmp)
                    case '=': case '!=': case '<>': case '':
                        // キーワード
                        if ( $sSearch === '' ) {
                            $sRefinedSearch  = '';
                        } else {
                            $sRefinedSearch  = $this->_refine($sSearch, false);
                        }
                        break;
                    // その他
                    default:
                        // その他の演算子は置換しない
                        continue;
                }
                // 適用条件を取得
                $aConditions                = $this->_validateAdjustURIApplyConds((array) ArrayUtil::getValue($aCond, 'conditions', array()));
                // キーワード
                if ( $sReplace === '' ) {
                    $sRefinedReplace         = '';
                } else {
                    $sRefinedReplace         = $this->_refine($sReplace, false);
                }
                // 条件配列を生成
                $aConds[$sSetName][$sName]  = array(
                    'conditions' => $aConditions,       // 適用条件
                    'target'     => $sTarget,           // チェック対象
                    'isuripart'  => $bURIPart,          // チェック対象はURIの構成要素か否か
                    'compare'    => $sCompare,          // チェック演算子
                    'ignorecase' => $bIgnoreCase,       // チェック時に大文字小文字無視するか否か
                    'search'     => $sRefinedSearch,    // 検索文字列
                    'searchorg'  => $sSearch,           // 検索文字列(オリジナル)
                    'replace'    => $sRefinedReplace,   // 置換文字列
                    'replaceorg' => $sReplace,          // 置換文字列(オリジナル)
                    'options'    => $aOptions,          // オプション
                );
            }
        }
        return $aConds;
    }

    /**
     * URI調整の適用条件配列の有効化
     *
     * @param   array   $aConditions
     * @return  array   ターゲット情報配列
     * @throw   SC\exception\
     */
    protected function _validateAdjustURIApplyConds(array $aConditions)
    {
        // 空配列なら空配列のまま
        if ( $aConditions === array() ) {
            return $aConditions;
        }
        // 3次元配列でなければ3次元にする
        $aConditions                              = ArrayUtil::incRankTo($aConditions, 3);
        // 3次元配列を処理
        foreach ( $aConditions as $sSet => $aCondSet ) {
            foreach ( $aCondSet as $sCond => $aCond ) {
                // 条件なしか？
                if ( $aCond === array() ) {
                    // 条件なし → 結果条件を保持
                    $aConditions[$sSet][$sCond]   = array(
                        'target'     => 'none',             // チェック対象
                        'from'       => 'none',             // チェック対象取得元
                        'isuripart'  => false,              // チェック対象はURIの構成要素か否か
                        'value'      => 'none',             // チェック対象の値
                        'compare'    => '=',                // チェック演算子
                        'ignorecase' => false,              // チェック時に大文字小文字無視するか否か
                        'search'     => '',                 // 検索文字列
                        'searchorg'  => '',                 // 検索文字列(オリジナル)
                        'ornext'     => false,              // 次条件とのOR判定をするか否か
                        'options'    => array(),            // オプション
                        'failure'    => false,              // マッチ失敗
                        'checked'    => true,               // チェック済みか否か(マッチ失敗ならチェック済み)
                        'matched'    => true,               // マッチ結果
                    );
                    continue;
                }
                // マッチ失敗
                $bFailure                         = false;
                // 対象を取得
                $sTarget                          = trim(ArrayUtil::getValue($aCond, 'target', 'uri:host'));
                $aTarget                          = explode(':', $sTarget, 2);
                $iCount                           = count($aTarget);
                if ( $iCount < 2 ) {
                    $sTargetKey                   = $sTarget;
                    $sTargetFrom                  = 'uri';
                } else {
                    $sTargetKey                   = $aTarget[1];
                    $sTargetFrom                  = strtolower($aTarget[0]);
                }
                // 大文字小文字無視判定デフォルト値
                $bIgnoreCase                      = false;
                $bURIPart                         = false;
                // ソースの指定
                switch ($sTargetFrom) {
                    // URI情報
                    case 'uri': case 'url':
                        // URI情報は都度解析 → 空文字で保持しておく
                        $sTargetValue             = '';
                        $bCheckNow                = false;
                        // キーは必ず小文字
                        $sTargetKey               = strtolower($sTargetKey);
                        switch ( $sTargetKey ) {
                            // hostの場合だけデフォルトは大文字小文字無視
                            case 'host':
                                $bIgnoreCase      = true;
                                $bURIPart         = true;
                                break;
                            // host以外の有効なURIパーツ
                            case 'scheme': case 'port': case 'user': case 'pass': case 'path': case 'query': case 'fragment':
                                $bURIPart         = true;
                                break;
                            // URI全体にマッチさせる
                            case 'uri': case 'url':
                                $bURIPart         = false;
                                break;
                            // その他
                            default:
                                // その他はマッチしない
                                $bFailure         = true;
                                $bURIPart         = false;
                                break;
                        }
                        break;

                    // サーバ情報
                    case 'server':
                        $bRetCode                 = isset($this->aAdjustURITarget[$sTargetKey]);
                        if ( $bRetCode === true ) {
                            $sTargetValue         = $this->oRequest->getServer($sTargetKey, '');
                        } else {
                            $bFound               = false;
                            foreach ( $this->aAdjustURITargetPrefix as $sPrefix => $bRetCode ) {
                                $iCmp             = strncmp($sPrefix, $sTargetKey, strlen($sPrefix));
                                if ( $iCmp === 0 ) {
                                    $bFound       = true;
                                    $sTargetValue = $this->oRequest->getServer($sTargetKey, '');
                                    break;
                                }
                            }
                            if ( $bFound !== true ) {
                                $sTargetValue     = '';
                            }
                        }
                        $bCheckNow                = true;
                        break;

                    // リクエスト情報
                    case 'request':
                    case 'get':
                    case 'post':
                    case 'cookie':
                        // リクエスト情報はそのまま使う
                        $sMethod                  = 'get' . ucfirst($sTargetFrom);
                        $sTargetValue             = $this->oRequest->$sMethod($sTargetKey, '');
                        $bCheckNow                = true;
                        break;

                    // その他
                    default:
                        // その他のソースはマッチしない
                        $bFailure                 = true;
                        break;
                }
                // オプション
                $aOptions                         = (array)  ArrayUtil::getValue($aCond, 'options',    array());
                // 大文字小文字無視？
                $bRetCode                         = in_array('nocase', $aOptions) || in_array('NC', $aOptions) || in_array('ignorecase', $aOptions);
                if ( $bRetCode === true ) {
                    $bIgnoreCase                  = true;
                }
                $bIgnoreCase                      = (bool)   ArrayUtil::getValue($aCond, 'ignorecase', $bIgnoreCase);
                // ornext
                $bOrNext                          = in_array('ornext', $aOptions) || in_array('OR', $aOptions);
                $bOrNext                          = (bool)   ArrayUtil::getValue($aCond, 'ornext',     $bOrNext);
                // 演算子チェック
                $sCompare                         = trim(ArrayUtil::getValue($aCond, 'compare', '='));
                $sValue                           = (string) ArrayUtil::getValue($aCond, 'value',      '');
                $sSearch                          = (string) ArrayUtil::getValue($aCond, 'search',     '');
                switch ( $sCompare ) {
                    // 正規表現(preg_match)
                    case '~': case '!~':
                        if ( $sSearch === '' ) {
                            // 正規表現は空文字でマッチしない
                            $bFailure             = true;
                            $sRefinedSearch       = '';
                        } else {
                            if ( $bIgnoreCase === true ) {
                                $sExtent          = 'ui';
                            } else {
                                $sExtent          = 'u';
                            }
                            // キーワード
                            $sRefinedSearch       = $this->validatePCRE($this->_refine($sSearch, false), false, '#', $sExtent);
                        }
                        break;
                    // 完全一致(strpos)
                    case '=': case '!=': case '<>': case '':
                        // キーワード
                        if ( $sSearch === '' ) {
                            $sRefinedSearch       = '';
                        } else {
                            $sRefinedSearch       = $this->_refine($sSearch, false);
                        }
                        break;
                    // その他
                    default:
                        // その他の演算子はマッチしない
                        $bFailure                 = true;
                        break;
                }
                // 適用条件情報を生成
                $aCond                            = array(
                    'target'     => $sTargetKey,        // チェック対象
                    'from'       => $sTargetFrom,       // チェック対象取得元
                    'isuripart'  => $bURIPart,          // チェック対象はURIの構成要素か否か
                    'value'      => $sTargetValue,      // チェック対象の値
                    'compare'    => $sCompare,          // チェック演算子
                    'ignorecase' => $bIgnoreCase,       // チェック時に大文字小文字無視するか否か
                    'search'     => $sRefinedSearch,    // 検索文字列
                    'searchorg'  => $sSearch,           // 検索文字列(オリジナル)
                    'ornext'     => $bOrNext,           // 次条件とのOR判定をするか否か
                    'options'    => $aOptions,          // オプション
                    'failure'    => $bFailure,          // マッチ失敗
                    'checked'    => $bFailure,          // チェック済みか否か(マッチ失敗ならチェック済み)
                    'matched'    => false,              // マッチ結果
                );
                // 今チェックするか？
                if ( $bCheckNow === true && $bFailure === false ) {
                    // マッチ失敗してない かつ 今チェックする
                    $aCond['matched']             = $this->_matchAdjustURIApplyCond($aCond, $sTargetValue, "ValidateApplyCond :: $sSet :: $sCond");
                    $aCond['checked']             = true;
                }
                // 結果条件を保持
                $aConditions[$sSet][$sCond]       = $aCond;
            }
        }
        return $aConditions;
    }

    /**
     * マッチング
     *
     * @param   array   $aCond      比較条件
     * @param   string  $sValue     比較値
     * @param   string  $sLogLabel  ログ
     * @return  bool    条件にマッチしたか否か(true/false)
     */
    protected function _matchAdjustURIApplyCond(array $aCond, $sValue, $sLogLabel)
    {
        // 比較処理
        $bFound                 = false;
        $bCmpMatch              = true;
        $bMatched               = false;
        $aLogMatch              = array();
        switch ( $aCond['compare'] ) {
            // 正規表現で比較(preg_match)
            case '!~':
                $bCmpMatch      = false;
            // 正規表現で比較
            case '~':
                if ( $aCond['search'] === '' || $sValue === '' ) {
                    // 正規表現がない or 正規表現で空文字にマッチはNG
                    break;
                }
                $bFound         = (bool) preg_match($aCond['search'], $sValue);
                if ( $bFound === $bCmpMatch ) {
                    $bMatched   = true;
                }
                // マッチログ
                if ( $this->iLogMatch > 1 ) {
                    $aLogMatch  = array(
                        'regex'        => array(
                            'regex'    => $aCond['search'],
                            'found'    => $bFound,
                            'cmpmatch' => $bCmpMatch,
                        ),
                    );
                }
                break;

            // 完全不一致で比較(str*cmp)
            case '!=': case '<>':
                $bCmpMatch      = false;
            // 完全一致で比較
            case '=':
                if ( $aCond['ignorecase'] === true ) {
                    $sCmpFunc   = 'strcasecmp';
                } else {
                    $sCmpFunc   = 'strcmp';
                }
                $bFound         = ! (bool) $sCmpFunc($aCond['search'], $sValue);
                if ( $bFound === $bCmpMatch ) {
                    $bMatched   = true;
                }
                // マッチログ
                if ( $this->iLogMatch > 1 ) {
                    $aLogMatch  = array(
                        'eq'           => array(
                            'cmpfunc'  => $sCmpFunc,
                            'found'    => $bFound,
                            'cmpmatch' => $bCmpMatch,
                        ),
                    );
                }
                break;

            // その他
            default:
                // マッチしない
                break;
        }
        // マッチログ
        if ( $this->iLogMatch > 1 ) {
            $aLogMatch          = array_merge(array(
                'matched'    => $bMatched,
                'compare'    => $aCond['compare'],
                'ignorecase' => $aCond['ignorecase'],
                'search'     => $aCond['search'],
                'value'      => $sValue,
            ), $aLogMatch);
            \Log::dump($aLogMatch, "Adjust URI matching  [ $sLogLabel ]:", \Log::LEVEL_TRACE);
        }
        return $bMatched;
    }

    /**
     * 文字列中にあるURIを調整
     *
     * @param   string  $sInput         調整文字列
     * @param   bool    $bUtf8          UTF-8か否か
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済み文字列
     */
    public static function adjustURIString($sInput, $bUtf8 = true, $sPathPrefix = '')
    {
        $oSelf = static::getInstance();
        return $oSelf->_adjustURIString($sInput, $bUtf8, $sPathPrefix);
    }

    /**
     * 文字列中にあるURIを調整
     *
     * @param   string  $sInput         調整文字列
     * @param   bool    $bUtf8          UTF-8か否か
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済み文字列
     * @throw   SC\exception\common\parameter\NotAString
     */
    protected function _adjustURIString($sInput, $bUtf8 = true, $sPathPrefix = '')
    {
        // 入力チェック
        $bRetCode       = Validate::isString($sInput);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Input must be string.');
        }
        $sInput         = (string) $sInput;
        // 空文字か否か
        $sOutput        = trim($sInput);
        if ( $sInput === '' ) {
            // 空文字もしくは空白のみならそのまま返す
            return $sInput;
        }
        // UTF-8か否か
        if ( $bUtf8 !== false ) {
            $sREExtUtf8 = 'u';
        } else {
            $sREExtUtf8 = '';
        }
        // that hack
        $that           = $this;
        $cbReplaceFunc  = function($aMatches) use ($that, $sPathPrefix){
            return $that->adjustURIStringReplace($aMatches, $sPathPrefix);
        };
        $sSearch        = $this->sUriRE . $sREExtUtf8;
        $mRetValue      = preg_replace_callback($sSearch, $cbReplaceFunc, $sInput);
        if ( $mRetValue !== NULL ) {
            $sOutput    = $mRetValue;
        } else {
            $sOutput    = $sInput;
            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for url-adjust.');
            if ( $this->bLogPCREError === true ) {
                \Log::dump(array(
                    'func'    => 'preg_replace_callback',
                    'search'  => $sSearch,
                    'replace' => $cbReplaceFunc,
                    'subject' => $sInput,
                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
            }
        }
        return $sOutput;
    }

    /**
     * 文字列中にあるURIを調整
     *
     * @param   array   $aMatches       マッチした文字列
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  置換後の文字列
     */
    public function adjustURIStringReplace($aMatches, $sPathPrefix = '')
    {
        return $this->_adjustURIStringReplace($aMatches, $sPathPrefix);
    }

    /**
     * 文字列中にあるURIを調整
     *
     * @param   array   $aMatches       マッチした文字列
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  置換後の文字列
     */
    protected function _adjustURIStringReplace($aMatches, $sPathPrefix = '')
    {
        // 参照数
        $iCount         = count($aMatches);
        switch ( $iCount ) {
            case 4:
            case 7:
                $sPref  = $aMatches[$iCount-3];
                $sQuote = $aMatches[$iCount-2];
                $sUri   = $aMatches[$iCount-1];
                break;

            case 9:
                $sPref  = $aMatches[7];
                $sQuote = '';
                $sUri   = $aMatches[8];
                break;

            case 11:
            case 13:
                $sPref  = '';
                $sQuote = $aMatches[$iCount-2];
                $sUri   = $aMatches[$iCount-1];
                break;

            case 14:
                $sPref  = '';
                $sQuote = '';
                $sUri   = $aMatches[13];
                break;

            default:
                return $aMatches[0];
        }
        // ヒットしたURI調整
        $sAdjusted      = $this->_adjustURI('production', $sUri,      NULL, $sPathPrefix);
        if ( $this->bUseStagingSP === true ) {
            // SPステージング用の調整を行う
            $sAdjusted  = $this->_adjustURI('staging-sp', $sAdjusted, NULL, '');
        }
        $sReplaced      = $sPref . $sQuote . $sAdjusted . $sQuote;
        return $sReplaced;
    }

    /**
     * URIを調整
     *
     * @param   string  $sType          調整タイプ
     * @param   string  $sUri           URI
     * @param   array   $aAdjustConds   調整条件
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済みURI
     */
    public static function adjustURI($sType, $sUri, array $aAdjustConds = NULL, $sPathPrefix = '')
    {
        $oSelf                = static::getInstance();
        $aCondTypes           = array(
            'production'     => true,
            'staging-source' => $oSelf->bUseStaging,
            'staging-sp'     => $oSelf->bUseStagingSP,
        );
        $bRetCode             = ArrayUtil::getValue($aCondTypes, $sType, false);
        if ( $bRetCode !== true ) {
            return $sUri;
        }
        $aAdjustConds         = ArrayUtil::unite($aAdjustConds, array($sType => array()), false);
        $aAdjustConds[$sType] = $oSelf->_validateAdjustURIConds($aAdjustConds[$sType]);
        return $oSelf->_adjustURI($sType, $sUri, $aAdjustConds, $sPathPrefix);
    }

    /**
     * URIを調整 for 変換
     *
     * @param   string  $sUri           URI
     * @param   bool    $bWithStaging   ステージング用の調整も行う
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済みURI
     */
    public static function adjustURIProduction($sUri, $bWithStaging = true, $sPathPrefix = '')
    {
        $oSelf = static::getInstance();
        $sUri  = $oSelf->_adjustURI('production', $sUri, NULL, $sPathPrefix);
        if ( $bWithStaging !== true || $oSelf->bUseStagingSP !== true ) {
            // ステージング用の調整は行わない
            return $sUri;
        }
        // ステージング用の調整
        $sUri  = $oSelf->_adjustURI('staging-sp', $sUri, NULL, '');
        return $sUri;
    }

    /**
     * URIを調整 for ソースサイトのステージング対応
     *
     * @param   string  $sUri           URI
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済みURI
     */
    public static function adjustURIStagingSource($sUri, $sPathPrefix = '')
    {
        $oSelf = static::getInstance();
        if ( $oSelf->bUseStaging !== true ) {
            // ステージング用の調整は行わない
            return $sUri;
        }
        // ステージング用の調整
        $sUri  = $oSelf->_adjustURI('staging-source', $sUri, NULL, $sPathPrefix);
        return $sUri;
    }

    /**
     * URIを調整 for SPサイトのステージング対応
     *
     * @param   string  $sUri           URI
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済みURI
     */
    public static function adjustURIStagingSP($sUri, $sPathPrefix = '')
    {
        $oSelf = static::getInstance();
        if ( $oSelf->bUseStagingSP !== true ) {
            // ステージング用の調整は行わない
            return $sUri;
        }
        // ステージング用の調整
        $sUri  = $oSelf->_adjustURI('staging-sp', $sUri, NULL, $sPathPrefix);
        return $sUri;
    }

    /**
     * URIを調整
     *
     * @param   string  $sType          調整タイプ
     * @param   string  $sRawUri        URI
     * @param   array   $aAdjustConds   調整条件
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済みURI
     */
    protected function _adjustURI($sType, $sRawUri, array $aAdjustConds = NULL, $sPathPrefix = '')
    {
        // 指定がなければデフォルト設定
        if ( $aAdjustConds === NULL ) {
            $aAdjustConds              = ArrayUtil::getValue($this->aAdjustConds, $sType, array());
        }
        if ( $aAdjustConds === array() ) {
            // 調整不要
            if ( $this->iLogMatch > 0 ) {
                \Log::trace("Adjust URI [$sType] for '$sRawUri': nothing to do.");
            }
            return $sRawUri;
        }
        // 調整情報があるので調整する
        $oUri                          = new Uri($sRawUri);
        // スキームがあるか？
        $sScheme                       = $oUri->getScheme();
        if ( $sScheme === '' ) {
            // スキームなし
            $bHasScheme                = false;
        } else {
            // スキームあり
            $bHasScheme                = true;
        }
        $sHost                         = $oUri->getHost();
        if ( $sHost !== '' ) {
            $bHasHost                  = true;
        } else {
            $bHasHost                  = false;
        }
        $bModified                     = false;
        foreach ( $aAdjustConds as $sName => $aCondSet ) {
            foreach ( $aCondSet as $iKey => $aCond ) {
                // ターゲットキーを取得
                $sTargetKey            = $aCond['target'];
                if ( $sTargetKey === '' ) {
                    // URIの調整対象がない or 正しくない
                    continue;
                }
                // 適用条件判定
                $bMatched              = $this->_matchApplyCond($aCond, $oUri);
                if ( $bMatched !== true ) {
                    // 適用外
                    continue;
                }
                $sCompare              = $aCond['compare'];
                $bIgnoreCase           = $aCond['ignorecase'];
                // URIの調整対象を特定
                $sGetMethod            = 'get' . ucfirst($sTargetKey);
                $bRetCode              = method_exists($oUri, $sGetMethod);
                if ( $bRetCode !== true ) {
                    // URIの調整対象がない or 正しくない
                    continue;
                }
                $sSetMethod            = 'set' . ucfirst($sTargetKey);
                $bRetCode              = method_exists($oUri, $sSetMethod);
                if ( $bRetCode !== true ) {
                    // URIの調整対象がない or 正しくない
                    continue;
                }
                // URIの調整
                $sTarget               = $oUri->$sGetMethod();
                // 対象集合
                $bMatchCmp             = true;
                switch ( $sCompare ) {
                    // 正規表現(preg_replace)
                    case '!~':
                        // notが付いていれば補集合
                        $bMatchCmp     = false;
                    case '~':
                        // 正規表現で置換
                        $sReplaced     = preg_replace($aCond['search'], $aCond['replace'], $sTarget);
                        if ( $sReplaced === NULL ) {
                            // 置換に失敗 → そのまま
                            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for adjust uri in Util.');
                            if ( $this->bLogPCREError === true ) {
                                \Log::dump(array(
                                    'func'    => 'preg_replace',
                                    'search'  => $aCond['search'],
                                    'replace' => $aCond['replace'],
                                    'subject' => $sTarget,
                                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
                            }
                        } else {
                            if ( ( ( $sReplaced !== $sTarget ) ^ ( $bMatchCmp === false ) ) === 1 ) {
                                // 置換した XOR 補集合
                                $oUri->$sSetMethod($sReplaced);
                                $bModified = true;
                            }
                        }
                        break;

                    // 完全一致(str*cmp)
                    case '!=': case '<>':
                        // notが付いていれば補集合
                        $bMatchCmp     = false;
                    case '=':
                        // 条件指定
                        if ( $bIgnoreCase === true ) {
                            $sCmpFunc  = 'strcasecmp';
                        } else {
                            $sCmpFunc  = 'strcmp';
                        }
                        // 完全一致判定
                        $bCmp          = ! (bool) $sCmpFunc($sTarget, $aCond['search']);
                        if ( $bCmp === $bMatchCmp ) {
                            $oUri->$sSetMethod($aCond['replace']);
                            $bModified = true;
                        }
                        break;

                    // その他の場合は無視
                    default:
                        break;
                }
            }
        }
        // ホスト指定なし もしくは 修正があった
        if ( $bHasHost === false || $bModified === true ) {
            // ホスト指定がなければパスの接頭辞補正を行う
            // ホスト指定がある場合は修正があればパスの接頭辞補正を行う
            $sPathPrefix               = trim($sPathPrefix);
            $bFound                    = (bool) preg_match('#^/#S', $oUri->getPath());
            if ( $bFound === true ) {
                // パス接頭辞を付与する
                $bModified             = true;
                $sNewPath              = rtrim($sPathPrefix, '/') . '/' . ltrim($oUri->getPath(), '/');
                $oUri->setPath($sNewPath);
            }
        }
        if ( $bModified === true ) {
            // ビルド
            if ( $bHasHost === true ) {
                // ホスト名あり
                $sUri                  = $oUri->build(Uri::TYPE_ABSOLUTE);
            } else {
                // ホスト名なし
                $sUri                  = $oUri->build(Uri::TYPE_RELATIVE);
                // スキームがあるか？
                if ( $bHasScheme === true ) {
                    $sUri              = $sScheme . ':' . $sUri;
                }
            }
            if ( $this->iLogMatch > 0 ) {
                if ( $sUri === $sRawUri ) {
                    \Log::trace("Adjust URI [$sType] for '$sRawUri': nothing to do.");
                } else {
                    \Log::trace("Adjust URI [$sType] for '$sRawUri' => '$sUri' at " . __LINE__ . ' in ' . __METHOD__);
                }
            }
        } else {
            $sUri                      = $sRawUri;
            if ( $this->iLogMatch > 0 ) {
                \Log::trace("Adjust URI [$sType] for '$sRawUri': nothing to do.");
            }
        }
        return $sUri;
    }

    /**
     * URI調整の適用条件にマッチしたか否か
     *
     * @param   array       $aAdjustCond    URI調整条件
     * @param   SC\libs\Uri $oUri           URI
     * @return  bool        true/false
     */
    protected function _matchApplyCond(array $aAdjustCond, Uri $oUri)
    {
        $bMatched    = false;
        // 適用条件を取得
        $aConditions = $aAdjustCond['conditions'];
        if ( $aConditions === array() ) {
            // 条件指定なし
            return true;
        }
        foreach ( $aConditions as $sSet => $aCondSet ) {
            $bPrevOr                    = false;
            foreach ( $aCondSet as $sCond => $aCond ) {
                // ornext指定を保持
                // 前条件が，マッチしていてornext指定あり → この条件は判定しない
                if ( $bMatched === true && $bPrevOr === true ) {
                    // ornext指定もしくはOR指定があれば次の条件へ
                    $bPrevOr            = $aCond['ornext'];
                    continue;
                }
                // 条件判定 (初期は必ずマッチしない)
                $bMatched               = false;
                // チェック済み？
                if ( $aCond['checked'] === true ) {
                    // チェック済み
                    $bMatchedThis       = $aCond['matched'];
                } else {
                    // チェック
                    $sTargetValue       = $this->_getTargetForApplyCond($aCond, $oUri);
                    $bMatchedThis       = $this->_matchAdjustURIApplyCond($aCond, $sTargetValue, "MatchApplyCond :: $sSet :: $sCond");
                }
                // マッチした？
                if ( $bMatchedThis === true ) {
                    // マッチしたら次の条件へ
                    $bMatched           = true;
                    $bPrevOr            = $aCond['ornext'];
                    continue;
                }
                // マッチしていない
                if ( $aCond['ornext'] === true ) {
                    // ornext指定があれば次の条件へ
                    $bPrevOr            = $aCond['ornext'];
                    continue;
                }
                // マッチしていないのでNG
                $bMatched               = false;
                break;
            }
            // マッチしていたら抜ける
            if ( $bMatched === true ) {
                break;
            }
        }
        return $bMatched;
    }

    /**
     * 比較対象文字列を取得する for 適用条件
     *
     * @param   array       $aCond  URI調整条件
     * @param   SC\libs\Uri $oUri   URI
     * @return  string      比較対象文字列
     */
    protected function _getTargetForApplyCond(array $aCond, Uri $oUri)
    {
        // 取得元がuriでなければ取得値があるはずなのでそのまま返す
        if ( $aCond['from'] !== 'uri' ) {
            return $aCond['value'];
        }
        // パーツでなければURIをそのまま返す
        if ( $aCond['isuripart'] !== true ) {
            return $oUri->getRawUri();
        }
        // URIの適用対象を特定
        $sGetMethod = 'get' . ucfirst($aCond['target']);
        $bRetCode   = method_exists($oUri, $sGetMethod);
        if ( $bRetCode !== true ) {
            // URIの調整対象がない or 正しくない → 空文字を返す
            return '';
        }
        return $oUri->$sGetMethod();
    }

    /**
     * パスを正規化する
     *
     * @param   string  $sRawPath       パス
     * @param   string  $sBasePath      ベースパス
     * @param   string  $sDirSep        DIRECTORY_SEPARATOR
     * @param   bool    $bNormalizeSep  連続したセパレータの正規化をするかどうか
     * @return  string  調整済みパス
     */
    public static function normalizePath($sRawPath, $sBasePath = '', $sDirSep = DIRECTORY_SEPARATOR, $bNormalizeSep = true)
    {
        $oSelf = static::getInstance();
        return $oSelf->_normalizePath($sRawPath, $sBasePath, $sDirSep, $bNormalizeSep);
    }

    /**
     * パスを正規化する
     *
     * @param   string  $sRawPath       パス
     * @param   string  $sCWDir         カレントディレクトリ
     * @param   string  $sDirSep        DIRECTORY_SEPARATOR
     * @param   bool    $bNormalizeSep  連続したセパレータの正規化をするかどうか
     * @return  string  調整済みパス
     * @throw   SC\exception\common\parameter\NotAString
     */
    protected function _normalizePath($sRawPath, $sCWDir = '', $sDirSep = DIRECTORY_SEPARATOR, $bNormalizeSep = true)
    {
        // 入力チェック
        $bRetCode            = Validate::isString($sRawPath);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Path must be string.');
        }
        $bRetCode            = Validate::isString($sCWDir);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Current working directory must be string.');
        }
        $bRetCode            = Validate::isString($sDirSep);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Directory separator must be string.');
        }
        // カレントディレクトリ
        if ( $sCWDir === '' ) {
            $sCWDir          = getcwd();
        }
        $sCWDir              = str_replace(array('/','\\'), array($sDirSep, $sDirSep), $sCWDir);
        // 入力が空ならベース
        if ( $sRawPath === '' ) {
            return $sCWDir;
        }
        $sRawPath            = str_replace(array('/','\\'), array($sDirSep, $sDirSep), $sRawPath);
        // 末尾がディレクトリセパレータで終わっているか？
        $sRight1Char         = substr($sRawPath, -strlen($sDirSep));
        if ( $sRight1Char !== $sDirSep ) {
            // 末尾がディレクトリセパレータでなければ空文字
            $sRight1Char     = '';
        }
        // ルートならそのまま返す
        if ( $sRawPath === $sDirSep ) {
            return $sRawPath;
        }
        // 入力が空ならベース
        $sRawPath            = rtrim($sRawPath, $sDirSep);
        if ( $sRawPath === '' ) {
            return $sCWDir . $sRight1Char;
        }
        $sCWDir              = rtrim($sCWDir, $sDirSep) . $sDirSep;
        $bIsAbsolute         = ! (bool) strncmp($sDirSep, $sRawPath, strlen($sDirSep));
        if ( $bIsAbsolute !== true ) {
            // Windowsはさらに先頭3文字チェック
            $bIsAbsolute     = (bool) preg_match("#^[A-Z]:[\\\\/]#uSi", $sRawPath);
            if ( $bIsAbsolute !== true ) {
                $sRawPath    = $sCWDir . rtrim($sRawPath, $sDirSep);
            }
        }
        $sNormalized         = $this->_normalizePathReplace($sRawPath, $sDirSep, $bNormalizeSep) . $sRight1Char;
        if ( $bIsAbsolute !== true ) {
            // 相対パスならばカレントディレクトリを除去できるなら除去する
            $bCmp            = ! (bool) strncmp($sCWDir, $sNormalized, strlen($sCWDir));
            if ( $bCmp === true ) {
                // 一致 → 除去する
                $sNormalized = substr($sNormalized, strlen($sCWDir));
            }
        }
        return $sNormalized;
    }

    /**
     * パスを正規化する
     *
     * @param   string  $sPath          パス
     * @param   string  $sDirSep        DIRECTORY_SEPARATOR
     * @param   bool    $bNormalizeSep  連続したセパレータの正規化をするかどうか
     * @return  string  調整済みパス
     */
    protected function _normalizePathReplace($sRawPath, $sDirSep, $bNormalizeSep = true)
    {
        // ディレクトリ区切り
        $sDirSepRE             = strtr($sDirSep, array('#' => '\\#', '\\' => '\\\\'));
        if ( (bool) $bNormalizeSep === true ) {
            // 連続したセパレータを正規化
            $sNormalized       = preg_replace("#{$sDirSepRE}{2,}#u", $sDirSep, $sRawPath);
        } else {
            $sNormalized       = $sRawPath;
        }
        // カレントディレクトリを正規化
        $sNormalized           = preg_replace(array("#{$sDirSepRE}(\\.{$sDirSepRE})+#u", "#{$sDirSepRE}\\.$#u"), array($sDirSep, ''), $sNormalized);
        // 親ディレクトリの正規化が必要か？
        $bFound                = (bool) preg_match("#{$sDirSepRE}\\.\\.({$sDirSepRE}|\$)#u", $sNormalized);
        if ( $bFound !== true ) {
            // 不要なら終わり
            return $sNormalized;
        }
        // 必要ならセパレータで分割
        $aPathParts            = (array) explode($sDirSep, $sNormalized);
        $iMax                  = count($aPathParts);
        $iLevel                = 0;
        $aPathNormalized       = array();
        for ( $i=$iMax-1 ; $i>0 ; $i-- ) {
            // 最後からさかのぼる
            if ( $aPathParts[$i] === '..' ) {
                // 親ディレクトリの指定 → レベルアップ
                $iLevel++;
                continue;
            }
            if ( $iLevel > 0 ) {
                // レベルがあればディレクトリを無視
                $i            -= ($iLevel-1);
                $iLevel        = 0;
                continue;
            }
            // 無関係ならパーツとして保持
            $aPathNormalized[] = $aPathParts[$i];
        }
        // 先頭は必ず保持
        $aPathNormalized[]     = $aPathParts[0];
        // セパレータで結合
        $sPath                 = join($sDirSep, array_reverse($aPathNormalized));
        return $sPath;
    }

    /**
     * 単位を考慮して整数化する(G,M,k)
     *
     * @param   string  $sInput     単位付きの整数化する文字列
     * @param   int     $iBase      基数
     * @return  int     変換後の数値
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function toIntWithUnit($sInput, $iBase = 1024)
    {
        // 入力チェック
        $bRetCode  = Validate::isStringNotZero($sInput);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Input must be non-zero byte string.');
        }
        $iBase     = (int) $iBase;
        if ( $iBase < 1 ) {
            $iBase = 1024;
        }
        // 正規表現で処理
        $bRetCode  = (bool) preg_match('#^(.*?)([GMK])?$#Si', $sInput, $aMatches);
        if ( $bRetCode !== true ) {
            return 0;
        }
        $iNum            = (int) preg_replace('#[^0-9]#S', '', $aMatches[1]);
        $iCount          = count($aMatches);
        if ( $iCount < 3 ) {
            return $iNum;
        }
        // 単位付き
        $aMultiplier = array(
            'G' => $iBase * $iBase * $iBase,
            'g' => $iBase * $iBase * $iBase,
            'M' => $iBase * $iBase,
            'm' => $iBase * $iBase,
            'K' => $iBase,
            'k' => $iBase,
        );
        $iNum  = $iNum * $aMultiplier[$aMatches[2]];
        return $iNum;
    }

    /**
     * preg_replace用にパターンの有効化
     *
     * @param   array|string    $mPatterns      PCREパターン or PCREパターン配列
     * @param   bool            $bHasDelimiter  デリミタが既に含まれているか
     * @param   string          $sDelimiter     デリミタがない場合に付与するデリミタ
     * @param   string          $sModifier      デリミタがない場合に付与する修飾子指定
     * @return  array|string    有効化されたパターン
     * @throw   SC\exception\common\parameter\NotAnArray
     */
    public static function validatePCRE($mPatterns, $bHasDelimiter = true, $sDelimiter = '#', $sModifier = 'u')
    {
        // 配列か？
        $bIsScalar                    = is_scalar($mPatterns);
        if ( $bIsScalar === true ) {
            $aPatterns                = array($mPatterns);
        } else {
            $bRetCode                 = is_array($mPatterns);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\common\parameter\NotAnArray('Patterns must be array.');
            }
            $aPatterns                = $mPatterns;
        }
        // 有効化
        $aSearches                    = array();
        if ( $bHasDelimiter === true ) {
            // デリミタあり
            foreach ( $aPatterns as $sKey => $sSearch ) {
                // サニタイズ
                $sSearch              = (string) $sSearch;
                $iPos                 = strpos($sSearch, "\0");
                if ( $iPos !== false ) {
                    $sSearch          = substr($sSearch, 0, $iPos);
                }
                // 修飾子チェック
                $bFound               = (bool) preg_match('#^(.)(.*)(\\1)([A-Za-z]*)$#u', $sSearch, $aMatches);
                if ( $bFound === true ) {
                    // 有効な形式ならeを除去
                    $aSearches[$sKey] = $aMatches[1] . $aMatches[2] . $aMatches[3] . str_replace('e', '', $aMatches[4]);
                }
            }
        } else {
            // デリミタなし → 付与？
            $sDelimiter               = trim($sDelimiter);
            if ( $sDelimiter !== '' ) {
                $sDelimiter           = $sDelimiter[0];
                $sModifier            = preg_replace('#[^A-Za-z]#u', '', $sModifier);
            }
            foreach ( $aPatterns as $sKey => $sSearch ) {
                // サニタイズ
                $iPos                 = strpos($sSearch, "\0");
                if ( $iPos !== false ) {
                    $sSearch          = substr($sSearch, 0, $iPos);
                }
                // デリミタを付与
                if ( $sDelimiter === '' ) {
                    $aSearches[$sKey] = $sSearch;
                } else {
                    $aSearches[$sKey] = $sDelimiter . str_replace($sDelimiter, "\\$sDelimiter", $sSearch) . $sDelimiter . $sModifier;
                }
            }
        }
        // 配列か？
        if ( $bIsScalar === true ) {
            $mValue                   = $aSearches[0];
        } else {
            $mValue                   = $aSearches;
        }
        return $mValue;
    }

    /**
     * ホスト名がローカルであるか否か
     *
     * @param   string  $sHost
     * @return  bool    ローカルか否か
     */
    public static function isHostLocal($sHost)
    {
        $oSelf = static::getInstance();
        return $oSelf->_isHostLocal($sHost);
    }

    /**
     * ホスト名がローカルであるか否か
     *
     * @param   string  $sHost
     * @return  bool    ローカルか否か
     * @throw   SC\exception\common\parameter\NotAString
     */
    protected function _isHostLocal($sHost)
    {
        // 入力チェック
        $bRetCode  = Validate::isString($sHost);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Host must be string.');
        }
        $sHost     = trim($sHost);
        if ( $sHost === '' ) {
            return false;
        }
        // IPアドレスか否か
        $bIsIPAddr = (bool) preg_match('#^((?:[1-9]|1[0-9]|2[0-4])?[0-9]|25[0-5])\.((?:[1-9]|1[0-9]|2[0-4])?[0-9]|25[0-5])\.((?:[1-9]|1[0-9]|2[0-4])?[0-9]|25[0-5])\.((?:[1-9]|1[0-9]|2[0-4])?[0-9]|25[0-5])$#uS', $sHost, $aMatches);
        if ( $bIsIPAddr === true ) {
            // IPアドレスでローカル判定を行う対象： '0.x.x.x' , '127.x.x.x' , '169.254.x.x' , SERVER_ADDR
            $iIP1  = (int) $aMatches[1];
            if ( $iIP1 === 127 || $iIP1 === 0 ) {
                return true;
            }
            $iIP2  = (int) $aMatches[2];
            if ( $iIP1 === 169 && $iIP2 === 254 ) {
                return true;
            }
            $sAddr = $this->oRequest->getServer('SERVER_ADDR', '');
            if ( $sAddr !== '' && $sAddr === $aMatches[0] ) {
                return true;
            }
            return false;
        }
        // ドメインは大文字小文字無視
        $sHost     = strtolower($sHost);
        // IPアドレスではなくローカル判定を行う対象： 'localhost', 'localhost.localdomain', HTTP_HOST , SERVER_NAME
        if ( $sHost === 'localhost' || $sHost === 'localhost.localdomain' ) {
            return true;
        }
        $sHTTPHost = $this->oRequest->getServer('HTTP_HOST', '');
        if ( $sHTTPHost !== '' && $sHTTPHost === $sHost ) {
            return true;
        }
        $sName     = $this->oRequest->getServer('SERVER_NAME', '');
        if ( $sName !== '' && $sName === $sHost ) {
            return true;
        }
        return false;
    }

    /**
     * 両端のHTMLタグを除去
     *
     * @param   string  $sHTML
     * @return  string  HTML文字列
     */
    public static function stripTagBothEnds($sHTML)
    {
        // 置換
        $mValue = preg_replace('#^<[^>]+>|</[^>]+>$#S', '', $sHTML);
        if ( $mValue === NULL ) {
            // 置換失敗 → そのまま返す
            return $sHTML;
        }
        return $mValue;
    }

    /**
     * ファイルの圧縮
     *
     * @param   string  $sFile      圧縮対象のファイル名
     * @param   int     $iLevel     圧縮レベル(0～9)
     * @param   string  $sExtent    拡張子
     * @return  bool    true/false  圧縮できたか否か
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\common\filesystem\NotReadable
     * @throw   SC\exception\common\filesystem\NotWritable
     */
    public static function gzip($sFilename, $iLevel = 9, $sExtent = '.gz')
    {
        // 入力チェック
        $bRetCode       = Validate::isStringNotZero($sFilename);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Filename must be non-zero byte string.');
        }
        $sFilename      = trim($sFilename);
        $iCmp           = strncmp('/', $sFilename, 1);
        if ( $iCmp !== 0 ) {
            $sFilename  = static::normalizePath($sFilename);
        }
        $iLevel         = (int) $iLevel;
        if ( $iLevel < 0 || 9 < $iLevel ) {
            $iLevel     = 9;
        }
        $bRetCode       = Validate::isStringNotZero($sExtent);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('File extent must be non-zero byte string.');
        }
        // 読み書きチェック
        clearstatcache(true, $sFilename);
        $bRetCode       = is_readable($sFilename);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\filesystem\NotReadable("File must be readable. (filename: '$sFilename')");
        }
        $sArchive       = $sFilename . $sExtent;
        $sDirname       = dirname($sArchive);
        clearstatcache(true, $sDirname);
        $bRetCode       = is_writable($sDirname);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\filesystem\NorWritable("Archive must be writable . (dir: '$sDirname')");
        }
        // 圧縮時にはメモリ使用量制限を外す
        set_time_limit(0);
        ini_set('memory_limit', '-1');
        $sMode          = 'wxb' . $iLevel;
        $rGZFile        = gzopen($sArchive, $sMode);
        if ( $rGZFile === false ) {
            \Log::warning("gzopen failure '{$sArchive}'. (mode: $sMode)");
            return false;
        }
        $rFile          = fopen($sFilename, 'rb');
        if ( $rFile === false ) {
            \Log::warning("fopen failure '{$sFilename}' (mode: rb)");
            $bClose     = gzclose($rGZFile);
            return false;
        }
        // 終端に達するまで読み込み
        $iChunkSize     = 1024*512;
        $iFilesize      = filesize($sFilename);
        $iTotal         = 0;
        for ( $bEOF = feof($rFile) ; $bEOF !== true ; $bEOF = feof($rFile) ) {
            $sInput     = fread($rFile, $iChunkSize);
            $iSize      = strlen($sInput);
            $iBytes     = gzwrite($rGZFile, $sInput);
            if ( $iBytes < 1 || $iBytes !== $iSize ) {
                \Log::warning("gzwrite failure '{$sArchive}'. (size:$iSize !== bytes:$iBytes)");
                $bClose = gzclose($rGZFile);
                $bClose = fclose($rFile);
                return false;
            }
            $iTotal    += $iBytes;
        }
        $bClose         = gzclose($rGZFile);
        $bClose         = fclose($rFile);
        // アーカイブできたら削除
        $iFilesize      = filesize($sArchive);
        \Log::info("Archive file '{$sArchive}' (bytes: {$iTotal} --> {$iFilesize})");
        unlink($sFilename);
    }

    /**
     * CSVを作成する
     *
     * @param   array   $aData
     * @param   string  $sDelimiter
     * @param   string  $sEnclosure
     * @param   string  $sEscape
     * @return  string  CSV文字列
     */
    public static function build_csv(array $aData, $sDelimiter = ',', $sEnclosure = '"', $sEscape = "\\")
    {
        $sDelimiter             = (string) substr((string) $sDelimiter, 0, 1);
        $sEnclosure             = (string) substr((string) $sEnclosure, 0, 1);
        $sEscape                = (string) substr((string) $sEscape,    0, 1);
        $aReplacePair           = array(
            $sEscape    => $sEscape . $sEscape,
            $sEnclosure => $sEscape . $sEnclosure,
            "\x00"      => "\\0",
            "\x01"      => "\\x01",
            "\x02"      => "\\x02",
            "\x03"      => "\\x03",
            "\x04"      => "\\x04",
            "\x05"      => "\\x05",
            "\x06"      => "\\x06",
            "\x07"      => "\\a",
            "\x08"      => "\\b",
            "\x09"      => "\\t",
            "\x0a"      => "\\n",
            "\x0b"      => "\\v",
            "\x0c"      => "\\f",
            "\x0d"      => "\\r",
            "\x0e"      => "\\x0e",
            "\x0f"      => "\\x0f",
            "\x10"      => "\\x10",
            "\x11"      => "\\x11",
            "\x12"      => "\\x12",
            "\x13"      => "\\x13",
            "\x14"      => "\\x14",
            "\x15"      => "\\x15",
            "\x16"      => "\\x16",
            "\x17"      => "\\x17",
            "\x18"      => "\\x18",
            "\x19"      => "\\x19",
            "\x1a"      => "\\x1a",
            "\x1b"      => "\\e",
            "\x1c"      => "\\x1c",
            "\x1d"      => "\\x1d",
            "\x1e"      => "\\x1e",
            "\x1f"      => "\\x1f",
            "\x7f"      => "\\x7f",
        );
        foreach ( $aData as $sKey => $mValue ) {
            $mValue             = (string) $mValue;
            if ( $mValue === '' ) {
                $sValue         = $sEnclosure . $sEnclosure;
            } else {
                $sValue         = strtr($mValue, $aReplacePair);
                if ( $sValue !== $mValue ) {
                    $sValue     = $sEnclosure . $sValue . $sEnclosure;
                } else {
                    $iPos       = strpos($sValue, $sDelimiter);
                    if ( $iPos !== false ) {
                        $sValue = $sEnclosure . $sValue . $sEnclosure;
                    }
                }
            }
            $aData[$sKey]       = $sValue;
        }
        return join($sDelimiter, $aData);
    }

    /**
     * 配列の値を再帰的に除去
     *
     *  配列でなかった場合にはそのまま返す
     *
     * @param   mixed   $mInput         変換前の値
     * @param   mixed   $mNULLValue     NULL値の代わりに使う値
     * @return  mixed   変換後の値
     */
    public static function stripValue($mInput, $mNULLValue = NULL)
    {
        $bRetCode    = is_array($mInput);
        if ( $bRetCode !== true ) {
            return $mInput;
        }
        foreach ( $mInput as $sKey => $mValue ) {
            $bRetCode = is_scalar($mValue);
            if ( $bRetCode === true ) {
                $mInput[$sKey] = $mNULLValue;
            } else {
                $mInput[$sKey] = static::stripValue($mValue, $mNULLValue);
            }
        }
        return $mInput;
    }

    /**
     * クエリ形式の文字列から値を除去して返す
     *
     * @param   mixed   $mInput     入力文字列か入力文字列の配列
     * @param   string  $sSep       セパレータ
     * @return  mixed   $mOutput
     */
    public static function stripValueString($mInput, $sSep = '&')
    {
        $bRetCode          = is_array($mInput);
        if ( $bRetCode !== true ) {
            // 文字列として扱う
            $sInput        = (string) $mInput;
            $sSepQ         = strtr($sSep, array('[' => '\\[', ']' => '\\]', '\\' => '\\\\'));
            $sPattern      = static::validatePCRE("=(?:[^$sSepQ]*?|\"[^\"]*?\")(?=$sSep|\$)", false, '#', 'Sm');
            $sOutput       = preg_replace($sPattern, '=', $sInput);
            return $sOutput;
        }
        // 配列の場合には再帰
        foreach ( $mInput as $sKey => $mValue ) {
            $mInput[$sKey] = static::stripValueString($mValue, $sSep);
        }
        return $mInput;
    }

    /**
     * 時刻を取得
     *
     * @return  string  時刻
     */
    public static function strftime($sFormat = '%Y/%m/%d %H:%M:%S.%N %Z', $fNow = 0.0)
    {
        if ( $fNow <= 0.0 ) {
            $fNow  = microtime(true);
        }
        $sNowUnder = sprintf('%06.0f', ( $fNow - floor($fNow) ) * 1000000);
        $sTimeZone = date('T', $fNow);
        $sFormat   = str_replace('%N', $sNowUnder, $sFormat);
        $sFormat   = str_replace('%Z', $sTimeZone, $sFormat);
        $sTime     = strftime($sFormat, (int) floor($fNow));
        return $sTime;
    }

    /**
     * 時刻を取得
     *
     * @return  string  時刻
     */
    public static function date($sFormat = 'Y/m/d H:i:s.u O', $fNow = 0.0)
    {
        if ( $fNow <= 0.0 ) {
            $fNow  = microtime(true);
        }
        $sNowUnder = sprintf('%06.0f', ( $fNow - floor($fNow) ) * 1000000);
        $sFormat   = str_replace('u', $sNowUnder, $sFormat);
        $sTime     = date($sFormat, (int) floor($fNow));
        return $sTime;
    }
}
