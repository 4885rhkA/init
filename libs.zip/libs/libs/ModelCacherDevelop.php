<?php
/**
 * ModelCacherDevelop
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ModelCacherDevelop
 */
class ModelCacherDevelop extends ModelCacher
{
    /**
     * 設定ファイルのキャッシュファイル
     *
     * @var string CONFIG_CACHE_NAME
     */
    const CONFIG_CACHE_NAME = 'models-cache-develop.php';

    /**
     * 設定ファイルのキャッシュロック
     *
     * @var string CONFIG_CACHE_LOCK
     */
    const CONFIG_CACHE_LOCK = 'models-cache-develop.lock';
}
