<?php
/**
 * AbstractDBTest
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

class SQLiteTest extends \PHPUnit_Framework_TestCase
{
    private $target = null;

    public function setUp()
    {
        $this->markTestSkipped();
    }

    public function testInsert()
    {
        $aInfoList = array(
//             array(
//                 'input'  => array(
//                     'table'   => 'table1',
//                     'fields'  => array(
//                         array( 'name' => 'col11', 'value' => 'text1',               'type' => 'varchar',   'expr' => false ),
//                         array( 'name' => 'col12', 'value' => 111111,                'type' => 'int',       'expr' => false ),
//                         array( 'name' => 'col13', 'value' => 111.11,                'type' => 'number',    'expr' => false ),
//                         array( 'name' => 'col14', 'value' => '2012-01-11 11:11:11', 'type' => 'timestamp', 'expr' => false ),
//                         array( 'name' => 'col15', 'value' => NULL,                  'type' => 'string',    'expr' => false ),
//                     ),
//                     'binds'   => array(),
//                     'seqname' => '',
//                 ),
//                 'expect' => "INSERT INTO table1 (col11,col12,col13,col14,col15) VALUES (:col11,:col12,:col13,:col14,:col15)",
//             ),
            array(
                'input'  => "INSERT INTO table1 (col11,col12,col13,col14,col15) VALUES (:col11,:col12,:col13,:col14,:col15)",
                'expect' => "INSERT INTO table1 (col11,col12,col13,col14,col15) VALUES (:col11,:col12,:col13,:col14,:col15)",
            ),
        );
        foreach ( $aInfoList as $aInfo ) {
            $mInput  = $aInfo['input'];
            $sExpect = $aInfo['expect'];
            $sResult = $this->target->insert($mInput);
            $this->assertEquals(array('input' => $mInput, 'sql' => $sExpect), array('input' => $mInput, 'sql' => $sResult));
        }
    }

    public function testBuildInsertSql()
    {
        $aInfoList = array(
            array(
                'input' => array(
                    'table'   => 'table1',
                    'fields'  => array(
                        array( 'name' => 'col11', 'value' => 'text1',               'type' => 'varchar',   'expr' => false ),
                        array( 'name' => 'col12', 'value' => 111111,                'type' => 'int',       'expr' => false ),
                        array( 'name' => 'col13', 'value' => 111.11,                'type' => 'number',    'expr' => false ),
                        array( 'name' => 'col14', 'value' => '2012-01-11 11:11:11', 'type' => 'timestamp', 'expr' => false ),
                        array( 'name' => 'col15', 'value' => NULL,                  'type' => 'string',    'expr' => false ),
                        array( 'name' => 'col21', 'value' => 'text2',               'type' => 'varchar',   'expr' => true  ),
                        array( 'name' => 'col22', 'value' => 222222,                'type' => 'int',       'expr' => true  ),
                        array( 'name' => 'col23', 'value' => 222.22,                'type' => 'number',    'expr' => true  ),
                        array( 'name' => 'col24', 'value' => '2012-02-22 22:22:22', 'type' => 'timestamp', 'expr' => true  ),
                        array( 'name' => 'col25', 'value' => NULL,                  'type' => 'string',    'expr' => true  ),
                    ),
                    'binds'   => array(),
                    'seqname' => '',
                ),
                'expect' => "INSERT INTO table1 (col11,col12,col13,col14,col15,col21,col22,col23,col24,col25) VALUES (:col11,:col12,:col13,:col14,:col15,'text2','222222','222.22','2012-02-22 22:22:22',NULL)",
            ),
        );
        foreach ( $aInfoList as $aInfo ) {
            $mInput  = $aInfo['input'];
            $sExpect = $aInfo['expect'];
            $sResult = SQLite::buildInsertSql($mInput);
            $this->assertEquals(array('input' => $mInput, 'sql' => $sExpect), array('input' => $mInput, 'sql' => $sResult));
        }
    }
}

