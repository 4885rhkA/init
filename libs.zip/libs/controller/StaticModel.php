<?php
/**
 * 静的ページモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * 静的ページモデルコントローラ
 */
class StaticModel extends AbstractTemplateModel
{
    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // テンプレートエンジン
        $sEngine                       = strtolower(trim(\ArrayUtil::getValue($this->aSelector, 'engine', 'smarty')));
        // ソースから変数値を取得する
        $aSources                      = (array) \ArrayUtil::getValue($this->aSelector, 'sources', array());
        $aTplValues                    = $this->_getValuesFromSources($aSources, $sEngine);
        foreach ( $aTplValues as $sKey => $mValue ) {
            $this->aTplValues[$sKey]   = $mValue;
        }
        return parent::_process();
    }

    /**
     * ソースからテンプレート用の変数値を取得する
     *
     * @param   array   $aSources   ソース情報リスト
     * @param   string  $sEngine    出力エンジン
     * @return  array   抽出変数リスト
     */
    protected function _getValuesFromSources(array $aSources, $sEngine)
    {
        // 抽出変数リスト
        $aValues                       = array();
        // ソースの数だけ取得
        foreach ( $aSources as $sName => $aSource ) {
            // 変数マージ
            $aSource               = $this->_mergeIncludes($aSource);
            // 取得パラメータがない場合には次のソースへ
            $aSource['parameters'] = (array) \ArrayUtil::getValue($aSource, 'parameters', array());
            if ( $aSource['parameters'] === array() ) {
                continue;
            }
            // ページのチェック
            $sSource               = trim(\ArrayUtil::getValue($aSource, 'source', $sName));
            if ( $sSource === '' ) {
                // 変数を取得しない
                $aRetVals          = array();
            } else {
                // 変数を取得
                $aSource['source'] = $sSource;
                $aRetVals          = $this->_getValuesFromSource($aSource, $sEngine);
            }
            // 変数をマージ
            $aValues               = \ArrayUtil::unite($aValues, $aRetVals, true);
            // チェーン
            $this->_chain($aSource, $aValues);
        }
        return $aValues;
    }

    /**
     * ソースから変数を抽出する
     *
     * @param   array   $aSource    ソース情報
     * @param   string  $sEngine    出力エンジン
     * @return  mixed   抽出した変数
     */
    protected function _getValuesFromSource(array $aSource, $sEngine)
    {
        // ソースからHTMLを取得
        $sSource                     = (string) \ArrayUtil::getValue($aSource,         'source',   '');
        $aStored                     = (array)  \ArrayUtil::getValue($this->aStored,   $sSource,   array());
        $sSourceBody                 = (string) \ArrayUtil::getValue($aStored,         'adjusted', '');
        // エクストラクタ
        $sExtractor                  = trim(\ArrayUtil::getValue($aSource, 'extractor', 'XPath'));
        $aOptions                    = array(
            'format' => strtoupper(trim(\ArrayUtil::getValue($aSource, 'format', 'HTML'))),
        );
        $bRetCode                    = isset($this->aValidExtractor[$sExtractor]);
        if ( $bRetCode === true ) {
            // 抽出する
            $aValue                  = call_user_func(array("SC\\libs\\{$sExtractor}Extractor", 'extract'), $aSource['parameters'], $sSourceBody, $aOptions);
            \LogRegistry::save('sc:request', 'EXTRACTOR', $sExtractor);
        } else {
            // 抽出しない
            $aValue                  = array();
        }
        return $aValue;
    }

    /**
     * チェーンのターゲット情報の収集
     *
     * @return  array   チェーンのターゲット情報
     */
    protected function _getChainTarget()
    {
        $aTargets             = array(
            'header'    => array(),
            'body'      => '',
            'status'    => \SC\libs\HttpStatus::NEVER_DONE,
        );
        return $aTargets;
    }
}
