<?php
/**
 * イテレータが正しくない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\ArrayObject;

/**
 * イテレータが正しくない場合の例外
 */
class InvalidIterator extends \SC\exception\libs\ArrayObject
{
}
