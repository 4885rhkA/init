<?php
/**
 * 抽象JSONモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * 抽象JSONモデルコントローラ
 */
abstract class AbstractJSONModel extends AbstractModel
{
    /**
     * 生データのJSONを使用するか否か
     *
     * @var bool RAW_DATA_JSON
     */
    const RAW_DATA_JSON = false;

    /**
     * データ変数配列
     *
     * @var array $aValues
     */
    protected $aValues = array();

    /**
     * JSONファイル名
     *
     * @var string $sJSONFile
     */
    protected $sJSONFile = '';

    /**
     * HTTPステータスコード
     *
     * @var int $iHTTPStatus
     */
    protected $iHTTPStatus = \SC\libs\HttpStatus::INTERNAL_SERVER_ERROR;

    /**
     * エラーの有無
     *
     * @var bool $bHasError
     */
    protected $bHasError = false;

    /**
     * エラーメッセージ
     *
     * @var string $sErrMessage
     */
    protected $sErrMessage = '';

    /**
     * エラーコード
     *
     * @var int $iErrCode
     */
    protected $iErrCode = -1;

    /**
     * ログインエラー時にログイン画面を表示する
     *
     * @var bool SHOW_LOGIN
     */
    const SHOW_LOGIN = false;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ステータス指定
        $iHTTPStatus     = (int) \ArrayUtil::getValue($this->aSelector, 'status', $this->iHTTPStatus);
        if ( $iHTTPStatus < 100 || 999 < $iHTTPStatus ) {
            // 異常値ならば500にする
            $iHTTPStatus = \SC\libs\HttpStatus::INTERNAL_SERVER_ERROR;
        }
        $sHTTPStatus     = \SC\libs\HttpStatus::getMessage($iHTTPStatus);
        // Content-Typeがpass指定ならセットする
        $sContentType    = trim(\ArrayUtil::getValue($this->aSelector, 'mime', ''));
        if ( $sContentType !== '' && $sContentType !== 'pass' ) {
            $this->oResponse->setMimeType($sContentType);
        } else {
            if ( $this->sJSONFile !== '' ) {
                $sFile = $this->sJSONFile;
            } else {
                $sFile = AP_DIR . '/tmp/.__dummy__.json';
            }
            $sMimeType = \SC\libs\File::getMimeTypeByName($sFile);
            $this->oResponse->setMimeType($sMimeType);
        }
        $sCharset      = trim(\ArrayUtil::getValue($this->aSelector, 'charset', ''));
        if ( $sCharset !== '' && $sCharset !== 'pass' ) {
            $this->oResponse->setOutputEncoding($sCharset);
        }
        $sOutput       = $this->_makeResultJSON(static::RAW_DATA_JSON);
        $this->oResponse->setResult($sOutput, $iHTTPStatus);
        \Log::info("Output normally (Status: $iHTTPStatus $sHTTPStatus)");
        return true;
    }

    /**
     * エラーで終了するJSON情報を生成する
     *
     * @param   string  $sMessage   エラーメッセージ
     * @param   array   $aValues    エラー用の追加情報
     * @return  bool    true
     */
    final protected function _raiseErrorJSON($sMessage, array $aOptions = array(), \Exception $oException = NULL)
    {
        // エラー出力を固定
        $this->bHasError   = true;
        $this->sErrMessage = (string) $sMessage;
        $this->iErrCode    = (int)    \ArrayUtil::getValue($aOptions, 'errcode', $this->iErrCode);
        $this->aValues     = (array)  \ArrayUtil::getValue($aOptions, 'data',   array());
        $iStatus           = (int)    \ArrayUtil::getValue($aOptions, 'status', 200);
        $sOutput           = $this->_makeResultJSON();
        $this->oResponse->setResult($sOutput, $iStatus);
        if ( $oException !== NULL ) {
            throw $oException;
        }
        return true;
    }

    /**
     * JSON情報を生成する
     *
     * @return  string
     */
    final protected function _makeResultJSONRaw()
    {
        try {
            \SC\libs\ErrorHandler::setThrowNextExceptionOn();
            $sOutput = \SC\libs\JSON::encode($this->aValues);
            \SC\libs\ErrorHandler::setThrowNextExceptionOff();
        } catch (\SC\exception\php\error\Warning $oException) {
            // JSON化できなかった
            $aValues = $this->_base64encode($this->aValues);
            $sOutput = \SC\libs\JSON::encode($aValues);
        }
        return $sOutput;
    }

    /**
     * JSON情報を生成する
     *
     * @return  string
     */
    final protected function _makeResultJSON($bUseRaw = self::RAW_DATA_JSON)
    {
        if ( $bUseRaw === true ) {
            return $this->_makeResultJSONRaw();
        }
        // 出力JSONデータフォーマット
        //  {
        //      result: true,
        //      error: {
        //          message: '',
        //          code: -1,
        //      },
        //      data: {},
        //      accesskey: 'アクセスのたびに発行されるユニークID',
        //      accesstime: 'アクセス時刻',
        //      onetimeticket: 'ワンタイムチケットとして発行されるユニークID'
        //  }

        // 出力配列
        if ( $this->bHasError === true ) {
            // エラーがあればエラーを保持する
            $aResult['result'] = false;
            $aResult['error']  = array(
                'message' => $this->sErrMessage,
                'code'    => $this->iErrCode,
            );
        } else {
            $aResult['result'] = true;
            $aResult['error']  = array(
                'message' => '',
                'code'    => -1,
            );
        }
        // 情報をセット
        $aResult['accesskey' ] = \Log::getAccessKey();
        $aResult['accesstime'] = \Log::getAccessTime();
        // ワンタイムチケットが発行済みならセットする
        // $sOneTimeTicket        = \MCP\base\OneTimeTicket::get();
        // if ( $sOneTimeTicket !== '' ) {
        //     $sKey              = \MCP\base\OneTimeTicket::REQUEST_KEY_TICKET;
        //     $aResult[$sKey]    = $sOneTimeTicket;
        // }
        $aResult['data']       = $this->aValues;
        try {
            \SC\libs\ErrorHandler::setThrowNextExceptionOn();
            $sOutput           = \SC\libs\JSON::encode($aResult);
            \SC\libs\ErrorHandler::setThrowNextExceptionOff();
        } catch (\SC\exception\php\error\Warning $oException) {
            // JSON化できなかった
            $aResult['data']   = $this->_base64encode($this->aValues);
            $aResult['base64'] = true;
            $sOutput           = \SC\libs\JSON::encode($aResult);
        }
        return $sOutput;
    }

    /**
     * 再帰的にBASE64でエンコード
     *
     * @param   array   $aData  エンコードしたい対象配列
     * @return  array
     */
    protected function _base64encode(array $aData) {
        foreach ( $aData as $sKey => $mValue ) {
            $bRetCode         = is_string($mValue);
            if ( $bRetCode === true ) {
                $aData[$sKey] = base64_encode($mValue);
                continue;
            }
            $bRetCode         = is_array($mValue);
            if ( $bRetCode === true ) {
                $aData[$sKey] = $this->_base64encode($mValue);
                continue;
            }
            $aData[$sKey]     = $mValue;
        }
        return $aData;
    }

    /**
     * ログインチェック
     *
     * @return  bool    true
     * @throw   SC\exception\controller\AbstractModel\LoginErrorChain
     */
    protected function _checkLogin()
    {
        // ログインチェック
        try {
            parent::_checkLogin();
        } catch (\SC\exception\model\Login\NotLogin $oException) {
            // 認証エラー
            $this->_raiseErrorJSON('Login required.', array(), $oException);
        }
        return true;
    }
}
