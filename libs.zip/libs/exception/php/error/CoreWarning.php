<?php
/**
 * コア警告例外 (E_CORE_WARNING)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * コア警告例外 (E_CORE_WARNING)
 */
class CoreWarning extends \SC\exception\php\error
{
}
