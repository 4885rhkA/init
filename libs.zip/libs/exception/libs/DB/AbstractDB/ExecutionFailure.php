<?php
/**
 * SQL実行ができなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\DB\AbstractDB;

/**
 * SQL実行ができなかった場合の例外
 */
class ExecutionFailure extends \SC\exception\libs\DB\AbstractDB
{
}
