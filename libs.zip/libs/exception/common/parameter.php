<?php
/**
 * パラメータの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common;

/**
 * パラメータの例外
 */
class parameter extends \SC\exception\common
{
}
