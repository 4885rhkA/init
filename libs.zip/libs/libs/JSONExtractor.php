<?php
/**
 * JSON用の抽出装置
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * JSON用の抽出装置
 */
class JSONExtractor extends AbstractExtractor
{
    /**
     * JSONから変数を抽出する
     *
     * @param   array   $aParams        パラメータ指定
     * @param   string  $sInput         JSON
     * @return  array   ソース
     */
    protected function _extract(array $aParams, $sInput, array $aOptions = array())
    {
        // @todo 未実装
        return array($sInput);
    }
}
