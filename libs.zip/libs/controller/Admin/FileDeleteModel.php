<?php
/**
 * ファイル削除モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイル削除モデルコントローラ
 */
class FileDeleteModel extends AbstractJSONModel
{
    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage    = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();

        // PATH_INFOからステージ種別を取得
        $sPathInfo       = $this->oRequest->getPathInfo();
        $sStage          = $this->oStage->getStageName($sPathInfo);

        // リクエストパラメータから削除ファイル名を取得
        $sPath           = $this->oRequest->getRequest('path');
        // Gitパラメータ
        $sAuthor         = $this->oLogin->getAuthor();
        $sMessage        = 'delete file/directory via control panel.';  // コミットメッセージは固定

        try {
            $this->oStage->deleteFile($sStage, $sPath, $sAuthor, $sMessage);
            $this->aValues   = array(
                // no value
            );
        } catch (\Exception $oException) {
            $this->bHasError   = true;
            $this->sErrMessage = $oException->getMessage();
        }

        return parent::_process();
    }
}
