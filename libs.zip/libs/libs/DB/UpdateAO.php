<?php
/**
 * UpdateAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * UpdateAO
 */
class UpdateAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'table'      => 'string',                       // 更新対象
        'fields'     => 'SC\\libs\\DB\\FieldListAO',    // フィールドリスト
        'conditions' => 'SC\\libs\\DB\\UpdateCondAO',   // 条件句
        'binds'      => 'SC\\libs\\DB\\BindListAO',     // BINDパラメータ
    );
}
