<?php
/**
 * プロパティ名の指定がない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\ArrayObject;

/**
 * プロパティ名の指定がない場合の例外
 */
class EmptyPropertyName extends \SC\exception\libs\ArrayObject
{
}
