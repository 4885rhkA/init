<?php
/**
 * 抽象ロガー
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * 抽象ロガー
 */
abstract class AbstractLog
{
    /**
     * エラーログ出力レベル
     *
     * 0000 0000 0000 0000 0000 0000 0001
     *
     * @var int LEVEL_ERROR
     */
    const LEVEL_ERROR = E_ERROR;

    /**
     * 警告ログ出力レベル
     *
     * 0000 0000 0000 0000 0000 0000 0010
     *
     * @var int LEVEL_WARNING
     */
    const LEVEL_WARNING = E_WARNING;

    /**
     * 注意ログ出力レベル
     *
     * 0000 0000 0000 0000 0000 0000 1000
     *
     * @var int LEVEL_NOTICE
     */
    const LEVEL_NOTICE = E_NOTICE;

    /**
     * 情報ログ出力レベル
     *
     * 0000 0001 0000 0000 0000 0000 0000
     *
     * @var int LEVEL_INFO
     */
    const LEVEL_INFO = 1048576;

    /**
     * デバッグログ出力レベル
     *
     * 0000 0010 0000 0000 0000 0000 0000
     *
     * @var int LEVEL_DEBUG
     */
    const LEVEL_DEBUG = 2097152;

    /**
     * トレースログ出力レベル
     *
     * 0000 0100 0000 0000 0000 0000 0000
     *
     * @var int LEVEL_TRACE
     */
    const LEVEL_TRACE = 4194304;

    /**
     * デバッグログ出力レベル
     *
     * 1111 1111 1111 1111 1111 1111
     *
     * @var int LEVEL_MAX
     */
    const LEVEL_MAX = 16777215;

    /**
     * ログ出力レベル
     *
     * 0000 0001 0000 0000 0000 0000 1011
     *
     * @var int $iLogLevel
     */
    protected $iLogLevel = 1048587;

    /**
     * ログ出力レベル
     *
     * @var int $iDisplayLevel
     */
    protected $iDisplayLevel = 0;

    /**
     * レベル文字列
     *
     * @var array $aPriorities
     */
    protected $aPriorities = array(
        self::LEVEL_ERROR   => 'error',
        self::LEVEL_WARNING => 'warn',
        self::LEVEL_NOTICE  => 'notice',
        self::LEVEL_INFO    => 'info',
        self::LEVEL_DEBUG   => 'debug',
        self::LEVEL_TRACE   => 'trace',
    );

    /**
     * レベル色づけ
     *
     * @var bool $bUseLevelColor
     */
    protected $bUseLevelColor = false;

    /**
     * 色づけ指定
     *
     * セミコロン区切りで複数指定可能
     *
     * Attribute codes:        00=none 01=bold 04=underscore 05=blink 07=reverse 08=concealed
     * Text color codes:       30=black 31=red 32=green 33=yellow 34=blue 35=magenta 36=cyan 37=white   39=none
     * Background color codes: 40=black 41=red 42=green 43=yellow 44=blue 45=magenta 46=cyan 47=white   49=none
     *
     * @var array $aLevelColor
     */
    protected $aLevelColor = array(
        self::LEVEL_ERROR   => '5;31',
        self::LEVEL_WARNING => '35',
        self::LEVEL_NOTICE  => '34',
        self::LEVEL_INFO    => '0',
        self::LEVEL_DEBUG   => '36',
        self::LEVEL_TRACE   => '33',
    );

    /**
     * ユニークIDの基数
     *
     * @var string UNIQID_BASE
     */
    const UNIQID_BASE = 36;

    /**
     * ユニークID
     *
     * @var string $sUniqId
     */
    private static $sUniqId = '';

    /**
     * アクセス識別子
     *
     * @var string $sAccessId
     */
    private static $sAccessId = '';

    /**
     * アクセス秒
     *
     * @var float $fAccessSec
     */
    private static $fAccessSec = 0.0;

    /**
     * アクセス時刻
     *
     * @var string $sAccessTime
     */
    private static $sAccessTime = '';

    /**
     * 初期化処理を行っているか否か
     *
     * @var bool $bInitialized
     */
    private static $bInitialized = false;

    /**
     * ログ出力にPHPデフォルトを使用するか否か
     *
     * @var bool $bUseDefault
     */
    protected $bUseDefault = false;

    /**
     * ログディレクトリの根元
     *
     * @var string LOG_ROOT
     */
    const LOG_ROOT = AP_DIR;

    /**
     * ログディレクトリ
     *
     * @var string LOG_BASE
     */
    const LOG_BASE = 'log';

    /**
     * ログディレクトリ
     *
     * @var string LOG_EXT
     */
    const LOG_EXT = 'log';

    /**
     * 自前のログディレクトリの根元
     *
     * @var string $sLogRoot
     */
    protected $sLogRoot = self::LOG_ROOT;

    /**
     * 自前のログ出力先
     *
     * @var string $sLogFile
     */
    protected $sLogFile = '%Y/%m/app-%Y%m%d.log';

    /**
     * 自前のログ出力先(古パス)
     *
     * @var string $sLogFilePath
     */
    protected $sLogFilePath = '';

    /**
     * 時刻フォーマット
     *
     * @var string TIME_FORMAT
     */
    const TIME_FORMAT = '%Y/%m/%d %H:%M:%S.%N %Z';

    /**
     * 時刻フォーマット
     *
     * @var string $sTimeFormat
     */
    protected $sTimeFormat = self::TIME_FORMAT;

    /**
     * アーカイブするか否か
     *
     * @var bool $bArchive
     */
    protected $bArchive = false;

    /**
     * ログレジストリのインスタンス
     *
     * @var SC\libs\LogRegistry $oRegistry
     */
    protected $oRegistry = NULL;

    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
        $this->_preInitialize();
        $this->_initialize();
    }

    /**
     * デストラクタ
     */
    final public function __destruct()
    {
        $this->_finalize();
    }

    /**
     * 初期化前処理
     *
     * @return bool true
     */
    final private function _preInitialize()
    {
        // 初期化前処理を行っているか？
        if ( self::$bInitialized === true ) {
            // 行っていたら抜ける
            return true;
        }
        self::$bInitialized = true;
        // ログの初期設定
        self::$fAccessSec   = microtime(true);
        self::$sAccessTime  = Util::strftime(self::TIME_FORMAT, self::$fAccessSec);
        $aUniqIdParts       = explode('.', uniqid('', true), 2);
        self::$sUniqId      = base_convert($aUniqIdParts[1] . '.' . $aUniqIdParts[0], 16, self::UNIQID_BASE);
        self::$sAccessId    = MakeId::getShortUniq();
        // レジストリに登録
        LogRegistry::save('sc:request', 'ACCESSKEY',   $this->getAccessKey());
        LogRegistry::save('sc:request', 'ACCESSID',    $this->getAccessId());
        LogRegistry::save('sc:request', 'UNIQUEID',    $this->getUniqId());
        LogRegistry::save('sc:request', 'ACCESSSEC',   $this->getAccessSec());
        LogRegistry::save('sc:request', 'ACCESSSTIME', $this->getAccessTime());
        return true;
    }

    /**
     * 初期化処理
     *
     * @return bool true
     */
    protected function _initialize()
    {
        return true;
    }

    /**
     * 終了処理
     *
     * @return bool true
     */
    protected function _finalize()
    {
        return true;
    }

    /**
     * ユニークIDを取得
     *
     * @return  string  ユニークID
     */
    final public static function getUniqId()
    {
        return self::$sUniqId;
    }

    /**
     * アクセス識別子を取得
     *
     * @return  string  アクセス識別子
     */
    final public static function getAccessId()
    {
        return self::$sAccessId;
    }

    /**
     * 公開識別子を取得
     *
     * @return  string  公開識別子
     */
    final public static function getAccessKey()
    {
        $sAccessKey = self::$sUniqId . '-' . self::$sAccessId;
        return $sAccessKey;
    }

    /**
     * アクセス秒を取得
     *
     * @return  float   アクセス秒
     */
    final public static function getAccessSec()
    {
        return self::$fAccessSec;
    }

    /**
     * アクセス時刻を取得
     *
     * @return  string  アクセス時刻文字列
     */
    final public static function getAccessTime()
    {
        return self::$sAccessTime;
    }

    /**
     * ログ出力
     *
     * @param   int     $iLevel
     * @param   string  $sMessage
     * @param   bool    $bAlways
     * @return  bool    true
     */
    protected function _log($iLevel, $sMessage, $bAlways = false)
    {
        if ( $bAlways !== true ) {
            // 常時でなければチェック
            if ( ( $this->iLogLevel & $iLevel ) !== $iLevel ) {
                // 出力レベルではないので終了
                return true;
            }
        }
        $sTime         = Util::strftime($this->sTimeFormat);
        $sAccessId     = self::$sAccessId;
        $sPriority     = $this->aPriorities[$iLevel];
        if ( $this->bUseLevelColor === true ) {
            $sPriority = "\x1b[{$this->aLevelColor[$iLevel]}m{$sPriority}\x1b[0m";
            // [  033 [  1  ;  3  2  m     a     033 [  0  ;  3  9  m  ]
            // 5b 1b  5b 31 3b 33 32 6d 20 61 20 1b  5b 30 3b 33 39 6d 5d
        }
        $sMessage      = trim($sMessage);
        $sLine         = "$sTime\t$sAccessId\t[$sPriority]\t$sMessage\n";
        if ( $this->bUseDefault === true ) {
            $bRetCode  = error_log($sLine, 0);
        } else {
            $bRetCode  = error_log($sLine, 3, $this->sLogFilePath);
        }
        // 画面表示レベルかどうかチェック
        if ( ( $this->iDisplayLevel & $iLevel ) === $iLevel ) {
            echo $sLine;
        }
        return $bRetCode;
    }

    /**
     * ログディレクトリの根元のパスを設定する
     *
     * @param   string  $sLogRoot   ログディレクトリの根元のパス
     * @return  true
     * @throws  SC\exception\libs\Log\NoRoot
     */
    protected function _setLogRoot($sLogRoot)
    {
        // パスチェック
        $bRetCode            = \SC\libs\Validate::isStringNotZero($sLogRoot);
        if ( $bRetCode !== true ) {
            // パスの指定がない → NG
            throw new \SC\exception\common\parameter\ZeroByteString('Log directory root path is needed.');
        }
        // ディレクトリがあるか？
        clearstatcache();
        $bRetCode            = file_exists($sLogRoot);
        if ( $bRetCode !== true ) {
            // ログディレクトリの根元のパスは必ず存在する必要がある
            throw new \SC\exception\libs\Log\NoRoot('Log directory root path does not exist.');
        }
        $this->sLogRoot      = realpath($sLogRoot);
        $this->_setLogFile($this->sLogFile);
        return true;
    }

    /**
     * ログファイルのパスを設定する
     *
     * @param   string  $sLogFile   ログファイルパス
     * @return  true
     * @throws  SC\exception\common\parameter\ZeroByteString
     * @throws  SC\exception\libs\Log\NotWritable
     * @throws  SC\exception\libs\Log\CantTouch
     */
    protected function _setLogFile($sLogFile)
    {
        // パスチェック
        $sLogFile            = Util::strftime($sLogFile, self::$fAccessSec);
        if ( $sLogFile === '' ) {
            // ファイルの指定がない → NG
            throw new \SC\exception\common\parameter\ZeroByteString('Log file name is needed.');
        }
        $sPath               = $this->sLogRoot . DIRECTORY_SEPARATOR . static::LOG_BASE . DIRECTORY_SEPARATOR . $sLogFile;
        // 親ディレクトリがあるか？
        $sParent             = dirname($sPath);
        clearstatcache();
        $bRetCode            = file_exists($sParent);
        if ( $bRetCode !== true ) {
            // 親ディレクトリがない → 作成する
            $bRetCode        = mkdir($sParent, 0777, true);
            if ( $bRetCode !== true ) {
                // 作成に失敗した
                clearstatcache();
                $bRetCode    = file_exists($sParent);
                if ( $bRetCode !== true ) {
                    // 失敗した上に実際に作成されていない → ログ出力できない
                    throw new \SC\exception\libs\Log\CantMkdir("Can't mkdir log dir for '$sPath'");
                }
            }
        }
        // ログファイルがあるか？
        clearstatcache();
        $bRetCode            = file_exists($sPath);
        if ( $bRetCode === true ) {
            // ファイルがある → 書き込み可能か？
            $bRetCode        = is_writable($sPath);
            if ( $bRetCode !== true ) {
                // ファイルがあるが書き込み不可 → ログ出力できない
                throw new \SC\exception\libs\Log\NotWritable("Can't write log for '$sPath'");
            }
        } else {
            // ファイルがない → ログファイルを作成する
            $bRetCode        = touch($sPath);
            if ( $bRetCode !== true ) {
                // ファイルが作成できなかった → ログ出力できない
                throw new \SC\exception\libs\Log\CantTouch("Can't touch log for '$sPath'");
            }
            // ファイルを作成したプロセスのみアーカイブする
            $this->bArchive = true;
        }
        // 有効なのでストア
        $this->sLogFile      = $sLogFile;
        $this->sLogFilePath  = realpath($sPath);
        return true;
    }

    /**
     * 過去のログファイルのアーカイブ化
     *
     * @return  true
     */
    protected function _archive()
    {
        // アーカイブするか？
        if ( $this->bArchive !== true ) {
            // アーカイブしないなら抜ける
            return true;
        }
        // アーカイブする
        $sRoot     = $this->sLogRoot . DIRECTORY_SEPARATOR . static::LOG_BASE;
        $iFlags    = \FilesystemIterator::FOLLOW_SYMLINKS | \FilesystemIterator::SKIP_DOTS;
        $oFiles    = new \RecursiveDirectoryIterator($sRoot, $iFlags);
        $oList     = new \RecursiveIteratorIterator($oFiles);
        // 前日の3:00のタイムスタンプを取得
        $aNow      = getdate((int) floor(self::$fAccessSec));
        $iChckTime = mktime(3, 0, 0, $aNow['mon'], $aNow['mday']-1, $aNow['year']);
        foreach ($oList as $oFileInfo) {
            // 拡張子で判定
            $sExtension = $oFileInfo->getExtension();
            if ( $sExtension !== static::LOG_EXT ) {
                // ログではない → 次へ
                continue;
            }
            // 日時で判定
            $iMTime     = $oFileInfo->getMTime();
            if ( $iChckTime < $iMTime ) {
                // 最近のファイル → 次へ
                continue;
            }
            // アーカイブ
            $sFilename  = $oFileInfo->getPathname();
            $sArchive   = $sFilename . '.gz';
            $bRetCode   = file_exists($sArchive);
            if ( $bRetCode === true ) {
                // 存在する → アーカイブ不可なので次へ
                \Log::warning("gzopen failure '{$sArchive}'. (mode: $sMode)");
                continue;
            }
            // ファイルを圧縮
            Util::gzip($sFilename, 9, '.gz');
        }

        return true;
    }
}
