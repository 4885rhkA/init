<?php
/**
 * コントロールパネルDownloadモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * コントロールパネルDownloadモデルコントローラ
 */
class DownloadModel extends PublicModel
{
    /**
     * 強制的にダウンロードさせるか否か
     *
     * @var bool FORCE_DOWNLOAD
     */
    const FORCE_DOWNLOAD = true;
}
