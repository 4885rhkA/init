<?php
/**
 * ステージ種別の指定がない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\model\Stage;

/**
 * ステージ種別の指定がない場合の例外
 */
class EmptyStage extends \SC\exception\model\Stage
{
}
