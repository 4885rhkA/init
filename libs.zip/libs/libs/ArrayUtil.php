<?php
/**
 * ArrayUtil
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ArrayUtil
 */
class ArrayUtil
{
    /**
     * 配列の最大次元数
     *
     * @var int RANK_MAX
     */
    const RANK_MAX = 256;

    /**
     * インスタンス
     *
     * @var SC\libs\ArrayUtil $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\ArrayUtil
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * 配列から値を取得
     *
     * @param   array   $aInput
     * @param   string  $sKey
     * @param   mixed   $mDefault
     * @return  mixed   値
     */
    public static function getValue(array $aInput, $sKey, $mDefault = NULL)
    {
        // キーがあるか？
        $bRetCode = array_key_exists($sKey, $aInput);
        if ( $bRetCode !== true ) {
            // なければデフォルトを返す
            return $mDefault;
        }
        // あればその値を返す
        return $aInput[$sKey];
    }

    /**
     * 配列の再帰的結合
     *
     * @param   array   $aBase
     * @param   array   $aPlus
     * @param   bool    $bOverwrite
     * @return  array   結合した配列
     */
    public static function unite(array $aBase, array $aPlus, $bOverwrite = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_unite($aBase, $aPlus, $bOverwrite);
    }

    /**
     * 配列の再帰的結合
     *
     * @param   array   $aBase
     * @param   array   $aPlus
     * @param   bool    $bOverwrite
     * @return  array   結合した配列
     */
    protected function _unite(array $aBase, array $aPlus, $bOverwrite = false)
    {
        // あるか？
        $iCount                     = count($aPlus);
        if ( $iCount < 1 ) {
            return $aBase;
        }
        $iCount                     = count($aBase);
        if ( $iCount < 1 ) {
            return $aPlus;
        }
        // 両方あるので結合する
        $aBaseKeys                  = array_keys($aBase);
        $aPlusKeys                  = array_keys($aPlus);
        $aKeys                      = array_merge($aBaseKeys, $aPlusKeys);
        $aKeys                      = array_unique($aKeys);
        $aUnited                    = array();
        // キーの数だけループ
        foreach ( $aKeys as $sKey ) {
            // 値があるか？
            $bRetCode               = array_key_exists($sKey, $aPlus);
            if ( $bRetCode !== true ) {
                $aUnited[$sKey]     = $aBase[$sKey];
                continue;
            }
            $bRetCode               = array_key_exists($sKey, $aBase);
            if ( $bRetCode !== true ) {
                $aUnited[$sKey]     = $aPlus[$sKey];
                continue;
            }
            // 両方あるのでセット
            $bRetCode               = is_array($aBase[$sKey]);
            if ( $bRetCode === true ) {
                $bRetCode           = is_array($aPlus[$sKey]);
                if ( $bRetCode === true ) {
                    // 配列同士なら再帰的に結合
                    $aUnited[$sKey] = $this->_unite($aBase[$sKey], $aPlus[$sKey], $bOverwrite);
                    continue;
                }
            }
            // 結合できないので上書きか否か
            if ( $bOverwrite !== true ) {
                $aUnited[$sKey]     = $aBase[$sKey];
            } else {
                $aUnited[$sKey]     = $aPlus[$sKey];
            }
        }
        // 結合後の配列を返す
        return $aUnited;
    }

    /**
     * 連想キーと要素との関係を維持しつつ配列をソートする
     *
     * @param   array   $aTarget    配列
     * @param   int     $iSortFlags ソートの動作を修正するフラグ
     * @return  bool    true
     */
    public static function asort(array &$aTarget, $iSortFlags=SORT_REGULAR)
    {
        return asort($aTarget, $iSortFlags);
    }

    /**
     * 配列をキーでソートする
     *
     * @param   array   $aTarget    配列
     * @param   int     $iSortFlags ソートの動作を修正するフラグ
     * @return  bool    true
     */
    public static function ksort(array &$aTarget, $iSortFlags=SORT_REGULAR)
    {
        return ksort($aTarget, $iSortFlags);
    }

    /**
     * "自然順"アルゴリズムで配列をソートする
     *
     * @param   array   $aTarget    配列
     * @return  bool    true
     */
    public static function natsort(array &$aTarget)
    {
        return natsort($aTarget);
    }

    /**
     * 大文字小文字を区別しない"自然順"アルゴリズムを用いて配列をソートする
     *
     * @param   array   $aTarget    配列
     * @return  bool    true
     */
    public static function natcasesort(array &$aTarget)
    {
        return natcasesort($aTarget);
    }

    /**
     * "自然順"アルゴリズムで配列をキーでソートする
     *
     * @param   array   $aTarget    配列
     * @return  bool    true
     */
    public static function natksort(array &$aTarget)
    {
        return uksort($aTarget, 'strnatcmp');
    }

    /**
     * 大文字小文字を区別しない"自然順"アルゴリズムを用いて配列をソートする
     *
     * @param   array   $aTarget    配列
     * @return  bool    true
     */
    public static function natcaseksort(array &$aTarget)
    {
        return uksort($aTarget, 'strnatcasecmp');
    }

    /**
     * 配列をソートする
     *
     * @param   array   $aTarget    配列
     * @param   int     $iSortFlags ソートの動作を修正するフラグ
     * @return  bool    true
     */
    public static function sort(array &$aTarget, $iSortFlags=SORT_REGULAR)
    {
        return sort($aTarget, $iSortFlags);
    }

    /**
     * ユーザ定義の比較関数で配列をソートし、連想インデックスを保持する
     *
     * @param   array       $aTarget        配列
     * @param   callback    $cbCmpFunction  コールバック関数
     * @return  bool        true
     */
    public static function uasort(array &$aTarget, $cbCmpFunction)
    {
        return uasort($aTarget, $cbCmpFunction);
    }

    /**
     * ユーザ定義の比較関数を用いて、キーで配列をソートする
     *
     * @param   array       $aTarget        配列
     * @param   callback    $cbCmpFunction  コールバック関数
     * @return  bool        true
     */
    public static function uksort(array &$aTarget, $cbCmpFunction)
    {
        return uksort($aTarget, $cbCmpFunction);
    }

    /**
     * ユーザー定義の比較関数を使用して、配列を値でソートする
     *
     * @param   array       $aTarget        配列
     * @param   callback    $cbCmpFunction  コールバック関数
     * @return  bool        true
     */
    public static function usort(array &$aTarget, $cbCmpFunction)
    {
        return usort($aTarget, $cbCmpFunction);
    }

    /**
     * 要素を逆順にした配列を返す
     *
     * @param   array   $aTarget        配列
     * @param   bool    $iPreserveKeys  キーと値の組み合わせを保持するか否か
     * @return  array
     */
    public static function reverse(array $aTarget, $iPreserveKeys=true)
    {
        return array_reverse($aTarget, $iPreserveKeys);
    }

    /**
     * 全要素をintにキャスト
     *
     * @param   mixed   $mTarget    配列
     * @return  array   キャスト後の配列
     */
    public static function toInt($mTarget)
    {
        // インスタンスを取得
        $oSelf          = static::getInstance();
        // 配列かどうか
        $bIsArray       = is_array($mTarget);
        if ( $bIsArray === true ) {
            $aConverted = $mTarget;
        } else {
            $aConverted = array($mTarget);
        }
        // 再帰的に変換
        $bRetCode       = array_walk_recursive($aConverted, array($oSelf, '_toInt'));
        if ( $bRetCode !== true ) {
            // 変換失敗
            return $mTarget;
        }
        if ( $bIsArray === true ) {
            // 配列ならそのまま返す
            return $aConverted;
        }
        return $aConverted[0];
    }

    /**
     * intにキャスト
     *
     * @param   mixed   $mValue     変換対象(参照)
     * @return  bool    true
     */
    protected function _toInt(&$mValue)
    {
        $mValue = (int) $mValue;
        return true;
    }

    /**
     * 配列の次元を増加させる
     *
     * @param   mixed   $mInput     配列
     * @param   int     $iRank      増加させる時限
     * @return  array   次元が増加したランク
     */
    public static function incRankTo($mInput, $iRank = 1)
    {
        // 配列にする
        $aValue       = (array) $mInput;
        if ( $iRank < 2 || $iRank > static::RANK_MAX ) {
            // 1次元なら配列なので返す
            return $aValue;
        }
        // 次元数を確認
        $mFirst       = reset($aValue);
        $bIsArray     = is_array($mFirst);
        for ( $i = 2 ; $bIsArray === true ; $i++ ) {
            if ( $iRank <= $i ) {
                // 指定ランクを超えた
                return $aValue;
            }
            $mFirst   = reset($mFirst);
            $bIsArray = is_array($mFirst);
        }
        // 差分の時限だけ増加
        $iDiffs       = $iRank - ( $i - 1 );
        for ( $i = 0 ; $i < $iDiffs ; $i++ ) {
            $aValue   = array($aValue);
        }
        return $aValue;
    }

    /**
     * 再帰join
     *
     * @param   string  $sGlue          結合文字列
     * @param   mixed   $mInput         配列
     * @param   bool    $bRecursively   再帰処理するか
     * @return  string  文字列
     */
    public static function join($sGlue = '', $mInput = NULL, $bRecursively = true)
    {
        // スカラ値はそのまま返す
        $bRetCode              = is_scalar($mInput);
        if ( $bRetCode === true ) {
            return $mInput;
        }
        $bRetCode              = is_array($mInput);
        if ( $bRetCode === true ) {
            $mInput            = (array) $mInput;
        }
        $sGlue                 = (string) $sGlue;
        foreach ( $mInput as $sKey => $mValue ) {
            if ( $bRecursively === true ) {
                $mInput[$sKey] = static::join($sGlue, $mValue, $bRecursively);
            } else {
                $mInput[$sKey] = (string) $mValue;
            }
        }
        return join($sGlue, $mInput);
    }

    /**
     * 再帰join
     *
     * @param   string  $sGlue          結合文字列
     * @param   mixed   $mInput         配列
     * @param   bool    $bRecursively   再帰処理するか
     * @return  string  文字列
     */
    public static function implode($sGlue = '', $mInput = NULL, $bRecursively = true)
    {
        return static::join($sGlue, $mInput, $bRecursively);
    }

    /**
     * explode
     *
     * @param   string  $sGlue  結合文字列
     * @param   string  $sInput 文字列
     * @param   int     $iCount 個数
     * @return  array   配列
     */
    public static function explode($sGlue = '', $sInput = '', $iCount = NULL)
    {
        if ( $sGlue === '' ) {
            $sFunc   = 'str_split';
            $aArgs   = array((string) $sInput);
        } else {
            $sFunc   = 'explode';
            $aArgs   = array((string) $sGlue, (string) $sInput);
        }
        if ( $iLimit !== NULL ) {
            $aArgs[] = (int) $iCount;
        }
        return call_user_func_array($sFunc, $aArgs);
    }
}
