<?php
/**
 * 正常にソースが取得できなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\ConvertModel;

/**
 * 正常にソースが取得できなかった場合の例外
 */
class CantGetSourceNomally extends \SC\exception\controller\ConvertModel
{
}
