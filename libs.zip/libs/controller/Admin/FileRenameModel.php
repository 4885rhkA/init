<?php
/**
 * ファイルリネームモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイルリネームモデルコントローラ
 */
class FileRenameModel extends AbstractJSONModel
{
    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();

        // PATH_INFOからステージ種別を取得
        // ex.) /stage/live/file/rename.json
        $sPathInfo       = $this->oRequest->getPathInfo();
        $sStage          = $this->oStage->getStageName($sPathInfo);

        // リクエストパラメータからファイル名を取得
        $sFrom           = $this->oRequest->getRequest('from');
        $sTo             = $this->oRequest->getRequest('to');
        $sTo             = mb_convert_kana($sTo, 'a'); // 「全角」英数字を「半角」に変換
        // Gitパラメータ
        $sAuthor         = $this->oLogin->getAuthor();
        $sMessage        = 'rename file/directory via control panel.';  // コミットメッセージは固定

        try {
            $this->oStage->renameFile($sStage, $sFrom, $sTo, $sAuthor, $sMessage);
            $this->aValues = array(
                'newpath' => dirname($sFrom) . '/' . $sTo,
            );
        } catch (\Exception $oException) {
            $this->bHasError   = true;
            $this->sErrMessage = $oException->getMessage();
        }

        return parent::_process();
    }
}
