<?php
/**
 * ファイル更新モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイル更新モデルコントローラ
 */
class FileUpdateModel extends AbstractJSONModel
{
    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage    = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();

        // PATH_INFOからステージ種別を取得
        $sPathInfo       = $this->oRequest->getPathInfo();
        $sStage          = $this->oStage->getStageName($sPathInfo);

        // リクエストパラメータからファイル名・ファイル内容を取得
        $sFilename       = $this->oRequest->getRequest('file');
        $aData           = $this->oRequest->getRequest('data');
        $sAuthor         = $this->oLogin->getAuthor();
        $sMessage        = 'update file via control panel.';  // コミットメッセージは固定

        $this->oStage->updateFile($sStage, $sFilename, $aData, $sAuthor, $sMessage);

        $aData           = $this->oStage->readFile($sStage, $sFilename);
        $this->aValues   = array(
            'content'    => $aData['content'],
            'modifytime' => $aData['modifytime'],
        );

        return parent::_process();
    }
}
