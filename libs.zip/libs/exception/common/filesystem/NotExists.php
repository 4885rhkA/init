<?php
/**
 * ファイルが存在しない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\filesystem;

/**
 * ファイルが存在しない場合の例外
 */
class NotExists extends \SC\exception\common\filesystem
{
}
