<?php
/**
 * InsertAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * InsertAO
 */
class InsertAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'table'      => 'string',                       // 挿入対象
        'fields'     => 'SC\\libs\\DB\\FieldListAO',    // フィールドリスト
        'binds'      => 'SC\\libs\\DB\\BindListAO',     // BINDパラメータ
        'seqname'    => 'string',                       // シーケンス名 for PDO_PGSQL
    );
}
