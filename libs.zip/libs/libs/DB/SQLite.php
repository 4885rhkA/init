<?php
/**
 * SQLiteDB
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * SQLiteDB
 */
class SQLite extends AbstractDB
{
    /**
     * データソースネーム
     *
     * @var string BASE
     */
    const BASE = AP_DIR;

    /**
     * データソースネーム接頭辞
     *
     * @var string DSN_PREFIX
     */
    const DSN_PREFIX = 'sqlite';

    /**
     * データベース
     *
     * @var string DATABASE
     */
    const DATABASE = '/db/smartconvert.sqlite';

    /**
     * データソースネーム
     *
     * @var array $aOptions
     */
    protected $aOptions = array();  // @todo ★

    /**
     * トランザクション開始SQL
     *
     * @var string SQL_BEGIN
     */
    const SQL_BEGIN = 'BEGIN IMMEDIATE TRANSACTION';

    /**
     * トランザクション完了SQL
     *
     * @var string SQL_COMMIT
     */
    const SQL_COMMIT = 'COMMIT TRANSACTION';

    /**
     * トランザクションロールバックSQL
     *
     * @var string SQL_ROLLBACK
     */
    const SQL_ROLLBACK = 'ROLLBACK TRANSACTION';

    /**
     * datetime型を時刻文字列に変換する際のフォーマット
     *
     * @var string
     */
    const DATETIME_TO_STRING = '%Y/%m/%d %H:%M:%S';

    /**
     * データベース接続情報の収集
     *
     * @return  bool    true
     */
    protected function _collect()
    {
        $this->_setDataBase(static::BASE . $this->sDataBase);
        return parent::_collect();
    }

    /**
     * datetimeフィールドを時刻文字列にフォーマットする
     *
     * @param   string  $sField     フィールド名
     * @return  string  フォーマット後の時刻文字列
     */
    public static function formatDateTimeToString($sField, $sFormat = '', $sModifier = 'localtime')
    {
        if ( $sFormat === '' ) {
            $sFormat = static::DATETIME_TO_STRING;
        }
        $bRetCode    = strpos($sFormat, '%s');
        if ( $sFormat === '%s' ) {
            // Seconds from UNIX Epoch must not use modifier
            $sModifier = '';
        }
        if ( $sModifier === '' || $sModifier === NULL ) {
            $sField  = sprintf("strftime('%s',%s)", $sFormat, $sField);
        } else {
            $sField  = sprintf("strftime('%s',%s,'%s')", $sFormat, $sField, $sModifier);
        }
        return $sField;
    }

    /**
     * VACUUM
     *
     * @return  bool    true
     */
    protected function _vacuum()
    {
// @todo
        return true;
    }
}
