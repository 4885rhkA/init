<?php
/**
 * ArrayObject
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ArrayObject
 */
class ArrayObject implements \IteratorAggregate, \Countable, \ArrayAccess
{
    /**
     * AOクラス名の指定
     *
     * @var string AO_CLASS
     */
    const AO_CLASS = __CLASS__;

    /**
     * プロパティ型指定があるもののみ保持できる
     *
     * $this->aPropTypesにて指定があるプロパティのみ保持するか否かを判定する
     *
     * @var bool CAN_STORE_ONLY_RESERVED_KEY
     */
    const CAN_STORE_ONLY_RESERVED_KEY = false;

    /**
     * プロパティキー名指定があるもののみ保持できる
     *
     * インクリメント方式(キー名無指定)で値を保持するか否かを判定する
     * true:  キー名の指定が必須
     * false: キー名の指定がない→インクリメント方式
     *
     *  (ex) true: $arr[] = value; → 例外 \SC\exception\libs\ArrayObject\EmptyPropertyName
     *
     * @var bool CAN_STORE_ONLY_SPECIFIED_KEY
     */
    const CAN_STORE_ONLY_SPECIFIED_KEY = false;

    /**
     * array指定の場合にArrayObjectを使うか否か
     *
     * @var bool PREFER_TO_USE_ARRAYOBJECT
     */
    const PREFER_TO_USE_ARRAYOBJECT = false;

    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array();

    /**
     * プロパティ型指定(インクリメント式)
     *
     *  型名： bool, int, float, string, array, クラス名, self, static
     *
     * @var string $sPropType
     */
    protected $sPropType = '';

    /**
     * ストアするデータ
     *
     * @var array $storage
     */
    protected $storage = array();

    /**
     * イテレータクラス名
     *
     * @var string $sIterator
     */
    protected $sIterator = 'ArrayIterator';

    /**
     * ArrayObjectクラス名をリセットするか
     *
     * @var bool RESET_ARRAY_CLASS
     */
    const RESET_ARRAY_CLASS = false;

    /**
     * ArrayObjectクラス名
     *
     * @var string $sArrayClass
     */
    protected $sArrayClass = '';

    /**
     * コンストラクタ
     *
     * @param   mixed   $aInput         初期指定配列
     * @param   string  $sIterator      イテレータクラス名
     * @param   string  $sArrayClass    ArrayObjectを生成する場合のクラス名
     * @throw   SC\exception\libs\ArrayObject\NotChildren
     * @throw   SC\exception\libs\ArrayObject\InvalidIterator
     */
    public function __construct($aInput = NULL, $sIterator = NULL, $sArrayClass = NULL)
    {
        // 初期指定配列
        $bRetCode                  = is_array($aInput);
        if ( $bRetCode !== true ) {
            // 配列ではない → オブジェクトチェック
            $bRetCode              = is_object($aInput);
            if ( $bRetCode !== true ) {
                // オブジェクトではない → 配列に変換
                $aInput            = (array) $aInput;
            } else {
                // 自クラスか？
                $sInputClass       = get_class($aInput);
                $sThisClass        = get_class($this);
                $bRetCode          = Util::is_a($sInputClass, $sThisClass);
                if ( $bRetCode !== true ) {
                    // 自クラスではない → 例外
                    throw new \SC\exception\libs\ArrayObject\NotChildren("'$sInputClass' is not one of children of '$sThisClass'");
                }
                // 自クラスなら値を保持
                $aInput            = $aInput->storage;
            }
        }
        // イテレータチェック
        if ( $sIterator !== NULL ) {
            try {
                $sIterator         = trim($sIterator);
                $aCheck            = new \ArrayObject(array(), 0, $sIterator);
                $this->sIterator   = $sIterator;
            } catch (\InvalidArgumentException $oException) {
                // イテレータが無効
                throw new \SC\exception\libs\ArrayObject\InvalidIterator($oException->getMessage(), $oException->getCode(), $oException);
            }
        }
        // ArrayObjectチェック
        $sArrayClass               = trim($sArrayClass);
        if ( $sArrayClass !== '' ) {
            $sArrayClass           = trim($sArrayClass);
            $bRetCode              = ! (bool) strcasecmp('array', $sArrayClass);
            if ( $bRetCode === true ) {
                // 配列
                $this->sArrayClass = 'array';
            } else {
                $bRetCode          = Util::is_a($sArrayClass, __CLASS__);
                if ( $bRetCode !== true ) {
                    // ArrayObjectが無効
                    throw new \SC\exception\libs\ArrayObject\InvalidArrayClass('Invalid ArrayObject class name');
                }
            }
            $this->sArrayClass     = $sArrayClass;
        }
        // 値をセット
        $this->storage             = array();
        foreach ( $aInput as $sProp => $mValue ) {
            $this->offsetSet($sProp, $mValue);
        }
    }

    /**
     * イテレータを取得する
     *
     *  required by \IteratorAggregate
     *
     * @return  \Traversable
     */
    public function getIterator()
    {
        // イテレータは取得時に必ず毎回生成する
        return new $this->sIterator($this->storage);
    }

    /**
     * イテレータクラス名を取得する
     *
     * @return  string
     */
    public function getIteratorClass ()
    {
        // イテレータクラス名を返す
        return $this->sIterator;
    }

    /**
     * 件数を取得する
     *
     *  required by \Countable
     *
     * @return  int
     */
    public function count()
    {
        // 件数を返す
        return count($this->storage);
    }

    /**
     * オフセットが存在するかどうか
     *
     *  required by \ArrayAccess
     *
     * @param   string  $sProp
     * @return  bool    true/false
     * @throw   SC\exception\common\parameter\NotAString
     */
    public function offsetExists($sProp)
    {
        // 入力チェック
        $bRetCode = Validate::isString($sProp);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Property name must be string');
        }
        // 存在するか否か
        $bRetCode = array_key_exists($sProp, $this->storage);
        return $bRetCode;
    }

    /**
     * プロパティゲッター
     *
     * @param   string  $sProp
     * @return  mixed   $mValue
     */
    public function & offsetGet($sProp)
    {
        // 入力チェック
        $bRetCode                  = Validate::isString($sProp);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Property name must be string');
        }
        // 存在チェック
        $bRetCode                  = array_key_exists($sProp, $this->storage);
        if ( $bRetCode !== true ) {
            $aNullValue            = NULL;
            return $aNullValue;
            throw new \SC\exception\common\parameter\NotAString('Nooooooo'); // @todo ★★★
            // 参照を返す必要があるため存在しなければNULLで値をセット
            $sClass = $this->sArrayClass;

            $this->storage[$sProp] = $this->_createChildArrayObject(NULL, $this->sArrayClass);

            $this->storage[$sProp] = NULL;

        }
        return $this->storage[$sProp];
    }

    /**
     * オフセットを設定する
     *
     * @param   string  $sProp
     * @param   mixed   $mValue
     * @return  void
     */
    public function offsetSet($sProp, $mValue)
    {
        // 入力チェック
        $bRetCode                  = Validate::isString($sProp);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Property name must be string');
        }
        // インクリメント方式がありか？
        if ( $sProp === NULL || $sProp === '' ) {
            if ( static::CAN_STORE_ONLY_SPECIFIED_KEY === true ) {
                // インクリメント方式はNG
                throw new \SC\exception\libs\ArrayObject\EmptyPropertyName("Property must not be empty");
            }
            // 正規化してセットする
            $this->storage[]       = $this->_normalizeValueByType($this->sPropType, $mValue);
        } else {
            // プロパティ名あり
            if ( static::CAN_STORE_ONLY_RESERVED_KEY === true ) {
                // 要型指定チェック
                $bRetCode          = isset($this->aPropTypes[$sProp]);
                if ( $bRetCode !== true ) {
                    // 型指定がされていない場合はNG
                    throw new \SC\exception\libs\ArrayObject\UnknownPropertyName("Property '$sProp' is not reserved");
                }
            }
            // 正規化してセットする
            $sType                 = (string) ArrayUtil::getValue($this->aPropTypes, $sProp, '');
            $this->storage[$sProp] = $this->_normalizeValueByType($sType, $mValue);
        }
        return;
    }

    /**
     * オフセットの設定を解除する
     *
     *  required by \ArrayAccess
     *
     * @param   string  $sProp
     * @return  void
     */
    public function offsetUnset($sProp)
    {
        // 入力チェック
        $bRetCode = Validate::isString($sProp);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Property name must be string');
        }
        // 存在するか？
        $bRetCode = array_key_exists($sProp, $this->storage);
        if ( $bRetCode === true ) {
            unset($this->storage[$sProp]);
        }
        return;
    }

    /**
     * 型に応じた正規化
     *
     * @param   string  $sType      正規化する型名
     * @param   mixed   $mValue     正規化する値
     * @return  bool    true
     */
    protected function _normalizeValueByType($sType, $mValue)
    {
        // 初期化
        $mNormalized             = NULL;
        // 型指定があるか？
        $bRetCode                = is_string($sType);
        if ( $bRetCode !== true || $sType === '' || $sType === 'mixed' ) {
            // 型指定なし → 任意の型がOK
            $bRetCode            = is_array($mValue);
            if ( $bRetCode !== true ) {
                // 配列でなければそのまま返す
                $mNormalized     = $mValue;
            } else {
                // 配列はArrayObjectとして正規化
                $mNormalized     = $this->_createChildArrayObject($mValue, $this->sArrayClass);
            }
        } else {
            // 型指定あり → 型名を正規化
            if ( $sType === 'self' || $sType === 'static' ) {
                $sType           = get_class($this);
            }
            $sTypeChecked        = Util::normalizeTypeName($sType);
            // 型に応じて正規化
            switch ( $sTypeChecked ) {
                // 配列はArrayObjectとして正規化
                case 'array':
                    $mNormalized = $this->_createChildArrayObject($mValue, $this->sArrayClass);
                    break;

                // 不明な型 → クラス名として正規化
                case 'unknown type':
                    $sClass      = $sType;
                    $mNormalized = new $sClass($mValue);
                    break;

                // その他は型で正規化
                default:
                    $mNormalized = Util::normalizeType($sTypeChecked, $mValue);
                    break;
            }
        }
        return $mNormalized;
    }

    /**
     * 子ArrayObjectを生成する
     *
     * @param   mixed   $mValue         値
     * @param   string  $sArrayClass    ArrayObjectを生成する場合のクラス名
     * @return  mixed   SC\libs\ArrayObject | array
     */
    protected function _createChildArrayObject($mValue, $sArrayClass = '')
    {
        // オブジェクトを優先するか？
        if ( $sArrayClass !== 'array' || static::PREFER_TO_USE_ARRAYOBJECT === true ) {
            // 配列はArrayObjectとして正規化
            if ( $sArrayClass !== '' ) {
                $sArrayClass = $sArrayClass;
            } else {
                $sArrayClass = static::AO_CLASS;
            }
            if ( static::RESET_ARRAY_CLASS === true ) {
                $sChildClass = '';
            } else {
                $sChildClass = $sArrayClass;
            }
            $oInstance       = new $sArrayClass($mValue, $this->sIterator, $sChildClass);
        } else {
            // 配列としてセット
            $oInstance       = (array) $mValue;
        }
        return $oInstance;
    }

    /**
     * 配列として取得
     *
     * @param   bool    $bRecursively   再帰的に配列にするか
     * @return  array   配列
     */
    public function getArray($bRecursively = true)
    {
        return $this->getArrayCopy($bRecursively);
    }

    /**
     * 配列として取得
     *
     * @param   bool    $bRecursively   再帰的に配列にするか
     * @return  array   配列
     */
    public function toArray($bRecursively = true)
    {
        return $this->getArrayCopy($bRecursively);
    }

    /**
     * 配列として取得
     *
     * @param   bool    $bRecursively   再帰的に配列にするか
     * @return  array   配列
     */
    public function getArrayCopy($bRecursively = true)
    {
        // 配列
        return $this->_toArray($this, $bRecursively);
    }

    /**
     * 配列にする
     *
     * @param   SC\libs\ArrayObject     $oInstance      ArrayObjectインスタンス
     * @param   bool                    $bRecursively   再帰的に配列にするか
     * @return  array                   配列
     */
    protected function _toArray(ArrayObject $oInstance, $bRecursively)
    {
        // 配列へ変換する
        return $this->_toArrayEach($oInstance->storage, $bRecursively);
    }

    /**
     * 配列にする
     *
     * @param   array   $aStorage   ループする配列
     * @param   bool    $bRecursively   再帰的に配列にするか
     * @return  array   配列
     */
    protected function _toArrayEach(array $oInstance, $bRecursively)
    {
        $aRetArray = array();
        foreach ( $oInstance as $sKey => $mValue ) {
            // 再帰か？
            if ( $bRecursively !== true ) {
                // 再帰ではない
                $aRetArray[$sKey] = $mValue;
                continue;
            }
            // 再帰ならチェック
            $sType                = Util::gettype($mValue);
            // 配列か？
            switch ( $sType ) {
                // 配列の場合再帰
                case 'array':
                    $aRetArray[$sKey] = $this->_toArrayEach($mValue, $bRecursively);
                    break;

                // オブジェクトの場合配列にしてから再帰
                case 'object': case 'unknown type':
                    // 変換メソッドがコールできるか？
                    $bRetCode = is_callable(array($mValue, 'getArrayCopy'));
                    if ( $bRetCode === true ) {
                        // 配列へ変換
                        $aRetArray[$sKey] = $this->_toArrayEach($mValue->getArrayCopy(), $bRecursively);
                    } else {
                        // 変換不能
                        $aRetArray[$sKey] = $mValue;
                    }
                    break;

                // その他
                default:
                    // そのまま
                    $aRetArray[$sKey] = $mValue;
                    break;
            }
        }
        return $aRetArray;
    }

    /**
     * キーを配列として取得
     *
     * @return  array   キー配列
     */
    public function keys()
    {
        return array_keys($this->storage);
    }

    /**
     * 値を配列として取得
     *
     * @return  array   値配列
     */
    public function values()
    {
        return array_values($this->storage);
    }

    /**
     * 分割
     *
     * @param   string  $sGlue          分割文字列
     * @param   string  $sTarget        対象文字列
     * @param   int     $iLimit         分割数
     * @param   string  $sIterator      イテレータクラス名
     * @param   string  $sArrayClass    ArrayObjectを生成する場合のクラス名
     * @return  SC\libs\ArrayObject
     */
    public static function explode($sGlue, $sTarget, $iLimit = NULL, $sIterator = NULL, $sArrayClass = NULL)
    {
        // 分割
        $sGlue = (string) $sGlue;
        if ( $sGlue === '' ) {
            $aInput = str_split($sTarget, 1);
        } else if ( $iLimit === NULL ) {
            $aInput = explode($sGlue, $sTarget);
        } else {
            $aInput = explode($sGlue, $sTarget, $iLimit);
        }
        return new static($aInput, $sIterator, $sArrayClass);
    }

    /**
     * 結合
     *
     * @param   string  $sGlue          結合文字列
     * @param   bool    $bRecursively   再帰結合するか
     * @return  string  結合した文字列
     */
    public function implode($sGlue = ',', $bRecursively = true)
    {
        // 結合する
        return $this->join($sGlue, $bRecursively);
    }

    /**
     * 結合
     *
     * @param   string  $sGlue          結合文字列
     * @param   bool    $bRecursively   再帰結合するか
     * @return  string  結合した文字列
     * @throw   SC\exception\common\parameter\NotAString
     */
    public function join($sGlue = ',', $bRecursively = true)
    {
        // 入力チェック
        $bRetCode     = Validate::isString($sGlue);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Glue must be string');
        }
        $sGlue        = (string) $sGlue;
        $bRecursively = (bool) $bRecursively;
        $aContainer   = $this->getArrayCopy();
        return $this->_join($sGlue, $aContainer, $bRecursively);
    }

    /**
     * 結合
     *
     * @param   string  $sGlue          結合文字列
     * @param   array   $aContainer     結合対象
     * @param   bool    $bRecursively   再帰結合するか
     * @return  string  結合した文字列
     */
    protected function _join($sGlue, array $aContainer, $bRecursively)
    {
        // 再帰
        $aResult                    = array();
        foreach ( $aContainer as $sKey => $mValue ) {
            $bRetCode               = is_array($mValue);
            if ( $bRetCode === true ) {
                if ( $bRecursively !== true ) {
                    $aResult[$sKey] = 'Array';
                } else {
                    $aResult[$sKey] = $this->_join($sGlue, $mValue, $bRecursively);
                }
            } else {
                $aResult[$sKey]     = $mValue;
            }
        }
        return join($sGlue, $aResult);
    }

    /**
     * 配列の先頭要素を取得
     *
     * @return  mixed
     */
    public function reset()
    {
        return reset($this->storage);
    }

    /**
     * 配列の末尾要素を取得
     *
     * @return  mixed
     */
    public function end()
    {
        return end($this->storage);
    }

    /**
     * pop
     *
     * @return  mixed
     */
    public function pop()
    {
        return array_pop($this->storage);
    }

    /**
     * push
     *
     * @param   mixed   $mValue
     * @return  void
     */
    public function push($mValue)
    {
        // 配列なら子ArrayObjectを生成
        $bRetCode   = is_array($mValue);
        if ( $bRetCode === true ) {
            $mValue = $this->_createChildArrayObject($mValue, $this->sArrayClass);
        }
        return array_push($this->storage, $mValue);
    }

    /**
     * shift
     *
     * @return  mixed
     */
    public function shift()
    {
        return array_shift($this->storage);
    }

    /**
     * unshift
     *
     * @param   mixed   $mValue
     * @return  void
     */
    public function unshift($mValue)
    {
        // 配列なら子ArrayObjectを生成
        $bRetCode   = is_array($mValue);
        if ( $bRetCode === true ) {
            $mValue = $this->_createChildArrayObject($mValue, $this->sArrayClass);
        }
        return array_unshift($this->storage, $mValue);
    }

    /**
     * search
     *
     * @param   mixed   $mNeedle
     * @param   bool    $bStrict
     * @return  scalar  キー
     */
    public function search($mNeedle, $bStrict = false)
    {
        return array_search($mNeedle, $this->storage, (bool) $bStrict);
    }

    /**
     * in_array
     *
     * @param   mixed   $mNeedle
     * @param   bool    $bStrict
     * @return  bool    true/false
     */
    public function in_array($mNeedle, $bStrict = false)
    {
        return in_array($mNeedle, $this->storage, (bool) $bStrict);
    }

    /**
     * key_exists
     *
     * @param   string  $sProp
     * @return  bool    true/false
     */
    public function key_exists($sProp)
    {
        return $this->offsetExists($sProp);
    }

    /**
     * merge_recursive
     *
     * @param   mixed   $mValue
     * @param   bool    $bRecursively   再帰結合するか
     * @return  SC\libs\ArrayObject
     */
    public function merge_recursive($mValue)
    {
        return $this->merge($mValue, true);
    }

    /**
     * merge
     *
     * @param   mixed   $mValue
     * @return  SC\libs\ArrayObject
     */
    public function merge($mValue, $bRecursively = false)
    {
        // 配列に変換
        $aStorage      = $this->getArrayCopy();
        $bRetCode      = Util::is_a($mValue, __CLASS__);
        if ( $bRetCode === true ) {
            $aValue    = $mValue->getArrayCopy();
        } else {
            $aValue    = (array) $mValue;
        }
        // マージ
        if ( $bRecursively === true ) {
            $aMerged   = array_merge_recursive($aStorage, $aValue);
        } else {
            $aMerged   = array_merge($aStorage, $aValue);
        }
        // 値をセット
        $this->storage = array();
        foreach ( $aMerged as $sProp => $mValue ) {
            $this->offsetSet($sProp, $mValue);
        }
        return $this;
    }

    /**
     * 配列の再帰的結合
     *
     * @param   mixed   $mValue
     * @param   bool    $bOverwrite
     * @return  SC\libs\ArrayObject
     */
    public function unite($mValue, $bOverwrite = false)
    {
        // 配列に変換
        $aStorage      = $this->getArrayCopy();
        $bRetCode      = Util::is_a($mValue, __CLASS__);
        if ( $bRetCode === true ) {
            $aValue    = $mValue->getArrayCopy();
        } else {
            $aValue    = (array) $mValue;
        }
        // マージ
        $aMerged       = ArrayUtil::unite($aStorage, $aValue, (bool) $bOverwrite);
        // 値をセット
        $this->storage = array();
        foreach ( $aMerged as $sProp => $mValue ) {
            $this->offsetSet($sProp, $mValue);
        }
        return $this;
    }

    /**
     * 配列の値をソートする
     *
     * @param   string  $sMethod
     * @param   array   $aArgs
     * @return  bool    true
     */
    public function _sort($sMethod, array $aArgs)
    {
        // 引数の先頭に配列を追加
        $aStorage = $this->getArrayCopy();
        $aArgs    = array_reverse($aArgs);
        $aArgs[]  = & $aStorage;
        $aArgs    = array_reverse($aArgs);
        // ソートする
        $mValue = call_user_func_array(array('SC\libs\ArrayUtil', $sMethod), $aArgs);
        // 値をセットしなおす
        $this->storage = array();
        foreach ( $aStorage as $sProp => $mValue ) {
            $this->offsetSet($sProp, $mValue);
        }
        return $mValue;
    }

    /**
     * 連想キーと要素との関係を維持しつつ配列をソートする
     *
     * @param   int     $iSortFlags ソートの動作を修正するフラグ
     * @return  bool    true
     */
    public function asort($iSortFlags = SORT_REGULAR)
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * 配列をキーでソートする
     *
     * @param   int     $iSortFlags ソートの動作を修正するフラグ
     * @return  bool    true
     */
    public function ksort($iSortFlags = SORT_REGULAR)
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * "自然順"アルゴリズムで配列をソートする
     *
     * @return  bool    true
     */
    public function natsort()
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * 大文字小文字を区別しない"自然順"アルゴリズムを用いて配列をソートする
     *
     * @return  bool    true
     */
    public function natcasesort()
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * "自然順"アルゴリズムで配列をキーでソートする
     *
     * @return  bool    true
     */
    public function natksort()
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * 大文字小文字を区別しない"自然順"アルゴリズムを用いて配列をソートする
     *
     * @return  bool    true
     */
    public function natcaseksort()
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * 配列をソートする
     *
     * @param   int     $iSortFlags ソートの動作を修正するフラグ
     * @return  bool    true
     */
    public function sort($iSortFlags = SORT_REGULAR)
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * ユーザ定義の比較関数で配列をソートし、連想インデックスを保持する
     *
     * @param   callback    $cbCmpFunction  コールバック関数
     * @return  bool        true
     */
    public function uasort($cbCmpFunction)
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * ユーザ定義の比較関数を用いて、キーで配列をソートする
     *
     * @param   callback    $cbCmpFunction  コールバック関数
     * @return  bool        true
     */
    public function uksort($cbCmpFunction)
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * ユーザー定義の比較関数を使用して、配列を値でソートする
     *
     * @param   callback    $cbCmpFunction  コールバック関数
     * @return  bool        true
     */
    public function usort($cbCmpFunction)
    {
        return $this->_sort(__FUNCTION__, func_get_args());
    }

    /**
     * 要素を逆順にした配列を返す
     *
     * @param   bool    $iPreserveKeys  キーと値の組み合わせを保持するか否か
     * @return  SC\libs\ArrayObject
     */
    public function reverse($iPreserveKeys = true)
    {
        // 引数の先頭に配列を追加
        $aStorage = $this->getArrayCopy();
        // 逆順にする
        $aStorage = array_reverse($aStorage, $iPreserveKeys);
        // 値をセットしなおす
        $this->storage = array();
        foreach ( $aStorage as $sProp => $mValue ) {
            $this->offsetSet($sProp, $mValue);
        }
        return $this;
    }
}
