<?php
/**
 * バリデーションクラス
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * バリデーションクラス
 */
class Validate
{
    /**
     * 整数か否かチェック
     *
     * @param   mixed   $mValue
     * @param   bool    $bStrict
     * @return  bool
     */
    public static function isInt($mValue, $bStrict=false)
    {
        // 整数型ならtrue
        $bRetCode     = is_int($mValue);
        if ( $bRetCode === true ) {
            return true;
        }
        // 文字列として10進数かどうか判定
        $bRetCode     = (bool) preg_match('#^[-+]?[0-9]+$#S', $mValue);
        if ( $bRetCode === true ) {
            return true;
        }
        return false;
    }

    /**
     * 文字列か否かチェック
     *
     * @param   mixed   $mValue
     * @param   bool    $bStrict
     * @return  bool
     */
    public static function isString($mValue, $bStrict=false)
    {
        // 文字列型ならtrue
        $bRetCode     = is_string($mValue);
        if ( $bRetCode === true ) {
            return true;
        }
        if ( $bStrict === true ) {
            return false;
        }
        $bRetCode     = is_scalar($mValue);
        if ( $bRetCode === true || $mValue === NULL ) {
            return true;
        }
        return false;
    }

    /**
     * 文字列か否かチェック(空文字はNG)
     *
     * @param   mixed   $mValue
     * @param   bool    $bStrict
     * @return  bool
     */
    public static function isStringNotZero($mValue, $bStrict=false, $sTrimList=" \t\n\r\x0b\0")
    {
        // 文字列化か否か
        $bRetCode = static::isString($mValue, $bStrict);
        if ( $bRetCode !== true ) {
            // 文字列でない → NG
            return false;
        }
        // 両端除去か？
        if ( $sTrimList !== '' && $sTrimList !== NULL && $sTrimList !== false ) {
            $mValue = trim($mValue);
        }
        // 空文字か？
        if ( $mValue === '' ) {
            // 空文字はNG
            return false;
        }
        return true;
    }
}
