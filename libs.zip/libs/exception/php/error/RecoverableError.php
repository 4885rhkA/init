<?php
/**
 * キャッチ可能なエラー例外 (E_RECOVERABLE_ERROR)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * キャッチ可能なエラー例外 (E_RECOVERABLE_ERROR)
 */
class RecoverableError extends \SC\exception\php\error
{
}
