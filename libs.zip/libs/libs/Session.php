<?php
/**
 * セッション
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * セッション
 */
final class Session
{
    /**
     * セッションクッキー名
     *
     * @var string SESSION_NAME
     */
    const SESSION_NAME = 'SMARTCONVERT_SID';

    /**
     * セッションクッキー接頭辞(旧方式)
     *
     * @var string SESSION_PREFIX
     */
    const SESSION_PREFIX = 'SC_SID';

    /**
     * キャッシュリミッタ
     *
     * @var string CACHE_LIMITER
     */
    const CACHE_LIMITER = 'private_no_expire';

    /**
     * キャッシュリミッタ
     *
     * @var string $sCacheLimiter
     */
    protected static $sCacheLimiter = self::CACHE_LIMITER;

    /**
     * クッキーパス
     *
     * @var string COOKIE_PATH
     */
    const COOKIE_PATH = '/';

    /**
     * クッキードメイン
     *
     * @var string COOKIE_DOMAIN
     */
    const COOKIE_DOMAIN = NULL;

    /**
     * セッションネームスペース for デフォルト
     *
     * @var string NAMESPACE_DEFAULT
     */
    const NAMESPACE_DEFAULT = 'default';

    /**
     * セッションネームスペース for フラッシュデータ
     *
     * @var string NAMESPACE_FLASH
     */
    const NAMESPACE_FLASH = 'flash';

    /**
     * フラッシュデータ
     *
     * @var array $aFlashData
     */
    protected $aFlashData = array();

    /**
     * インスタンス
     *
     * @var SC\libs\Session $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * セッションを開始したか否か
     *
     * @var bool $bStarted
     */
    protected $bStarted = false;

    /**
     * セッション名
     *
     * @var string $sSessName
     */
    protected $sSessName = self::SESSION_NAME;

    /**
     * セッションID
     *
     * @var string $sSessId
     */
    protected $sSessId = '';

    /**
     * コンストラクタ
     *
     * @param   string  $sSessId
     */
    protected function __construct($sSessId = '')
    {
        // クッキーからセッション名を取得する
        $bFound         = false;
        $sSessionId     = trim(Request::getCookie(static::SESSION_NAME, ''));
        if ( $sSessionId !== '' ) {
            $bFound     = true;
            // 見つかればセッション名をセット
            session_name(static::SESSION_NAME);
            session_id($sSessionId);
        } else {
            // 無ければ旧方式でのセッション名
            $aKeys      = Request::getCookieKeys();
            foreach ( $aKeys as $sKey ) {
                $bFound = (bool) preg_match('/^(' . static::SESSION_PREFIX. '#[A-Za-z0-9]+)$/', $sKey, $aMatched);
                if ( $bFound === true ) {
                    // 見つかればセッション名をセット
                    session_name($aMatched[1]);
                    session_id(Request::getCookie($aMatched[1]));
                    break;
                }
            }
        }
        if ( $bFound !== true ) {
            // 見つからなければ生成してセッション名をセット
            session_name(static::SESSION_NAME);
        }
        // セッションIDが指定されていればセット
        if ( $sSessId !== '' ) {
            session_id($sSessId);
        }
        // この時点ではセッションは開始しない
        $this->sSessName   = session_name();
        $this->sSessId     = session_id();
        LogRegistry::save('sc:request', $this->sSessName, $this->sSessId);
    }

    /**
     * インスタンスを取得する
     *
     * @param   string  $sSessId
     * @return  SC\libs\Session
     */
    public static function getInstance($sSessId = '')
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static($sSessId);
        }
        return self::$oInstance;
    }

    /**
     * キャッシュリミッターのセット
     *
     *  ※特別な値としてヘッダを一切送らない false を指定することができる
     *
     * @param   string  $sCacheLimiter
     * @return  bool    true
     */
    public static function setCacheLimiter($sCacheLimiter = self::CACHE_LIMITER)
    {
        // インスタンスを取得
        $bRetCode = static::isStarted();
        // すでに開始しているか？
        if ( $bRetCode === true ) {
            // 開始済み
            return false;
        }
        if ( $sCacheLimiter !== false ) {
            switch ( $sCacheLimiter ) {
                // 有効な指定
                case 'public':
                case 'private_no_expire':
                case 'private':
                case 'nocache':
                    break;

                // 無効な指定 → デフォルトにする
                default:
                    $sCacheLimiter = static::CACHE_LIMITER;
                    break;
            }
        }
        // 値を保持する
        self::$sCacheLimiter = $sCacheLimiter;
        return true;
    }

    /**
     * セッションを開始する
     *
     * @param   string  $sSessId
     * @return  SC\libs\Session
     */
    public static function start($sSessId = '')
    {
        // インスタンスを取得
        $oSelf            = static::getInstance($sSessId);
        // すでに開始しているか？
        if ( $oSelf->bStarted === true ) {
            // 開始済み
            return $oSelf;
        }
        $oSelf->bStarted  = true;
        // セッション開始
        session_set_cookie_params(0, self::COOKIE_PATH, self::COOKIE_DOMAIN, false, true);
        session_cache_limiter(self::$sCacheLimiter);
        session_start();
        $oSelf->sSessName = session_name();
        $oSelf->sSessId   = session_id();
        // フラッシュ情報の初期化
        $oSelf->initFlashData();
        // ログ出力
        \Log::info("Session has started. [{$oSelf->sSessName}={$oSelf->sSessId}]");
        LogRegistry::save('sc:display', $oSelf->sSessName, $oSelf->sSessId);
        LogRegistry::save('sc:request', 'SESSION_STARTED', '1');
        LogRegistry::save('sc:display', 'SESSION_STARTED', '1');
        return $oSelf;
    }

    /**
     * インスタンスが生成済みかどうか
     *
     * @return  bool    生成済:true／未生成:false
     */
    public static function isStarted()
    {
        // インスタンスを取得
        $oSelf = static::getInstance();
        return $oSelf->bStarted;
    }

    /**
     * セッション名の取得
     *
     * @return  string  セッション名
     */
    public static function getSessName()
    {
        // インスタンスを取得
        $oSelf = static::getInstance();
        return $oSelf->sSessName;
    }

    /**
     * セッションIDの取得
     *
     * @return  string  セッションID
     */
    public static function getSessId()
    {
        // インスタンスを取得
        $oSelf = static::getInstance();
        return $oSelf->sSessId;
    }

    /**
     * セッション破壊
     *
     * @return  bool    true
     */
    public function destory()
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない
            return false;
        }
        // セッションを破壊
        $aSessionKeys = array_keys($_SESSION);
        foreach ( $aSessionKeys as $sNameSpace ) {
            if ( $sNameSpace !== self::NAMESPACE_FLASH ) {
                unset($_SESSION[$sNameSpace]);
            }
        }
        $bRetCode      = session_regenerate_id(true);
        $this->sSessId = session_id();
        return $bRetCode;
    }

    /**
     * セッションデータの取得
     *
     * @param   string  $sKey
     * @param   string  $sNameSpace
     * @return  mixed   セッションデータ
     */
    public function get($sKey, $sNameSpace = self::NAMESPACE_DEFAULT)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            $this->start();
        }
        // 入力チェック
        $bRetCode = $this->_checkInput($sKey, $sNameSpace);
        // 存在チェック
        $bRetCode = isset($_SESSION[$sNameSpace][$sKey]);
        if ( $bRetCode !== true ) {
            // 存在しない → NULLを返す
            return NULL;
        }
        // 存在するなら値を返す
        return $_SESSION[$sNameSpace][$sKey];
    }

    /**
     * セッションデータの保存
     *
     * @param   string  $sKey
     * @param   mixed   $mValue
     * @param   string  $sNameSpace
     * @return  bool    true
     */
    public function set($sKey, $mValue, $sNameSpace = self::NAMESPACE_DEFAULT)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // 入力チェック
        $bRetCode = $this->_checkInput($sKey, $sNameSpace);
        // セッションに格納
        $bRetCode = isset($_SESSION[$sNameSpace]);
        if ( $bRetCode !== true ) {
            // ネームスペースの初期化
            $_SESSION[$sNameSpace]    = array();
        }
        $_SESSION[$sNameSpace][$sKey] = $mValue;
        return true;
    }

    /**
     * セッションデータのクリア
     *
     * @param   string  $sKey
     * @param   string  $sNameSpace
     * @return  bool    true
     */
    public function clear($sKey, $sNameSpace = self::NAMESPACE_DEFAULT)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // 入力チェック
        $bRetCode = $this->_checkInput($sKey, $sNameSpace);
        // 存在チェック
        $bRetCode = isset($_SESSION[$sNameSpace][$sKey]);
        if ( $bRetCode !== true ) {
            // 存在しない → クリア済みとして正常終了
            return true;
        }
        // 存在するなら値をクリア
        unset($_SESSION[$sNameSpace][$sKey]);
        return true;
    }

    /**
     * 全セッションデータの取得
     *
     * @param   string  $sNameSpace
     * @return  array   全セッションデータ
     */
    public function getAll($sNameSpace = self::NAMESPACE_DEFAULT)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // 入力チェック
        $bRetCode = $this->_checkInputKeyNameSpace($sNameSpace);
        // 存在チェック
        $bRetCode = isset($_SESSION[$sNameSpace]);
        if ( $bRetCode !== true ) {
            // 存在しない → 空の配列を返す
            return array();
        }
        // 存在するなら値を返す
        return $_SESSION[$sNameSpace];
    }

    /**
     * 全セッションデータのクリア
     *
     * @param   string  $sNameSpace
     * @return  bool    true
     */
    public function clearAll($sNameSpace = self::NAMESPACE_DEFAULT)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // 入力チェック
        $bRetCode = $this->_checkInputKeyNameSpace($sNameSpace);
        // 存在チェック
        $bRetCode = isset($_SESSION[$sNameSpace]);
        if ( $bRetCode !== true ) {
            // 存在しない → クリア済みとして正常終了
            return true;
        }
        // 存在するなら空の配列にする
        $_SESSION[$sNameSpace] = array();
        return true;
    }

    /**
     * フラッシュデータの初期化
     *
     * @return  bool    true
     */
    protected function initFlashData()
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // フラッシュデータの取得＆クリア
        $this->aFlashData = $this->getAll  (self::NAMESPACE_FLASH);
        $bRetCode         = $this->clearAll(self::NAMESPACE_FLASH);
        return $bRetCode;
    }

    /**
     * フラッシュデータの取得 (前回)
     *
     * @param   string  $sKey
     * @return  mixed   フラッシュデータ
     */
    public function getFlashData($sKey)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // キーチェック
        $bRetCode = $this->_checkInputKey($sKey);
        // 前回情報にあるか？
        $bRetCode = isset($this->aFlashData[$sKey]);
        if ( $bRetCode !== true ) {
            // 無ければNULL
            return NULL;
        }
        // 前回ありなら返す
        return $this->aFlashData[$sKey];
    }

    /**
     * フラッシュデータの取得 (今回)
     *
     * @param   string  $sKey
     * @return  mixed   フラッシュデータ
     */
    public function getFlashDataSet($sKey)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // 今回セットしたフラッシュデータ
        return $this->get($sKey, self::NAMESPACE_FLASH);
    }

    /**
     * フラッシュデータの保存
     *
     * @param   string  $sKey
     * @param   mixed   $mValue
     * @return  bool    true
     */
    public function setFlashData($sKey, $mValue)
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // セッションネームスペース for フラッシュデータを指定して保存
        $bRetCode = $this->set($sKey, $mValue, self::NAMESPACE_FLASH);
        return $bRetCode;
    }

    /**
     * フラッシュデータの復帰
     *
     * @return  bool    true
     */
    public function restoreFlashData()
    {
        // すでに開始しているか？
        if ( $this->bStarted !== true ) {
            // 開始してない → 開始
            return $this->start();
        }
        // セッションネームスペース for フラッシュデータを指定して保存
        $bRetCode      = $this->clearAll(self::NAMESPACE_FLASH);
        foreach ( $this->aFlashData as $sKey => $mValue ) {
            $bRetCode &= $this->setFlashData($sKey, $mValue, self::NAMESPACE_FLASH);
        }
        return $bRetCode;
    }

    /**
     * 入力チェック
     *
     * @param   string  $sKey
     * @param   string  $sNameSpace
     * @return  bool    true
     */
    protected function _checkInput($sKey, $sNameSpace)
    {
        // キーチェック
        $bRetCode = $this->_checkInputKey($sKey);
        // ネームスペースチェック
        $bRetCode = $this->_checkInputKeyNameSpace($sNameSpace);

        return true;
    }

    /**
     * キー入力チェック
     *
     * @param   string  $sKey
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _checkInputKey($sKey)
    {
        // キー入力チェック
        $sKey = trim($sKey);
        if ( $sKey === '' ) {
            // セッション変数名が指定されていない
            throw new \SC\exception\common\parameter\ZeroByteString('キー名が指定されていません。');
        }

        return true;
    }

    /**
     * ネームスペース入力チェック
     *
     * @param   string  $sNameSpace
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _checkInputKeyNameSpace($sNameSpace)
    {
        // ネームスペース入力チェック
        $sNameSpace = trim($sNameSpace);
        if ( $sNameSpace === '' ) {
            // セッションネームスペースが指定されていない
            throw new \SC\exception\common\parameter\ZeroByteString('ネームスペースが指定されていません。');
        }

        return true;
    }
}
