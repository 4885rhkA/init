<?php
/**
 * RecordAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * RecordAO
 */
class RecordAO extends AbstractAO
{
    /**
     * プロパティ型指定があるもののみ保持できる
     *
     * $this->aPropTypesにて指定があるプロパティのみ保持するか否かを判定する
     *
     * @var bool CAN_STORE_ONLY_RESERVED_KEY
     */
    const CAN_STORE_ONLY_RESERVED_KEY = false;
}
