<?php
/**
 * ファイルシステムの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common;

/**
 * ファイルシステムの例外
 */
class filesystem extends \SC\exception\common
{
}
