<?php
/**
 * Adminの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller;

/**
 * Adminの例外
 */
class Admin extends \SC\exception\controller
{
}
