<?php
/**
 * エラーハンドラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * エラーハンドラ
 */
final class ErrorHandler
{
    /**
     * 例外の一覧
     *
     * @var array $aExceptions
     */
    protected $aExceptions = array(
        E_ERROR             => 'Error',                 //      1   0000 0000 0000 0001
        E_RECOVERABLE_ERROR => 'RecoverableError',      //  4,096   0001 0000 0000 0000
        E_WARNING           => 'Warning',               //      2   0000 0000 0000 0010 ログのみ
        E_PARSE             => 'Parse',                 //      4   0000 0000 0000 0100
        E_DEPRECATED        => 'Deprecated',            //  8,192   0010 0000 0000 0000 ログのみ
        E_NOTICE            => 'Notice',                //      8   0000 0000 0000 1000 ログのみ
        E_STRICT            => 'Strict',                //  2,048   0000 1000 0000 0000 ログのみ
        E_CORE_ERROR        => 'CoreError',             //     16   0000 0000 0001 0000
        E_CORE_WARNING      => 'CoreWarning',           //     32   0000 0000 0010 0000
        E_COMPILE_ERROR     => 'CompileError',          //     64   0000 0000 0100 0000
        E_COMPILE_WARNING   => 'CompileWarning',        //    128   0000 0000 1000 0000
        E_USER_ERROR        => 'UserError',             //    256   0000 0001 0000 0000
        E_USER_WARNING      => 'UserWarning',           //    512   0000 0010 0000 0000 ログのみ
        E_USER_NOTICE       => 'UserNotice',            //  1,024   0000 0100 0000 0000 ログのみ
        E_USER_DEPRECATED   => 'UserDeprecated',        // 16,384   0100 0000 0000 0000 ログのみ
    );

    /**
     * エラーレベル
     *
     * @var string MAX_LEVEL
     */
    const MAX_LEVEL = '0111 1111 1111 1111 1111 1111 1111 1111';

    /**
     * エラーハンドリングするエラーレベル
     *
     * @var string HANDLE_LEVEL
     */
    const HANDLE_LEVEL = '0111 1111 1111 1111 1111 1111 1111 1111';

    /**
     * ログ出力するのみのエラーレベル
     *
     * @var string LOG_ONLY_LEVEL
     */
    const LOG_ONLY_LEVEL = '0111 1111 1111 1111 0110 1110 0000 1010';

    /**
     * ログ出力するのみのエラーレベル
     *
     * @var int $iLogOnlyLevel
     */
    protected $iLogOnlyLevel = 2147446282;

    /**
     * 次回のPHPエラーは必ず例外を投げる
     *
     *  この場合にはログに出力しない
     *
     * @var bool $bThrowNextException
     */
    protected $bThrowNextException = false;

    /**
     * ログレベルの一覧
     *
     * @var array $aLogLevel
     */
    protected $aLogLevel = array(
        E_ERROR             => 'error',
        E_RECOVERABLE_ERROR => 'error',
        E_WARNING           => 'warning',
        E_PARSE             => 'error',
        E_DEPRECATED        => 'notice',
        E_NOTICE            => 'notice',
        E_STRICT            => 'notice',
        E_CORE_ERROR        => 'error',
        E_CORE_WARNING      => 'warning',
        E_COMPILE_ERROR     => 'error',
        E_COMPILE_WARNING   => 'warning',
        E_USER_ERROR        => 'error',
        E_USER_WARNING      => 'warning',
        E_USER_NOTICE       => 'notice',
        E_USER_DEPRECATED   => 'notice',
    );

    /**
     * ログレベルに応じてレポートしないクラス
     *
     * @var array $aNoReportClasses
     */
    protected $aNoReportClasses = array(
        E_ERROR             => array(),
        E_RECOVERABLE_ERROR => array(),
        E_WARNING           => array(
            '^Smarty(_|$)',
        ),
        E_PARSE             => array(),
        E_DEPRECATED        => array(
            '^Smarty(_|$)',
        ),
        E_NOTICE            => array(
            '^Smarty(_|$)',
        ),
        E_STRICT            => array(
            '^Smarty(_|$)',
        ),
        E_CORE_ERROR        => array(),
        E_CORE_WARNING      => array(
            '^Smarty(_|$)',
        ),
        E_COMPILE_ERROR     => array(),
        E_COMPILE_WARNING   => array(
            '^Smarty(_|$)',
        ),
        E_USER_ERROR        => array(),
        E_USER_WARNING      => array(
            '^Smarty(_|$)',
        ),
        E_USER_NOTICE       => array(
            '^Smarty(_|$)',
        ),
        E_USER_DEPRECATED   => array(
            '^Smarty(_|$)',
        ),
    );

    /**
     * 常にレポートするか否か
     *
     * @var bool $bReportAll
     */
    protected $bReportAll = false;

    /**
     * インスタンス
     *
     * @var SC\libs\ErrorHandler $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // ログ出力のみを行うレベル指定
        $this->iLogOnlyLevel = bindec(static::LOG_ONLY_LEVEL);
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\ErrorHandler
     */
    protected static function _getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new self();
        }
        return self::$oInstance;
    }

    /**
     * エラーハンドラ登録
     *
     * @return  bool    true
     */
    public static function regist()
    {
        $oSelf    = self::_getInstance();
        $oSelf->_regist();
        return true;
    }

    /**
     * エラーハンドラ登録
     *
     * @return  bool    true
     * @throw   SC\exception\libs\ErrorHandler\CantRegist
     */
    protected function _regist()
    {
        // エラー設定
        ini_set('display_errors',         'off');
        ini_set('display_startup_errors', 'off');
        error_reporting(E_ALL|E_STRICT);

        // エラーハンドリング対象
        $iLevel               = bindec(static::HANDLE_LEVEL);
        // 登録 (１回目の登録ではエラーをハンドリングできない → ２回登録する)
        $aCallback            = array(&$this, 'handle');
        $mRetCode             = set_error_handler($aCallback, $iLevel);
        $mRetCode             = set_error_handler($aCallback, $iLevel);
        if ( $mRetCode === NULL ) {
            // エラーハンドラ登録失敗
            throw new \SC\exception\libs\ErrorHandler\CantRegist("Can't regist error handler");
        }

        // レポートするか？
        $sReportAll           = strtolower(trim((string) ArrayUtil::getValue($_SERVER, 'SC_REPORT_ALL_ERRORS', 'off')));
        if ( $sReportAll === 'on' || $sReportAll === 'true' || $sReportAll === '1' || $sReportAll === '' ) {
            $this->bReportAll = true;
        } else {
            $this->bReportAll = false;
        }

        return true;
    }

    /**
     * エラーハンドラ
     *
     * ハンドリングに失敗した場合にはtrueを返すことで
     * PHP標準のエラーハンドラが作動する
     *
     * @param   int     $iErrLevel
     * @param   string  $sErrMessage
     * @param   string  $sFilename
     * @param   int     $iLineNo
     * @return  bool    エラーハンドリングできたらfalse
     * @throw   SC\exception\php\error\UnknownError
     * @throw   SC\exception\php\error\Error
     * @throw   SC\exception\php\error\RecoverableError
     * @throw   SC\exception\php\error\Warning
     * @throw   SC\exception\php\error\Parse
     * @throw   SC\exception\php\error\Deprecated
     * @throw   SC\exception\php\error\Notice
     * @throw   SC\exception\php\error\Strict
     * @throw   SC\exception\php\error\CoreError
     * @throw   SC\exception\php\error\CoreWarning
     * @throw   SC\exception\php\error\CompileError
     * @throw   SC\exception\php\error\CompileWarning
     * @throw   SC\exception\php\error\UserError
     * @throw   SC\exception\php\error\UserWarning
     * @throw   SC\exception\php\error\UserNotice
     * @throw   SC\exception\php\error\UserDeprecated
     */
    public static function handle($iErrLevel, $sErrMessage, $sFilename, $iLineNo)
    {
        // エラーハンドラインスタンスを取得
        $oSelf              = self::_getInstance();
        // 現在のエラーレポート状態を取得
        $iReportLevel       = error_reporting();
        if ( $oSelf->bThrowNextException === true || ( $iReportLevel !== 0 && ( $iErrLevel & $oSelf->iLogOnlyLevel ) !== $iErrLevel ) ) {
            // レポートになっているので例外を発行
            $bRetCode       = array_key_exists($iErrLevel, $oSelf->aExceptions);
            if ( $bRetCode !== true ) {
                // 未知の例外
                $sException = 'SC\\exception\\php\\error\\UnknownError';
            } else {
                // 既知の例外
                $sException = 'SC\\exception\\php\\error\\' . $oSelf->aExceptions[$iErrLevel];
            }
            $oException     = new $sException($sErrMessage, $iErrLevel);
            // ファイルと行番号をセットして例外を投げる
            $oException->setFile($sFilename);
            $oException->setLine($iLineNo);
            if ( $oSelf->bThrowNextException !== true ) {
                // ログを出力
                $bRetCode       = $oSelf->_log($iErrLevel, $sErrMessage, $sFilename, $iLineNo);
                if ( $bRetCode !== true ) {
                    // ログ出力できなかった場合には標準エラーハンドリングにフォールバック
                    return true;
                }
            } else {
                // 一度投げたら次回は戻す
                $oSelf->bThrowNextException = false;
            }
            throw $oException;
        }
        // レポートするか？
        $bDoReport          = true;
        if ( $oSelf->bReportAll === true ) {
            // 全てのエラーをレポート
            $bDoReport      = true;
        } else {
            // エラーのレポートをするか否かチェック
            $bDoReport      = $oSelf->_checkNoReportClasses($iErrLevel);
        }
        // レポート
        if ( $bDoReport === true ) {
            $bRetCode       = $oSelf->_log($iErrLevel, $sErrMessage, $sFilename, $iLineNo);
            if ( $bRetCode !== true ) {
                // ログ出力できなかった場合には標準エラーハンドリングにフォールバック
                return true;
            }
        }
        return false;
    }

    /**
     * エラー処理のログ
     *
     * @param   int     $iErrLevel
     * @param   string  $sErrMessage
     * @param   string  $sFilename
     * @param   int     $iLineNo
     * @return  bool    true
     */
    protected function _log($iErrLevel, $sErrMessage, $sFilename, $iLineNo)
    {
        // ログ出力のために例外を生成
        $oException = new \SC\exception\php\error\Log($sErrMessage, $iErrLevel);
        $oException->setFile($sFilename);
        $oException->setLine($iLineNo);
        $sMessage   = $oException->__toString();
        $sMessage   = preg_replace('/^#[01] .*\\n/mS', '',               $sMessage);
        $sMessage   = preg_replace('/^#([0-9]+) /mSe', '"#".(\1-2)." "', $sMessage);
        // ログレベルをチェック
        $bRetCode   = array_key_exists($iErrLevel, $this->aLogLevel);
        if ( $bRetCode !== true ) {
            // 未知のログレベル
            $sLevel = $this->aLogLevel[E_ERROR];
        } else {
            // 既知のログレベル
            $sLevel = $this->aLogLevel[$iErrLevel];
        }
        // ログ出力
        $bRetCode   = \Log::$sLevel($sMessage);

        return $bRetCode;
    }

    /**
     * ログ出力のみを行うレベル
     *
     * @return  int     ログ出力を行うレベル
     */
    public static function getLogOnlyLevel()
    {
        $oSelf                = self::_getInstance();
        return $oSelf->iLogOnlyLevel;
    }

    /**
     * ログ出力のみを行うレベル
     *
     * @param   int     $iLogOnlyLevel  ログ出力を行うレベル
     * @return  bool    true
     * @throws  SC\exception\common\parameter\NotAnInt
     */
    public static function setLogOnlyLevel($iLogOnlyLevel)
    {
        // ログ出力のみを行うレベル指定
        $bRetCode             = Validate::isInt($iLogOnlyLevel);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAnInt('Log only level must be int');
        }
        $oSelf                = self::_getInstance();
        $oSelf->iLogOnlyLevel = $iLogOnlyLevel & bindec(static::MAX_LEVEL);
        return true;
    }

    /**
     * 次のPHPエラーは必ず例外を投げる設定をオン
     *
     * @return  bool    true
     */
    public static function setThrowNextExceptionOn()
    {
        $oSelf                      = self::_getInstance();
        $oSelf->bThrowNextException = true;
        return true;
    }

    /**
     * 次のPHPエラーは必ず例外を投げる設定をオフ
     *
     * @return  bool    true
     */
    public static function setThrowNextExceptionOff()
    {
        $oSelf                      = self::_getInstance();
        $oSelf->bThrowNextException = false;
        return true;
    }

    /**
     * エラー画面の表示
     *
     * @param   Exception   $oException
     * @param   int         $iHTTPStatus
     * @return  bool        true
     */
    public static function show(\Exception $oException, $iHTTPStatus)
    {
        $oSelf = static::_getInstance();
        $oSelf->_show($oException, $iHTTPStatus, 'ModelSelector');
        return true;
    }

    /**
     * エラー画面の表示
     *
     * @param   Exception   $oException
     * @param   int         $iHTTPStatus
     * @return  bool        true
     */
    public static function showAdmin(\Exception $oException, $iHTTPStatus)
    {
        $oSelf = static::_getInstance();
        $oSelf->_show($oException, $iHTTPStatus, 'ModelSelectorAdmin');
        return true;
    }

    /**
     * エラー画面の表示
     *
     * @param   Exception   $oException
     * @param   int         $iHTTPStatus
     * @return  NULL
     */
    protected function _show(\Exception $oException, $iHTTPStatus, $sModelSelector)
    {
        $oRequest                             = \Request::getInstance();
        $oResponse                            = \Response::getInstance();
        // テンプレート
        $sTemplateBase                        = constant("SC\\libs\\{$sModelSelector}::BASE");
        $sTemplateDir                         = constant("SC\\libs\\{$sModelSelector}::TEMPLATE_DIR");
        // 環境別ディレクトリの指定を使うか否か
        $iVersionCmp                          = version_compare(SC_PRODUCT_VERSION, '2.0-dev');
        if ( $iVersionCmp < 0 ) {
            $sUseEnvDirDefault                = '0';
        } else {
            $sUseEnvDirDefault                = '1';
        }
        $sUseEnvDir                           = strtolower($oRequest->getServer('SC_USE_ENV_DIR', $sUseEnvDirDefault));
        if ( $sUseEnvDir === '0' || $sUseEnvDir === 'off' || $sUseEnvDir === 'false' ) {
            $sEnvironmentDir                  = 'contents';
        } else {
            $sEnvironmentDir                  = constant("SC\\libs\\{$sModelSelector}::ENV_DIR");
        }
        $oSmarty                              = new Smarty();
        $oSmarty->setTemplateDir($sTemplateBase, $sEnvironmentDir, $sTemplateDir);
        $aTemplateDirs                        = (array) $oSmarty->getTemplateDir();
        $bHasTemplate                         = false;
        $sErrorTempalte                       = $oResponse->getErrorTempalte();
        $sTemplateFile                        = '';
        clearstatcache();
        foreach ( $aTemplateDirs as $sTemplateDir ) {
            $sTemplateFile                    = rtrim($sTemplateDir, "/\\") . '/' . $sErrorTempalte;
            $bHasTemplate                     = file_exists($sTemplateFile);
            if ( $bHasTemplate === true ) {
                break;
            }
        }
        $sHTTPStatus                          = HttpStatus::getMessage($iHTTPStatus);
        if ( $bHasTemplate !== true ) {
            $sAccessTime                      = \Log::getAccessTime();
            $sAccessKey                       = \Log::getAccessKey();
            // テンプレートがない → 素の出力
            $aOutput                          = array(
                '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">',
                '<html>',
                '  <head>',
                "    <title>$iHTTPStatus $sHTTPStatus</title>",
                '  </head>',
                '  <body>',
                "    <h1>$iHTTPStatus $sHTTPStatus</h1>",
                '    <p>システムエラーが発生したため画面を表示することができませんでした。</p>',
                '    <p>システム管理者にご連絡ください。</p>',
                "    <p>アクセスコード： <span>$sAccessKey</span><br />",
                "       アクセスタイム： <span>$sAccessTime</span></p>",
                '  </body>',
                '</html>',
            );
            $sOutput                          = join("\n", $aOutput);
        } else {
            // 予約変数の処理
            $aConstants                       = SmartyConstants::get();
            $aConstants['__HTTP_CODE__']      = $iHTTPStatus;
            $aConstants['__HTTP_MESSAGE__']   = $sHTTPStatus;
            // 予約変数の処理
            $aTplVals                         = array();
            $aTplVals                         = \ArrayUtil::unite($aConstants, $aTplVals, false);
            // テンプレート変数のセット
            $oSmarty->assign($aTplVals);
            // 表示処理
            $sOutput                          = $oSmarty->fetch($sTemplateFile);
            $sResponseTemplate                = $oRequest->getServer('SC_RESPONSE_TEMPLATE', '0');
            if ( $sResponseTemplate === '1' || $sResponseTemplate === 'true' || $sResponseTemplate === 'on' ) {
                $oResponse->addHeader('X-' . SC_PRODUCT_NAME . '-Template', $sTemplateFile, true, NULL, NULL);
            }
        }
        // 表示処理
        $oResponse->setResult($sOutput, $iHTTPStatus);
        $oResponse->out();
        // エラーハンドラの出力では終了する
        exit();
    }

    /**
     * エラーのレポートをするか否かチェック
     *
     * @param   int     $iErrLevel
     * @return  bool    レポートするか否か
     */
    protected function _checkNoReportClasses($iErrLevel)
    {
        // 除外チェック
        $bRetCode   = isset($this->aNoReportClasses[$iErrLevel]);
        if ( $bRetCode !== true ) {
            // 除外指定なし → レポート
            return true;
        }
        $iCount     = count($this->aNoReportClasses[$iErrLevel]);
        if ( $iCount < 1 ) {
            // 除外指定なし → レポート
            return true;
        }
        // バックトレース情報を取得
        $aBackTrace = array_slice(debug_backtrace(2), 2);
        $sClass     = '';
        foreach ( $aBackTrace as $aInfo ) {
            $sClass = ArrayUtil::getValue($aInfo, 'class', '');
            if ( $sClass !== '' ) {
                break;
            }
        }
        if ( $sClass === '' ) {
            // クラスがない → レポート
            return true;
        }
        // クラスチェック
        foreach ( $this->aNoReportClasses[$iErrLevel] as $sClassRE ) {
            $bFound = (bool) preg_match('#' . str_replace('#', "\\#", $sClassRE) . '#Su', $sClass);
            if ( $bFound === true ) {
                // 除外
                return false;
            }
        }
        return true;
    }
}
