<?php
/**
 * Publicモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * Publicモデルコントローラ
 */
class PublicModel extends AbstractModel
{
    /**
     * 公開ディレクトリのベース
     *
     * @var string PUBLIC_BASE
     */
    const PUBLIC_BASE = \SC\libs\ModelSelector::BASE;

    /**
     * 公開ディレクトリの指定
     *
     * @var string PUBLIC_DIR
     */
    const PUBLIC_DIR = \SC\libs\ModelSelector::PUBLIC_DIR;

    /**
     * 強制的にダウンロードさせるか否か
     *
     * @var bool FORCE_DOWNLOAD
     */
    const FORCE_DOWNLOAD = false;

    /**
     * クラス接尾辞
     *
     * @var string CLASS_SUFFIX
     */
    const CLASS_SUFFIX = '';

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ファイルをダウンロード
        $sFilename        = trim(\Util::refine($this->aSelector['filename']), '/');
        $sFilename        = \Util::normalizePath(static::PUBLIC_BASE . '/' . $this->aSelector['env_dir'] . '/' . static::PUBLIC_DIR . '/' . $sFilename);
        if ( static::FORCE_DOWNLOAD !== true ) {
            // MIMEタイプを取得
            $sMime            = trim(\ArrayUtil::getValue($this->aSelector, 'mime', ''));
            $sMimeLower       = strtolower($sMime);
            if ( $sMimeLower === '' || $sMimeLower === 'auto' ) {
                $oFile        = call_user_func(array('\SC\libs\File' . static::CLASS_SUFFIX, 'getInstance'), $sFilename);
                $sMime        = $oFile->getMimeType();
            } else {
                $oFile        = NULL;
            }
            // MIME文字コードを取得
            $sCharset         = trim(\SC\libs\ArrayUtil::getValue($this->aSelector, 'charset', ''));
            $sCharsetLower    = strtolower($sCharset);
            if ( $sCharsetLower === '' || $sCharsetLower === 'auto' ) {
                if ( $oFile === NULL ) {
                    $oFile    = call_user_func(array('\SC\libs\File' . static::CLASS_SUFFIX, 'getInstance'), $sFilename);
                    $sCharset = $oFile->getMimeType();
                }
            }
        } else {
            // 強制的にダウンロードさせる
            $sMime            = 'application/force-download';
            $sCharset         = 'UTF-8';
            $sBasename        = basename($sFilename);
            $this->oResponse->addHeader('Content-Disposition', 'attachment; filename="' . $sBasename . '"', true, NULL, NULL);
        }
        $this->oResponse->setDownload($sFilename, $this->aSelector['status'], $sMime, $sCharset);
        return true;
    }
}
