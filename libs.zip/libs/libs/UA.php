<?php
/**
 * UA
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * UA
 */
class UA
{
    /**
     * インスタンス
     *
     * @var SC\libs\UA $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * ユーザーエージェント
     *
     * @var string $sUserAgent
     */
    protected $sUserAgent = '';

    /**
     * 端末のOSバージョン
     *
     * @var string $sVersion
     */
    protected $sVersion = '';

    /**
     * 端末のOSタイプ：未判定
     *
     * @var int TYPE_NEVER
     */
    const TYPE_NEVER = -1;

    /**
     * 端末のOSタイプ：不明なOS
     *
     * @var int TYPE_UNKNOWN
     */
    const TYPE_UNKNOWN = 0;

    /**
     * 端末のOSタイプ：iOS
     *
     * @var int TYPE_IOS
     */
    const TYPE_IOS = 10;

    /**
     * 端末のOSタイプ：Android
     *
     * @var int TYPE_ANDROID
     */
    const TYPE_ANDROID = 20;

    /**
     * 端末のOSタイプ：Windows Phone
     *
     * @var int TYPE_WINDOWS_PHONE
     */
    const TYPE_WINDOWS_PHONE = 30;

    /**
     * 端末のOSタイプ：BlackBerry
     *
     * @var int TYPE_BLACKBERRY
     */
    const TYPE_BLACKBERRY = 40;

    /**
     * 端末のOSタイプ
     *
     * @var int $iType
     */
    protected $iType = self::TYPE_NEVER;

    /**
     * スマートフォンか否か
     *
     * @var bool $bSmartPhone
     */
    protected $bSmartPhone = false;

    /**
     * タブレットか否か
     *
     * @var bool $bTablet
     */
    protected $bTablet = false;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\UA
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
            self::$oInstance->_parse();
        }
        return self::$oInstance;
    }

    /**
     * パース
     *
     * @return  bool    true
     */
    protected function _parse()
    {
        // ユーザーエージェントを取得
        $this->sUserAgent               = Request::getServer('HTTP_USER_AGENT');

        // ex:
        // iOS              Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7
        // Android          Mozilla/5.0 (Linux; U; Android 2.3.6; ja-jp; SC-03D Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1
        // Windows Phone    Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; T-01B; Windows Phone 6.5.3.5)
        // BlackBerry1      BlackBerry9300/5.0.0.1007 Profile/MIDP-2.1 Configuration/CLDC-1.1 VendorID/220
        // BlackBerry2      Mozilla/5.0 (BlackBerry; U; BlackBerry 9780; ja) AppleWebKit/534.8+ (KHTML, like Gecko) Version/6.0.0.587 Mobile Safari/534.8+
        $bFound                         = (bool) preg_match('#\b(iPod|iPad|iPhone|Android|Windows Phone|BlackBerry[0-9]*)\b#i', $this->sUserAgent, $aMatches);
        if ( $bFound !== true ) {
            // ユーザーエージェントが見つからなかった
            $this->iType                = static::TYPE_UNKNOWN;
            $this->sInfo                = '';
            $this->sVersion             = '';
            return true;
        }

        // タイプ
        $this->sInfo                    = $aMatches[1];
        $sInfo                          = strtolower($this->sInfo);
        $this->bSmartPhone              = false;
        $this->bTablet                  = false;
        switch ( $sInfo ) {
            case 'ipad':
                $this->bTablet          = true;
            case 'iphone':
            case 'ipod':
                $this->iType            = static::TYPE_IOS;
                $this->sVersion         = (string) preg_replace('#^.*\b(iPod(?: touch)?|iPad|iPhone(?: Simulator)?);(?: U;)? CPU(?: iPhone)? OS ([0-9]+(?:_[0-9]+)+) like Mac OS X\b.*$#i', '\2', $this->sUserAgent);
                if ( $this->bTablet === false ) {
                    $this->bSmartPhone  = true;
                }
                break;

            case 'android':
                $this->iType            = static::TYPE_ANDROID;
                $this->sVersion         = (string) preg_replace('#^.* Android ([0-9]+(\.[0-9]+)+);.*$#i', '\1', $this->sUserAgent);
                $bMobile                = (bool)   preg_match('#\sMobile Safari/[0-9]#i', $this->sUserAgent);
                if ( $bMobile !== true ) {
                    $this->sInfo .= ' Tablet';
                    $this->bTablet      = true;
                } else {
                    $this->bSmartPhone  = true;
                }
                break;

            case 'windows phone':
                $this->iType            = static::TYPE_WINDOWS_PHONE;
                $this->sVersion         = (string) preg_replace('#^.* Windows Phone ([0-9]+(\.[0-9]+)+)\b.*$#i', '\1', $this->sUserAgent);
                $this->bSmartPhone      = true;
                break;

            case 'blackberry':
                $this->iType            = static::TYPE_BLACKBERRY;
                $this->sVersion         = (string) preg_replace('#^.*\b(BlackBerry[0-9]+/([0-9]+(\.[0-9]+)+) |BlackBerry [0-9]+; .*\bVersion/([0-9]+(\.[0-9]+)+)\b).*$#i', '\2\4', $this->sUserAgent);
                $this->bSmartPhone      = true;
                break;

            default:
                $this->iType            = static::TYPE_UNKNOWN;
                $this->sVersion         = '';
                break;
        }
        return true;
    }

    /**
     * iOS端末か否か
     *
     * @return  bool    true/false
     */
    public static function isIOS()
    {
        $oSelf = static::getInstance();
        if ( $oSelf->iType === static::TYPE_IOS ) {
            return true;
        }
        return false;
    }

    /**
     * Android端末か否か
     *
     * @return  bool    true/false
     */
    public static function isAndroid()
    {
        $oSelf = static::getInstance();
        if ( $oSelf->iType === static::TYPE_ANDROID ) {
            return true;
        }
        return false;
    }

    /**
     * Windows Phone端末か否か
     *
     * @return  bool    true/false
     */
    public static function isWindowsPhone()
    {
        $oSelf = static::getInstance();
        if ( $oSelf->iType === static::TYPE_WINDOWS_PHONE ) {
            return true;
        }
        return false;
    }

    /**
     * BlackBerry端末か否か
     *
     * @return  bool    true/false
     */
    public static function isBlackBerry()
    {
        $oSelf = static::getInstance();
        if ( $oSelf->iType === static::TYPE_BLACKBERRY ) {
            return true;
        }
        return false;
    }

    /**
     * スマートフォン端末か否か(タブレットは含まない)
     *
     * @return  bool    true/false
     */
    public static function isSmartPhone()
    {
        $oSelf = static::getInstance();
        return $oSelf->bSmartPhone;
    }

    /**
     * タブレット端末か否か
     *
     * @return  bool    true/false
     */
    public static function isTablet()
    {
        $oSelf = static::getInstance();
        return $oSelf->bTablet;
    }

    /**
     * ユーザーエージェント情報
     *
     * @return  string  ユーザーエージェント情報を取得
     */
    public static function get()
    {
        $oSelf = static::getInstance();
        return $oSelf->sUserAgent;
    }

    /**
     * ユーザーエージェントタイプ
     *
     * @return  int     ユーザーエージェントタイプ
     */
    public static function getType()
    {
        $oSelf = static::getInstance();
        return $oSelf->iType;
    }

    /**
     * ユーザーエージェント情報
     *
     * @return  string  ユーザーエージェント情報を取得
     */
    public static function getInfo()
    {
        $oSelf = static::getInstance();
        return $oSelf->sInfo;
    }

    /**
     * ユーザーエージェントのバージョン
     *
     * @return  string  ユーザーエージェントのバージョンを取得
     */
    public static function getVersion()
    {
        $oSelf = static::getInstance();
        return $oSelf->sVersion;
    }
}
