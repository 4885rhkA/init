<?php
/**
 * UpdateCondAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * UpdateCondAO
 */
class UpdateCondAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'where'      => 'string',   // WHERE句
    );
}
