<?php
/**
 * エラー例外 (E_ERROR)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * エラー例外 (E_ERROR)
 */
class Error extends \SC\exception\php\error
{
}
