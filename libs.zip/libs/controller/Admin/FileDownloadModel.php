<?php
/**
 * ファイルダウンロードモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイルダウンロードモデルコントローラ
 */
class FileDownloadModel extends DownloadModel
{
    /**
     * 公開ディレクトリのベース
     *
     * @var string PUBLIC_BASE
     */
    const PUBLIC_BASE = \SC\libs\ModelSelector::BASE;

    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 公開ディレクトリの指定
     *
     * @var string PUBLIC_DIR
     */
    const PUBLIC_DIR = '.';

    /**
     * 処理
     *
     * @return  true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage                = \SC\model\Stage::getInstance();

        // PATH_INFOからステージ種別を取得
        $sPathInfo                   = $this->oRequest->getPathInfo();
        $sStage                      = $this->oStage->getStageName($sPathInfo);

        // リクエストパラメータからファイル名を取得
        $sFilepath                   = $this->oRequest->getRequest('path');
        $sFilename                   = $this->oStage->downloadFile($sStage, $sFilepath);

        $this->aSelector['filename'] = $sFilename;

        return parent::_process();
    }
}
