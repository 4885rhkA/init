<?php
/**
 * ログアウトモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ログアウトモデルコントローラ
 */
class LogoutModel extends AbstractJSONModel
{
    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        $this->oLogin->logout();

        return parent::_process();
    }
}
