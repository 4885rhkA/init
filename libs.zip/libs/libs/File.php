<?php
/**
 * File
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * File
 */
class File extends \SplFileInfo
{
    /**
     * ベース
     *
     * @var string BASE
     */
    const BASE = AP_DIR;

    /**
     * 中間ディレクトリ
     *
     * @var array $sIntermediate
     */
    protected $sIntermediate = array(
        'contents',
        'tmp',
        'log',
    );

    /**
     * セキュリティチェック
     *
     * @var string SECURE
     */
    const SECURE = true;

    /**
     * ファイル名
     *
     * @var string $sFilename
     */
    protected $sFilename = '';

    /**
     * finfoインスタンス
     *
     * @var \finfo $oFileinfo
     */
    private static $oFileinfo = NULL;

    /**
     * finfoインスタンス
     *
     * @var \finfo $oFinfo
     */
    protected $oFinfo = NULL;

    /**
     * ファイルタイプ (fifo, char, dir, block, link, file, socket, unknown)
     *
     * @var string $sFileType
     */
    protected $sFileType = '';

    /**
     * MIME-Type
     *
     * @var string $sMimeType
     */
    protected $sMimeType = 'application/octet-stream';

    /**
     * 拡張子別MIME-Type
     *
     * @var array $aMimeTypes
     */
    protected $aMimeTypes = array(
        'epub'  => 'application/epub+zip',
        'json'  => 'application/json',
        'doc'   => 'application/msword',
        'dot'   => 'application/msword',
        'bin'   => 'application/octet-stream',
        'lzh'   => 'application/octet-stream',
        'pdf'   => 'application/pdf',
        'rdf'   => 'application/rdf+xml',
        'rss'   => 'application/rss+xml',
        'rtf'   => 'application/rtf',
        'cab'   => 'application/vnd.ms-cab-compressed',
        'xls'   => 'application/vnd.ms-excel',
        'xlt'   => 'application/vnd.ms-excel',
        'eot'   => 'application/vnd.ms-fontobject',
        'chm'   => 'application/vnd.ms-htmlhelp',
        'ppt'   => 'application/vnd.ms-powerpoint',
        'xps'   => 'application/vnd.ms-xpsdocument',
        'pptx'  => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'sldx'  => 'application/vnd.openxmlformats-officedocument.presentationml.slide',
        'ppsx'  => 'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
        'potx'  => 'application/vnd.openxmlformats-officedocument.presentationml.template',
        'xlsx'  => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'xlxt'  => 'application/vnd.openxmlformats-officedocument.spreadsheetml.template',
        'docx'  => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'dotx'  => 'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
        'wsdl'  => 'application/wsdl+xml',
        '7z'    => 'application/x-7z-compressed',
        'bz'    => 'application/x-bzip',
        'bz2'   => 'application/x-bzip2',
        'woff'  => 'application/x-font-woff',
        'tfc'   => 'application/x-font-ttf',
        'tff'   => 'application/x-font-ttf',
        'rar'   => 'application/x-rar-compressed',
        'swf'   => 'application/x-shockwave-flash',
        'tar'   => 'application/x-tar',
        'xhtml' => 'application/xhtml+xml',
        'xml'   => 'application/xml',
        'xsl'   => 'application/xml',
        'dtd'   => 'application/xml-dtd',
        'xslt'  => 'application/xslt+xml',
        'zip'   => 'application/zip',
        'bmp'   => 'image/bmp',
        'gif'   => 'image/gif',
        'jpeg'  => 'image/jpeg',
        'jpg'   => 'image/jpeg',
        'png'   => 'image/png',
        'svg'   => 'image/svg+xml',
        'svgz'  => 'image/svg+xml',
        'tiff'  => 'image/tiff',
        'tif'   => 'image/tiff',
        'ico'   => 'image/x-icon',
        'css'   => 'text/css',
        'csv'   => 'text/csv',
        'html'  => 'text/html',
        'htm'   => 'text/html',
        'txt'   => 'text/plain',
        'text'  => 'text/plain',
        'log'   => 'text/plain',
        'tsv'   => 'text/tab-separated-values',
        'js'    => 'text/javascript',
        'jsonp' => 'text/javascript',
        'mpeg'  => 'video/mpeg',
        'mpg'   => 'video/mpeg',
        'mov'   => 'video/quicktime',
        'wmv'   => 'video/x-ms-wmv',
        'avi'   => 'video/x-msvideo',
    );

    /**
     * 書き込み時に上書きするか否か
     *
     * @var bool $bOverwrite
     */
    protected $bOverwrite = true;

    /**
     * 再帰的に削除するか否か
     *
     * @var bool $bRecursively
     */
    protected $bRecursively = true;

    /**
     * 書き込み時に例外を投げるか否か
     *
     * @var bool $bThrowException
     */
    protected $bThrowException = true;

    /**
     * コンストラクタ
     *
     * @param   string  $sFilename      ファイル名
     */
    public function __construct($sFilename)
    {
        // コール元チェック
        $sClass          = get_class($this);
        $aBTrace         = debug_backtrace(2);
        $aCallInfo       = ArrayUtil::getValue($aBTrace, 1, array());
        $sCaller         = ArrayUtil::getValue($aCallInfo, 'class', '');
        $bFromSelf       = true;
        if ( $sCaller === '' ) {
            $bFromSelf   = false;
        } else {
            $bFromSelf   = Util::is_a($sCaller, __CLASS__);
        }
        if ( $bFromSelf !== true ) {
            // コール元は自クラスではない
            $sMethod     = __FUNCTION__;
            $sMessage    = "Call to protected {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
            trigger_error($sMessage, E_USER_ERROR);
        }
        // ファイルのチェック
        $sFilename       = $this->_checkFile($sFilename);
        // 親クラスのコンストラクタ
        parent::__construct($sFilename);
        // クラス指定
        $this->setInfoClass($sClass);
        // finfoインスタンスを取得
        $this->oFinfo    = $this->_getFinfo();
        // プロパティを保持
        $this->_updateFileinfo();
    }

    /**
     * インスタンスを取得する
     *
     * @param   string  $sFilename      ファイル名
     * @return  SC\libs\File
     */
    public static function getInstance($sFilename)
    {
        $oSelf = new static($sFilename);
        return $oSelf;
    }

    /**
     * インスタンスを取得する
     *
     * @param   \SplFileInfo    $oFileInfo      ファイルオブジェクト
     * @return  SC\libs\File
     */
    public static function getInstanceFrom(\SplFileInfo $oFileInfo)
    {
        $sFilename = $oFileInfo->getPathname();
        $oSelf     = new static($sFilename);
        return $oSelf;
    }

    /**
     * finfoインスタンスを取得する
     *
     * @return  \finfo
     */
    private function _getFinfo()
    {
        // 存在しなければ作成
        if ( self::$oFileinfo === NULL ) {
            self::$oFileinfo = new \finfo();
        }
        return self::$oFileinfo;
    }

    /**
     * ファイルのチェック
     *
     * @param   string  $sFilename      ファイル名
     * @return  string  ファイル名
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\libs\File\AccessDenied
     */
    protected function _checkFile($sFilename)
    {
        // 文字列か？
        $bRetCode           = Validate::isStringNotZero($sFilename);
        if ( $bRetCode !== true ) {
            // 文字列ではない
            throw new \SC\exception\common\parameter\ZeroByteString('Filename must be non zero byte string.');
        }
        // セキュリティチェック
        if ( static::SECURE !== false ) {
            $sFilename      = Util::normalizePath($sFilename,                                '', '/');
            $bCheck         = false;
            foreach ( $this->sIntermediate as $sIntermediate ) {
                $sBaseDir   = Util::normalizePath(static::BASE . '/' . $sIntermediate, '', '/') . '/';
                $iCmp       = strncmp($sBaseDir, $sFilename, strlen($sBaseDir));
                if ( $iCmp === 0 ) {
                    // 1つでも有効ならOK
                    $bCheck = true;
                    break;
                }
            }
            if ( $bCheck === false ) {
                // アクセス不可例外
                throw new \SC\exception\libs\File\AccessDenied("Access denied: file='$sFilename' for base dir.");
            }
        }
        return (string) $sFilename;
    }

    /**
     * ファイルの情報を取得
     *
     * @return  bool true
     */
    protected function _updateFileinfo()
    {
        $this->sFilename       = $this->getPathname();
        // ファイル情報
        $this->sFileType       = '';
        $this->sMimeType       = 'application/octet-stream';
        // 読めるか？
        clearstatcache();
        $bRetCode              = is_readable($this->sFilename);
        if ( $bRetCode === true ) {
            // 読めるならファイルの情報を取得
            $this->sFileType   = filetype($this->sFilename);
            if ( $this->sFileType === 'dir' ) {
                $sMimeType     = '';
            } else {
                $sExt          = strtolower($this->getExtension());
                $sMimeType     = ArrayUtil::getValue($this->aMimeTypes, $sExt, '');
                if ( $sMimeType === '' ) {
                    $sMimeType = str_replace('text/x-c++', 'text/plain', $this->oFinfo->file($this->sFilename, FILEINFO_NONE|FILEINFO_PRESERVE_ATIME|FILEINFO_MIME_TYPE));
                }
            }
        } else {
            // 読めないときにはそのまま解析
            $sExt              = strtolower($this->getExtension());
            $sMimeType         = ArrayUtil::getValue($this->aMimeTypes, $sExt, '');
        }
        if ( $sMimeType !== '' ) {
            $this->sMimeType   = $sMimeType;
        }
        return true;
    }

    /**
     * 読み込み
     *
     * @param   bool    $bThrowException    エラー時に例外を投げるか
     * @return  string  ファイルの内容
     * @throw   SC\exception\libs\File\CantRead
     * @throw   SC\exception\libs\File\NotReadable
     */
    public function read($bThrowException = NULL)
    {
        // オプション指定
        if ( $bThrowException === NULL ) {
            $bThrowException = $this->bThrowException;
        } else {
            $bThrowException = (bool) $bThrowException;
        }
        // ファイルの存在チェック
        clearstatcache();
        $bRetCode            = is_readable($this->sFilename);
        if ( $bRetCode === true ) {
            // 読み込み可能なら返す
            $sData           = file_get_contents($this->sFilename);
            if ( $sData !== false ) {
                // 正常なら返す
                return $sData;
            }
            // 読み込み可能なファイルが存在しない
            if ( $bThrowException === true ) {
                throw new \SC\exception\libs\File\CantRead("Can't read file: file='{$this->sFilename}'.");
            }
            // エラーなら空文字を返す
            return '';
        }
        // 読み込み可能なファイルが存在しない
        if ( $bThrowException === true ) {
            throw new \SC\exception\libs\File\NotReadable("File is not readable: file='{$this->sFilename}'.");
        }
        // エラーなら空文字を返す
        return '';
    }

    /**
     * 書き込み
     *
     * @param   string  $sData              書き込みデータ
     * @param   bool    $bOverwrite         上書きするかどうか
     * @param   bool    $bThrowException    エラー時に例外を投げるか
     * @return  int     書き込みサイズ
     * @throw   SC\exception\libs\File\CantWrite
     */
    public function write($sData, $bOverwrite = NULL, $bThrowException = NULL)
    {
        // オプション指定
        if ( $bOverwrite === NULL ) {
            $bOverwrite      = $this->bOverwrite;
        } else {
            $bOverwrite      = (bool) $bOverwrite;
        }
        if ( $bThrowException === NULL ) {
            $bThrowException = $this->bThrowException;
        } else {
            $bThrowException = (bool) $bThrowException;
        }
        // 入力チェック
        $sData               = (string) $sData;
        $iLength             = strlen($sData);
        if ( $iLength === 0 ) {
            // 書き込みデータはなし → touch
            $bRetCode        = $this->touch(NULL, NULL, $bThrowException);
            // touch成功時 → 0を返す / touch失敗時 → 0を返す or 例外
            return 0;
        }
        try {
            // 書き込みチェック
            $this->_checkForWrite($this->sFilename, $bOverwrite);
        } catch (\SC\exception\libs\File $oException) {
            // 例外が発生したか？
            if ( $bThrowException === true ) {
                throw $oException;
            }
            return 0;
        }
        // 書き込みできるので書く
        $iOutSize            = file_put_contents($this->sFilename, $sData, LOCK_EX);
        clearstatcache();
        if ( $iOutSize === false ) {
            // 書き込み失敗
            if ( $bThrowException === true ) {
                throw new \SC\exception\libs\File\CantWrite("Can't write file: file='{$this->sFilename}'.");
            }
            return 0;
        }
        return $iOutSize;
    }

    /**
     * 作成・更新(touch)
     *
     * @param   int     $iMTime             更新日時のタイムスタンプ
     * @param   int     $iATime             アクセス日時のタイムスタンプ
     * @param   bool    $bThrowException    エラー時に例外を投げるか
     * @return  bool    実行成否
     * @throw   SC\exception\libs\File\CantTouch
     */
    public function touch($iMTime = NULL, $iATime = NULL, $bThrowException = NULL)
    {
        // オプション指定
        if ( $bThrowException === NULL ) {
            $bThrowException = $this->bThrowException;
        } else {
            $bThrowException = (bool) $bThrowException;
        }
        try {
            // タイムスタンプチェック
            $iMTime          = $this->_checkForTouch($iMTime);
            $iATime          = $this->_checkForTouch($iATime);
        } catch (\SC\exception\libs\File $oException) {
            // 例外が発生したか？
            if ( $bThrowException === true ) {
                throw $oException;
            }
            return false;
        }
        // 書き込みできるのでtouch
        $bRetCode            = touch($this->sFilename, $iMTime, $iATime);
        clearstatcache();
        if ( $bRetCode === false ) {
            // touch失敗
            if ( $bThrowException === true ) {
                throw new \SC\exception\libs\File\CantTouch("Can't touch file: file='{$this->sFilename}'.");
            }
            return false;
        }
        return true;
    }

    /**
     * 書き込み可能かチェック
     *
     * @param   string  $sPath          パス
     * @param   bool    $bOverwrite     上書きするか否か
     * @return  bool    true
     * @throw   SC\exception\libs\File\ADirectory
     * @throw   SC\exception\libs\File\NotADirectory
     * @throw   SC\exception\libs\File\NotWritable
     * @throw   SC\exception\libs\File\CantBeOverwritten
     * @throw   SC\exception\libs\File\CantMkdir
     */
    protected function _checkForWrite($sPath, $bOverwrite)
    {
        // ファイルの存在チェックだけ先に行う
        $bRetCode            = file_exists($sPath);
        if ( $bRetCode === true ) {
            // 存在する → ディレクトリか？
            $bRetCode        = is_dir($sPath);
            if ( $bRetCode === true ) {
                // ディレクトリ
                throw new \SC\exception\libs\File\ADirectory("Path is a directory: path='$sPath'.");
            }
            // 存在する → 書き込み可能？
            $bRetCode        = is_writable($sPath);
            if ( $bRetCode !== true ) {
                // 書き込み権限ない
                throw new \SC\exception\libs\File\NotWritable("Path is not writable: path='$sPath'.");
            }
            // 存在して書き込み可能 → 上書き？
            if ( $bOverwrite !== true ) {
                // 上書きしない
                throw new \SC\exception\libs\File\CantBeOverwritten("Path can't be overwritten: path='$sPath'.");
            }
            // 存在してディレクトリではなく書き込み可能で上書き
            return true;
        }
        // 存在しない → 親ディレクトリの権限チェック
        $sParent             = preg_replace('#[/\\\\][^/\\\\]*$#uS', '', $sPath);
        $bRetCode            = file_exists($sParent);
        if ( $bRetCode === true ) {
            // 存在する → ディレクトリか？
            $bRetCode        = is_dir($sParent);
            if ( $bRetCode !== true ) {
                // ディレクトリではない
                throw new \SC\exception\libs\File\NotADirectory("Parent is not a directory: path='$sParent'.");
            }
            // 存在する → 書き込み可能？
            $bRetCode        = is_writable($sParent);
            if ( $bRetCode !== true ) {
                // 書き込み権限ない
                throw new \SC\exception\libs\File\NotWritable("Parent is not writable: path='$sParent'.");
            }
            // 存在してディレクトリで書き込み可能
            return true;
        }
        // 存在しない → 親ディレクトリを作成する
        try {
            // 再帰的にディレクトリを作成
            \SC\libs\ErrorHandler::setThrowNextExceptionOn();
            $bRetCode        = mkdir($sParent, 0777, true);
            \SC\libs\ErrorHandler::setThrowNextExceptionOff();
            if ( $bRetCode !== true ) {
                // 親ディレクトリの作成失敗
                throw new \SC\exception\libs\File\CantMkdir("Can't mkdir for parent: path='$sParent'.");
            }
        } catch (\SC\exception\php\error $oException) {
            // PHPエラー例外が発生した
            throw new \SC\exception\libs\File\CantMkdir("Can't mkdir for parent: path='$sParent'.", $oException);
        }
        return true;
    }

    /**
     * タイムスタンプチェック
     *
     * @param   int     $iTime      タイムスタンプ
     * @param   bool    $bOverwrite     上書きするか否か
     * @return  int     タイムスタンプ
     * @throw   SC\exception\libs\File\NotATimestamp
     */
    protected function _checkForTouch($iTime)
    {
        // 入力チェック
        if ( $iTime === NULL ) {
            // NULLはOK
            return time();
        }
        $bRetCode = Validate::isInt($iTime);
        if ( $bRetCode !== true ) {
            // タイムスタンプではない
            throw new \SC\exception\libs\File\NotATimestamp(\Debug::dump($iTime, 'Argument 1 is not a timestamp as', false));
        }
        $iTime    = (int) $iTime;
        return $iTime;
    }

    /**
     * ファイルの削除 (unlinkは自動的にキャッシュをクリアしてくれる)
     *
     * @param   bool    $bRecursively       ディレクトリの場合に再帰的に削除するか
     * @param   bool    $bThrowException    エラー時に例外を投げるか
     * @return  int     削除したファイルの数
     */
    public function remove($bRecursively = NULL, $bThrowException = NULL)
    {
        return $this->_remove($this->sFilename, $bRecursively, $bThrowException);
    }

    /**
     * ファイルの削除 (unlinkは自動的にキャッシュをクリアしてくれる)
     *
     * @param   string  $sPath              削除するパス
     * @param   bool    $bRecursively       ディレクトリの場合に再帰的に削除するか
     * @param   bool    $bThrowException    エラー時に例外を投げるか
     * @return  int     削除したファイルの数
     * @throw   \SC\exception\libs\File\DoesNotExist
     * @throw   \SC\exception\libs\File\NotWritable
     * @throw   \SC\exception\libs\File\CantRemove
     */
    protected function _remove($sPath, $bRecursively = NULL, $bThrowException = NULL)
    {
        // オプション指定
        if ( $bRecursively === NULL ) {
            $bRecursively    = $this->bRecursively;
        } else {
            $bRecursively    = (bool) $bRecursively;
        }
        if ( $bThrowException === NULL ) {
            $bThrowException = $this->bThrowException;
        } else {
            $bThrowException = (bool) $bThrowException;
        }
        // ファイルの存在チェック
        $bRetCode            = file_exists($sPath);
        if ( $bRetCode !== true ) {
            // 存在しないファイルは削除できない
            if ( $bThrowException === true ) {
                throw new \SC\exception\libs\File\DoesNotExist("Path does not exist: path='{$sPath}'.");
            }
            return 0;
        }
        // 存在する → 書き込み可能？
        $bRetCode            = is_writable($sPath);
        if ( $bRetCode !== true ) {
            // 書き込み権限ない
            throw new \SC\exception\libs\File\NotWritable("Path is not writable: path='$sPath'.");
        }
        // 存在して書き込み可能 → ディレクトリか？
        $bRetCode            = is_dir($sPath);
        if ( $bRetCode !== true ) {
            // ディレクトリじゃないのでunlink
            \Log::trace("Remove file: '$sPath'");
            $bRetCode        = unlink($sPath);
            if ( $bRetCode !== true ) {
                // 削除失敗
                if ( $bThrowException === true ) {
                    throw new \SC\exception\libs\File\CantRemove("Can't remove file: file='{$sPath}'.");
                }
                return 0;
            }
            return 1;
        }
        // ディレクトリ
        try {
            $iCount          = $this->_rmdir($sPath, $bRecursively);
        } catch (\SC\exception\libs\File $oException) {
            // 例外が発生したか？
            if ( $bThrowException === true ) {
                throw $oException;
            }
            return 0;
        }
        return $iCount;
    }

    /**
     * ディレクトリの削除
     *
     * @param   string  $sPath              削除するパス
     * @param   bool    $bRecursively       再帰的に削除するか
     * @return  int     削除したファイルの数
     * @throw   \SC\exception\libs\File\CantRemoveRecursively
     */
    protected function _rmdir($sPath, $bRecursively = NULL)
    {
        try {
            // ディレクトリの削除をしてみる
            \SC\libs\ErrorHandler::setThrowNextExceptionOn();
            $bRetCode = rmdir($sPath);
            \SC\libs\ErrorHandler::setThrowNextExceptionOff();
            if ( $bRetCode === true ) {
                // 削除成功
                \Log::trace("Remove dir:  '$sPath'");
                return 1;
            }
            // 削除失敗 → 再帰的に削除
        } catch (\SC\exception\php\error $oException) {
            // PHPエラー例外が発生した → 再帰的に削除
        }
        if ( $bRecursively !== true ) {
            // 再帰的に削除しない → 例外
            throw new \SC\exception\libs\File\CantRemoveRecursively("Can't remove directory recursively: path='{$sPath}'.");
        }
        // ファイルの一覧を取得
        $aFiles       = Util::getFileList($sPath, '', false, false, NULL, true, true);
        $iCount       = 0;
        foreach ( $aFiles as $sFilename ) {
            // 子を再帰的に削除
            $iCount  += $this->_remove($sFilename, $bRecursively);
        }
        // 再度ディレクトリの削除をしてみる
        \SC\libs\ErrorHandler::setThrowNextExceptionOn();
        \Log::trace("Remove dir:  '$sPath'");
        $bRetCode = rmdir($sPath);
        \SC\libs\ErrorHandler::setThrowNextExceptionOff();
        // 削除成功
        return $iCount+1;
    }

    /**
     * ファイルの移動・名前変更
     *
     * @param   string  $sDestPath          ファイル名
     * @param   bool    $bOverwrite         上書きするかどうか
     * @param   bool    $bThrowException    エラー時に例外を投げるか
     * @return  int     成功したかどうか
     */
    public function moveTo($sDestPath, $bOverwrite = NULL, $bThrowException = NULL)
    {
        // オプション指定
        if ( $bOverwrite === NULL ) {
            $bOverwrite      = $this->bOverwrite;
        } else {
            $bOverwrite      = (bool) $bOverwrite;
        }
        if ( $bThrowException === NULL ) {
            $bThrowException = $this->bThrowException;
        } else {
            $bThrowException = (bool) $bThrowException;
        }
        // 移動先のクラスを作る
        $oDestination        = static::getInstance($sDestPath);
        try {
            // 移動チェック
            $this->_checkForMove($oDestination, $bOverwrite);
        } catch (\SC\exception\libs\File $oException) {
            // 例外が発生したか？
            if ( $bThrowException === true ) {
                // リスロー
                throw $oException;
            }
            // 失敗時には書き込み
            return false;
        }
        // 存在する場合には削除
        $bRetCode            = $oDestination->isFile();
        if ( $bRetCode === true ) {
            $oDestination->remove();
        }
        // 移動できるので移動 (renameは上書きできない)
        $bRetCode            = rename($this->sFilename, $oDestination->sFilename);
        clearstatcache();
        if ( $bRetCode !== true ) {
            // 移動失敗
            if ( $bThrowException === true ) {
                throw new \SC\exception\libs\File\CantMove("Can't move file: from='{$this->sFilename}' to='{$oDestination->sFilename}'.");
            }
            return false;
        }
        // ファイルを移動先のものに切り替え
        $this->__construct($oDestination->sFilename);
        return true;
    }

    /**
     * 移動可能かチェック
     *
     * @param   SC\libs\File    $oDestination   移動先ファイル
     * @param   bool            $bOverwrite     上書きするか否か
     * @return  bool            true
     * @throw   SC\exception\libs\File\NotReadable
     */
    protected function _checkForMove(File $oDestination, $bOverwrite)
    {
        // ファイルの読み込みチェック
        clearstatcache();
        $bRetCode = is_readable($this->sFilename);
        if ( $bRetCode !== true ) {
            // 移動元が存在しない
            throw new \SC\exception\libs\File\NotReadable("Source file is not readable: file='{$this->sFilename}'.");
        }
        // ファイルの書き込みチェック
        $bRetCode = $this->_checkForWrite($oDestination->sFilename, $bOverwrite);
        return true;
    }

    /**
     * MIME-Type
     *
     * @return  string
     */
    public function getMimeType()
    {
        return $this->sMimeType;
    }

    /**
     * MIME-Type
     *
     * @param   string  $sFilename      ファイル名
     * @return  string
     */
    static public function getMimeTypeByName($sFilename)
    {
        $oSelf = static::getInstance($sFilename);
        return $oSelf->getMimeType();
    }

    /**
     * 親ディレクトリのパスを返す
     *
     * @return  string
     */
    public function getParent()
    {
        return parent::getPath();
    }

    /**
     * 無効getPath
     *
     * @return  string
     */
    public function getPath($sClassName = NULL)
    {
        $aBTrace  = debug_backtrace(2);
        $sClass   = get_class($this);
        $sMethod  = __FUNCTION__;
        $sMessage = "Call to private {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
        trigger_error($sMessage, E_USER_ERROR);
    }

    /**
     * 無効getPathInfo
     *
     * @param   string      $sClassName         使用したい SplFileInfo 派生クラスの名前
     * @return  \SplFileObject
     */
    public function getPathInfo($sClassName = NULL)
    {
        $aBTrace  = debug_backtrace(2);
        $sClass   = get_class($this);
        $sMethod  = __FUNCTION__;
        $sMessage = "Call to private {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
        trigger_error($sMessage, E_USER_ERROR);
    }

    /**
     * 無効getFileInfo
     *
     * @param   string      $sClassName         使用したい SplFileInfo 派生クラスの名前
     * @return  \SplFileObject
     */
    public function getFileInfo($sClassName = NULL)
    {
        $aBTrace  = debug_backtrace(2);
        $sClass   = get_class($this);
        $sMethod  = __FUNCTION__;
        $sMessage = "Call to private {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
        trigger_error($sMessage, E_USER_ERROR);
    }

    /**
     * 無効openFile
     *
     * @param   string      $sOpenMode          ファイルを開く際のモード
     * @param   bool        $bUseIncludePath    TRUE に設定すると、このファイル名を include_path の中からも探します。
     * @param   resource    $rContext           コンテキスト
     * @return  \SplFileObject
     */
    public function openFile($sOpenMode = 'r', $bUseIncludePath = false, $rContext = NULL)
    {
        $aBTrace  = debug_backtrace(2);
        $sClass   = get_class($this);
        $sMethod  = __FUNCTION__;
        $sMessage = "Call to private {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
        trigger_error($sMessage, E_USER_ERROR);
    }
}
