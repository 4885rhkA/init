<?php
/**
 * HTTPのアクセスが実行できなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\Http;

/**
 * HTTPのアクセスが実行できなかった場合の例外
 */
class CantExecHTTP extends \SC\exception\libs\Http
{
}
