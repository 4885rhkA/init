<?php
/**
 * ステージ管理モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ステージ管理モデルコントローラ
 */
class StageModel extends StaticModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oSite  = \SC\model\Site::getInstance();
        $this->oStage = \SC\model\Stage::getInstance();

        // サイト情報を取得
        $siteId   = $this->oLogin->getSiteId();
        $siteInfo = $this->oSite->getData($siteId);

        // ステージ情報を取得
        $stageInfo = array(
            'live'    => array(),
            'verify'  => array(),
            'develop' => array(),
        );
        $this->oStage->setNoWarningOn();
        if ( $siteInfo['stglive'] === true ) {
            $stageInfo['live']    = $this->oStage->getData('live');
        }
        if ( $siteInfo['stgverify'] === true ) {
            $stageInfo['verify']  = $this->oStage->getData('verify');
        }
        if ( $siteInfo['stgdevelop'] === true ) {
            $stageInfo['develop'] = $this->oStage->getData('develop');
        }

        $this->aTplValues = array(
            'login'   => $this->oLogin->getData(),
            'site'    => $siteInfo,
            'stages'  => $stageInfo,
        );

        return parent::_process();
    }
}
