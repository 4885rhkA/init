<?php
/**
 * SelectAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * SelectAO
 */
class SelectAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'fields'     => 'SC\\libs\\DB\\FieldListAO',    // フィールドリスト
        'from'       => 'string',                       // FROM句(単独の場合)
        'froms'      => 'SC\\libs\\DB\\FromListAO',     // FROM句(複数の場合)
        'conditions' => 'SC\\libs\\DB\\SelectCondAO',   // 条件句
        'binds'      => 'SC\\libs\\DB\\BindListAO',     // BINDパラメータ
        'update'     => 'bool',                         // FOR UPDATE句
        'onerecord'  => 'bool',                         // 取得するのは1レコード
    );
}
