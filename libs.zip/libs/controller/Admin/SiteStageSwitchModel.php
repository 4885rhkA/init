<?php
/**
 * ステージ切替モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ステージ切替モデルコントローラ
 */
class SiteStageSwitchModel extends AbstractJSONModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oSite = \SC\model\Site::getInstance();
        $this->oSite->setNoWarningOn();

        // サイト情報を取得
        $siteId       = $this->oLogin->getSiteId();
        $siteInfo     = $this->oSite->getData($siteId);
        $branch       = (string) $this->oRequest->getPost('branch', '');
        $source       = (string) $this->oRequest->getPost('source', '');

        // validation
        $this->oStage = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();
        if ( (bool) preg_match('#^(live|verify|develop)$#', $branch) !== true ) {
            $this->bHasError = true;
            $this->sErrMessage = "指定されたブランチ（{$branch}）は有効な値ではありません。";
            return parent::_process();
        }
        $stagingSources = $this->oStage->getStagingSources();
        $aSources = array();
        foreach ($stagingSources as $stagingSource) {
            $aSources[$stagingSource['name']] = $stagingSource['active'];
        }
        if ( array_key_exists($source, $aSources) !== true ) {
            $this->bHasError = true;
            $this->sErrMessage = "指定されたステージング名（{$source}）は有効な値ではありません。";
            return parent::_process();
        }

        // 切り替えフラグ
        $bSwitchBranch  = true;
        $bSwitchStaging = true;

        // ブランチチェック
        $currentBranch = $this->oStage->getCurrentBranchName();
        if ( (bool) preg_match('#^(live|verify|develop)$#', $currentBranch) !== true ) {
            $this->bHasError   = true;
            $this->sErrMessage = "Cannot find the current branch";
            return parent::_process();
        } elseif ( $currentBranch === $branch ) {
            $bSwitchBranch = false;
        }
        // 切り替え先ステージングチェック
        $currentSource = array_search(true, $aSources);
        if ( $currentSource === $source ) {
            $bSwitchStaging = false;
        }

        try {
            // ブランチ切り替え処理
            if ( $bSwitchBranch === true ) {
                $result  = $this->oStage->switchBranch($branch);
                if ( $result === false ) {
                    throw new \Exception("Failed to switch branch from '" . $currentBranch . "' to '" . $branch . "'");
                }
            }
            // ステージング切り替え処理
            if ( $bSwitchStaging === true ) {
                $result  = $this->oStage->switchStagingSource($source);
                if ( $result === false ) {
                    throw new \Exception("Failed to switch staging from '" . $currentSource . "' to '" . $source . "'");
                }
            }
        } catch (\Exception $e) {
            $this->bHasError = true;
            $this->sErrMessage = $e->getMessage();
        }

        return parent::_process();
    }
}
