<?php
/**
 * Metrics
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Metrics
 */
class Metrics
{
    /**
     * メトリクスデータを保存するディレクトリの指定
     *
     * @var string DATA_DIR
     */
    const DATA_DIR = 'tmp/metrics';

    /**
     * メトリクスパラメータ
     *
     * @var array $aParameters
     */
    protected $aParameters = array(
        'cpu'       => 'cpu.ini',           // 単位期間内の平均(average)
        'mem'       => 'mem.ini',           // 単位期間内の平均(average)
        'network'   => 'network.ini',       // 単位期間内の平均(average)
        'request'   => 'request.ini',       // 単位期間内の合計(sum)
        'instances' => 'instances.ini',     // 単位期間内の最大(max)
    );

    /**
     * 期間のメトリクスデータの取得
     *
     * @param   int     $iFrom      開始日時のタイムスタンプ
     * @param   int     $iTo        終了日時のタイムスタンプ
     * @param   int     $iPeriod    間隔
     * @return  array   メトリクスデータ
     */
    public static function get($iFrom, $iTo, $iPeriod)
    {
        $oSelf = new static();
        return $oSelf->_get($iFrom, $iTo, $iPeriod);
    }

    /**
     * 期間のメトリクスデータの取得
     *
     * @param   int     $iFrom      開始日時のタイムスタンプ
     * @param   int     $iTo        終了日時のタイムスタンプ
     * @param   int     $iPeriod    間隔
     * @return  array   メトリクスデータ
     */
    protected function _get($iFrom, $iTo, $iPeriod)
    {
        // 時刻を取得
        for ( $iTime = $iFrom ; $iTime < $iTo ; $iTime += $iPeriod ) {
            $aDate         = getdate($iTime);
            $sKey          = sprintf('%04d/%02d/%02d', $aDate['year'], $aDate['mon'], $aDate['mday']);
            $sPathBase     = AP_DIR . '/' . static::DATA_DIR . '/' . $sKey;
            $aDataEach     = array(
                'key'  => $sKey,
                'time' => $aDate,
            );
            $aData[$iTime] = $this->_getEach($aDataEach, $sKey, $sPathBase);
        }
        return $this->_reform($aData);
    }

    /**
     * 月別のメトリクスデータの取得
     *
     * @param   array   $aList      月のタイムスタンプリスト
     * @return  array   メトリクスデータ
     */
    public static function getByMonth(array $aList)
    {
        $oSelf = new static();
        return $oSelf->_getByMonth($aList);
    }

    /**
     * 月別のメトリクスデータの取得
     *
     * @param   array   $aList      月のタイムスタンプリスト
     * @return  array   メトリクスデータ
     */
    protected function _getByMonth(array $aList)
    {
        $aData             = array();
        foreach ( $aList as $iTime => $aDate ) {
            $sKey          = sprintf('%04d/%02d', $aDate['year'], $aDate['mon']);
            $sPathBase     = AP_DIR . '/' . static::DATA_DIR . '/' . $sKey;
            $aDataEach     = array(
                'key'  => $sKey,
                'time' => $aDate,
            );
            $aData[$iTime] = $this->_getEach($aDataEach, $sKey, $sPathBase);
        }
        return $this->_reform($aData);
    }

    /**
     * メトリクスデータの取得
     *
     * @param   array   $aData      データ
     * @param   string  $sKey       キー
     * @param   string  $sPathBase  データファイル配置のベース
     * @return  array   メトリクスデータ
     */
    protected function _getEach(array $aData, $sKey, $sPathBase)
    {
        foreach ( $this->aParameters as $sKey => $sFile ) {
            $sPathname        = $sPathBase . '/' . $sFile;
            $bRetCode         = file_exists($sPathname);
            if ( $bRetCode !== true ) {
                $aData[$sKey] = array();
                continue;
            }
            $aInfo            = parse_ini_file($sPathname, true);
            if ( $aInfo === false ) {
                $aData[$sKey] = array();
                continue;
            }
            $bRetCode         = isset($aInfo[$sKey]);
            if ( $bRetCode !== true ) {
                $aData[$sKey] = array();
                continue;
            }
            $aData[$sKey]     = $aInfo[$sKey];
        }
        return $aData;
    }

    /**
     * メトリクスデータの整形
     *
     * @param   array   $aData      データ
     * @return  array   メトリクスデータ
     */
    protected function _reform(array $aRawData)
    {
        $aData = array();
        foreach ( $aRawData as $iTime => $aEach ) {
            foreach ( $aEach as $sKey => $aMetrics ) {
                $aData[$sKey][$iTime] = $aMetrics;
            }
        }
        return $aData;
    }
}
