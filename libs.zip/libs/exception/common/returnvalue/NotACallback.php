<?php
/**
 * 戻り値がコールバック型(疑似型)ではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\returnvalue;

/**
 * 戻り値がコールバック型(疑似型)ではなかった場合の例外
 */
class NotACallback extends \SC\exception\common\returnvalue
{
}
