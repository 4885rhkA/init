<?php
/**
 * 注意例外 (E_NOTICE)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * 注意例外 (E_NOTICE)
 */
class Notice extends \SC\exception\php\error
{
}
