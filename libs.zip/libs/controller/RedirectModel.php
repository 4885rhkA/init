<?php
/**
 * リダイレクトモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * リダイレクトモデルコントローラ
 */
class RedirectModel extends AbstractModel
{
    /**
     * 処理
     *
     * @return true
     * @throw  \SC\exception\controller\RedirectModel\NotARedirectStatus
     */
    protected function _process()
    {
        // リダイレクト先の調整
        $sRedirect             = \Util::refine($this->aSelector['redirect'], true);
        $bStaging              = (bool) \ArrayUtil::getValue($this->aSelector, 'staging',    true);     // PC            → PC-stg
        $bStagingSP            = (bool) \ArrayUtil::getValue($this->aSelector, 'staging-sp', true);     //            SP → SP-stg
        $bAdjust               = (bool) \ArrayUtil::getValue($this->aSelector, 'url-adjust', false);    // PC(stg) → SP → SP-stg
        if ( $bAdjust === true ) {
            // PC(stg) → SP → SP-stg
            $sRedirect         = \Util::adjustURIProduction($sRedirect, $bStagingSP, $this->oRequest->getEntryPoint());
        } else if ( $bStaging === true ) {
            // PC → PC-stg
            $sRedirect         = \Util::adjustURIStagingSource($sRedirect);
        } else {
            // 調整を行わない
        }
        // RFC3982を考慮してリダイレクトのURLを正規化
        $bUseRFC3982           = (bool) \ArrayUtil::getValue($this->aSelector, 'rfc3982', false);
        $bOldUseRFC3982        = \SC\libs\Http::getUseRFC3982();
        \SC\libs\Http::setUseRFC3982($bUseRFC3982);
        $sRedirect             = \SC\libs\Http::normalizeUrl($sRedirect, array());
        \SC\libs\Http::setUseRFC3982($bOldUseRFC3982);
        // ステータスをセット
        $iStatus               = $this->aSelector['status'];
        if ( $iStatus !== 301 && $iStatus !== 302 && $iStatus !== 303 && $iStatus !== 305 && $iStatus !== 307 ) {
            // エラー
            throw new \SC\exception\controller\RedirectModel\NotARedirectStatus("not a redirect status [code={$iStatus}]", $iStatus);
        }
        // リダイレクト
        $this->oResponse->setRedirect($sRedirect, $iStatus);
        return true;
    }
}
