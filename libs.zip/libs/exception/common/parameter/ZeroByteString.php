<?php
/**
 * パラメータが空文字列だった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\parameter;

/**
 * パラメータが空文字列だった場合の例外
 */
class ZeroByteString extends \SC\exception\common\parameter
{
}
