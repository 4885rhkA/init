<?php
/**
 * サイトリリース予約モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * サイトリリース予約モデルコントローラ
 */
class SiteReleaseReserveModel extends AbstractJSONModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oSite         = \SC\model\Site::getInstance();
        $this->oSite->setNoWarningOn();

        // サイト情報を取得
        $siteId              = $this->oLogin->getSiteId();
        $timing              = (int)    $this->oRequest->getPost('timing',        0);
        $specifiedtime       = (string) $this->oRequest->getPost('specifiedtime', '');
        if ( $specifiedtime === '' ) {
            $now             = getdate();
            $minutes         = (int) ((ceil($now['minutes']/10)+1)*10);
            $specifiedtime   = date('Y/m/d H:i:s',mktime($now['hours'], $minutes, 0, $now['mon'], $now['mday'], $now['year']));
        }

        // validation
        if ( $timing !== 1 && $timing !== 2 ) {
            $this->bHasError   = true;
            $this->sErrMessage = "指定されたタイミング({$timing})は有効な値ではありません。";
            return parent::_process();
        }
        if ( $timing === 2 ) {
            $specifiedDate = new \DateTime($specifiedtime);
            $fromDate      = new \DateTime();
            $toDate        = new \DateTime();
            $fromDate->modify('+30 minutes');
            $toDate->modify('+5 day');
            if ( $specifiedDate < $fromDate || $specifiedDate > $toDate ) {
                $this->bHasError   = true;
                $this->sErrMessage = "指定された予約日時({$specifiedtime})は有効な値ではありません。";
                return parent::_process();
            }
        }

        try {
            //サイトリリース予約処理
            $author = $this->oLogin->getAuthor();
            $result = $this->oSite->reserveRelease($siteId, $author, strtotime($specifiedtime));
            if ( $result === false ) {
                $this->bHasError = true;
            }
            $this->aValues      = array(
                'timing'        => $timing,
                'specifiedtime' => $specifiedtime,
            );

        } catch (\Exception $e) {
            $this->bHasError = true;
        }

        return parent::_process();
    }
}
