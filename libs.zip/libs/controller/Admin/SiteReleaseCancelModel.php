<?php
/**
 * サイトリリース予約取消モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * サイトリリース予約取消モデルコントローラ
 */
class SiteReleaseCancelModel extends AbstractJSONModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oSite = \SC\model\Site::getInstance();
        $this->oSite->setNoWarningOn();

        try {
            $siteId = $this->oLogin->getSiteId();
            // @todo validate
            // サイトIDをチェックする

            // リリース予約取消
            $this->oSite->cancelRelease($siteId);
        } catch (\Exception $oException) {
            // ログを出力
            $this->bHasError   = true;
            $this->sErrMessage = $oException->getMessage();
        }

        return parent::_process();
    }
}
