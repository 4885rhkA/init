<?php
/**
 * ファイルに書き込み権限がない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\File;

/**
 * ファイルに書き込み権限がない場合の例外
 */
class NotWritable extends \SC\exception\libs\File
{
}
