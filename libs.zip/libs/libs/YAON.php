<?php
/**
 * YAON
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * YAON
 */
class YAON extends JSON
{
    /**
     * JSON decode
     *
     * @param   string  $sJSON
     * @param   bool    $bAssoc
     * @param   int     $iDepth
     * @param   int     $iOptions
     * @return  string  JSON
     * @throw   SC\exception\libs\JSON\CantDecode
     */
    protected function _decode($sJSON, $bAssoc = true, $iDepth = 512, $iOptions = 0)
    {
        if ( $sJSON === NULL ) {
            return NULL;
        }
        $bRetCode    = is_string($sJSON);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('input parameter is not a string');
        }
        $sJSON       = trim($sJSON);
        if ( $sJSON === '' ) {
            return NULL;
        }
        $sJSON       = preg_replace('#^([^"\'\n]*(?:(?:"[^"\n]*"[^"\n]*)*|(?:\'[^\'\n]*\'[^\'\n]*)*))//.*$#SumU', '$1',       $sJSON);
        $sJSON       = preg_replace('#[ \t]+\\\r?\n[ \t]*#Su',                                                    '',         $sJSON);
        $aReplaces   = array(
            '\\' => '\\\\',
            '"'  => '\\u0022',
            "'"  => '"',
        );
        $sJSON       = str_replace(array_keys($aReplaces), array_values($aReplaces), $sJSON);
        $sJSON       = preg_replace('#^(\s*)([A-Za-z0-9_]+(?:[-._][A-Za-z0-9]*)*)(\s*:)#SumU',                    '$1"$2"$3', $sJSON);
        $sJSON       = preg_replace('#,(\s*[}\]])#SuU',                                                           '$1',       $sJSON);
//         $sJSON       = preg_replace('#^\s*$#Sum',                                                                 '',         $sJSON);
//         $sJSON       = preg_replace('#\n{2,}#uS',                                                                 "\n",       $sJSON);
        $sJSON       = trim($sJSON);
        $iCmp        = strcasecmp('null', $sJSON);
        if ( $iCmp === 0 ) {
            return NULL;
        }
        // パラメータ
        $aArgs       = array($sJSON, $bAssoc, $iDepth);
        // バージョンチェック
        $bPHP54      = version_compare(PHP_VERSION, '5.4.0', '>=');
        if ( $bPHP54 === true ) {
            // オプション指定
            $aArgs[] = ( (int) $iOptions ) | $this->iDecodeMask;
        }
        // JSONデコード
        $aDecoded    = call_user_func_array('json_decode', $aArgs);
        if ( $aDecoded === NULL ) {
            $iCode   = json_last_error();
            throw new \SC\exception\libs\JSON\CantDecode("JSON decode error [code={$iCode}]", $iCode);
        }
        return $aDecoded;
    }
}
