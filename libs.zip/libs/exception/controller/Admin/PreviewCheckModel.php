<?php
/**
 * PreviewCheckModelの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\Admin;

/**
 * PreviewCheckModelの例外
 */
class PreviewCheckModel extends \SC\exception\controller\Admin
{
}
