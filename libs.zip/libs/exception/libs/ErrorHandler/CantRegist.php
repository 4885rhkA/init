<?php
/**
 * エラーハンドラが登録できなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\ErrorHandler;

/**
 * エラーハンドラが登録できなかった場合の例外
 */
class CantRegist extends \SC\exception\libs\ErrorHandler
{
}
