<?php
/**
 * インプットコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * インプットコントローラクラス
 */
class Input extends AbstractInput
{
    /**
     * 画面処理
     *
     * @var bool PROCESS
     */
    const PROCESS = self::PROCESS_INDEX;

    /**
     * エラーハンドラ
     *
     * @var string ERRORHANDLER
     */
    const ERRORHANDLER = 'SC\libs\ErrorHandler::show';

    /**
     * 前処理
     *
     * @return true
     */
    protected function _preProcess()
    {
        // リライト
        // 未実装
        // → mod_rewriteを使おう
        // → 画面から設定できない
        // $aConfig = $this->oConfig->get('rewrite');
        // $aConfig = array();
        // $this->oRequest->rewite($aConfig);
        return parent::_preProcess();
    }

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // モデルセレクト
        $aSelector = \SC\libs\ModelSelector::select();
        $sModel    = "SC\\controller\\{$aSelector['model']}Model";
        // モデルコントローラを駆動
        $oModel    = $sModel::getInstance();
        $oModel->setSelector($aSelector);
        $oModel->execute();
        return true;
    }
}
