<?php
/**
 * AbstractInputの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller;

/**
 * AbstractInputの例外
 */
class AbstractInput extends \SC\exception\controller
{
}
