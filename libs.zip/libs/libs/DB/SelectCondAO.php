<?php
/**
 * SelectCondAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * SelectCondAO
 */
class SelectCondAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'where'      => 'string',   // WHERE句
        'groupby'    => 'string',   // GROUP BY句
        'having'     => 'string',   // HAVING句
        'orderby'    => 'string',   // ORDER BY句
        'limit'      => 'int',      // LIMIT句
        'offset'     => 'int',      // OFFSET句
    );
}
