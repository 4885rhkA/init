<?php
/**
 * 抽象テンプレートモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * 抽象テンプレートモデルコントローラ
 */
abstract class AbstractTemplateModel extends AbstractModel
{
    /**
     * テンプレートディレクトリのベース
     *
     * @var string TEMPLATE_BASE
     */
    const TEMPLATE_BASE = \SC\libs\ModelSelector::BASE;

    /**
     * テンプレートディレクトリの指定
     *
     * @var string TEMPLATE_DIR
     */
    const TEMPLATE_DIR = \SC\libs\ModelSelector::TEMPLATE_DIR;

    /**
     * 有効なエクストラクタ
     *
     * @var array $aValidExtractor
     */
    protected $aValidExtractor = array(
        'XPath'  => 'true',
    );

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ステータス指定
        $mHTTPStatus                              = \ArrayUtil::getValue($this->aSelector, 'status', NULL);
        if ( $mHTTPStatus === 'pass' || $mHTTPStatus === null ) {
            // pass or nullなら取得
            $iHTTPStatus                          = (int) \ArrayUtil::getValue($this->aResState, 'primary',   \SC\libs\HttpStatus::NEVER_DONE);
            if ( $iHTTPStatus === \SC\libs\HttpStatus::NEVER_DONE ) {
                $iHTTPStatus                      = (int) \ArrayUtil::getValue($this->aResState, 'secondary', \SC\libs\HttpStatus::NEVER_DONE);
                if ( $iHTTPStatus === \SC\libs\HttpStatus::NEVER_DONE ) {
                    // 取得できなかった
                    $iHTTPStatus                  = \SC\libs\HttpStatus::INTERNAL_SERVER_ERROR;
                }
            }
        } else {
            $iHTTPStatus                          = (int) $mHTTPStatus;
            if ( $iHTTPStatus < 100 || 999 < $iHTTPStatus ) {
                // 異常値ならば500にする
                $iHTTPStatus                      = \SC\libs\HttpStatus::INTERNAL_SERVER_ERROR;
            }
        }
        $sHTTPStatus                              = \SC\libs\HttpStatus::getMessage($iHTTPStatus);
        // Content-Typeがpass指定ならセットする
        $sContentType                             = trim(\ArrayUtil::getValue($this->aSelector, 'mime', ''));
        if ( $sContentType !== '' && $sContentType !== 'pass' ) {
            $this->oResponse->setMimeType($sContentType);
        }
        $sMimeType                                = $this->oResponse->getMimeType();
        $bCharsetPassForce                        = (bool) \ArrayUtil::getValue($this->aSelector, 'pass-force', false);
        $sCharset                                 = trim(\ArrayUtil::getValue($this->aSelector, 'charset',    ''));
        if ( $bCharsetPassForce === true && $sCharset === 'pass' ) {
            $this->oResponse->setOutputEncoding('pass');
        } else {
            if ( $sCharset !== '' && $sCharset !== 'pass' ) {
                $this->oResponse->setOutputEncoding($sCharset);
            }
        }
        $sCharset                                 = $this->oResponse->getOutputEncoding();
        // テンプレートエンジン
        $sEngine                                  = strtolower(trim(\ArrayUtil::getValue($this->aSelector, 'engine', 'smarty')));
        $aStoredName                              = array(
            'pass'     => 'raw',
            'none'     => 'raw',
            'adjusted' => 'adjusted',
        );
        switch ($sEngine) {
            // テンプレートエンジンは使用しない
            case 'pass': case 'none':
            case 'adjusted':
                $sPrimary                         = (string) \ArrayUtil::getValue($this->aSelector, 'primary',    '');
                $sSource                          = (string) \ArrayUtil::getValue($this->aSelector, 'source',     $sPrimary);
                $aStored                          = (array)  \ArrayUtil::getValue($this->aStored,   $sSource,     array());
                $sStoredName                      = (string) \ArrayUtil::getValue($aStoredName,     $sEngine,     '');
                $sOutput                          = (string) \ArrayUtil::getValue($aStored,         $sStoredName, '');
                $sOutputTemplate                  = $sEngine;
                break;

            // 指定がない場合にはSmartyを使う
            case 'smarty':
            default:
                // 予約変数の処理
                $aConstants                       = \SC\libs\SmartyConstants::get();
                $aConstants['__HTTP_CODE__']      = $iHTTPStatus;
                $aConstants['__HTTP_MESSAGE__']   = $sHTTPStatus;
                // テンプレート変数があれば保持
                $aTplVals                         = (array) \ArrayUtil::getValue($this->aSelector, 'parameters', array());
                $aTplVals                         = \ArrayUtil::unite($aTplVals,   $this->aTplValues, true);
                $aTplVals                         = \ArrayUtil::unite($aConstants, $aTplVals,         false);
                // テンプレート
                $oSmarty                          = new \SC\libs\Smarty();
                \SC\libs\SmartyDebug::getInstance();
                $oSmarty->setTemplateDir(static::TEMPLATE_BASE, $this->aSelector['env_dir'], static::TEMPLATE_DIR);
                // テンプレート変数のセット
                $oSmarty->assign($aTplVals);
                // 表示処理
                $sOutput                          = $oSmarty->fetch($this->aSelector['template']);
                $sOutputTemplate                  = $this->aSelector['template'];
                $sResponseTemplate                = $this->oRequest->getServer('SC_RESPONSE_TEMPLATE', '0');
                if ( $sResponseTemplate === '1' || $sResponseTemplate === 'true' || $sResponseTemplate === 'on' ) {
                    $this->oResponse->addHeader('X-' . SC_PRODUCT_NAME . '-Template', $sOutputTemplate, true, NULL, NULL);
                }
                break;
        }
        // テキストのみ置換する
        $bRetCode                                 = $this->oResponse->isMimeTypeText();
        if ( $bRetCode === true ) {
            // 正規表現のUTF-8指定
            if ( $sCharset === 'UTF-8' ) {
                $sREExtUtf8                       = 'u';
                $bUtf8                            = true;
            } else {
                $sREExtUtf8                       = '';
                $bUtf8                            = false;
            }
            // URL調整
            $bRetCode                             = (bool) \ArrayUtil::getValue($this->aSelector, 'url-adjust', false);
            if ( $bRetCode === true ) {
                // URL調整を行う
                $sOutput                          = \Util::adjustURIString($sOutput, $bUtf8, $this->aSelector['preview']);
            }
            // 最終置換
            $aReplacePairs                        = (array) \ArrayUtil::getValue($this->aSelector, 'replaces', array());
            $iCount                               = count($aReplacePairs);
            if ( $iCount > 0 ) {
                $aSearches                        = array_keys($aReplacePairs);
                $aReplaces                        = array_values($aReplacePairs);
                foreach ( $aSearches as $i => $sSearch ) {
                    $aSearches[$i]                = $sSearch . $sREExtUtf8;
                    $aReplaces[$i]                = (string) $aReplaces[$i];
                    if ( $aReplaces[$i] !== '' ) {
                        $aReplaces[$i]            = \Util::refine($aReplaces[$i]);
                    }
                }
                $aSearches                        = \Util::validatePCRE($aSearches, true);
                $mRetValue                        = preg_replace($aSearches, $aReplaces, $sOutput);
                if ( $mRetValue !== NULL ) {
                    $sOutput                      = $mRetValue;
                } else {
                    \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for output-replaces.');
                    if ( $this->bLogPCREError === true ) {
                        \Log::dump(array(
                            'func'    => 'preg_replace',
                            'search'  => $aSearches,
                            'replace' => $aReplaces,
                            'subject' => $sOutput,
                        ), 'PCRE replace info:', \Log::LEVEL_TRACE);
                    }
                }
            }
        }
        // 出力
        $this->oResponse->setResult($sOutput, $iHTTPStatus);
        \Log::info("Output normally [{$sOutputTemplate}] (Status: $iHTTPStatus $sHTTPStatus)");
        \LogRegistry::save('sc:request', 'TEMPLATE',        $sOutputTemplate);
        \LogRegistry::save('sc:display', 'TEMPLATE',        $sOutputTemplate);
        \LogRegistry::save('sc:request', 'TEMPLATE_ENGINE', $sEngine);
        \LogRegistry::save('sc:display', 'TEMPLATE_ENGINE', $sEngine);
        \LogRegistry::save('sc:request', 'STATUS',          $iHTTPStatus);
        \LogRegistry::save('sc:display', 'STATUS',          $iHTTPStatus);
        \LogRegistry::save('sc:request', 'STATUS_MESSAGE',  $sHTTPStatus);
        \LogRegistry::save('sc:display', 'STATUS_MESSAGE',  $sHTTPStatus);
        \LogRegistry::save('sc:request', 'CONTENT_TYPE',    $sMimeType);
        \LogRegistry::save('sc:display', 'CONTENT_TYPE',    $sMimeType);
        \LogRegistry::save('sc:request', 'CHARSET',         $sCharset);
        \LogRegistry::save('sc:display', 'CHARSET',         $sCharset);
        return true;
    }

    /**
     * ソースからテンプレート用の変数値を取得する
     *
     * @param   array   $aSources   ソース情報リスト
     * @param   string  $sEngine    出力エンジン
     * @return  array   抽出変数リスト
     */
    protected function _getValuesFromSources(array $aSources, $sEngine)
    {
        return array();
    }

    /**
     * ソースから変数を抽出する
     *
     * @param   array   $aSource    ソース情報
     * @param   string  $sEngine    出力エンジン
     * @return  mixed   抽出した変数
     */
    protected function _getValuesFromSource(array $aSource, $sEngine)
    {
        return array();
    }

    /**
     * 変数を読み込んでマージ
     *
     * @param   array   $aSource    ソース情報
     * @return  mixed   抽出した変数
     */
    protected function _mergeIncludes(array $aSource)
    {
        // マージ変数リストのコピー
        $aIncludes                  = (array) \ArrayUtil::getValue($aSource, 'includes',   array());
        if ( $aIncludes === array() ) {
            // 無ければ抜ける
            return $aSource;
        }
        $aMerged                    = array();
        foreach ( $aIncludes as $sModel ) {
            $aEach                  = (array) \ArrayUtil::getValue($this->aSelector['config']['models'], $sModel, array());
            foreach ( $aEach as $sKey => $mValue ) {
                if ( $sKey === 'name' || $sKey === 'description' || $sKey === 'primary' ) {
                    continue;
                }
                $bRetCode           = is_array($mValue);
                if ( $bRetCode === true ) {
                    $aPrevious      = \ArrayUtil::getValue($aMerged, $sKey,   array());
                    $aMerged[$sKey] = \ArrayUtil::unite($aPrevious,  $mValue, true);
                } else {
                    $aMerged[$sKey] = $mValue;
                }
            }
        }
        $aSource                    = \ArrayUtil::unite($aSource, $aMerged, false);
        return $aSource;
    }

    /**
     * チェーン
     *
     * @param   array   $aSources   ソース情報
     * @param   array   $aRetVals   抽出変数
     * @return  bool    true
     * @throw   SC\exception\controller\ConvertModel\CantGetSourceNomally
     */
    protected function _chain(array $aSource, array $aRetVals)
    {
        // チェーンがあるか？
        $bRetCode                  = is_array(\ArrayUtil::getValue($aSource, 'chain', NULL));
        if ( $bRetCode !== true ) {
            // チェーンがない
            return true;
        }
        // チェーン構造の正規化
        $bRetCode                  = isset($aSource['chain']['name']);
        if ( $bRetCode === true ) {
            // 1次元 → 2次元
            $aChains               = array($aSource['chain']);
        } else {
            // 2次元と想定
            $aChains               = $aSource['chain'];
        }
        // チェーン対象の数だけ処理
        foreach ( $aChains as $aEach ) {
            // チェーン情報があるか？
            $bRetCode              = isset($aEach['name']);
            if ( $bRetCode !== true ) {
                // チェーン情報がない → 次へ
                continue;
            }
            $bRetCode              = is_array($aEach['conditions']);
            if ( $bRetCode !== true ) {
                // チェーン情報がない → 次へ
                continue;
            }
            // チェーン先を取得
            $sChain                = (string) $aEach['name'];
            $aSelector             = (array)  \ArrayUtil::getValue($this->aSelector['config']['models'], $sChain, array());
            if ( $aSelector === array() ) {
                // チェーン先がない
                continue;
            }
            // チェーン判定
            $aTargets              = $this->_getChainTarget();
            $aTargets['parameter'] = $aRetVals;
            // チェーンするかどうか
            $bRetCode              = \SC\libs\ModelSelector::isSelectedChain($sChain, $aEach['conditions'], $aTargets);
            if ( $bRetCode === true ) {
                // チェーンする場合にはチェーン情報を構成してリスロー
                $this->aChain      = \SC\libs\ModelSelector::makeSelector($aSelector, $this->aSelector['config'], $this->aSelector['name']);
                $this->aTplValues  = (array) \ArrayUtil::unite($this->aTplValues, $aRetVals, true);
                throw new \SC\exception\controller\ConvertModel\Chain("Do chain to '{$sChain}' < '{$this->aSelector['name']}'");
            }
        }
        // チェーンしない
        return true;
    }

    /**
     * チェーンのターゲット情報の収集
     *
     * @return  array   チェーンのターゲット情報
     */
    protected function _getChainTarget()
    {
        return array();
    }
}
