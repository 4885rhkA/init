<?php
/**
 * Hash
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Hash
 */
class Hash
{
    /**
     * インスタンス
     *
     * @var SC\libs\Util $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * 16進数2進数基数変換テーブル
     *
     * @var array $aHexBinTable
     */
    protected $aHexBinTable = array(
        '0' => '0000',
        '1' => '0001',
        '2' => '0010',
        '3' => '0011',
        '4' => '0100',
        '5' => '0101',
        '6' => '0110',
        '7' => '0111',
        '8' => '1000',
        '9' => '1001',
        'a' => '1010',
        'b' => '1011',
        'c' => '1100',
        'd' => '1101',
        'e' => '1110',
        'f' => '1111',
    );

    /**
     * Base64Urlテーブル
     *
     * @var array $aBase64UrlTable
     */
    protected $aBase64UrlTable = array(
        0  => 'A',
        1  => 'B',
        2  => 'C',
        3  => 'D',
        4  => 'E',
        5  => 'F',
        6  => 'G',
        7  => 'H',
        8  => 'I',
        9  => 'J',
        10 => 'K',
        11 => 'L',
        12 => 'M',
        13 => 'N',
        14 => 'O',
        15 => 'P',
        16 => 'Q',
        17 => 'R',
        18 => 'S',
        19 => 'T',
        20 => 'U',
        21 => 'V',
        22 => 'W',
        23 => 'X',
        24 => 'Y',
        25 => 'Z',
        26 => 'a',
        27 => 'b',
        28 => 'c',
        29 => 'd',
        30 => 'e',
        31 => 'f',
        32 => 'g',
        33 => 'h',
        34 => 'i',
        35 => 'j',
        36 => 'k',
        37 => 'l',
        38 => 'm',
        39 => 'n',
        40 => 'o',
        41 => 'p',
        42 => 'q',
        43 => 'r',
        44 => 's',
        45 => 't',
        46 => 'u',
        47 => 'v',
        48 => 'w',
        49 => 'x',
        50 => 'y',
        51 => 'z',
        52 => '0',
        53 => '1',
        54 => '2',
        55 => '3',
        56 => '4',
        57 => '5',
        58 => '6',
        59 => '7',
        60 => '8',
        61 => '9',
        62 => '-',
        63 => '_',
    );

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Util
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * ハッシュ値を取得
     *
     *  サポートしているハッシュアルゴリズム(hash_algosの結果)
     *      md2             hmac-md2            文字列長＝32
     *      md4             hmac-md4            文字列長＝32
     *      md5             hmac-md5            文字列長＝32
     *      sha1            hmac-sha1           文字列長＝40
     *      sha224          hmac-sha224         文字列長＝56
     *      sha256          hmac-sha256         文字列長＝64
     *      sha384          hmac-sha384         文字列長＝96
     *      sha512          hmac-sha512         文字列長＝128
     *      ripemd128       hmac-ripemd128      文字列長＝32
     *      ripemd160       hmac-ripemd160      文字列長＝40
     *      ripemd256       hmac-ripemd256      文字列長＝64
     *      ripemd320       hmac-ripemd320      文字列長＝80
     *      whirlpool       hmac-whirlpool      文字列長＝128
     *      tiger128,3      hmac-tiger128,3     文字列長＝32
     *      tiger160,3      hmac-tiger160,3     文字列長＝40
     *      tiger192,3      hmac-tiger192,3     文字列長＝48
     *      tiger128,4      hmac-tiger128,4     文字列長＝32
     *      tiger160,4      hmac-tiger160,4     文字列長＝40
     *      tiger192,4      hmac-tiger192,4     文字列長＝48
     *      snefru          hmac-snefru         文字列長＝64
     *      snefru256       hmac-snefru256      文字列長＝64
     *      gost            hmac-gost           文字列長＝64
     *      adler32         hmac-adler32        文字列長＝8
     *      crc32           hmac-crc32          文字列長＝8
     *      crc32b          hmac-crc32b         文字列長＝8
     *      salsa10         hmac-salsa10        文字列長＝128
     *      salsa20         hmac-salsa20        文字列長＝128
     *      haval128,3      hmac-haval128,3     文字列長＝32
     *      haval160,3      hmac-haval160,3     文字列長＝40
     *      haval192,3      hmac-haval192,3     文字列長＝48
     *      haval224,3      hmac-haval224,3     文字列長＝56
     *      haval256,3      hmac-haval256,3     文字列長＝64
     *      haval128,4      hmac-haval128,4     文字列長＝32
     *      haval160,4      hmac-haval160,4     文字列長＝40
     *      haval192,4      hmac-haval192,4     文字列長＝48
     *      haval224,4      hmac-haval224,4     文字列長＝56
     *      haval256,4      hmac-haval256,4     文字列長＝64
     *      haval128,5      hmac-haval128,5     文字列長＝32
     *      haval160,5      hmac-haval160,5     文字列長＝40
     *      haval192,5      hmac-haval192,5     文字列長＝48
     *      haval224,5      hmac-haval224,5     文字列長＝56
     *      haval256,5      hmac-haval256,5     文字列長＝64
     *
     * @param   string  $sInput     取得したい値
     * @param   string  $sKey       HMAC型式の場合のキー
     * @param   string  $sAlgo      ハッシュアルゴリズム
     * @param   bool    $bRawOutput バイナリデータとして取得したいか否か
     * @param   bool    $bBase64Url 基数変換するか否か
     * @param   int     $iLength    取得したい文字列長(0以外で固定長)
     * @return  string  ハッシュ値
     */
    public static function hash($sInput, $sKey = '', $sAlgo = 'md5', $bRawOutput = false, $bBase64Url = false, $iLength = 0)
    {
        $oSelf = static::getInstance();
        return $oSelf->_hash($sInput, $sKey, $sAlgo, $bRawOutput, $bBase64Url, $iLength);
    }

    /**
     * ハッシュ値を取得
     *
     *  サポートしているハッシュアルゴリズム(hash_algosの結果)
     *      md2             hmac-md2            文字列長＝32
     *      md4             hmac-md4            文字列長＝32
     *      md5             hmac-md5            文字列長＝32
     *      sha1            hmac-sha1           文字列長＝40
     *      sha224          hmac-sha224         文字列長＝56
     *      sha256          hmac-sha256         文字列長＝64
     *      sha384          hmac-sha384         文字列長＝96
     *      sha512          hmac-sha512         文字列長＝128
     *      ripemd128       hmac-ripemd128      文字列長＝32
     *      ripemd160       hmac-ripemd160      文字列長＝40
     *      ripemd256       hmac-ripemd256      文字列長＝64
     *      ripemd320       hmac-ripemd320      文字列長＝80
     *      whirlpool       hmac-whirlpool      文字列長＝128
     *      tiger128,3      hmac-tiger128,3     文字列長＝32
     *      tiger160,3      hmac-tiger160,3     文字列長＝40
     *      tiger192,3      hmac-tiger192,3     文字列長＝48
     *      tiger128,4      hmac-tiger128,4     文字列長＝32
     *      tiger160,4      hmac-tiger160,4     文字列長＝40
     *      tiger192,4      hmac-tiger192,4     文字列長＝48
     *      snefru          hmac-snefru         文字列長＝64
     *      snefru256       hmac-snefru256      文字列長＝64
     *      gost            hmac-gost           文字列長＝64
     *      adler32         hmac-adler32        文字列長＝8
     *      crc32           hmac-crc32          文字列長＝8
     *      crc32b          hmac-crc32b         文字列長＝8
     *      salsa10         hmac-salsa10        文字列長＝128
     *      salsa20         hmac-salsa20        文字列長＝128
     *      haval128,3      hmac-haval128,3     文字列長＝32
     *      haval160,3      hmac-haval160,3     文字列長＝40
     *      haval192,3      hmac-haval192,3     文字列長＝48
     *      haval224,3      hmac-haval224,3     文字列長＝56
     *      haval256,3      hmac-haval256,3     文字列長＝64
     *      haval128,4      hmac-haval128,4     文字列長＝32
     *      haval160,4      hmac-haval160,4     文字列長＝40
     *      haval192,4      hmac-haval192,4     文字列長＝48
     *      haval224,4      hmac-haval224,4     文字列長＝56
     *      haval256,4      hmac-haval256,4     文字列長＝64
     *      haval128,5      hmac-haval128,5     文字列長＝32
     *      haval160,5      hmac-haval160,5     文字列長＝40
     *      haval192,5      hmac-haval192,5     文字列長＝48
     *      haval224,5      hmac-haval224,5     文字列長＝56
     *      haval256,5      hmac-haval256,5     文字列長＝64
     *
     * @param   string  $sInput     取得したい値
     * @param   string  $sKey       HMAC型式の場合のキー
     * @param   string  $sAlgo      ハッシュアルゴリズム
     * @param   bool    $bRawOutput バイナリデータとして取得したいか否か
     * @param   bool    $bBase64Url 基数変換するか否か
     * @param   int     $iLength    取得したい文字列長(0以外で固定長)
     * @return  string  ハッシュ値
     * @throw   SC\exception\common\parameter\NotAString
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\libs\Hash\CantCalculate
     */
    protected function _hash($sInput, $sKey = '', $sAlgo = 'md5', $bRawOutput = false, $bBase64Url = false, $iLength = 0)
    {
        // 入力チェック
        $bRetCode      = Validate::isString($sInput);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Input must be string.');
        }
        $bRetCode      = Validate::isStringNotZero($sAlgo);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Hash algorithm must be non-zero byte string.');
        }
        // アルゴリズムをチェック
        $bNoUseHMAC    = (bool) strncmp('hmac-', $sAlgo, 5);
        if ( $bNoUseHMAC === true ) {
            // ハッシュ値を計算
            $sHash     = hash((string) $sAlgo, (string) $sInput, (bool) $bRawOutput);
        } else {
            // HMACならキーは空文字NG
            $bRetCode  = Validate::isStringNotZero($sKey);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\common\parameter\ZeroByteString('Secret key must be non-zero byte string for HMAC.');
            }
            $sAlgoHMAC = substr($sAlgo, 5);
            $bRetCode  = Validate::isStringNotZero($sAlgoHMAC);
            if ( $bRetCode !== true ) {
                throw new \SC\exception\common\parameter\ZeroByteString('Hash algorithm must be non-zero byte string.');
            }
            // ハッシュ値を計算
            $sHash    = hash_hmac((string) $sAlgoHMAC, (string) $sInput, (string) $sKey, (bool) $bRawOutput);
        }
        if ( $sHash === false || $sHash === NULL ) {
            // ハッシュ値が計算できなかった
            throw new \SC\exception\libs\Hash\CantCalculate("Can't calculate hash for '$sAlgo'.");
        }
        // 基数変換するか？
        if ( $bBase64Url === true ) {
            // 基数変換する
            $sHash    = $this->_hex2base64url($sHash);
        }
        // 文字列長を変更するか？
        $iLength      = (int) $iLength;
        if ( $iLength === 0 ) {
            // そのまま
            return $sHash;
        }
        $sHash        = substr($sHash, 0, $iLength);
        return $sHash;
    }

    /**
     * 16進数をbase64urlに変換する
     *
     * @param   string  $sInput     変換したい16進数
     * @return  string  base64urlに変換
     */
    public static function hex2base64url($sInput)
    {
        $oSelf = static::getInstance();
        return $oSelf->_hex2base64url($sInput);
    }

    /**
     * 16進数をbase64urlに変換する
     *
     * @param   string  $sInput     変換したい16進数
     * @return  string  base64urlに変換
     * @throw   SC\exception\common\parameter\NotAString
     */
    protected function _hex2base64url($sInput)
    {
        // 入力チェック
        $bRetCode     = Validate::isString($sInput);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Input must be string.');
        }
        $sInput       = strtolower($sInput);
        // 無効な文字を除去
        $sInput       = preg_replace('#[^0-9a-f]#S', '', $sInput);
        // 2進数に変換
        $aParts       = str_split($sInput, 16);
        $sBinary      = '';
        foreach ( $aParts as $sEach ) {
            $sBinary .= base_convert($sEach, 16, 2);
        }
        // 先頭に0パディングして6文字ずつ分割
        $aParts       = str_split(str_repeat('0', (6-(strlen($sBinary)%6))%6) . $sBinary, 6);
        $sOutput      = '';
        $aTable       = $this->aBase64UrlTable;
        foreach ( $aParts as $sEach ) {
            $sOutput .= $aTable[bindec($sEach)];
        }
        $sOutput      = ltrim($sOutput, '0');
        return $sOutput;
    }
}
