<?php
/**
 * ModelSelectorDevelop
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 */
namespace SC\libs;

/**
 * ModelSelectorDevelop
 */
class ModelSelectorDevelop extends ModelSelector
{
    /**
     * モデルタイプ
     *
     *  production, admin, live, verify, develop
     *
     * @var string TYPE
     */
    const TYPE = 'develop';

    /**
     * 環境ディレクトリの指定
     *
     * @var string ENV_DIR
     */
    const ENV_DIR = 'contents/stage.develop';
}
