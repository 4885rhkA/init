<?php
/**
 * JSON
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * JSON
 */
class JSON
{
    /**
     * エンコードオプション
     *
     *  デフォルト値：          456     0001 1100 1000
     *
     * JSON_HEX_TAG               1     0000 0000 0001
     * JSON_HEX_AMP               2     0000 0000 0010
     * JSON_HEX_APOS              4     0000 0000 0100
     * JSON_HEX_QUOT              8     0000 0000 1000      *
     * JSON_FORCE_OBJECT         16     0000 0001 0000
     * JSON_NUMERIC_CHECK        32     0000 0010 0000
     * JSON_UNESCAPED_SLASHES    64     0000 0100 0000      *
     * JSON_PRETTY_PRINT        128     0000 1000 0000      *
     * JSON_UNESCAPED_UNICODE   256     0001 0000 0000      *
     *
     * @var string ENCODE_MASK
     */
    const ENCODE_MASK = 200;

    /**
     * エンコード時のオプション指定のマスク値
     *
     * @var int $iEncodeMask
     */
    protected $iEncodeMask = self::ENCODE_MASK;

    /**
     * デコードオプション
     *
     *  デフォルト値：            3     0000 0000 0011
     *
     * JSON_OBJECT_AS_ARRAY       1     0000 0000 0001      *
     * JSON_BIGINT_AS_STRING      2     0000 0000 0010      *
     *
     * @var string DECODE_MASK
     */
    const DECODE_MASK = 3;

    /**
     * デコード時のオプション指定のマスク値
     *
     * @var int $iDecodeMask
     */
    protected $iDecodeMask = self::DECODE_MASK;

    /**
     * インスタンス
     *
     * @var SC\libs\JSON $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // オプション指定
        $this->iEncodeMask = static::ENCODE_MASK;
        $this->iDecodeMask = static::DECODE_MASK;
        // 定数チェック
        Util::define('JSON_BIGINT_AS_STRING',    2);
        Util::define('JSON_UNESCAPED_SLASHES',  64);
        Util::define('JSON_PRETTY_PRINT',      128);
        Util::define('JSON_UNESCAPED_UNICODE', 256);
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Util
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * JSON encode
     *
     * @param   mixed   $mObject
     * @param   int     $iOptions
     * @param   string  $sSpace
     * @return  string  JSON
     */
    public static function encode($mObject, $iOptions = 0, $sSpace = NULL)
    {
        $oSelf = static::getInstance();
        return $oSelf->_encode($mObject, $iOptions, $sSpace);
    }

    /**
     * JSON encode/stringify
     *
     * @param   mixed       $mObject
     * @param   callback    $cbSerializer
     * @param   string      $sSpace
     * @param   int         $iOptions
     * @return  string      JSON
     */
    public static function stringify($mObject, $cbSerializer = NULL, $sSpace = NULL, $iOptions = 0)
    {
        // シリアライザー指定があるか？
        $bRetCode = is_callable($cbSerializer);
        if ( $bRetCode !== true ) {
            // デフォルトシリアライザー
            $oSelf = static::getInstance();
            $sJSON = $oSelf->_encode($mObject, $iOptions, $sSpace);
        } else {
            // 指定のシリアライザー
            $sJSON = $cbSerializer($mObject, $iOptions, $sSpace);
        }
        return $sJSON;
    }

    /**
     * JSON decode
     *
     * @param   string  $sJSON
     * @param   bool    $bAssoc
     * @param   int     $iDepth
     * @param   int     $iOptions
     * @return  string  JSON
     * @throw   SC\exception\libs\JSON\CantDecode
     */
    public static function decode($sJSON, $bAssoc = true, $iDepth = 512, $iOptions = 0)
    {
        $oSelf = static::getInstance();
        return $oSelf->_decode($sJSON, $bAssoc, $iDepth, $iOptions);
    }

    /**
     * JSON decode/parse
     *
     * @param   string  $sJSON
     * @param   bool    $bAssoc
     * @param   int     $iDepth
     * @param   int     $iOptions
     * @return  string  JSON
     */
    public static function parse($sJSON, $bAssoc = true, $iDepth = 512, $iOptions = 0)
    {
        return static::decode($sJSON, $bAssoc, $iDepth, $iOptions);
    }

    /**
     * JSON encode
     *
     * @param   mixed   $mObject
     * @param   int     $iOptions
     * @param   string  $sSpace
     */
    protected function _encode($mObject, $iOptions = 0, $sSpace = NULL)
    {
        // オプション指定
        $iOptions = ( (int) $iOptions ) | $this->iEncodeMask;
        $sJSON = json_encode($mObject, $iOptions);
        // バージョンチェック
        $bPHP54   = version_compare(PHP_VERSION, '5.4.0', '>=');
        if ( $bPHP54 !== true ) {
            if ( ( $iOptions & JSON_UNESCAPED_SLASHES ) === JSON_UNESCAPED_SLASHES ) {
                $sJSON = $this->_reformUnescapeSlashes($sJSON);
            }
            if ( ( $iOptions & JSON_UNESCAPED_UNICODE ) === JSON_UNESCAPED_UNICODE ) {
                $sJSON = $this->_reformUnescapeUnicode($sJSON);
            }
            if ( ( $iOptions & JSON_PRETTY_PRINT ) === JSON_PRETTY_PRINT ) {
                $sJSON = $this->_reformRrettyPrint($sJSON);
            }
        }
        return $sJSON;
    }

    /**
     * スラッシュのエスケープを除去
     *
     * @param   string  $sRawJSON
     * @param   string  変換後のJSON
     */
    protected function _reformUnescapeSlashes($sRawJSON)
    {
        $sJSON = str_replace('\\/', '/', $sRawJSON);
        return $sJSON;
    }

    /**
     * エスケープされたUNICODEをデコード
     *
     * @param   string  $sRawJSON
     * @param   string  変換後のJSON
     */
    protected function _reformUnescapeUnicode($sRawJSON)
    {
        // UNICODEをデコード
        $sJSON = preg_replace_callback('/((?:\\\\u(?!0022)[\\dA-Za-z]+)+)/S', array($this, '_decodeUnicodeWithJSON'), $sRawJSON);
        return $sJSON;
    }

    /**
     * UNICODE文字列のJSONデコード
     *
     * @param   array   $aMatches
     * @param   string  デコードした文字列
     */
    protected function _decodeUnicodeWithJSON(array $aMatches)
    {
        // マッチしたUNICODE文字列をJSONデコードする
        return json_decode('"' . $aMatches[1] . '"');
    }

    /**
     * 見やすいように整形
     *
     * @param   string  $sRawJSON
     * @param   string  変換後のJSON
     */
    protected function _reformRrettyPrint($sRawJSON)
    {
        return $sRawJSON;
    }

    /**
     * JSON decode
     *
     * @param   string  $sJSON
     * @param   bool    $bAssoc
     * @param   int     $iDepth
     * @param   int     $iOptions
     * @return  string  JSON
     * @throw   SC\exception\libs\JSON\CantDecode
     */
    protected function _decode($sJSON, $bAssoc = true, $iDepth = 512, $iOptions = 0)
    {
        if ( $sJSON === NULL ) {
            return NULL;
        }
        $bRetCode    = is_string($sJSON);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('input parameter is not a string');
        }
        $sJSON       = trim($sJSON);
        if ( $sJSON === '' ) {
            return NULL;
        }
        $sJSON       = preg_replace('#^([^"\n]*(?:"[^"\n]*"[^"\n]*)*)//.*$#SumU',  '',          $sJSON);
        $sJSON       = str_replace ('\\',                                          '\\\\',      $sJSON);
        $sJSON       = preg_replace('# *,(\s*[}\]])#uS',                           '$1',        $sJSON);
        $sJSON       = preg_replace('#\n{2,}#uS',                                  "\n",        $sJSON);
        $sJSON       = trim($sJSON);
        $iCmp        = strcasecmp('null', $sJSON);
        if ( $iCmp === 0 ) {
            return NULL;
        }
        // パラメータ
        $aArgs       = array($sJSON, $bAssoc, $iDepth);
        // バージョンチェック
        $bPHP54      = version_compare(PHP_VERSION, '5.4.0', '>=');
        if ( $bPHP54 === true ) {
            // オプション指定
            $aArgs[] = ( (int) $iOptions ) | $this->iDecodeMask;
        }
        // JSONデコード
        $aDecoded    = call_user_func_array('json_decode', $aArgs);
        if ( $aDecoded === NULL ) {
            $iCode   = json_last_error();
            throw new \SC\exception\libs\JSON\CantDecode("JSON decode error [code={$iCode}]", $iCode);
        }
        return $aDecoded;
    }
}
