<?php
/**
 * ログインエラーのチェーン先の設定が存在しない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller\AbstractModel;

/**
 * ログインエラーのチェーン先の設定が存在しない場合の例外
 */
class EmptyLoginErrorConfig extends \SC\exception\controller\AbstractModel
{
}
