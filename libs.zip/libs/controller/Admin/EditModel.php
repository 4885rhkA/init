<?php
/**
 * 編集モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * 編集モデルコントローラ
 */
class EditModel extends StaticModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oSite  = \SC\model\Site::getInstance();
        $this->oStage = \SC\model\Stage::getInstance();

        // サイト情報を取得
        $siteId   = $this->oLogin->getSiteId();
        $this->oStage->setNoWarningOn();
        $siteInfo = $this->oSite->getData($siteId);

        $this->aTplValues = array(
            'login'   => $this->oLogin->getData(),
        );

        return parent::_process();
    }
}
