<?php
/**
 * Content-*の解析中に不明なトークンが発生した場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\MimeDecoder;

/**
 * Content-*の解析中に不明なトークンが発生した場合の例外
 */
class UnknownTokenType extends \SC\exception\libs\MimeDecoder
{
}
