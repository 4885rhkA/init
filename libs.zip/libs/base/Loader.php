<?php
/**
 * オートローダ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\base;

/**
 * オートローダ
 */
final class Loader
{
    /**
     * クラスファイルのベースディレクトリ
     *
     * @var string $sBaseDir
     */
    protected $sBaseDir = __DIR__;

    /**
     * クラスファイルの拡張子
     *
     * @var string EXTENT
     */
    const EXTENT = '.php';

    /**
     * ベース名前空間
     *
     * @var string $sBaseNS
     */
    protected $sBaseNS = '';

    /**
     * デフォルトオートローダを使用するか否か
     *
     * @var bool $bUseDefaultLoader
     */
    protected $bUseDefaultLoader = true;

    /**
     * 読み込み処理をログ出力するか？
     *
     * @var bool $bLogLoading
     */
    protected $bLogLoading = false;

    /**
     * ログクラスが読み込み済みか
     *
     * @var bool $bLogLoaded
     */
    protected $bLogLoaded = false;

    /**
     * オートローダに登録済みか否か
     *
     * @var bool $bRegistered
     */
    protected static $bRegistered = false;

    /**
     * インスタンス
     *
     * @var SC\base\Loader $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // フレームワークディレクトリ
        $bRetCode = defined('FW_DIR');
        if ( $bRetCode === true ) {
            $this->sBaseDir = FW_DIR;
        } else {
            $this->sBaseDir = realpath(__DIR__ . '/..');
        }
        // ネームスペースベース
        $aNameSpace    = explode('\\', __NAMESPACE__);
        $this->sBaseNS = $aNameSpace[0];
        // デフォルトオートローダを使用するか否か
        $bRetCode      = isset($_SERVER['SC_NO_DEFAULT_LOADER']);
        if ( $bRetCode === true ) {
            $sUseDL    = strtolower(trim($_SERVER['SC_NO_DEFAULT_LOADER']));
            if ( $sUseDL === 'true' || $sUseDL === 'on' || $sUseDL === '1' ) {
                $this->bUseDefaultLoader = false;
            } else {
                $this->bUseDefaultLoader = true;
            }
        } else {
            $this->bUseDefaultLoader     = true;
        }
        // 読み込みをログ出力するか？
        $bRetCode      = isset($_SERVER['SC_LOG_LOADING']);
        if ( $bRetCode === true ) {
            $sUseDL    = strtolower(trim($_SERVER['SC_LOG_LOADING']));
            if ( $sUseDL === 'true' || $sUseDL === 'on' || $sUseDL === '1' ) {
                $this->bLogLoading       = true;
            } else {
                $this->bLogLoading       = false;
            }
        } else {
            $this->bLogLoading           = false;
        }
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\base\Loader
     */
    protected static function _getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new self();
        }
        return self::$oInstance;
    }

    /**
     * オートローダ登録
     *
     * @return  bool    true
     */
    public static function regist()
    {
        if ( self::$bRegistered === true ) {
            // 登録済みなら処理しない
            return true;
        }
        // ローダの生成
        $oSelf    = self::_getInstance();

        // Smartyはローダで読み込めないため先にロードしておく
        $oSelf->_loadSmarty();

        // 登録
        $bRetCode = spl_autoload_register(array($oSelf, 'load'),  true, true);
        if ( $bRetCode === true ) {
            // 登録済みフラグを立てる
            self::$bRegistered = true;
        }

        // デフォルトオートローダ
        if ( $oSelf->bUseDefaultLoader === true ) {
            // デフォルトオートローダを登録する
            $bRetCode = spl_autoload_register('spl_autoload',     true, false);
        }

        // 例外ローダを登録する
        $bRetCode = spl_autoload_register(array($oSelf, 'raise'), true, false);

        return $bRetCode;
    }

    /**
     * クラス読み込み
     *
     * @param   string  $sClassName
     * @return  bool    true
     */
    public static function load($sClassName)
    {
        $oSelf                         = self::_getInstance();
        if ( $oSelf->bLogLoading === true ) {
            $oSelf->_log("Class loading: $sClassName", 'info');
        }
        $sPath                         = $oSelf->_makeRelativePathFromClassName($sClassName);
        $sFilename                     = $oSelf->sBaseDir . DIRECTORY_SEPARATOR . $sPath . self::EXTENT;
        $bRetCode                      = $oSelf->_loadFile($sFilename);
        if ( $bRetCode !== true ) {
            // デフォルトオートローダの登録がある場合にはログ出力しない
            if ( $oSelf->bUseDefaultLoader !== true ) {
                // 読み込み失敗ならエラーログ
                $oSelf->_log("Class loading failure: $sClassName", 'warning');
            }
        } else {
            // 読み込み成功
            if ( $oSelf->bLogLoading === true ) {
                if ( $oSelf->bLogLoaded === false && $sClassName === 'SC\\libs\\Log' ) {
                    // ログ出力指定があり，ログクラス未読み込み，今回読み込みがログクラスならば
                    // アクセスキーを取得してLog初期化してから読み込み済みとする
                    $sLogAccessKey     = \SC\libs\Log::getAccessKey();
                    $oSelf->bLogLoaded = true;
                }
                $oSelf->_log("Class loaded: $sClassName", 'info');
            }
        }
        return $bRetCode;
    }

    /**
     * ログ出力
     *
     * @param   string  $sMessage
     * @param   string  $sLogLevel
     * @return  bool    true
     */
    protected function _log($sMessage, $sLogLevel = 'info')
    {
        if ( $this->bLogLoaded === true ) {
            \SC\libs\Log::$sLogLevel($sMessage);
        } else {
            error_log($sMessage);
        }
        return true;
    }

    /**
     * ダンプをログに出力する
     *
     * @param   mixed   $mValue     ダンプ出力したい変数(必ずコピー)
     * @param   string  $sLabel
     * @param   string  $sLogLevel
     * @return  bool    true
     */
    protected function _dump($mValue, $sLabel = '', $sLogLevel = 'info')
    {
        // ダンプを取得
        $sMessage   = \SC\libs\Debug::dump($mValue, (string)$sLabel, false);
        return $this->_log($sMessage, $sLogLevel);
    }

    /**
     * ファイルの読み込み
     *
     * @param   string  $sFilename
     * @return  bool    true
     * @throw   SC\exception\common\filesystem\NotReadable
     */
    protected function _loadFile($sFilename)
    {
        // 存在チェック
        clearstatcache();
        $bRetCode = is_readable($sFilename);
        if ( $bRetCode !== true ) {
            if ( $this->bUseDefaultLoader === true ) {
                // デフォルトオートローダの登録がある場合には例外にしない
                if ( $this->bLogLoading === true ) {
                    $this->_dump($bRetCode, "$sFilename is not readable:", 'warning');
                }
                return false;
            }
            // 読めない場合は例外
            throw new \SC\exception\common\filesystem\NotReadable('Class file is not readable for ' . $sFilename . '.');
        }

        // ファイルの読み込み
        require_once $sFilename;

        return true;
    }

    /**
     * クラス名から相対パスを生成
     *
     * @param   string  $sClassName
     * @return  string  相対パス
     */
    protected function _makeRelativePathFromClassName($sClassName)
    {
        $sClassName = preg_replace('#^' . $this->sBaseNS . '\\\\#u', '', $sClassName);
        $sClassName = str_replace('\\', DIRECTORY_SEPARATOR, $sClassName);
        return $sClassName;
    }

    /**
     * 例外を発生する
     *
     * @param   string  $sClassName
     * @throw   SC\exception\php\error\Error
     */
    public static function raise($sClassName)
    {
        // 例外
        throw new \SC\exception\php\error\Error("Class '$sClassName' not found");
    }

    /**
     * Smartyをロード
     *
     * @return  bool  true
     */
    public static function _loadSmarty()
    {
        if (!class_exists('Smarty')) {
            require_once 'Smarty/Smarty.class.php';
        }

        return true;
    }
}
