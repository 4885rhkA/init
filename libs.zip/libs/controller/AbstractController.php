<?php
/**
 * 抽象コントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * 抽象コントローラクラス
 */
abstract class AbstractController
{
    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
    }

    /**
     * execute
     *
     * @return true
     */
    abstract public static function execute();

    /**
     * 初期化処理
     *
     * @return true
     */
    protected function _initialize()
    {
        return true;
    }

    /**
     * 終了化処理
     *
     * @return true
     */
    protected function _finalize()
    {
        return true;
    }

    /**
     * プロセス
     *
     * @return true
     */
    abstract protected function _process();

    /**
     * プロセス前処理
     *
     * @return true
     */
    protected function _preProcess()
    {
        return true;
    }

    /**
     * プロセス後処理
     *
     * @return true
     */
    protected function _postProcess()
    {
        return true;
    }
}
