<?php
/**
 * コントロールパネルPublicモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * コントロールパネルPublicモデルコントローラ
 */
class PublicModel extends \SC\controller\PublicModel
{
    /**
     * 公開ディレクトリのベース
     *
     * @var string PUBLIC_BASE
     */
    const PUBLIC_BASE = \SC\libs\ModelSelectorAdmin::BASE;

    /**
     * クラス接尾辞
     *
     * @var string CLASS_SUFFIX
     */
    const CLASS_SUFFIX = 'Admin';
}
