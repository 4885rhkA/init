<?php
/**
 * 変換ページモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * 変換ページモデルコントローラ
 */
class ConvertModel extends AbstractTemplateModel
{
    /**
     * 取得したレスポンス情報
     *
     * @var array $aHTTPInfo
     */
    protected $aHTTPInfo = array(
        'method'    => '',
        'url'       => '',
        'status'    => \SC\libs\HttpStatus::NEVER_DONE,
        'rawheader' => '',
        'rawbody'   => '',
        'headers'   => array(),
        'body'      => '',
        'session'   => array(),
    );

    /**
     * リクエストリフォーム条件
     *
     * @var array $aReqReformConditions
     */
    protected $aReqReformConditions = array(
        // 別途付与するので必ず削除する必要があるもの
        array('target' => 'host',                 'type'=>'remove'),
    );

    /**
     * レスポンスリフォーム条件
     *
     * @var array $aResReformConditions
     */
    protected $aResReformConditions = array(
        // 別途付与するので必ず削除する必要があるもの
        array('target' => 'content-length',       'type'=>'remove'),
        array('target' => 'location',             'type'=>'remove'),
        // プロキシサーバ固有の設定であるべきなもの
        array('target' => 'content-disposition',  'type'=>'remove'),
        array('target' => 'content-language',     'type'=>'remove'),
        array('target' => 'keep-alive',           'type'=>'remove'),
        array('target' => 'connection',           'type'=>'remove'),
        array('target' => 'transfer-encoding',    'type'=>'remove'),
    );

    /**
     * レスポンス状態
     *
     * @var array $aResState
     */
    protected $aResState = array(
        'primary'      => \SC\libs\HttpStatus::NEVER_DONE,
        'secondary'    => \SC\libs\HttpStatus::NEVER_DONE,
        'action'       => 'template',
        'redirect'     => '',
        'error'        => array(),
        'stop'         => false,
        'content-type' => array(
            'name'     => 'Content-Type',
            'values'   => array( 'text/html; charset=UTF-8' ),
            'parsed'   => array(
                'raw'       => 'text/html',
                'primary'   => 'text',
                'secondary' => 'html',
                'charset'   => 'UTF-8',
                'subs'      => array(),
            ),
        ),
        'charset'      => 'UTF-8',
    );

    /**
     * 適用条件対象
     *
     * @var array $aReformTarget
     */
    protected $aReformTarget = array(
        'HTTP_HOST'            => true,     // host
        'SERVER_PORT'          => true,     // port
        'PATH_INFO'            => true,     // path
        'QUERY_STRING'         => true,     // query
        'REQUEST_URI'          => true,     // request uri
        'HTTPS'                => true,     // on
        'HTTP_USER_AGENT'      => true,     // Android
        'HTTP_REFERER'         => true,     // Referer
        'REQUEST_METHOD'       => true,     // GET/POST
        'REMOTE_ADDR'          => true,     // 192.168.1.1
        'REMOTE_ADDRS'         => true,     // 192.168.1.1
        'HTTP_X_FORWARDED_FOR' => true,     // 192.168.1.1
        'REMOTE_PORT'          => true,     // 65457
        'REMOTE_USER'          => true,     // username
        'AUTH_TYPE'            => true,     // Basic , Digest
        'PHP_AUTH_USER'        => true,     // auth username
        'PHP_AUTH_PW'          => true,     // auth passowrd
        'PHP_AUTH_DIGEST'      => true,     // auth digest
        'SERVER_PROTOCOL'      => true,     // HTTP/1.1
        'GATEWAY_INTERFACE'    => true,     // CGI/1.1
        'REQUEST_TIME'         => true,     // UNIX Epoch
        'HOSTNAME'             => true,     // hostname
        // SmartConvert Environment Variables
        'SC_PRODUCT_NAME'      => true,     // SmartConvert
        'SC_PRODUCT_VERSION'   => true,     // version of SmartConvert
        'SC_SOURCE_HOST'       => true,     // source host
        'SC_STAGING'           => true,     // is staging for Source-site
        'SC_STAGING_SP'        => true,     // is staging for SP-site
        'SC_SHOW_HIDDEN_PAGE'  => true,     // hidden page
    );

    /**
     * 適用条件対象
     *
     * @var array $aReformTargetPrefix
     */
    protected $aReformTargetPrefix = array(
        // SmartConvert Environment Variables
        'SC_OPT_'              => true,     // optional
    );

    /**
     * refineキーワード置換
     *
     * @var array $aReplacePairs
     */
    protected $aReplacePairs = array();

    /**
     * RFC3986方式のエンコード／デコードを行うか
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     *  このクラスのメソッド
     *      _urlencode          フラグにより判定
     *      _urldecode          フラグにより判定
     *
     * @var bool $bUseRFC3982
     */
    protected $bUseRFC3982 = false;

    /**
     * パスヘッダのマッチングのログ出力レベル
     *
     * @var int $iLogMatch
     */
    protected $iLogMatch = 0;

    /**
     * 生POSTデータをフィルタ処理したか否か
     *
     * @var bool $bFiltered
     */
    protected $bFiltered = false;

    /**
     * プロセス前処理
     *
     * @return true
     */
    protected function _preProcess()
    {
        // マッチ条件をログに出力するか否か
        $sLogMatch                = strtolower($this->oRequest->getServer('SC_LOG_PASSHEADERMATCHING', ''));
        if ( $sLogMatch === 'true' || $sLogMatch === 'on' || $sLogMatch === '1' ) {
            $this->iLogMatch      = 1;
        } else {
            $bRetCode             = \SC\libs\Validate::isInt($sLogMatch);
            if ( $bRetCode === true ) {
                $this->iLogMatch  = (int) $sLogMatch;
            } else {
                $this->iLogMatch  = 0;
            }
        }
        // Set-Cookieの場合のキーワード置換指定
        $this->aReplacePairs      = array(
            '{{__SET_COOKIE_DOMAIN__}}' => $this->oRequest->getServer('HTTP_HOST', '127.0.0.1'),
            '{{__SET_COOKIE_PATH__}}'   => $this->oRequest->getEntryPoint(),
        );
        return parent::_preProcess();
    }

    /**
     * 処理
     *
     * @return  bool    true
     */
    protected function _process()
    {
        // プライマリソースがあるかを先にチェック
        $bFound                                                = false;
        $sFirstPrimary                                         = '';
        foreach ( $this->aSelector['sources'] as $sName => $aSource ) {
            // ソース名を先に保持する
            $this->aSelector['sources'][$sName]['name']        = $sName;
            // プライマリチェック
            $bRetCode                                          = isset($aSource['primary']);
            if ( $bRetCode === true && $aSource['primary'] === true ) {
                // プライマリあり
                $bFound                                        = true;
                if ( $sFirstPrimary === '' ) {
                    $sFirstPrimary                             = $sName;
                }
            } else {
                $this->aSelector['sources'][$sName]['primary'] = false;
            }
        }
        if ( $bFound === false ) {
            // プライマリが1つもなかったのですべてプライマリにする
            foreach ( $this->aSelector['sources'] as $sName => $aSource ) {
                $this->aSelector['sources'][$sName]['primary'] = true;
                if ( $sFirstPrimary === '' ) {
                    $sFirstPrimary                             = $sName;
                }
            }
        }
        $this->aSelector['primary']                            = $sFirstPrimary;

        try {
            // ソースから変数値を取得する
            $sEngine                       = strtolower(trim(\ArrayUtil::getValue($this->aSelector, 'engine', 'smarty')));
            $aTplValues                    = $this->_getValuesFromSources($this->aSelector['sources'], $sEngine);
            foreach ( $aTplValues as $sKey => $mValue ) {
                $this->aTplValues[$sKey]   = $mValue;
            }
            // Content-Typeがpass指定ならセットする
            $sContentType                  = (string) \ArrayUtil::getValue($this->aSelector, 'mime', '');
            if ( $sContentType === 'pass' ) {
                $sParsed                   = (string) \ArrayUtil::getValue($this->aResState['content-type']['parsed'], 'raw', '');
                if ( $sParsed !== '' ) {
                    $this->oResponse->setMimeType($sParsed);
                }
            }
            $sCharset                      = (string) \ArrayUtil::getValue($this->aSelector, 'charset', '');
            if ( $sCharset === 'pass' ) {
                $this->oResponse->setInternalEncoding($sCharset);
            }
            $sParsed                       = (string) \ArrayUtil::getValue($this->aResState['content-type']['parsed'], 'charset', '');
            if ( $sParsed !== '' ) {
                $this->oResponse->setOutputEncoding($sParsed);
            }
        } catch (\SC\exception\controller\ConvertModel\CantGetSourceNomally $oPrevious) {
            // リダイレクトであれば何もしない
            if ( ( 100 <= $this->aHTTPInfo['status'] && $this->aHTTPInfo['status'] < 400 ) || $this->aHTTPInfo['status'] === 401 ) {
                // HTTPステータスが300系はリダイレクトなので何もせず返す
                // HTTPステータスが401はHTTP認証用なので何もせず返す
                return true;
            }
            // エラーテンプレート表示
            $aErrTemplates      = (array)  \ArrayUtil::getValue($this->aSelector, 'error-template',           array());
            $sErrTemplate       = (string) \ArrayUtil::getValue($aErrTemplates,   $this->aHTTPInfo['status'], ''     );
            if ( $sErrTemplate === '' ) {
                $sErrTemplate   = (string) \ArrayUtil::getValue($aErrTemplates,   '__DEFAULT__',              ''     );
                if ( $sErrTemplate === '' ) {
                    $oException = new \SC\exception\controller\ConvertModel\EmptyErrorTemplate('Empty error template', $this->aHTTPInfo['status'], $oPrevious);
                    // エラー時のテンプレート自体が指定されていない → 例外
                    $aErrInfo   = array(
                        'httpinfo' => $this->aHTTPInfo,
                        'selector' => $this->aSelector,
                        'resstate' => $this->aSelector,
                    );
                    $oException->setErrInfo($aErrInfo);
                    throw new $oException;
                }
            }
            $this->aSelector['status']     = $this->aHTTPInfo['status'];
            $this->aSelector['template' ]  = $sErrTemplate;
            $this->aSelector['mime']       = NULL;
            $this->aSelector['charset']    = 'UTF-8';
            $this->aSelector['engine']     = 'smarty';
            $this->aSelector['url-adjust'] = false;
        }

        return parent::_process();
    }

    /**
     * ソースからテンプレート用の変数値を取得する
     *
     * @param   array   $aSources   ソース情報リスト
     * @param   string  $sEngine    出力エンジン
     * @return  array   抽出変数リスト
     */
    protected function _getValuesFromSources(array $aSources, $sEngine)
    {
        // 抽出変数リスト
        $aValues                       = array();
        try {
            // ソースの数だけ取得
            foreach ( $aSources as $aSource ) {
                // ソースの取得が終了ならぬける
                if ( $this->aResState['stop'] === true ) {
                    break;
                }
                // 変数マージ
                $aSource               = $this->_mergeIncludes($aSource);
                // 取得パラメータがない場合には次のソースへ
                $aSource['passheader'] = (array) \ArrayUtil::getValue($aSource, 'passheader', array());
                $aSource['parameters'] = (array) \ArrayUtil::getValue($aSource, 'parameters', array());
                if ( $aSource['passheader'] === array() && $aSource['parameters'] === array() ) {
                    continue;
                }
                // URLのチェック
                $sUrl                  = trim(\ArrayUtil::getValue($aSource, 'url', ''));
                if ( $sUrl === '' ) {
                    // 変数を取得しない
                    $aRetVals          = array();
                } else {
                    // 変数を取得
                    $aRetVals          = $this->_getValuesFromSource($aSource, $sEngine);
                }
                // 変数をマージ
                $aValues               = \ArrayUtil::unite($aValues, $aRetVals, true);
                // チェーン
                $this->_chain($aSource, $aValues);
            }
        } catch (\SC\exception\libs\Http\CantExecHTTP $oException) {
            $sMessage = $oException->getMessage();
            $iCode    = $oException->getCode();
            throw new \SC\exception\controller\ConvertModel\CantGetSourceNomally($sMessage, $iCode, $oException);
        }
        return $aValues;
    }

    /**
     * ソースから変数を抽出する
     *
     * @param   array   $aSource    ソース情報
     * @param   string  $sEngine    出力エンジン
     * @return  mixed   抽出した変数
     */
    protected function _getValuesFromSource(array $aSource, $sEngine)
    {
        // ソースからHTMLを取得
        $sSourceBody                 = $this->_getSource($aSource);
        // 生の形式か否か
        $bRawBody                    = (bool) \ArrayUtil::getValue($aSource, 'rawbody', false);
        // ソースの保持
        $aStored                     = array( 'raw' => '', 'adjusted' => '' );
        if ( $sEngine === 'pass' ) {
            // 出力エンジンがpassの場合には生のデータを保持
            $aStored['raw']          = $sSourceBody;
        }
        // 生の形式か否かで処理を分ける
        if ( $bRawBody === true ) {
            $sExtractor              = 'pass';
        } else {
            $sExtractor              = 'XPath';
        }
        // チェーンがあるか？
        $bHasChain                   = is_array(\ArrayUtil::getValue($aSource, 'chain', NULL));
        // バイナリか？
        $bBinary                     = (bool) \ArrayUtil::getValue($this->aHTTPInfo['session'], 'binary', false);
        $bBinary                     = (bool) \ArrayUtil::getValue($aSource,                    'binary', $bBinary);
        // 生の形式ではないかチェーンがある場合にはHTMLを整形する
        if ( $bBinary !== true && ( $bRawBody !== true || $bHasChain === true || $sEngine === 'adjusted' ) ) {
            // HTMLを整形する
            $sAdjusted               = $this->_adjustResponseBody($aSource, $sSourceBody);
            if ( $bHasChain === true || $sEngine === 'adjusted' ) {
                // チェーンがあるなら保持する
                $aStored['adjusted'] = $sAdjusted;
            }
            if ( $bRawBody !== true ) {
                // 生の形式ではない場合にはソースとして使用する
                $sSourceBody         = $sAdjusted;
            }
        }
        // エクストラクタ
        $sExtractor                  = trim(\ArrayUtil::getValue($aSource, 'extractor', $sExtractor));
        $bRetCode                    = isset($this->aValidExtractor[$sExtractor]);
        if ( $bBinary !== true && $bRetCode === true ) {
            // 抽出する
            $aOptions                = array(
                'format' => strtoupper(trim(\ArrayUtil::getValue($aSource, 'format', 'HTML'))),
            );
            $aValue                  = call_user_func(array("SC\\libs\\{$sExtractor}Extractor", 'extract'), $aSource['parameters'], $sSourceBody, $aOptions);
            \LogRegistry::save('sc:request', 'EXTRACTOR', $sExtractor);
        } else {
            // 抽出しない
            $aValue                  = array();
        }
        // ソースの保持
        $sName                       = $aSource['name'];
        $this->aStored[$sName]       = $aStored;
        return $aValue;
    }

    /**
     * ソースを取得する
     *
     * @param   array   $aSource    ソース情報
     * @return  array   テンプレート変数値リスト
     * @throw   SC\exception\controller\ConvertModel\CantGetSourceNomally
     */
    protected function _getSource(array $aSource)
    {
        // 取得メソッドの特定
        $sMethod           = $this->_getHTTPMethod($aSource);
        // RFC3982
        $this->bUseRFC3982 = (bool) \ArrayUtil::getValue($aSource, 'rfc3982', false);
        $bOldUseRFC3982    = \SC\libs\Http::getUseRFC3982();
        \SC\libs\Http::setUseRFC3982($this->bUseRFC3982);
        // HTTPリクエストヘッダの調整
        $bRetCode          = isset($aSource['passheader']['send']);
        if ( $bRetCode === true ) {
            $aReqHeaders   = $this->_adjustRequestHeaders($aSource);
            $aCurlOpts     = (array) \ArrayUtil::getValue($aSource['passheader']['send'], 'curloptions', array());
        } else {
            $aCurlOpts     = array();
        }
        // リクエストURLの調整
        $sRequestUri       = $this->_adjustRequestURI($aSource);
        // POSTデータがあれば取得
        $sRawPostData      = $this->_getRawPostData($aSource);

        // タイムアウト
        $iTimeout          = (int) \ArrayUtil::getValue($aSource, 'timeout', 0);
        if ( $iTimeout > 0 ) {
            $iOldTimeout   = \SC\libs\Http::getTimeout();
            \SC\libs\Http::setTimeout($iTimeout);
        }
        try {
            // ソースを取得
            $aOptions      = array(
                'params'        => array(),
                'rawpostdata'   => $sRawPostData,
                'filtered'      => $this->bFiltered,
                'queryformat'   => 'normal',
                'headers'       => $aReqHeaders,
                'curloptions'   => $aCurlOpts,
            );
            $sSourceBody   = \SC\libs\Http::$sMethod($sRequestUri, $aOptions);
            // 取得情報を保持
            $this->aHTTPInfo = array(
                'method'    => $sMethod,
                'url'       => $sRequestUri,
                'status'    => \SC\libs\Http::getLastHttpStatus(),
                'rawheader' => \SC\libs\Http::getResponseHeader(),
                'rawbody'   => $sSourceBody,
                'headers'   => array(),
                'body'      => '',
                'session'   => \SC\libs\Http::getSessionInfo(),
            );
            // 取得できない場合には例外が発生
            // HTTPレスポンスヘッダの調整
            $bGoAhead      = $this->_adjustResponseHeaders($aSource);
        } catch (\SC\exception\libs\Http\CantExecHTTP $oException ) {
            // HTMLを取得できなかった
            $iStatus       = 500;
            $sSourceBody   = '';
            $bGoAhead      = $this->_analyzeResponse($aSource, $iStatus, array());
            // 継続するか？
            if ( $bGoAhead !== true ) {
                // 継続できないならリスロー
                throw $oException;
            }
            // 継続するなら警告ログを出力
            $sMessage      = $oException->getMessage();
            $sCode         = $oException->getCode();
            \Log::warning("Can't get response for '{$sRequestUri}' [reason: {$sMessage}, code: {$sCode}]");
        }

        // タイムアウトを元に戻す
        if ( $iTimeout > 0 ) {
            \SC\libs\Http::setTimeout($iOldTimeout);
        }
        // RFC3982を元に戻す
        \SC\libs\Http::setUseRFC3982($bOldUseRFC3982);

        // イレギュラーレスポンスの場合にセット
        $this->_setResponseIrregular($sSourceBody);

        // 次のソースへ進むか？
        if ( $bGoAhead !== true ) {
            throw new \SC\exception\controller\ConvertModel\CantGetSourceNomally("Can't get source nomally for '$sRequestUri'");
        }
        return $sSourceBody;
    }

    /**
     * チェーンのターゲット情報の収集
     *
     * @return  array   チェーンのターゲット情報
     */
    protected function _getChainTarget()
    {
        $aHeaders             = array();
        foreach ( $this->aHTTPInfo['headers'] as $aInfo ) {
            $sName            = $aInfo['name'];
            $aHeaders[$sName] = $aInfo['values'];
        }
        $aTargets             = array(
            'header'    => array_change_key_case($aHeaders, CASE_LOWER),
            'body'      => $this->aHTTPInfo['body'],
            'status'    => $this->aHTTPInfo['status'],
        );
        return $aTargets;
    }

    /**
     * 取得メソッドの特定
     *
     * @param   array   $aSources   ソース情報
     * @return  string  メソッド (GET/POST/PUT/DELETE/HEAD)
     */
    protected function _getHTTPMethod(array $aSource)
    {
        // 取得メソッドの特定
        $bRetCode             = isset($aSource['method']);
        if ( $bRetCode === true ) {
            $sMethod          = strtoupper(trim($aSource['method']));
            switch ( $sMethod ) {
                // HTTP接続メソッド (GET, POST, PUT, DELETE, HEAD)
                case 'GET': case 'POST': case 'PUT': case 'DELETE': case 'HEAD':
                    break;
                // 不明なメソッド → デフォルト＝アクセスされているメソッドを使用
                default:
                    $sMethod  = $this->oRequest->getServer('REQUEST_METHOD', 'GET');
                    break;
            }
        } else {
            // デフォルト＝アクセスされているメソッドを使用
            $sMethod          = $this->oRequest->getServer('REQUEST_METHOD', 'GET');
        }
        // 必ず大文字
        $sMethod              = strtoupper($sMethod);
        // 特定したメソッドを返す
        return $sMethod;
    }

    /**
     * リクエストヘッダの調整
     *
     * @param   array   $aSources   ソース情報
     * @return  array   リクエストヘッダ情報
     */
    protected function _adjustRequestHeaders(array $aSource)
    {
        $aInfo                    = $aSource['passheader']['send'];
        // User-Agentの指定があるか？
        $bRetCode                 = isset($aInfo['user-agent']);
        if ( $bRetCode === true ) {
            // 指定ありならセット
            \SC\libs\Http::setUserAgent($aInfo['user-agent']);
        }
        // 透過指定があるか？
        $bRetCode                 = isset($aInfo['transparent']);
        if ( $bRetCode !== true || $aInfo['transparent'] !== true ) {
            // 透過指定なし → ヘッダの変更なし → 空の配列を返す
            return array();
        }
        // ヘッダ透過なのでヘッダ取得
        $aHeaders                 = $this->oRequest->getRequestHeaders();
        $aHeaders                 = $this->_reformApacheRequestHeaders($aHeaders);
        // Content-LengthとProxy-AuthorizationとTEは除去する
        unset($aHeaders['content-length'], $aHeaders['proxy-authorization'], $aHeaders['te']);
        // ヘッダの調整指定があるか？
        $bRetCode                 = isset($aInfo['reform']);
        if ( $bRetCode !== true ) {
            // 調整指定がない → 最低限の調整
            $aChanges             = $this->aReqReformConditions;
        } else {
            // 調整指定をマージ
            $aChanges             = array_merge($this->aReqReformConditions, $aInfo['reform']);
        }
        // ヘッダを調整
        $aReformed                = $this->_reformHeaders($aHeaders, $aChanges);
        $bRefererForward          = (bool) \ArrayUtil::getValue($aInfo, 'referer-forward', false);
        $aHeaders                 = array();
        foreach ( $aReformed as $aInfo ) {
            $sName                = $aInfo['name'];
            // リファラではないかリファラの調整が不要
            $bRetCode             = (bool) strcasecmp('Referer', $sName);
            if ( $bRetCode === true || $bRefererForward !== true ) {
                // リファラではないかリファラの調整が不要
                $aHeaders[$sName] = $aInfo['values'];
                continue;
            }
            // リファラの調整が必要 for ソースサイトステージング
            $aEach                = array();
            foreach ( $aInfo['values'] as $iNum => $sValue ) {
                $aEach[$iNum]     = \Util::adjustURIStagingSource($sValue);
            }
            $aHeaders[$sName]     = $aEach;
        }
        // プロキシモードにする
        \SC\libs\Http::setProxyMode(true);
        return $aHeaders;
    }

    /**
     * リクエストURIの調整
     *
     * @param   array   $aSources   ソース情報
     * @return  string  リクエストURI
     */
    protected function _adjustRequestURI(array $aSource)
    {
        // リクエストURIを取得
        $sUrl                 = (string) \ArrayUtil::getValue($aSource, 'url', '');
        if ( $sUrl === '' ) {
            // 空なら何もしない
            return '';
        }
        // リクエストURIの調整
        $iRawURL              = (int) \ArrayUtil::getValue($aSource, 'rawurl', 0);
        if ( $iRawURL === 0 ) {
            // 要調整
            $oUri             = new \SC\libs\Uri($sUrl);
            $sQuery           = $this->oRequest->getServer('QUERY_STRING');
            $bRetCode         = isset($aSource['addquery']);
            if ( $bRetCode !== true || $aSource['addquery'] !== true ) {
                // クエリの追記指定がなければ置換
                $oUri->setQuery($sQuery);
            } else {
                // クエリは追記する
                $oUri->addQuery($sQuery);
            }
            // URIを生成
            $sRequestUri      = $oUri->build();
        } else if ( $iRawURL === 1 ) {
            // refineだけはする
            $sRequestUri      = \Util::refine($sUrl);
        } else {
            // そのまま使用する
            $sRequestUri      = $sUrl;
        }
        // リクエストURIの調整 for ステージング
        $sRequestUri = \Util::adjustURIStagingSource($sRequestUri);
        return $sRequestUri;
    }

    /**
     * 生POSTデータを取得
     *
     * @param   array   $aSource    リクエストソース情報
     * @return  string  生POSTデータ
     */
    protected function _getRawPostData($aSource)
    {
        // 生データ
        $sRawPostData            = $this->oRequest->getRawPostData();
        // ソースをフィルタする
        $this->bFiltered         = false;
        $aReplacePairs           = (array) \ArrayUtil::getValue($aSource, 'request-filter', array());
        $iCount                  = count($aReplacePairs);
        if ( $iCount > 0 ) {
            $aSearches           = array_keys($aReplacePairs);
            $aReplaces           = array_values($aReplacePairs);
            $aSearches           = \Util::validatePCRE($aSearches, true);
            $mRetValue           = preg_replace($aSearches, $aReplaces, $sRawPostData);
            if ( $mRetValue !== NULL ) {
                $this->bFiltered = true;
                $sRawPostData    = $mRetValue;
            } else {
                \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for request-filter.');
                if ( $this->bLogPCREError === true ) {
                    \Log::dump(array(
                        'func'    => 'preg_replace',
                        'search'  => $aSearches,
                        'replace' => $aReplaces,
                        'subject' => $sRawPostData,
                    ), 'PCRE replace info:', \Log::LEVEL_TRACE);
                }
            }
        }
        // 生POSTデータがあるか？
        return $sRawPostData;
    }

    /**
     * レスポンスヘッダの調整
     *
     * @param   array   $aSources   ソース情報
     * @return  bool    継続するか否か
     */
    protected function _adjustResponseHeaders(array $aSource)
    {
        // HTTPレスポンスの取得
        $iStatus                    = \SC\libs\Http::getLastHttpStatus();
        $sRawSourceHeader           = \SC\libs\Http::getResponseHeader();
        // ソースをフィルタする
        $aReplacePairs              = (array) \ArrayUtil::getValue($aSource, 'header-filter', array());
        $iCount                     = count($aReplacePairs);
        if ( $iCount > 0 ) {
            $aSearches              = array_keys($aReplacePairs);
            $aReplaces              = array_values($aReplacePairs);
            $aSearches              = \Util::validatePCRE($aSearches, true, '#', 'u');
            $mRetValue              = preg_replace($aSearches, $aReplaces, $sRawSourceHeader);
            if ( $mRetValue !== NULL ) {
                $sRawSourceHeader   = $mRetValue;
            } else {
                \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for header-filter.');
                if ( $this->bLogPCREError === true ) {
                    \Log::dump(array(
                        'func'    => 'preg_replace',
                        'search'  => $aSearches,
                        'replace' => $aReplaces,
                        'subject' => $sRawSourceHeader,
                    ), 'PCRE replace info:', \Log::LEVEL_TRACE);
                }
            }
        }
        $aRawHeaders                = explode("\n", $sRawSourceHeader);
        $aHeaders                   = $this->_reformHttpResponseHeaders($aRawHeaders);

        // ProxyPassReverseの調整
        $aHeaders                   = $this->_adjustResponseHeadersForReverse($aSource, $aHeaders);
        // レスポンス透過調整
        $aHeaders                   = $this->_adjustResponseHeadersTransparent($aSource, $aHeaders);
        // パスリバース後にレスポンスを解析
        $bGoAhead                   = $this->_analyzeResponse($aSource, $iStatus, $aHeaders);
        // レスポンスヘッダの最終調整
        $aHeaders                   = $this->_adjustResponseHeadersForConvert($aSource, $aHeaders);
        // レスポンスヘッダを保持
        $this->aHTTPInfo['headers'] = $aHeaders;
        // 継続するか否かを返す
        return $bGoAhead;
    }

    /**
     * ProxyPassReverseの調整
     *
     * @param   array   $aSources   ソース情報
     * @param   array   $aHeaders   レスポンスヘッダ
     * @return  array   調整したレスポンスヘッダ
     */
    protected function _adjustResponseHeadersForReverse(array $aSource, array $aHeaders)
    {
        // ProxyPassReverseの調整
        $bRetCode                   = isset($aSource['passheader']['reverse']);
        if ( $bRetCode !== true ) {
            // パスリバースしない → そのまま返す
            return $aHeaders;
        }
        $aInfo                      = (array) $aSource['passheader']['reverse'];
        // ProxyPassReverse : Location, Content-Location, URI
        $bRetCode                   = (bool)  \ArrayUtil::getValue($aInfo, 'enabled', false);
        if ( $bRetCode !== true ) {
            // パスリバースしない → そのまま返す
            return $aHeaders;
        }
        // URLを調整
        $aReverses                  = array( 'location', 'content-location', 'uri' );
        foreach ( $aReverses as $sField ) {
            $aHeader                = (array) \ArrayUtil::getValue($aHeaders, $sField, array());
            if ( $aHeader === array() ) {
                continue;
            }
            foreach ( $aHeader['values'] as $iKey => $sValue ) {
                $sValue             = \Util::adjustURIProduction($sValue, true, $this->aSelector['preview']);
                $aHeaders[$sField]['values'][$iKey] = $sValue;
            }
        }
        // 条件があるか？
        $aConditions                = (array) \ArrayUtil::getValue($aInfo, 'conditions', array());
        if ( $aConditions === array() ) {
            // 条件がない → そのまま返す
            return $aHeaders;
        }
        // パスリバース条件
        $sHttpProto                 = \Request::getServer('SC_PASSREVERSE_PROTO', '');
        if ( $sHttpProto !== 'http' && $sHttpProto !== 'https' ) {
            $sHttpProto             = '\1';
        }
        // リダイレクトのキーワード置換
        $sQuery                     = $this->oRequest->getServer('QUERY_STRING', '');
        if ( $sQuery !== '' ) {
            $sQuery                 = '?'. $sQuery;
        }
        $aReplacePairs              = array(
            '{{__HTTP_PROTO__}}'     => $sHttpProto,
            '{{__HTTP_HOST__}}'      => $this->oRequest->getServer('HTTP_HOST', '127.0.0.1'),
            '{{__ENTRY_POINT__}}'    => $this->oRequest->getEntryPoint(),
            '{{__WEBROOT_PATH__}}'   => $this->oRequest->getWebRootPath(),
            '{{__WEB_ROOT__}}'       => $this->oRequest->getEntryPoint(),
            '{{__CONTENTS_ROOT__}}'  => $this->oRequest->getWebRootPath(),
            '{{__PATH_INFO__}}'      => $this->oRequest->getServer('PATH_INFO',      '/'),
            '{{__ORIG_PATH_INFO__}}' => $this->oRequest->getServer('ORIG_PATH_INFO', '/'),
            '{{__QUERY_STRING__}}'   => $sQuery,
            '{{__SESSION_ID__}}'     => \Session::getSessId(),
            '{{__SOURCE_HOST__}}'    => $this->oRequest->getServer('SC_SOURCE_HOST', '127.0.0.1'),
        );
        $aReplaceKeys               = array_keys  ($aReplacePairs);
        $aReplaceValues             = array_values($aReplacePairs);
        foreach ( $aConditions as &$aCond ) {
            $aCond['replace']       = str_replace($aReplaceKeys, $aReplaceValues, $aCond['replace']);
        }
        // ProxyPassReverse : Location, Content-Location, URI
        $aChanges                   = array(
            array(
                'target'     => 'location',
                'type'       => 'replace',
                'raw'        => true,
                'conditions' => $aConditions,
            ),
            array(
                'target'     => 'content-location',
                'type'       => 'replace',
                'raw'        => true,
                'conditions' => $aConditions,
            ),
            array(
                'target'     => 'uri',
                'type'       => 'replace',
                'raw'        => true,
                'conditions' => $aConditions,
            ),
        );
        $aReformed                  = $this->_reformHeaders($aHeaders, $aChanges);
        return $aReformed;
    }

    /**
     * レスポンスヘッダの調整
     *
     * @param   array   $aSources   ソース情報
     * @param   array   $aHeaders   レスポンスヘッダ
     * @return  array   調整したレスポンスヘッダ
     */
    protected function _adjustResponseHeadersTransparent(array $aSource, array $aHeaders)
    {
        // 透過指定があるか？
        $bRetCode    = isset($aSource['passheader']['recv']);
        if ( $bRetCode !== true ) {
            // 透過指定なし → ヘッダの変更なし
            return $aHeaders;
        }
        // 透過指定があるか？
        $aInfo       = (array) \ArrayUtil::getValue($aSource['passheader'], 'recv', array());
        $bRetCode    = (bool)  \ArrayUtil::getValue($aInfo, 'transparent', false);
        if ( $bRetCode !== true ) {
            // 透過指定なし → ヘッダの変更なし
            return $aHeaders;
        }
        // ヘッダの調整指定があるか？
        $aConditions = (array) \ArrayUtil::getValue($aInfo, 'reform',      array());
        if ( $aConditions === array() ) {
            // 透過時の調整条件なし
            return $aHeaders;
        }
        // ヘッダの調整
        $aReformed   = $this->_reformHeaders($aHeaders, $aConditions);
        return $aReformed;
    }

    /**
     * レスポンスヘッダの調整
     *
     * @param   array   $aSources   ソース情報
     * @param   array   $aHeaders   レスポンスヘッダ
     * @return  array   調整したレスポンスヘッダ
     */
    protected function _adjustResponseHeadersForConvert(array $aSource, array $aHeaders)
    {
        // 変換のための最低限の調整
        $aChanges  = $this->aResReformConditions;
        // ヘッダを調整
        $aReformed = $this->_reformHeaders($aHeaders, $aChanges);
        // 調整したヘッダをセットするか否か
        // 透過指定があるか？
        $bRetCode  = isset($aSource['passheader']['recv']['transparent']);
        if ( $bRetCode === true && $aSource['passheader']['recv']['transparent'] === true) {
            // 透過指定あり → ヘッダをセット
            $this->_setResponseHeaders($aReformed);
        }
        return $aReformed;
    }

    /**
     * レスポンスヘッダのセット
     *
     * @param   array   $aHeaders   レスポンスヘッダ
     * @return  bool    true
     */
    protected function _setResponseHeaders(array $aRawHeaders)
    {
        $aHeaders             = array();
        foreach ( $aRawHeaders as $aInfo ) {
            $sName            = $aInfo['name'];
            $aHeaders[$sName] = $aInfo['values'];
        }
        // レスポンスヘッダをセット
        foreach ( $aHeaders as $sName => $mValue ) {
            $bRetCode         = is_array($mValue);
            if ( $bRetCode !== true ) {
                $this->oResponse->addHeader($sName, $sValue, false, NULL, NULL);
                continue;
            }
            foreach ( $mValue as $sValue ) {
                $this->oResponse->addHeader($sName, $sValue, false, NULL, NULL);
            }
        }
        return true;
    }

    /**
     * イレギュラーレスポンスのセット
     *
     * @param   string  $sSourceBody    レスポンス
     * @return  bool    true
     */
    protected function _setResponseIrregular($sSourceBody)
    {
        // 処理を分岐
        if        ( $this->aResState['action'] === 'redirect' ) {
            // リダイレクトならリダイレクトをセット
            $sMethod    = 'setRedirect';
            $sResValue  = $this->aResState['redirect'];
        } else if ( $this->aResState['action'] === 'error' ) {
            // エラーならエラーをセット
            $sMethod    = 'setError';
            $sResValue  = $sSourceBody;
        } else if ( $this->aResState['action'] === 'nothing' ) {
            // 何もしない場合にはそのままセット
            $sMethod    = 'setResult';
            $sResValue  = $sSourceBody;
        } else {
            // それ以外は正常レスポンスなので抜ける
            return true;
        }
        // ステータスコードを取得
        if         ( $this->aResState['primary'] !== \SC\libs\HttpStatus::NEVER_DONE ) {
            $iResStatus = $this->aResState['primary'];
        } else  if ( $this->aResState['primary'] !== \SC\libs\HttpStatus::NEVER_DONE ) {
            $iResStatus = $this->aResState['secondary'];
        } else {
            $iResStatus = $this->aResState['secondary'];
        }
        // レスポンスをセット
        $this->oResponse->$sMethod($sResValue, $iResStatus);
        return true;
    }

    /**
     * HTMLを加工
     *
     * @param   array   $aSources   ソース情報
     * @param   string  $sSourceBody
     * @return  string  加工済みのHTML
     * @throw   SC\exception\controller\ConvertModel\CantDetectEncoding
     */
    protected function _adjustResponseBody(array $aSource, $sSourceBody)
    {
        // 前後の空白を除去
        $sSourceBody             = trim($sSourceBody);
        // エンコード指定があるか？
        $bRetCode                = isset($aSource['encode']);
        if ( $bRetCode === true ) {
            $sEncodeSrc          = strtoupper($aSource['encode']);
            $sConverted          = $this->_convertEncoding($sSourceBody, $sEncodeSrc);
        } else {
            $sEncodeSrc          = '';
            $sConverted          = NULL;
        }
        if ( $sConverted === NULL ) {
            // ヘッダから文字コード検出
            if ( $this->aHTTPInfo['session']['charset'] !== '' ) {
                $sSourceEnc      = strtoupper(trim($this->aHTTPInfo['session']['charset'], '" '));
                $sConverted      = $this->_convertEncoding($sSourceBody, $this->aHTTPInfo['session']['charset']);
            }
        }
        if ( $sConverted === NULL ) {
            // 最終的に変換できなかった
            throw new \SC\exception\controller\ConvertModel\CantConvertEncoding('Can not convert encoding');
        }
        $sSourceBody             = $sConverted;
        // ソースをフィルタする
        $aReplacePairs           = (array) \ArrayUtil::getValue($aSource, 'input-filter', array());
        $iCount                  = count($aReplacePairs);
        if ( $iCount > 0 ) {
            $aSearches           = array_keys($aReplacePairs);
            $aReplaces           = array_values($aReplacePairs);
            $aSearches           = \Util::validatePCRE($aSearches, true, '#', 'u');
            $mRetValue           = preg_replace($aSearches, $aReplaces, $sSourceBody);
            if ( $mRetValue !== NULL ) {
                $sSourceBody     = $mRetValue;
            } else {
                \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for input-filter.');
                if ( $this->bLogPCREError === true ) {
                    \Log::dump(array(
                        'func'    => 'preg_replace',
                        'search'  => $aSearches,
                        'replace' => $aReplaces,
                        'subject' => $sSourceBody,
                    ), 'PCRE replace info:', \Log::LEVEL_TRACE);
                }
            }
        }
        // tidy
        $bRetCode                = extension_loaded('tidy');
        if ( $bRetCode === true ) {
            $aTidy               = (array) \ArrayUtil::getValue($aSource, 'tidy',    array());
            $bRetCode            = (bool)  \ArrayUtil::getValue($aTidy,   'enable',  true);
            if ( $bRetCode === true ) {
                $aTidyConfig     = (array) \ArrayUtil::getValue($aTidy,   'options', array());
                $sSourceBody     = tidy_repair_string($sSourceBody, $aTidyConfig, 'utf8');
            }
        }
        // HTMLをログ出力する設定か？
        $bLogHTML                = strtolower($this->oRequest->getServer('SC_LOG_HTML', '0'));
        if ( $bLogHTML === '1' || $bLogHTML === 'true' || $bLogHTML === 'on' ) {
            \Log::dump($sSourceBody, "HTML is following:", \Log::LEVEL_TRACE);
        }
        // XMLとして読み込めるようにHTMLエンティティにエンコード
        $sEncoded                = \Util::mb_convert_encoding($sSourceBody, 'HTML-ENTITIES', 'UTF-8');
        // 変換されなかった単独の&は&amp;に置換
        $sSearch                 = '/&(?!(\w+|#\d+|#x[\dA-Fa-f]+);)/u';
        $sReplace                = '&amp;';
        $mRetValue               = preg_replace($sSearch, $sReplace, $sEncoded);
        if ( $mRetValue !== NULL ) {
            $sEncoded            = $mRetValue;
        } else {
            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for &amp;.');
            if ( $this->bLogPCREError === true ) {
                \Log::dump(array(
                    'func'    => 'preg_replace',
                    'search'  => $sSearch,
                    'replace' => $sReplace,
                    'subject' => $sEncoded,
                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
            }
        }
        // scriptタグ中のエンティティを置換
        $sSearch                 = '#<script[^>]*>(?:(?>[^<]+)|(?:<[^/A-Za-z]+)|(?:<(?>[^>]+)(?<!/script)>))+</script>#uisSm';
        $sReplace                = get_class($this) . '::' . '_sanitizeHtmlCloseTags';
        $mRetValue               = preg_replace_callback($sSearch, array(&$this, '_sanitizeHtmlCloseTags'), $sEncoded);
        if ( $mRetValue !== NULL ) {
            $sEncoded            = $mRetValue;
        } else {
            \Log::notice('PCRE replace error has occurred: reason code=[' . preg_last_error() . '] for SCRIPT.');
            if ( $this->bLogPCREError === true ) {
                \Log::dump(array(
                    'func'    => 'preg_replace_callback',
                    'search'  => $sSearch,
                    'replace' => $sReplace,
                    'subject' => $sEncoded,
                ), 'PCRE replace info:', \Log::LEVEL_TRACE);
            }
        }
        // レスポンスボディを保持
        $this->aHTTPInfo['body'] = $sEncoded;
        return $sEncoded;
    }

    /**
     * HTMLの閉じタグをサニタイズする
     *
     * @param   array   $aMatches
     * @return  string  置換後の文字列
     */
    protected function _sanitizeHtmlCloseTags(array $aMatches)
    {
        $sNoScriptClose = substr($aMatches[0], 0, -9);
        $sSanitized     = str_replace('</', '<\/', $sNoScriptClose) . '</script>';
        return $sSanitized;
    }

    /**
     * 文字コード変換
     *
     * @param   string  $sString
     * @return  string  加工済みのHTML
     */
    protected function _convertEncoding($sString, $sEncodeSrc)
    {
        switch ( $sEncodeSrc ) {
            // 変換不要
            case 'UTF-8': case 'PASS':
            case 'ASCII': case 'US-ASCII':
                break;

            // 変換
            case 'SHIFT_JIS': case 'SHIFT-JIS': case 'SJIS': case 'SJIS-WIN': case 'XSJIS': case 'X-SJIS': case 'MS_KANJI': case 'WINDOWS-31J': case 'CP932': case 'MS932':
            case 'EUC-JP': case 'EUCJP-WIN': case 'JIS': case 'ISO-2022-JP':
                $sString = \Util::mb_convert_encoding($sString, 'UTF-8', $sEncodeSrc);
                break;

            // それ以外 → 自動検出
            default:
                return NULL;
        }
        return $sString;
    }

    /**
     * HTTPレスポンスの解析
     *
     * @param   array   $aSource        情報取得ソース
     * @param   int     $iResStatus     HTTPレスポンスステータス
     * @param   array   $aResHeaders    HTTPレスポンスヘッダ
     * @return  bool    継続フラグ      true:処理継続，false:処理を抜ける
     */
    protected function _analyzeResponse(array $aSource, $iResStatus, array $aResHeaders)
    {
        // -----------------------------------------------------------------------------
        // コンテントタイプの決定
        $sContentType                              = (string) \ArrayUtil::getValue($aSource, 'content-type', '');
        $bRetCode                                  = isset($aResHeaders['content-type']);
        $bRetCode                                  = isset($aResHeaders['content-type']);
        if ( $bRetCode === true ) {
            $aContentType                          = $aResHeaders['content-type'];
            $sContentType                          = join('; ', $aContentType['values']);
            $aContentType['parsed']                = $this->_extractContentType($sContentType);
            if ( $aContentType['parsed'] !== array() ) {
                $sCharset                          = $aContentType['parsed']['charset'];
            } else {
                $sCharset                          = '';
            }
        } else {
            $aContentType                          = array(
                'name'   => 'Content-Type',
                'values' => array(),
                'parsed' => array(),
            );
            $sCharset                              = '';
        }
        // 文字コードがContent-Typeにない場合には指定を採用
        if ( $sCharset === '' ) {
            $sCharsetContentType                   = (string) \ArrayUtil::getValue($aSource, 'encode', '');
            if ( $sCharsetContentType !== '' ) {
                $aContentType['parsed']['charset'] = $sCharsetContentType;
                $sCharset                          = $sCharsetContentType;
            }
        }
        // 後続処理に流れるか否かの指定
        $aTreatAs200s                              = (array) \ArrayUtil::getValue($aSource,      'treatAs200',    array());
        // 304,401を200として扱うか？
        $bTreat304As200                            = (bool)  \ArrayUtil::getValue($aTreatAs200s, '304',           false);
        $bTreat401As200                            = (bool)  \ArrayUtil::getValue($aTreatAs200s, '401',           false);
        $aTreatAs200s[304]                         = (bool)  \ArrayUtil::getValue($aSource,      'treat304As200', $bTreat304As200);
        $aTreatAs200s[401]                         = (bool)  \ArrayUtil::getValue($aSource,      'treat401As200', $bTreat401As200);

        // -----------------------------------------------------------------------------
        // HTTPステータスの決定
        //      ・プライマリステータスが決定済み
        //          ・200～299                                          →                                     ドキュメント解析                 →  処理継続
        //          ・その他                                            →                                     無視                             →  次のソースへ
        //      ・プライマリステータスが未決定
        //          ・プライマリソース
        //              ・200～299                                      →  プライマリステータスに     セット＆ドキュメント解析                 →  処理継続
        //              ・300～303                                      →  プライマリステータスに     セット＆リダイレクトセット＆stopフラグ   →  次のソースへ
        //              ・304                                           →  処理継続か否か判定(treat304As200: default=false)
        //              ・305～399                                      →  プライマリステータスに     セット＆リダイレクトセット＆stopフラグ   →  次のソースへ
        //              ・400                                           →  プライマリステータスに     セット＆エラーセット      ＆stopフラグ   →  次のソースへ
        //              ・401                                           →  処理継続か否か判定(treat401As200: default=false)
        //              ・402～599                                      →  プライマリステータスに     セット＆エラーセット      ＆stopフラグ   →  次のソースへ
        //              ・その他                                        →  プライマリステータスに500をセット＆エラーセット      ＆stopフラグ   →  次のソースへ
        //          ・セカンダリソース
        //              ・セカンダリステータスが未決定もしくは200～299
        //                  ・200～299                                  →  セカンダリステータスに     セット＆ドキュメント解析                 →  処理継続
        //                  ・300～303                                  →  セカンダリステータスに     セット＆リダイレクトセット               →  次のソースへ
        //                  ・304                                       →  処理継続か否か判定(treat304As200: default=false)
        //                  ・305～399                                  →  セカンダリステータスに     セット＆リダイレクトセット               →  次のソースへ
        //                  ・400                                       →  セカンダリステータスに     セット＆エラーセット                     →  次のソースへ
        //                  ・401                                       →  処理継続か否か判定(treat401As200: default=false)
        //                  ・402～599                                  →  セカンダリステータスに     セット＆エラーセット                     →  次のソースへ
        //                  ・その他                                    →  セカンダリステータスに500をセット＆エラーセット                     →  次のソースへ
        //              ・セカンダリステータスがその他                  →                                     無視                             →  次のソースへ
        //
        //  cf. HTTPレスポンスステータスコード分類
        //      100～199    送信継続
        //      200～299    ソース正常取得
        //      300～303    リダイレクト
        //      304         リダイレクト(変更なし)
        //      305～399    リダイレクト
        //      400         クライアントエラー
        //      401         クライアントエラー(認証)
        //      402～499    クライアントエラー
        //      500～599    サーバエラー
        // -----------------------------------------------------------------------------
        // プライマリステータスが決定済みか？
        if ( $this->aResState['primary'] !== \SC\libs\HttpStatus::NEVER_DONE ) {
            // 決定済みなので処理継続(ドキュメント解析)
            return true;
        }
        // プライマリステータスが未決定 → プライマリソースか？
        if ( $aSource['primary'] === true ) {
            // プライマリソースはステータスに応じて処理を決定
            if        ( 200 <= $iResStatus && $iResStatus < 300 ) {
                $this->aResState['primary']        = $iResStatus;
                $this->aResState['content-type']   = $aContentType;
                $this->aResState['charset']        = $sCharset;
                // 処理継続(ドキュメント解析)
                return true;
            } else if ( $iResStatus === 304 ) {
                $this->aResState['primary']        = $iResStatus;
                $this->aResState['content-type']   = $aContentType;
                $this->aResState['charset']        = $sCharset;
                if ( $bTreat304As200 === true ) {
                    // 処理継続(ドキュメント解析)
                    return true;
                } else {
                    $this->aResState['action']     = 'nothing';
                    $this->aResState['stop']       = true;
                    // 次のソースへ
                    return false;
                }
            } else if ( 300 <= $iResStatus && $iResStatus < 400 ) {
                $this->aResState['primary']        = $iResStatus;
                $this->aResState['content-type']   = $aContentType;
                $this->aResState['charset']        = $sCharset;
                $this->aResState['redirect']       = $this->_extractLocation($iResStatus, $aResHeaders);
                if ( $this->aResState['redirect'] !== '' ) {
                    $this->aResState['action']     = 'redirect';
                } else {
                    $this->aResState['action']     = 'nothing';
                }
                $this->aResState['stop']           = true;
                // 次のソースへ
                $bRetState                         = (bool) \ArrayUtil::getValue($aTreatAs200s, $iResStatus, false);
                return $bRetState;
            } else if ( $bTreat401As200 === true && $iResStatus === 401 ) {
                $this->aResState['primary']        = $iResStatus;
                $this->aResState['content-type']   = $aContentType;
                $this->aResState['charset']        = $sCharset;
                // 処理継続(ドキュメント解析)
                $bRetState                         = (bool) \ArrayUtil::getValue($aTreatAs200s, $iResStatus, true);
                return $bRetState;
            } else if ( 400 <= $iResStatus && $iResStatus < 600 ) {
                $this->aResState['primary']        = $iResStatus;
                $this->aResState['content-type']   = $aContentType;
                $this->aResState['charset']        = $sCharset;
                $this->aResState['action']         = 'error';
                $this->aResState['stop']           = true;
                // 次のソースへ
                $bRetState                         = (bool) \ArrayUtil::getValue($aTreatAs200s, $iResStatus, false);
                return $bRetState;
            } else {
                $this->aResState['primary']        = \HttpStatus::INTERNAL_SERVER_ERROR;
                $this->aResState['content-type']   = $aContentType;
                $this->aResState['charset']        = $sCharset;
                $this->aResState['action']         = 'error';
                $this->aResState['stop']           = true;
                // 次のソースへ
                return false;
            }
        }
        // セカンダリソース → セカンダリステータスが未決定もしくは200～299
        if ( $this->aResState['secondary'] === \SC\libs\HttpStatus::NEVER_DONE || ( 200 <= $this->aResState['secondary'] && $this->aResState['secondary'] < 300 ) ) {
            // セカンダリソースはステータスに応じて処理を決定
            if        ( 200 <= $iResStatus && $iResStatus < 300 ) {
                $this->aResState['secondary']      = $iResStatus;
                // 処理継続(ドキュメント解析)
                return true;
            } else if ( 300 <= $iResStatus && $iResStatus < 400 ) {
                $this->aResState['secondary']      = $iResStatus;
                // 次のソースへ
                $bRetState                         = (bool) \ArrayUtil::getValue($aTreatAs200s, $iResStatus, false);
                return $bRetState;
            } else if ( $bTreat401As200 === true && $iResStatus === 401 ) {
                $this->aResState['secondary']      = $iResStatus;
                // 処理継続(ドキュメント解析)
                $bRetState                         = (bool) \ArrayUtil::getValue($aTreatAs200s, $iResStatus, true);
                return $bRetState;
            } else if ( 400 <= $iResStatus && $iResStatus < 600 ) {
                $this->aResState['secondary']      = $iResStatus;
                // 次のソースへ
                $bRetState                         = (bool) \ArrayUtil::getValue($aTreatAs200s, $iResStatus, false);
                return $bRetState;
            } else {
                $this->aResState['secondary']      = \HttpStatus::INTERNAL_SERVER_ERROR;
                // 次のソースへ
                return false;
            }
        }
        // 次のソースへ
        return false;
    }

    /**
     * Content-Typeヘッダ値
     *
     * @param   string  $sContentType   Content-Typeヘッダ値
     * @return  array   Content-Type情報
     */
    protected function _extractContentType($sContentType)
    {
        if ( $sContentType === '' ) {
            return array();
        }
        // パーツ解析
        $aParts           = explode(';', $sContentType);
        $sType            = trim(array_shift($aParts));
        $aTypes           = explode('/', $sType, 2);
        $iCount           = count($aTypes);
        if ( $iCount === 1 ) {
            $sPrimary     = trim($aTypes[0]);
            $sSecondary   = '';
        } else if ( $iCount === 2 ) {
            $sPrimary     = trim($aTypes[0]);
            $sSecondary   = trim($aTypes[1]);
        } else {
            $sPrimary     = 'text';
            $sSecondary   = 'html';
        }
        $sCharset         = '';
        $aSubs            = array();
        foreach ( $aParts as $sPart ) {
            // 文字コード指定があるか？
            $sPart        = trim($sPart);
            $bFound       = (bool) preg_match('#^charset\s*=\s*("([^"]+)"|([^;\s]+))(?:[;\s]|$)$#i', $sPart, $aMatches);
            if ( $bFound === true ) {
                // 見つかったら保持
                $sCharset = trim($aMatches[1], '" ');
            } else {
                $aSubs[]  = $sPart;
            }
        }
        // 結果収集
        $aResult          = array(
            'raw'       => $sContentType,
            'primary'   => $sPrimary,
            'secondary' => $sSecondary,
            'charset'   => $sCharset,
            'subs'      => $aSubs,
        );
        return $aResult;
    }

    /**
     * Locationフィールドの抽出
     *
     *  see also: http://ja.wikipedia.org/wiki/HTTP%E3%82%B9%E3%83%86%E3%83%BC%E3%82%BF%E3%82%B9%E3%82%B3%E3%83%BC%E3%83%89
     *  ステータスコードが 300, 304, 306 の場合はLocationフィールドがない
     *
     * @param   int     $iResStatus     HTTPレスポンスステータス
     * @param   array   $aResHeaders    HTTPレスポンスヘッダ
     * @return  string  リダイレクト先
     * @throw   SC\exception\controller\ConvertModel\EmptyLocation
     */
    protected function _extractLocation($iResStatus, array $aResHeaders)
    {
        $bRetCode      = isset($aResHeaders['location']);
        if ( $bRetCode === true ) {
            $sLocation = trim((string)reset($aResHeaders['location']['values']));
        } else {
            $sLocation = '';
        }
        if ( $sLocation === '' ) {
            switch ( $iResStatus ) {
                // LocationがなくてもOK
                case 300: case 304: case 306:
                    break;

                // Locationがない場合は例外
                default:
                    throw new \SC\exception\controller\ConvertModel\EmptyLocation("Empty Location field for redirect status '$iResStatus'");
                    break;
            }
        }
        return $sLocation;
    }

    /**
     * HTTPレスポンスヘッダのリフォーム
     *
     *  リフォーム前の形式：
     *      array(string)
     *
     *  リフォーム後の形式：
     *      array(
     *          <LOWERNAME>  => array(
     *              'name'   => string
     *              'values' => array(string)
     *          )
     *      )
     *
     * @param   array   $aRawHeaders
     * @return  array   リフォーム後のHTTPレスポンスヘッダ
     */
    protected function _reformHttpResponseHeaders(array $aRawHeaders)
    {
        // 先頭行は必ずステータスなので除去
        $sHttpStatus                              = array_shift($aRawHeaders);

        // レスポンスヘッダを分解
        $aResHeaders                              = array();
        foreach ( $aRawHeaders as $sLine ) {
            // 名前と値に分割
            $aParts                               = explode(':', $sLine, 2);
            $sName                                = trim($aParts[0]);
            $sValue                               = trim($aParts[1]);
            $sLower                               = strtolower($sName);
            // 存在するか否か
            $bRetCode                             = isset($aResHeaders[$sLower]);
            if ( $bRetCode !== true ) {
                $aResHeaders[$sLower]             = array();
                $aResHeaders[$sLower]['name']     = $sName;
                $aResHeaders[$sLower]['values']   = array($sValue);
            } else {
                $aResHeaders[$sLower]['values'][] = $sValue;
            }
        }
        return $aResHeaders;
    }

    /**
     * Apacheリクエストヘッダのリフォーム
     *
     *  リフォーム前の形式：
     *      array(string => string)
     *
     *  リフォーム後の形式：
     *      array(
     *          <LOWERNAME>  => array(
     *              'name'   => string
     *              'values' => array(string)
     *          )
     *      )
     *
     * @param   array   $aRawHeaders
     * @return  array   リフォーム後のヘッダ
     */
    protected function _reformApacheRequestHeaders(array $aRawHeaders)
    {
        // レスポンスヘッダを分解
        $aReqHeaders                              = array();
        foreach ( $aRawHeaders as $sName => $sValue ) {
            // 名前と値に分割
            $sName                                = trim($sName);
            $sValue                               = trim($sValue);
            $sLower                               = strtolower($sName);
            // 存在するか否か
            $bRetCode                             = isset($aReqHeaders[$sLower]);
            if ( $bRetCode !== true ) {
                $aReqHeaders[$sLower]             = array();
                $aReqHeaders[$sLower]['name']     = $sName;
                $aReqHeaders[$sLower]['values']   = array($sValue);
            } else {
                $aReqHeaders[$sLower]['values'][] = $sValue;
            }
        }
        return $aReqHeaders;
    }

    /**
     * ヘッダ内容のリフォーム
     *
     *  リフォームの形式：
     *      array(
     *          <LOWERNAME>  => array(
     *              'name'   => string
     *              'values' => array(string)
     *          )
     *      )
     *
     * @param   array   $aHeaders       ヘッダ
     * @param   array   $aConditions    変更条件
     * @return  array   リフォーム後のヘッダ
     */
    protected function _reformHeaders(array $aHeaders, array $aConditions)
    {
        // リフォームの数だけ繰り返し
        foreach ( $aConditions as $sName => $aReform ) {
            // リフォームターゲット(必ず小文字)
            $sTarget           = strtolower(\ArrayUtil::getValue($aReform, 'target', ''));
            if ( $sTarget === '' ) {
                // ターゲットなしはリフォームしない
                continue;
            }
            $sType             = ucfirst(strtolower(\ArrayUtil::getValue($aReform, 'type',   '')));
            if ( $sTarget === '' ) {
                // タイプなしはリフォームしない
                continue;
            }
            // タイプごとに処理
            switch ( $sType ) {
                // ヘッダフィールドの追加・変更・削除
                case 'Add':
                case 'Replace':
                case 'Remove':
                    $aHeaders  = $this->{'_reformHeader' . $sType}($aHeaders, $sTarget, $aReform, "$sName :: $sType");
                    break;
                // その他
                default:
                    // 変更なし
                    break;
            }
        }
        // 修正したヘッダを返す
        return $aHeaders;
    }

    /**
     * ヘッダ内容のリフォーム(追加)
     *
     * @param   array   $aHeaders       ヘッダ
     * @param   string  $sTarget        ヘッダフィールド名
     * @param   array   $aReform        変更条件
     * @param   string  $sLogLabel      ログラベル
     * @return  array   リフォーム後のヘッダ
     */
    protected function _reformHeaderAdd(array $aHeaders, $sTarget, array $aReform, $sLogLabel)
    {
        // 条件取得
        $aConditions                        = (array) \ArrayUtil::getValue($aReform, 'conditions', array());
        if ( $aConditions !== array() ) {
            // 条件あり
            $bMatched                       = $this->_reformHeaderCond($aHeaders, $sTarget, $aConditions, $sLogLabel);
            if ( $bMatched !== true ) {
                // 条件無効 → 追加不要
                if ( $this->iLogMatch > 0 ) {
                    \Log::trace("Pass Header Reform [$sLogLabel]: nothing to do. ($sTarget)");
                }
                return $aHeaders;
            }
        }
        // 追加する → 生データか？
        $bRawData                           = (bool)   \ArrayUtil::getValue($aReform, 'raw',   false);
        $sName                              = $aReform['target'];
        $sValue                             = (string) \ArrayUtil::getValue($aReform, 'value', '');
        // 指定がなければURLエンコード
        if ( $bRawData !== true ) {
            $sName                          = $this->_urlencode(trim($sName));
            $sValue                         = $this->_urlencode(trim($sValue));
        }
        $aHeader                            = \ArrayUtil::getValue($aHeaders, $sTarget, array());
        if ( $aHeader === array() ) {
            // 存在しない
            $aHeaders[$sTarget]             = array(
                'name'   => $sName,
                'values' => array( $sValue ),
            );
        } else {
            // 存在するので追加
            $aHeaders[$sTarget]['values'][] = $sValue;
        }
        if ( $this->iLogMatch > 0 ) {
            \Log::trace("Pass Header Reform [$sLogLabel]: '$sName'='$sValue' added.");
        }
        return $aHeaders;
    }

    /**
     * ヘッダ内容のリフォーム(変更)
     *
     * @param   array   $aHeaders       ヘッダ
     * @param   string  $sTarget        ヘッダフィールド名
     * @param   array   $aReform        変更条件
     * @param   string  $sLogLabel      ログラベル
     * @return  array   リフォーム後のヘッダ
     */
    protected function _reformHeaderReplace(array $aHeaders, $sTarget, array $aReform, $sLogLabel)
    {
        // フィールドがあるか？
        $aHeader                 = (array) \ArrayUtil::getValue($aHeaders, $sTarget, array());
        if ( $aHeader === array() ) {
            // フィールドがない → 変更不要
            if ( $this->iLogMatch > 0 ) {
                \Log::trace("Pass Header Reform [$sLogLabel]: nothing to do. ($sTarget)");
            }
            return $aHeaders;
        }
        // 変更条件の正規化
        $aReformList             = $this->_reformHeaderReplaceReform($sTarget, $aReform);
        foreach ( $aReformList as $iKeyR => $aReform ) {
            // 条件取得
            $aConditions         = (array) \ArrayUtil::getValue($aReform, 'conditions', array());
            if ( $aConditions !== array() ) {
                // 条件あり
                $bMatched        = $this->_reformHeaderCond($aHeaders, $sTarget, $aConditions, "$sLogLabel :: $iKeyR");
                if ( $bMatched !== true ) {
                    // 条件無効 → 変更不要
                    if ( $this->iLogMatch > 0 ) {
                        \Log::trace("Pass Header Reform [$sLogLabel :: $iKeyR]: nothing to do. ($sTarget)");
                    }
                    continue;
                }
            }
            // 置換条件を取得
            $sSearch             = \Util::refine($aReform['search'],  false, $this->aReplacePairs);
            $sReplace            = \Util::refine($aReform['replace'], false, $this->aReplacePairs);
            switch ( $aReform['compare'] ) {
                // 正規表現で置換
                case '~':
                    if ( $aReform['ignorecase'] === true ) {
                        $sExtent = 'ui';
                    } else {
                        $sExtent = 'u';
                    }
                    $sSearch     = \Util::validatePCRE($sSearch, false, '#', $sExtent);
                    $sMethod     = 'preg_replace';
                    break;

                // 文字列置換
                case '=':
                    if ( $aReform['ignorecase'] === true ) {
                        $sMethod = 'str_ireplace';
                    } else {
                        $sMethod = 'str_replace';
                    }
                    break;

                // その他
                default:
                    // その他はない → 次へ
                    continue;
            }
            // 置換対象を取得
            $aTargetValues     = (array)  \ArrayUtil::getValue($aHeaders,      $sTarget,    array());
            $aTargetValues     = (array)  \ArrayUtil::getValue($aTargetValues, 'values',    array());
            foreach ( $aTargetValues as $iKeyT => $sTargetValue ) {
                $mRetValue     = call_user_func($sMethod, $sSearch, $sReplace, $sTargetValue);
                if ( $mRetValue === NULL ) {
                    if ( $this->iLogMatch > 0 ) {
                        \Log::trace("Pass Header Reform [$sLogLabel :: $iKeyR :: $iKeyT]: not replaced [$sMethod('$sSearch', '$sReplace', '$sTargetValue')].");
                    }
                    continue;
                }
                if ( $aReform['raw'] !== true ) {
                    $mRetValue = $this->_urlencode($mRetValue);
                }
                $aHeaders[$sTarget]['values'][$iKeyT] = $mRetValue;
                if ( $this->iLogMatch > 0 ) {
                    \Log::trace("Pass Header Reform [$sLogLabel :: $iKeyR :: $iKeyT]: replaced '{$sTargetValue}' as '{$mRetValue}'.");
                }
            }
        }
        return $aHeaders;
    }

    /**
     * ヘッダ内容のリフォーム(削除)
     *
     * @param   array   $aHeaders       ヘッダ
     * @param   string  $sTarget        ヘッダフィールド名
     * @param   array   $aReform        変更条件
     * @param   string  $sLogLabel      ログラベル
     * @return  array   リフォーム後のヘッダ
     */
    protected function _reformHeaderRemove(array $aHeaders, $sTarget, array $aReform, $sLogLabel)
    {
        // フィールドがあるか？
        $aHeader      = (array) \ArrayUtil::getValue($aHeaders, $sTarget, array());
        if ( $aHeader === array() ) {
            // フィールドがない → 削除不要
            if ( $this->iLogMatch > 0 ) {
                \Log::trace("Pass Header Reform [$sLogLabel]: nothing to do. ($sTarget)");
            }
            return $aHeaders;
        }
        // 条件取得
        $aConditions  = (array) \ArrayUtil::getValue($aReform, 'conditions', array());
        if ( $aConditions !== array() ) {
            // 条件あり
            $bMatched = $this->_reformHeaderCond($aHeaders, $sTarget, $aConditions, $sLogLabel);
            if ( $bMatched !== true ) {
                // 条件無効 → 削除不要
                if ( $this->iLogMatch > 0 ) {
                    \Log::trace("Pass Header Reform [$sLogLabel]: nothing to do. ($sTarget)");
                }
                return $aHeaders;
            }
        }
        // 削除
        unset($aHeaders[$sTarget]);
        if ( $this->iLogMatch > 0 ) {
            \Log::trace("Pass Header Reform [$sLogLabel]: '{$sTarget}' removed.");
        }
        return $aHeaders;
    }

    /**
     * ヘッダ内容のリフォーム(変更)のための変更条件の正規化
     *
     * @param   string  $sTarget        ヘッダフィールド名
     * @param   array   $aReform        変更条件
     * @return  array   変更条件の配列
     */
    protected function _reformHeaderReplaceReform($sTarget, array $aReform)
    {
        // 変更内容取得
        $sSearch                 = \ArrayUtil::getValue($aReform, 'search',  NULL);
        $sReplace                = \ArrayUtil::getValue($aReform, 'replace', NULL);
        // 条件取得
        $bRaw                    = (bool)   \ArrayUtil::getValue($aReform, 'raw',        false);
        $sCompare                = (string) \ArrayUtil::getValue($aReform, 'compare',    '=');
        $aOptions                = (array)  \ArrayUtil::getValue($aReform, 'options',    array());
        $bIgnoreCase             = (bool)   count(array_intersect(array('nocase', 'NC', 'ignorecase'), $aOptions));
        $bIgnoreCase             = (bool)   \ArrayUtil::getValue($aReform, 'ignorecase', $bIgnoreCase);
        $aConditions             = (array)  \ArrayUtil::getValue($aReform, 'conditions', array());
        if ( $aConditions === array() ) {
            // 条件なし
            $aReformList         = array();
            if ( $sSearch !== NULL ) {
                // 検索対象はあり
                $aReformList[]   = array(
                    'target'     => $aReform['target'], // targetは必ずある
                    'type'       => 'replace',          // typeは必ずreplace
                    'compare'    => $sCompare,          // 演算子
                    'ignorecase' => $bIgnoreCase,       // 大文字小文字無視するか否か
                    'search'     => $sSearch,           // 検索文字列(オリジナル)
                    'replace'    => $sReplace,          // 置換文字列(オリジナル)
                    'raw'        => $bRaw,              // 置換後にurlencodeするか否か
                    'options'    => $aOptions,          // オプション
                    'conditions' => array(),            // 条件はなし
                );
            }
            return $aReformList;
        }
        // 1次元配列なら2次元にする
        $mFirst                  = reset($aConditions);
        $bRetCode                = is_array($mFirst);
        if ( $bRetCode !== true ) {
            $aConditions         = array($aConditions);
        }
        // リフォーム
        $aEach                   = array(
            'target'     => $aReform['target'], // targetは必ずある
            'type'       => 'replace',          // typeは必ずreplace
            'compare'    => $sCompare,          // 演算子
            'ignorecase' => $bIgnoreCase,       // 大文字小文字無視するか否か
            'search'     => $sSearch,           // 検索文字列(オリジナル)
            'replace'    => $sReplace,          // 置換文字列(オリジナル)
            'raw'        => $bRaw,              // 置換後にurlencodeするか否か
            'options'    => $aOptions,          // オプション
            'conditions' => array(),            // 条件はなし
        );
        // 置換条件と適用条件が別か否か
        if ( $sSearch !== NULL ) {
            // 置換条件と適用条件が別々 → 分割は不要(適用条件部分のreplaceは無視)
            $aEach['conditions'] = $aConditions;
            $aReformList         = array($aEach);
        } else {
            // 置換条件と適用条件が同一 → 適用条件部分を置換条件と解釈して分割
            $aReformList         = $this->_reformHeaderReplaceReformSplit($aEach, $aConditions);
        }
        return $aReformList;
    }

    /**
     * 適用条件を置換条件と解釈して分割して変更条件の配列を生成
     *
     * @param   array   $aReform        変更条件
     * @param   array   $aConditions    適用条件
     * @return  array   変更条件の配列
     */
    protected function _reformHeaderReplaceReformSplit(array $aReform, array $aConditions)
    {
        // 置換条件と適用条件が同一 → 適用条件部分を置換条件と解釈して分割
        $aReformList             = array();
        foreach ( $aConditions as $iKey => $aCond ) {
            $aEach               = $aReform;
            // 適用条件の取得
            $sSearch             = \ArrayUtil::getValue($aCond, 'search',  NULL);
            if ( $sSearch === NULL ) {
                // 適用条件の検索指定なし → 次へ
                continue;
            }
            $sReplace            = \ArrayUtil::getValue($aCond, 'replace',  NULL);
            if ( $sReplace === NULL ) {
                // 適用条件の置換指定なし → 次へ
                continue;
            }
            // 適用条件の詳細取得
            $aEach['compare']    = (string) \ArrayUtil::getValue($aCond, 'compare',    $aReform['compare']);
            $aOptions            = (array)  \ArrayUtil::getValue($aCond, 'options',    $aReform['options']);
            $bIgnoreCase         = (bool)   count(array_intersect(array('nocase', 'NC', 'ignorecase'), $aOptions));
            $aEach['ignorecase'] = (bool)   \ArrayUtil::getValue($aCond, 'ignorecase', $bIgnoreCase||$aReform['ignorecase']);
            $aEach['search']     = $sSearch;
            $aEach['replace']    = $sReplace;
            $aEach['raw']        = (bool)   \ArrayUtil::getValue($aCond, 'raw',        $aReform['raw']);
            $aEach['options']    = $aOptions;
            $aEach['conditions'] = array();
            $aReformList[]       = $aEach;
        }
        return $aReformList;
    }

    /**
     * ヘッダ内容のリフォーム条件に合致するか否か
     *
     * @param   array   $aHeaders       ヘッダ
     * @param   string  $sTarget        ヘッダフィールド名
     * @param   array   $aConditions    適用条件
     * @param   string  $sLogLabel      ログラベル
     * @return  bool    合致するか否か
     */
    protected function _reformHeaderCond(array $aHeaders, $sTarget, array $aConditions, $sLogLabel)
    {
        // 1次元配列なら2次元にする
        $mFirst                  = reset($aConditions);
        $bRetCode                = is_array($mFirst);
        if ( $bRetCode !== true ) {
            $aConditions         = array($aConditions);
        }
        // 判定ループを回す
        $bMatched                = false;
        $bPrevOr                 = false;
        foreach ( $aConditions as $iKey => $aCond ) {
            // 前条件が，マッチしていてornext指定あり
            if ( $bMatched === true && $bPrevOr === true ) {
                // ornext指定もしくはOR指定があれば次の条件へ
                $bPrevOr         = $this->_checkCondOrNext($aCond);
                continue;
            }
            // 条件判定
            $bMatched            = false;
            $bPrevOr             = $this->_checkCondOrNext($aCond);
            // ターゲットを取得
            $aTargetValues       = $this->_getTargetValue($aHeaders, $sTarget, $aCond);
            if ( $aTargetValues !== array() ) {
                // 比較
                $bRetCode        = $this->_reformHeaderCondCompare($aCond, $aTargetValues, "$sLogLabel :: $iKey");
                if ( $bRetCode === true ) {
                    // 見つかったら次の条件へ
                    $bMatched    = true;
                    continue;
                }
            }
            // ornext指定もしくはOR指定がなければマッチしないのでNG
            if ( $bPrevOr !== true ) {
                break;
            }
        }
        return $bMatched;
    }

    /**
     * 比較対象文字列を取得する
     *
     * @param   array   $aHeaders       ヘッダ情報
     * @param   string  $sTarget        ヘッダフィールド名
     * @param   array   $aCond          比較条件
     * @return  array   比較対象文字列の配列
     */
    protected function _getTargetValue(array $aHeaders, $sTarget, array $aCond)
    {
        $aTargetKey                        = explode(':', (string) \ArrayUtil::getValue($aCond, 'target', $sTarget), 2);
        $iCount                            = count($aTargetKey);
        if ( $iCount === 1 ) {
            $sTargetKey                    = $aTargetKey[0];
            $sTargetFrom                   = 'header';
        } else {
            $sTargetKey                    = $aTargetKey[1];
            $sTargetFrom                   = strtolower($aTargetKey[0]);
        }
        switch ( $sTargetFrom ) {
            // ヘッダ
            case 'header':
                $sTargetKey                = strtolower($sTargetKey);
                $aTargetValues             = (array) \ArrayUtil::getValue($aHeaders,      $sTargetKey, array());
                $aTargetValues             = (array) \ArrayUtil::getValue($aTargetValues, 'values',    array());
                break;

            // サーバのチェック
            case 'server':
                if ( $sTargetKey === 'PATH_INFO' ) {
                    // PATH_INFOだけは指定のものを使う
                    $aTargetValues         = (array) $this->oRequest->getPathInfo();
                    break;
                }
                $bRetCode                  = isset($this->aReformTarget[$sTargetKey]);
                if ( $bRetCode === true ) {
                    $aTargetValues         = (array) $this->oRequest->getServer($sTargetKey, '');
                } else {
                    $bFound                = false;
                    foreach ( $this->aReformTargetPrefix as $sPrefix => $bRetCode ) {
                        $iCmp              = strncmp($sPrefix, $sTargetKey, strlen($sPrefix));
                        if ( $iCmp === 0 ) {
                            $bFound        = true;
                            $aTargetValues = (array) $this->oRequest->getServer($sTargetKey, '');
                            break;
                        }
                    }
                    if ( $bFound !== true ) {
                        $aTargetValues     = array();
                    }
                }
                break;

            // その他のターゲット
            case 'cookie':
            case 'request':
            case 'post':
            case 'get':
                $sMethod                   = 'get' . ucfirst($sTargetFrom);
                $aTargetValues             = (array) $this->oRequest->$sMethod($sTargetKey, '');
                break;

            // その他
            default:
                $aTargetValues             = array();
                break;
        }
        return $aTargetValues;
    }

    /**
     * ornextオプションがあるか？
     *
     * @param   array   $aCond      条件情報
     * @return  bool    OR指定があるか否か(true/false)
     */
    protected function _checkCondOrNext(array $aCond)
    {
        // オプション指定があるか？
        $bRetCode     = isset($aCond['options']);
        if ( $bRetCode !== true ) {
            // オプション指定なし
            return false;
        }
        // ornext指定があるか？
        $bRetCode     = in_array('ornext', $aCond['options']);
        if ( $bRetCode === true ) {
            // あればOR
            return true;
        }
        // OR指定があるか？
        $bRetCode     = in_array('OR', $aCond['options']);
        if ( $bRetCode === true ) {
            // あればOR
            return true;
        }
        // 無ければAND
        return false;
    }

    /**
     * 比較条件
     *
     * @param   array   $aCond          比較条件
     * @param   array   $aTargetValues  比較対象
     * @param   string  $sLogLabel      ログラベル
     * @return  bool    条件にマッチしたか否か(true/false)
     */
    protected function _reformHeaderCondCompare(array $aCond, array $aTargetValues, $sLogLabel)
    {
        // 比較対象があるか？
        if ( $aTargetValues === array() ) {
            // 比較対象として無効
            return false;
        }
        // 適用条件の取得
        $sSearchOrg          = \ArrayUtil::getValue($aCond, 'search',  NULL);
        if ( $sSearchOrg === NULL ) {
            // 条件として無効
            return false;
        }
        $sSearch             = \Util::refine((string) $sSearchOrg,  false, $this->aReplacePairs);
        // 適用条件の詳細取得
        $sCompare            = (string) \ArrayUtil::getValue($aCond, 'compare',    '=');
        $aOptions            = (array)  \ArrayUtil::getValue($aCond, 'options',    array());
        $bIgnoreCase         = (bool)   count(array_intersect(array('nocase', 'NC', 'ignorecase'), $aOptions));
        $bIgnoreCase         = (bool)   \ArrayUtil::getValue($aCond, 'ignorecase', $bIgnoreCase);
        $bSatisfyAll         =          in_array('satisfyall', $aOptions);
        $bSatisfyAll         = (bool)   \ArrayUtil::getValue($aCond, 'satisfyall', $bSatisfyAll);
        // 比較処理
        foreach ( $aTargetValues as $iKey => $sTargetValue ) {
            $bExpect                = true;
            $bMatched               = false;
            $aLogMatch              = array();
            switch ( $sCompare ) {
                // 正規表現で比較
                case '!~':
                    $bExpect        = false;
                // 正規表現で比較
                case '~':
                    if ( $sSearch === '' ) {
                        // 正規表現で空文字にマッチはNG
                        break;
                    }
                    if ( $bIgnoreCase === true ) {
                        $sExtent    = 'ui';
                    } else {
                        $sExtent    = 'u';
                    }
                    $sPattern       = \Util::validatePCRE($sSearch, false, '#', $sExtent);
                    $bFound         = (bool) preg_match($sPattern, $sTargetValue);
                    if ( $bFound === $bExpect ) {
                        $bMatched   = true;
                    }
                    // マッチログ
                    if ( $this->iLogMatch > 1 ) {
                        $aLogMatch  = array(
                            'regex'        => array(
                                'found'    => $bFound,
                                'expect'   => $bExpect,
                                'pattern'  => $sPattern,
                                'extent'   => $sExtent,
                            ),
                        );
                    }
                    break;

                // 完全不一致で比較
                case '!=': case '<>':
                    $bExpect      = false;
                // 完全一致で比較
                case '=':
                    if ( $bIgnoreCase === true ) {
                        $sCmpFunc   = 'strcasecmp';
                    } else {
                        $sCmpFunc   = 'strcmp';
                    }
                    $bCmp           = ! (bool) $sCmpFunc($sTargetValue, $sSearch);
                    if ( $bCmp === $bExpect ) {
                        $bMatched   = true;
                    }
                    // マッチログ
                    if ( $this->iLogMatch > 1 ) {
                        $aLogMatch  = array(
                            'eq'           => array(
                                'cmpfunc'  => $sCmpFunc,
                                'cmp'      => $bCmp,
                                'expect'   => $bExpect,
                            ),
                        );
                    }
                    break;

                // その他
                default:
                    // マッチしない
                    break;
            }
            // マッチログ
            if ( $this->iLogMatch > 1 ) {
                $aLogMatch          = array_merge(array(
                    'matched'      => $bMatched,
                    'compare'      => $sCompare,
                    'ignorecase'   => $bIgnoreCase,
                    'satisfyall'   => $bSatisfyAll,
                    'search'       => $sSearch,
                    'target'       => $sTargetValue,
                ), $aLogMatch);
                \Log::dump($aLogMatch, "Pass Header matching  [ $sLogLabel :: $iKey ]:", \Log::LEVEL_TRACE);
            }
            // Satisfy All or Satisfy Any ?
            if ( $bSatisfyAll !== true ) {
                // いずれかがマッチすればOK
                if ( $bMatched === true ) {
                    // マッチしたので抜ける
                    break;
                }
                // 次回に期待
            } else {
                // すべてがマッチすればOK
                if ( $bMatched !== true ) {
                    // マッチしなかったので抜ける
                    break;
                }
                // 次回も判定
            }
        }
        return $bMatched;
    }

    /**
     * urlencode
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _urlencode($sInput)
    {
        if ( $this->bUseRFC3982 === false ) {
            $sOutput = urlencode($sInput);
        } else {
            $sOutput = rawurlencode($sInput);
        }
        return $sOutput;
    }

    /**
     * urldecode
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _urldecode($sInput)
    {
        if ( $this->bUseRFC3982 === false ) {
            $sOutput = urldecode($sInput);
        } else {
            $sOutput = rawurldecode($sInput);
        }
        return $sOutput;
    }
}
