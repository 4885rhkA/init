<?php
/**
 * ConvertModelの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\controller;

/**
 * ConvertModelの例外
 */
class ConvertModel extends \SC\exception\controller
{
}
