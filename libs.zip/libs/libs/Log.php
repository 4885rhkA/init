<?php
/**
 * ロガー
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ロガー
 */
final class Log extends AbstractLog
{
    /**
     * 自前のログディレクトリの根元
     *
     * @var string $sLogRoot
     */
    protected $sLogRoot = self::LOG_ROOT;

    /**
     * 自前のログ出力先
     *
     * @var string $sLogFile
     */
    protected $sLogFile = '%Y/%m/app-%Y%m%d.log';

    /**
     * 自前のログ出力先(古パス)
     *
     * @var string $sLogFilePath
     */
    protected $sLogFilePath = '';

    /**
     * 開始ログを出力したか否か
     *
     * @var bool $bStarted
     */
    protected $bStarted = false;

    /**
     * インスタンス
     *
     * @var SC\libs\Log $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * 初期化処理
     *
     * @return bool true
     */
    protected function _initialize()
    {
        // ログの設定
        $this->sLogRoot                            = static::LOG_ROOT;
        $sLogFile                                  = Request::getServer('SC_LOG_FILE', $this->sLogFile);
        $this->_setLogFile($sLogFile);
        $this->iLogLevel                           = ( (int) Request::getServer('SC_LOG_LEVEL',         1048587) ) & static::LEVEL_MAX;
        $this->iDisplayLevel                       = ( (int) Request::getServer('SC_LOG_DISPALY_LEVEL',       0) ) & $this->iLogLevel;
        $sUseLevelColor                            = strtolower(Request::getServer('SC_LOG_LEVEL_COLOR', '0'));
        if ( $sUseLevelColor === '1' || $sUseLevelColor === 'on' || $sUseLevelColor === 'true' ) {
            $this->bUseLevelColor                  = true;
            $aKeys                                 = array_keys($this->aLevelColor);
            $aColors                               = explode(',', trim((string) Request::getServer('SC_LOG_LEVEL_COLOR_CODES', '')));
            $iMax                                  = min(count($aKeys), count($aColors));
            for ( $i=0 ; $i<$iMax ; $i++ ) {
                $bFound                            = (bool) preg_match('#^\d{1,3}(;\d{1,3})*$#S', $aColors[$i]);
                if ( $bFound === true ) {
                    // 有効なコード指定
                    $this->aLevelColor[$aKeys[$i]] = $aColors[$i];
                }
            }
        }
        return true;
    }

    /**
     * 終了処理
     *
     * @return bool true
     */
    protected function _finalize()
    {
        // ログのアーカイブ
        $this->_archive();
        // ログを終了
        $this->_stop();
        return true;
    }

    /**
     * インスタンスを取得する
     *
     * @param   bool    $bLogStart
     * @return  SC\libs\Log
     */
    protected static function _getInstance($bLogStart = true)
    {
        if ( static::$oInstance === NULL ) {
            static::$oInstance = new static();
        }
        if ( $bLogStart !== false && static::$oInstance->bStarted !== true ) {
            static::$oInstance->_start();
        }
        return static::$oInstance;
    }

    /**
     * ログを開始
     *
     * @return  bool    true
     */
    protected function _start()
    {
        // 開始ログ
        $sAccessId       = parent::getAccessId();
        $sUniqId         = parent::getUniqId();
        $sAccessTime     = parent::getAccessTime();
        $sMessage        = "LOG Start with ACCESSID=[$sAccessId] UNIQUEID=[$sUniqId] ACCESSTIME=[$sAccessTime]";
        $this->_log(static::LEVEL_INFO, $sMessage, true);
        // ログレジストリ
        $this->oRegistry = LogRegistry::getInstance();
        // 開始フラグを立てる
        $this->bStarted  = true;
        return true;
    }

    /**
     * ログを終了
     *
     * @return  bool    true
     */
    protected function _stop()
    {
        // データ取得
        $sAccessId      = parent::getAccessId();
        $sUniqId        = parent::getUniqId();
        $sAccessTime    = parent::getAccessTime();
        $sProcTime      = sprintf('%3.9f', microtime(true) - parent::getAccessSec());
        $this->oRegistry->save('sc:request', 'PROCESSTIME', $sProcTime);
        // ログレジストリ
        $aData          = $this->oRegistry->get();
        if ( $aData !== array() ) {
            $sMessage   = 'LOG Data: ' . Util::build_csv($aData, ' ');
            $this->_log(static::LEVEL_INFO, $sMessage, true);
        }
        // 終了ログ
        $sMessage       = "LOG End with ACCESSID=[$sAccessId] UNIQUEID=[$sUniqId] ACCESSTIME=[$sAccessTime] PROCESSTIME=[$sProcTime]";
        $this->_log(static::LEVEL_INFO, $sMessage, true);
        $this->bStarted = false;
        return true;
    }

    /**
     * デバッグログ出力
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    public static function debug($sMessage)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_log(static::LEVEL_DEBUG, $sMessage);
    }

    /**
     * トレースログ出力
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    public static function trace($sMessage)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_log(static::LEVEL_TRACE, $sMessage);
    }

    /**
     * 情報ログ出力
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    public static function info($sMessage)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_log(static::LEVEL_INFO, $sMessage);
    }

    /**
     * 情報注意出力
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    public static function notice($sMessage)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_log(static::LEVEL_NOTICE, $sMessage);
    }

    /**
     * 情報警告出力
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    public static function warning($sMessage)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_log(static::LEVEL_WARNING, $sMessage);
    }

    /**
     * 情報エラー出力
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    public static function error($sMessage)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_log(static::LEVEL_ERROR, $sMessage);
    }

    /**
     * ダンプをログに出力する
     *
     * ダンプ出力を取得するメソッド
     *
     * @param   mixed   $mValue     ダンプ出力したい変数(必ずコピー)
     * @param   string  $sLabel
     * @param   int     $iLevel     ログレベル
     * @return  bool    true
     */
    public static function dump($mValue, $sLabel = '', $iLevel = self::LEVEL_TRACE)
    {
        $oSelf      = static::_getInstance();
        $sMessage   = Debug::dump($mValue, (string)$sLabel, false);
        $bRetCode   = isset($oSelf->aPriorities[$iLevel]);
        if ( $bRetCode !== true ) {
            $iLevel = static::LEVEL_TRACE;
        }
        return $oSelf->_log($iLevel, $sMessage);
    }

    /**
     * 例外出力
     *
     * @param   \Exception  $oException
     * @param   string      $sPlace
     * @return  bool        true
     */
    public static function exception(\Exception $oException, $sPlace)
    {
        $oSelf     = static::_getInstance();
        $sName     = get_class($oException);
        $sMessage  = $oException->getMessage();
        $iCode     = $oException->getCode();
        $bRetCode  = is_numeric($iCode);
        $sCode     = '';
        if ( $bRetCode !== true || (int) $iCode !== 0 ) {
            $sCode = " with code=[$iCode]";
        }
        $bRetCode  = $oSelf->_log(static::LEVEL_ERROR, "Exception $sName has been caught in $sPlace$sCode\n" . $oException);
        return $bRetCode;
    }

    /**
     * ログファイルのパスを取得する
     *
     * @return  string  ログファイルパス
     */
    public static function getLogFile()
    {
        $oSelf = static::_getInstance();
        return $oSelf->sLogFile;
    }

    /**
     * ログディレクトリの根元のパスを設定する
     *
     * @param   string  $sLogRoot   ログディレクトリの根元のパス
     * @return  true
     */
    public static function setLogRoot($sLogRoot)
    {
        $oSelf = static::_getInstance(false);
        return $oSelf->_setLogRoot($sLogRoot);
    }

    /**
     * ログファイルのパスを設定する
     *
     * @param   string  $sLogFile   ログファイルパス
     * @return  true
     */
    public static function setLogFile($sLogFile)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setLogFile($sLogFile);
    }
}
