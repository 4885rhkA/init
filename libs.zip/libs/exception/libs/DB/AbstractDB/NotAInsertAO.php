<?php
/**
 * InsertAOではない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\DB\AbstractDB;

/**
 * InsertAOではない場合の例外
 */
class NotAInsertAO extends \SC\exception\libs\DB\AbstractDB
{
}
