<?php
/**
 * Uriの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs;

/**
 * Uriの例外
 */
class Uri extends \SC\exception\libs
{
}
