<?php
/**
 * 抽象抽出装置
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * 抽象抽出装置
 */
abstract class AbstractExtractor
{
    /**
     * ログ抽出値
     *
     * @var bool $bLogExtractValue
     */
    protected $bLogExtractValue = false;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        $this->bLogExtractValue = (bool) Request::getServer('SC_LOG_EXTRACT_VALUE', false);
    }

    /**
     * 入力から変数を抽出する
     *
     * @param   array   $aParams        パラメータ指定
     * @param   string  $sInput         入力
     * @param   array   $aOptions       オプション指定
     * @return  array   抽出結果
     */
    public static function extract(array $aParams, $sInput, array $aOptions = array())
    {
        $oSelf = new static();
        return $oSelf->_extract($aParams, $sInput, $aOptions);
    }

    /**
     * 入力から変数を抽出する
     *
     * @param   array   $aParams        パラメータ指定
     * @param   string  $sInput         入力
     * @param   array   $aOptions       オプション指定
     * @return  array   抽出結果
     */
    abstract protected function _extract(array $aParams, $sInput, array $aOptions = array());
}
