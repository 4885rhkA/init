<?php
/**
 * 抽象テンプレートモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * 抽象テンプレートモデルコントローラ
 */
abstract class AbstractTemplateModel extends \SC\controller\AbstractTemplateModel
{
    /**
     * テンプレートディレクトリのベース
     *
     * @var string TEMPLATE_BASE
     */
    const TEMPLATE_BASE = \SC\libs\ModelSelectorAdmin::BASE;

    /**
     * プロセス前処理
     *
     * @return true
     */
    protected function _preProcess()
    {
        $this->oLogin = \SC\model\Login::getInstance();
        return parent::_preProcess();
    }
}
