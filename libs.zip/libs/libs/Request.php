<?php
/**
 * リクエスト
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * リクエスト
 *
 * リクエストに関係したデータをハンドルするクラス
 *      $_GET                   保持する
 *      $_POST                  保持する
 *      $_COOKIE                保持する
 *      $_REQUEST               保持する
 *      $_FILES                 保持する
 *      $_SERVER                保持する
 *      $_ENV                   保持する
 *      $HTTP_RAW_POST_DATA     保持する(POST/PUT/DELETEのときのみ)がphp://inputから取得する
 *      $argc                   保持するが$_SERVER['argc']から取得する
 *      $argv                   保持するが$_SERVER['argv']から取得する
 *      apache_request_headers  保持する
 *      $GLOBALS                対象外
 */
class Request
{
    /**
     * 入力情報(スーパーグローバール用)
     *
     * @var array $aInputData
     */
    protected $aInputData = array(
        '_GET'            => array(),
        '_POST'           => array(),
        '_COOKIE'         => array(),
        '_REQUEST'        => array(),
        '_FILES'          => array(),
        '_SERVER'         => array(),
        '_ENV'            => array(),
        'argc'            => 0,
        'argv'            => array(),
        'REQUEST_HEADERS' => array(),
        'RAW_POST_DATA'   => '',
        'RAW_HEADER_DATA' => '',
    );

    /**
     * 入力情報(オリジナル)
     *
     * @var array $aInputOrig
     */
    protected $aInputOrig = array(
        '_GET'            => array(),
        '_POST'           => array(),
        '_COOKIE'         => array(),
        '_REQUEST'        => array(),
        '_FILES'          => array(),
        '_SERVER'         => array(),
        '_ENV'            => array(),
        'argc'            => 0,
        'argv'            => array(),
        'REQUEST_HEADERS' => array(),
        'RAW_POST_DATA'   => '',
        'RAW_HEADER_DATA' => '',
    );

    /**
     * 入力情報(値を除去したもの)
     *
     * @var array $aInputName
     */
    protected $aInputName = array(
        '_GET'            => array(),
        '_POST'           => array(),
        '_COOKIE'         => array(),
        '_REQUEST'        => array(),
        '_FILES'          => array(),
        '_SERVER'         => array(),
        '_ENV'            => array(),
        'argc'            => 0,
        'argv'            => array(),
        'REQUEST_HEADERS' => array(),
        'RAW_POST_DATA'   => '',
        'RAW_HEADER_DATA' => '',
    );

    /**
     * RFC3986方式のエンコード／デコードを行うか
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     *  このクラスのメソッド
     *      _urlencode          フラグにより判定
     *      _urldecode          フラグにより判定
     *
     * @var bool $bUseRFC3982
     */
    protected $bUseRFC3982 = false;

    /**
     * preview時の指定
     *
     * @var string
     */
    protected $sPreview = '';

    /**
     * クリア
     *
     * @var array $aTmpUploadFiles
     */
    protected $aTmpUploadFiles = array();

    /**
     * Content-Typeがmultipart/form-dataであるリクエストか否か
     *
     * @var bool $bFormData
     */
    protected $bFormData = false;

    /**
     * ログ出力時に値を除去するか否か
     *
     * @var bool $bLogStrippedValue
     */
    protected $bLogStrippedValue = true;

    /**
     * インスタンス
     *
     * @var SC\libs\Request $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
    }

    /**
     * デストラクタ
     */
    final public function __destruct()
    {
        $this->clean();
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\Request
     */
    final public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
            // コンストラクタではなくデータをロードする
            self::$oInstance->_load();
        }
        return self::$oInstance;
    }

    /**
     * 入力データの再読み込み処理
     *
     * @return  bool    true
     */
    public static function reload()
    {
        $oSelf = static::getInstance();
        return $oSelf->_load();
    }

    /**
     * 入力データの読み込み処理
     *
     * @return  bool    true
     */
    protected function _load()
    {
        // 生データを保持
        $aInput                                            = array(
            'aInputData',
            'aInputOrig',
        );
        foreach ( $aInput as $sInput ) {
            $this->{$sInput}['_GET'           ]            = (array) $_GET;
            $this->{$sInput}['_POST'          ]            = (array) $_POST;
            $this->{$sInput}['_COOKIE'        ]            = (array) $_COOKIE;
            $this->{$sInput}['_REQUEST'       ]            = (array) $_REQUEST;
            $this->{$sInput}['_FILES'         ]            = (array) $_FILES;
            $this->{$sInput}['_SERVER'        ]            = (array) $_SERVER;
            $this->{$sInput}['_ENV'           ]            = (array) $_ENV;
            $this->{$sInput}['argc'           ]            = $this->_getValue('argc', '_SERVER', 0,       true);
            $this->{$sInput}['argv'           ]            = $this->_getValue('argv', '_SERVER', array(), true);
            $this->{$sInput}['REQUEST_HEADERS']            = apache_request_headers();
        }
        $this->aInputName['_GET'           ]               = Util::stripValue($this->aInputData['_GET'           ], '');
        $this->aInputName['_POST'          ]               = Util::stripValue($this->aInputData['_POST'          ], '');
        $this->aInputName['_COOKIE'        ]               = Util::stripValue($this->aInputData['_COOKIE'        ], '');
        $this->aInputName['_REQUEST'       ]               = Util::stripValue($this->aInputData['_REQUEST'       ], '');
        $this->aInputName['_FILES'         ]               =                  $this->aInputData['_FILES'         ];
        $this->aInputName['_SERVER'        ]               = Util::stripValue($this->aInputData['_SERVER'        ], '');
        $this->aInputName['_ENV'           ]               = Util::stripValue($this->aInputData['_ENV'           ], '');
        $this->aInputName['argc'           ]               =                  $this->aInputData['argc'           ];
        $this->aInputName['argv'           ]               = Util::stripValue($this->aInputData['argv'           ], '');
        $this->aInputName['REQUEST_HEADERS']               = Util::stripValue($this->aInputData['REQUEST_HEADERS'], '');
        // SERVERの「REDIRECT_」は除去．
        foreach ( $this->aInputData['_SERVER'] as $sKey => $sValue ) {
            // REDIRECT_はあるか？
            $bFound                                        = (bool) preg_match('#^((REDIRECT_)+)(.+)$#S', $sKey, $aMatches);
            if ( $bFound !== true ) {
                // なければそのまま
                continue;
            }
            $iLevel                                        = (int) strlen($aMatches[1])/strlen('REDIRECT_');
            $sName                                         = $aMatches[3];
            for ( $iLevel-- ; $iLevel>=0 ; $iLevel-- ) {
                // 1レベル下のキーを生成
                $sNewKey                                   = str_repeat('REDIRECT_', $iLevel) . $sName;
                $bRetCode                                  = array_key_exists($sNewKey, $this->aInputData['_SERVER']);
                if ( $bRetCode === true ) {
                    // 1レベル下の値があれば抜ける
                    break;
                }
                $this->aInputData['_SERVER'][$sNewKey]     = $sValue;
                $this->aInputName['_SERVER'][$sNewKey]     = '';
            }
        }
        // SERVERの「REQUEST_URI」は必須
        if ( array_key_exists('REQUEST_URI', $this->aInputData['_SERVER']) === false ) {
            $this->aInputData['_SERVER']['REQUEST_URI']    = NULL;
            $this->aInputName['_SERVER']['REQUEST_URI']    = '';
        }
        // SERVERの「HOSTNAME」は必須
        if ( array_key_exists('HOSTNAME', $this->aInputData['_SERVER']) === false ) {
            $this->aInputData['_SERVER']['HOSTNAME']       = $this->_getValue('COMPUTERNAME', '_ENV', 'localhost', true);
            $this->aInputName['_SERVER']['HOSTNAME']       = '';
        }
        // X-Forwarded-Forを考慮したリモートアドレス
        if ( array_key_exists('HTTP_X_FORWARDED_FOR', $this->aInputData['_SERVER']) === true ) {
            $sXForwardedFor                                = $this->_getValue('HTTP_X_FORWARDED_FOR', '_SERVER', '',          true);
            $aIPAddrs                                      = array_map('trim', explode(',', $sXForwardedFor));
            $aIPAddrs[]                                    = $this->_getValue('REMOTE_ADDR',          '_SERVER', '127.0.0.1', true);
            $this->aInputData['_SERVER']['REMOTE_ADDRS']   = $aIPAddrs;
            $this->aInputName['_SERVER']['REMOTE_ADDRS']   = array();
        } else {
            $this->aInputData['_SERVER']['REMOTE_ADDRS']   = (array) $this->_getValue('REMOTE_ADDR',          '_SERVER', '127.0.0.1', true);
            $this->aInputName['_SERVER']['REMOTE_ADDRS']   = array();
        }
        // RFC3982を使うかどうか判定
        $sUseRFC3982                                       = strtolower($this->_getValue('SC_USE_RFC3982', '_SERVER', '0', true));
        if ( $sUseRFC3982 === '0' || $sUseRFC3982 === 'false' || $sUseRFC3982 === 'off' ) {
            $this->_setUseRFC3982(false);
        } else {
            $this->_setUseRFC3982(true);
        }
        // 値をストリップするか
        $sLogStrippedValue                                 = strtolower(\Request::getServer('SC_LOG_STRIPPED_VALUE', '1'));
        if ( $sLogStrippedValue === '0' || $sLogStrippedValue === 'false' || $sLogStrippedValue === 'off' ) {
            $this->bLogStrippedValue                       = false;
        } else {
            $this->bLogStrippedValue                       = true;
        }
        // POST/PUT/DELETEの場合だけ取得する
        $sMethod                                           = $this->_getValue('REQUEST_METHOD', '_SERVER', '', true);
        if ( $sMethod === 'POST' || $sMethod === 'PUT' ) {
            $this->aInputData['RAW_POST_DATA']             = (string) file_get_contents('php://input');
            $this->aInputOrig['RAW_POST_DATA']             = $this->aInputData['RAW_POST_DATA'];
            $this->aInputName['RAW_POST_DATA']             = '';
            // Content-Typeの補正
            $sContentType                                  = (string) ArrayUtil::getValue($this->aInputData['_SERVER'], 'CONTENT_TYPE',    '');
            $sContentTypeRaw                               = (string) ArrayUtil::getValue($this->aInputData['_SERVER'], 'SC_CONTENT_TYPE', '');
            if ( $sContentType === '' && $sContentTypeRaw !== '' ) {
                // 補正する
                $this->aInputData['REQUEST_HEADERS']['Content-Type'] = $sContentTypeRaw;
                $this->aInputName['REQUEST_HEADERS']['Content-Type'] = '';
                $this->aInputData['_SERVER']['CONTENT_TYPE']         = $sContentTypeRaw;
                $this->aInputName['_SERVER']['CONTENT_TYPE']         = '';
                $this->aInputData['RAW_HEADER_DATA']                 = $this->_buildRawHeaderData($this->aInputData['REQUEST_HEADERS'], "\r\n");
                $this->aInputName['RAW_HEADER_DATA']                 = $this->aInputData['RAW_HEADER_DATA'];
                // フォームデータを読み込む
                $this->_loadWithFormData();
            } else {
                $this->aInputData['RAW_HEADER_DATA']                 = $this->_buildRawHeaderData($this->aInputData['REQUEST_HEADERS'], "\r\n");
                $this->aInputName['RAW_HEADER_DATA']                 = $this->aInputData['RAW_HEADER_DATA'];
            }
        } else {
            $this->aInputData['RAW_HEADER_DATA']                     = $this->_buildRawHeaderData($this->aInputData['REQUEST_HEADERS'], "\r\n");
            $this->aInputName['RAW_HEADER_DATA']                     = $this->aInputData['RAW_HEADER_DATA'];
        }
        $this->aInputOrig['RAW_HEADER_DATA']                         = $this->_buildRawHeaderData($this->aInputOrig['REQUEST_HEADERS'], "\r\n");
        // 生PATH_INFOを生成
        $iScriptNameLen                                    = strlen($this->aInputData['_SERVER']['SCRIPT_NAME']);
        $iCmp                                              = strncmp($this->aInputData['_SERVER']['SCRIPT_NAME'], $this->aInputData['_SERVER']['REQUEST_URI'], $iScriptNameLen);
        if ( $iCmp !== 0 ) {
            $this->aInputData['_SERVER']['ORIG_PATH_INFO'] = $this->aInputData['_SERVER']['REQUEST_URI'];
            $this->aInputName['_SERVER']['ORIG_PATH_INFO'] = '';
        } else {
            $this->aInputData['_SERVER']['ORIG_PATH_INFO'] = substr($this->aInputData['_SERVER']['REQUEST_URI'], $iScriptNameLen);
            $this->aInputName['_SERVER']['ORIG_PATH_INFO'] = '';
        }
        // パスを保持
        $this->aInputData['WEBROOT_PATH']                  = rtrim(WEBROOT_PATH, '/');
        $this->aInputOrig['WEBROOT_PATH']                  = rtrim(WEBROOT_PATH, '/');
        $this->aInputName['WEBROOT_PATH']                  = '';
        $this->aInputData['ENTRY_POINT']                   = rtrim(ENTRY_POINT,  '/');
        $this->aInputOrig['ENTRY_POINT']                   = rtrim(ENTRY_POINT,  '/');
        $this->aInputName['ENTRY_POINT']                   = '';
        // ログを出力する
        $sLogRequestCSV                                    = trim(ArrayUtil::getValue($this->aInputData['_SERVER'], 'SC_LOG_VARIABLES_EXTERNAL', ''));
        if ( $sLogRequestCSV !== '' ) {
            $aLogRequests                                  = str_getcsv($sLogRequestCSV, ',');
            foreach ( $aLogRequests as $sLogKey ) {
                \SC\libs\Log::dump(ArrayUtil::getValue($this->aInputData, $sLogKey, array()), "Request info: \${$sLogKey}");
            }
        }
        $sLogRequestCSV                                    = trim(ArrayUtil::getValue($this->aInputData['_SERVER'], 'SC_LOG_VARIABLES_EXTERNAL_ORIG', ''));
        if ( $sLogRequestCSV !== '' ) {
            $aLogRequests                                  = str_getcsv($sLogRequestCSV, ',');
            foreach ( $aLogRequests as $sLogKey ) {
                \SC\libs\Log::dump(ArrayUtil::getValue($this->aInputOrig, $sLogKey, array()), "Request info: \${$sLogKey} (original)");
            }
        }
        $this->aInputData['_SERVER']['SC_PRODUCT_NAME']    = SC_PRODUCT_NAME;
        $this->aInputName['_SERVER']['SC_PRODUCT_NAME']    = '';
        $this->aInputData['_SERVER']['SC_PRODUCT_VERSION'] = SC_PRODUCT_VERSION;
        $this->aInputName['_SERVER']['SC_PRODUCT_VERSION'] = '';
        return true;
    }

    /**
     * リクエストヘッダ文字列を構成
     *
     * @param   array   $aInfo  リクエストヘッダ配列
     * @return  string  リクエストヘッダ文字列
     */
    protected function _buildRawHeaderData(array $aInput, $sEOL = "\r\n")
    {
        // リクエストヘッダを構成
        $aHeaders       = array();
        foreach ( $aInput as $sField => $sValue ) {
            $aHeaders[] = "{$sField}: $sValue";
        }
        $sOutput        = join($sEOL, $aHeaders);
        return $sOutput;
    }

    /**
     * 入力データの読み込み処理
     *
     * @return  bool    true
     */
    protected function _loadWithFormData()
    {
        if ( $this->aInputData['RAW_POST_DATA'] === '' ) {
            // フォームデータなし
            return true;
        }
        // フラグを立てる
        $this->bFormData              = true;
        // リクエストされたフォームデータをMIME解析する
        $sRequests                    = $this->aInputData['RAW_HEADER_DATA'] . "\r\n\r\n" . $this->aInputData['RAW_POST_DATA'];
        $aOptions                     = array(
            'eof'           => "\r\n",
            'decodeheaders' => true,
            'decodebodies'  => true,
            'content-type'  => 'applicateion/octet-stream',
            'includebodies' => true,
        );
        $oMimeDecoder                 = new MimeDecoder($sRequests, $aOptions);
        $aStructure                   = $oMimeDecoder->getStructure();
        // クエリ形式に変形
        $aFormData                    = array();
        $aFileData                    = array();
        foreach ( $aStructure['parts'] as $aPart ) {
            $bFormData                = ! (bool) strncasecmp('form-data', $aPart['content-disposition']['value'], 9);
            if ( $bFormData !== true ) {
                // フォームのデータではない → 処理しない
                continue;
            }
            if ( $aPart['content-disposition']['filename'] !== '' ) {
                // アップロードファイル → 処理しない
                $aFileData[]          = $aPart;
                continue;
            }
            $aFormData[]              = $this->_urlencode($aPart['content-disposition']['name']) . '=' . $this->_urlencode($aPart['body']);
        }
        // POSTデータをマージ
        $this->_mergeFormData($aFormData);
        // FILEデータをマージ
        $this->_mergeFileData($aFileData);
        return true;
    }

    /**
     * フォームデータを$_POST/$_REQUESTにマージ
     *
     * @param   array   $aFormData      マージするフォームデータ
     * @return  bool    true
     */
    protected function _mergeFormData(array $aFormData)
    {
        // フォームデータがあるか？
        $sFormData                    = join('&', $aFormData);
        if ( $sFormData === '' ) {
            // 無ければ終わり
            return true;
        }
        // フォームデータあり
        parse_str($sFormData, $aParsed);
        $aStripped                    = Util::stripValue($aParsed, '');
        // $_POSTに上書きして保持
        $this->aInputData['_POST']    = ArrayUtil::unite($this->aInputData['_POST'], $aParsed,   true);
        $this->aInputName['_POST']    = ArrayUtil::unite($this->aInputName['_POST'], $aStripped, true);
        // $_REQEUSTは設定に応じて上書きして保持
        $sRquestOrder                 = strtolower(trim(ini_get('request_order')));
        if ( $sRquestOrder === '' || $sRquestOrder === 'none' || $sRquestOrder === 'off' || $sRquestOrder === '0' ) {
            $sRquestOrder             = strtolower(trim(ini_get('variables_order')));
        }
        $iPos                         = strpos($sRquestOrder, 'p');
        if ( $iPos === false ) {
            // $_REQEUSTに$_POSTはマージしない設定
            return true;
        }
        $aOrderName                   = array(
            'e' => '_ENV',
            'g' => '_GET',
            'p' => '_POST',
            'c' => '_COOKIE',
            's' => '_SERVER',
        );
        $aRequestOrder                = str_split($sRquestOrder);
        $aRequestData                 = array();
        $aRequestName                 = array();
        foreach ( $aRequestOrder as $sKey ) {
            // 上書きするデータがあるか？
            $sName                    = ArrayUtil::getValue($aOrderName, $sKey, '');
            if ( $sName === '' ) {
                continue;
            }
            // 順に上書き
            $aRequestData             = ArrayUtil::unite($aRequestData, $this->aInputData[$sName], true);
            $aRequestName             = ArrayUtil::unite($aRequestName, $this->aInputName[$sName], true);
        }
        $this->aInputData['_REQUEST'] = $aRequestData;
        $this->aInputName['_REQUEST'] = $aRequestName;
        return true;
    }

    /**
     * フォームデータを$_FILESにマージ
     *
     * @param   array   $aFileData      マージするフォームデータ
     * @return  bool    true
     */
    protected function _mergeFileData(array $aFileData)
    {
        // フォームデータがあるか？
        $iCout                               = count($aFileData);
        if ( $iCout < 1 ) {
            // 無ければ終わり
            return true;
        }
        // フォームデータあり
        $sTmpDir                             = ini_get('upload_tmp_dir');
        $iMaxFiles                           = Util::toIntWithUnit(ini_get('max_file_uploads'));
        if ( $iMaxFiles <= 0 ) {
            $iMaxFiles                       = 20;
        }
        $iMaxFileSize                        = Util::toIntWithUnit(ini_get('upload_max_filesize'));
        if ( $iMaxFileSize <= 0 ) {
            $iMaxFileSize                    = 2097152;
        }
        $iMaxIniSize                         = (int) ArrayUtil::getValue($this->aInputData['_POST'], 'MAX_FILE_SIZE', 0);
        if ( $iMaxIniSize <= 0 ) {
            $iMaxIniSize                     = 2097152;
        }
        $aQueries                            = array(
            'name'     => array(),
            'type'     => array(),
            'tmp_name' => array(),
            'error'    => array(),
            'size'     => array(),
        );
        foreach ( $aFileData as $iNum => $aPart ) {
            // 変数をストア
            $sName                           = trim($aPart['content-disposition']['name']);
            $sFilename                       = trim($aPart['content-disposition']['filename']);
            $sType                           = $aPart['content-type']['value'];
            $sTmpName                        = 'none';
            $iError                          = UPLOAD_ERR_OK;
            $iSize                           = strlen($aPart['body']);
            // エラーチェック
            if ( $iNum >= $iMaxFiles ) {
                // 警告だけ出力して無視
                \Log::warning('Maximum number of allowable file uploads has been exceeded');
                continue;
            }
            if ( $iSize > $iMaxIniSize ) {
                // PHPで設定されたファイルサイズより大きい
                $iError                      = UPLOAD_ERR_INI_SIZE;
            } else if ( $iSize > $iMaxFileSize ) {
                // フォームで指定されたファイルサイズより大きい
                $iError                      = UPLOAD_ERR_FORM_SIZE;
            } else if ( $sFilename === '' ) {
                // ファイル名が指定されていない
                $iError                      = UPLOAD_ERR_NO_FILE;
            } else {
                // 一時ファイル作成
                $sTmpName                    = tempnam($sTmpDir, 'php');
                if ( $sTmpName === false ) {
                    // 一時ファイルを作成できなかった
                    $iError                  = UPLOAD_ERR_NO_TMP_DIR;
                } else {
                    $this->aTmpUploadFiles[] = $sTmpName;
                    // 書き込み
                    $iBytes                  = file_put_contents($sTmpName, $aPart['body']);
                    if ( $iBytes !== $iSize ) {
                        // 書き込みサイズが違う
                        $iError              = UPLOAD_ERR_CANT_WRITE;
                    }
                }
            }
            $sName                           = $this->_urlencode($sName);
            $sFilename                       = $this->_urlencode($sFilename);
            $sType                           = $this->_urlencode($sType);
            $sTmpName                        = $this->_urlencode($sTmpName);
            $aQueries['name'    ][]          = "{$sName}={$sFilename}";
            $aQueries['type'    ][]          = "{$sName}={$sType}";
            $aQueries['tmp_name'][]          = "{$sName}={$sTmpName}";
            $aQueries['error'   ][]          = "{$sName}={$iError}";
            $aQueries['size'    ][]          = "{$sName}={$iSize}";
        }
        $aInfo                               = array();
        // nameを構成
        $sQuery                              = join('&', $aQueries['name']);
        parse_str($sQuery, $aParsed);
        foreach ( $aParsed as $sKey => $mValue ) {
            $aInfo[$sKey]                    = array('name' => $mValue);
        }
        // typeを構成
        $sQuery                              = join('&', $aQueries['type']);
        parse_str($sQuery, $aParsed);
        foreach ( $aParsed as $sKey => $mValue ) {
            $aInfo[$sKey]['type']            = $mValue;
        }
        // tmp_nameを構成
        $sQuery                              = join('&', $aQueries['tmp_name']);
        parse_str($sQuery, $aParsed);
        foreach ( $aParsed as $sKey => $mValue ) {
            $aInfo[$sKey]['tmp_name']        = $mValue;
        }
        // errorを構成
        $sQuery                              = join('&', $aQueries['error']);
        parse_str($sQuery, $aParsed);
        foreach ( $aParsed as $sKey => $mValue ) {
            $aInfo[$sKey]['error']           = ArrayUtil::toInt($mValue);
        }
        // sizeを構成
        $sQuery                              = join('&', $aQueries['size']);
        parse_str($sQuery, $aParsed);
        foreach ( $aParsed as $sKey => $mValue ) {
            $aInfo[$sKey]['size']            = ArrayUtil::toInt($mValue);
        }
        $this->aInputData['_FILES']          = $aInfo;
        $this->aInputName['_FILES']          = $aInfo;
        return true;
    }

    /**
     * RFC3982フラグゲッター
     *
     * @return  bool    RFC3982フラグ
     */
    public static function getUseRFC3982()
    {
        $oSelf = static::getInstance();
        return $oSelf->_getUseRFC3982();
    }

    /**
     * RFC3982フラグセッター
     *
     * @param   bool    $bUseRFC3982
     * @return  bool    true
     */
    public static function setUseRFC3982($bUseRFC3982)
    {
        $oSelf = static::getInstance();
        return $oSelf->_setUseRFC3982($bUseRFC3982);
    }

    /**
     * RFC3982フラグゲッター
     *
     * @return  bool    RFC3982フラグ
     */
    protected function _getUseRFC3982()
    {
        return $this->bUseRFC3982;
    }

    /**
     * RFC3982フラグセッター
     *
     * @param   bool    $bUseRFC3982
     * @return  bool    true
     */
    protected function _setUseRFC3982($bUseRFC3982)
    {
        $this->bUseRFC3982 = (bool) $bUseRFC3982;
        return true;
    }

    /**
     * Content-Typeがmultipart/form-dataであるリクエストか否か
     *
     * @return  bool    フォームデータか否か
     */
    public static function isFormData()
    {
        $oSelf = static::getInstance();
        return $oSelf->bFormData;
    }

    /**
     * パスを取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  string  値
     */
    public static function getPathInfo($bOrig = false)
    {
        return static::getServer('PATH_INFO', '/', $bOrig);
    }

    /**
     * パスを変更
     *
     * @param   string  $sPathInfo      パス
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function setPathInfo($sPathInfo)
    {
        $bRetCode   = \SC\libs\Validate::isStringNotZero($sPathInfo);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('PATH_INFO must be a non-zero byte string.');
        }
        $oSelf = static::getInstance();
        $oSelf->aInputData['_SERVER']['PATH_INFO'] = (string) $sPathInfo;
        return true;
    }

    /**
     * パスを取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  string  値
     */
    public static function getOrigPathInfo($bOrig = false)
    {
        return static::getServer('ORIG_PATH_INFO', '/', $bOrig);
    }

    /**
     * パスを変更
     *
     * @param   string  $sOrigPathInfo  パス
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function setOrigPathInfo($sOrigPathInfo)
    {
        $bRetCode   = \SC\libs\Validate::isStringNotZero($sOrigPathInfo);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('ORIG_PATH_INFO must be a non-zero byte string.');
        }
        $oSelf = static::getInstance();
        $oSelf->aInputData['_SERVER']['ORIG_PATH_INFO'] = (string) $sOrigPathInfo;
        return true;
    }

    /**
     * パスパーツを取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   パスパーツ
     */
    public static function getPathParts($bOrig = false)
    {
        $sPathInfo  = static::getPathInfo($bOrig);
        $aPathParts = explode('/', trim($sPathInfo, '/'));
        return $aPathParts;
    }

    /**
     * $_REQUESTの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getRequest($sKey, $mDefault = '', $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sKey, '_REQUEST', $mDefault, $bOrig);
    }

    /**
     * $_GETの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getGet($sKey, $mDefault = '', $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sKey, '_GET', $mDefault, $bOrig);
    }

    /**
     * $_POSTの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getPost($sKey, $mDefault = '', $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sKey, '_POST', $mDefault, $bOrig);
    }

    /**
     * $_COOKIEの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getCookie($sKey, $mDefault = '', $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sKey, '_COOKIE', $mDefault, $bOrig);
    }

    /**
     * $_SERVERの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getServer($sKey, $mDefault = '', $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sKey, '_SERVER', $mDefault, $bOrig);
    }

    /**
     * $_ENVの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getEnv($sKey, $mDefault = '', $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sKey, '_ENV', $mDefault, $bOrig);
    }

    /**
     * スーパーグローバルの値を取得
     *
     * @param   string  $sKey           キー名
     * @param   string  $sName          スーパーグローバル変数名
     * @param   mixed   $mDefault       値がない場合のデフォルト値
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _getValue($sKey, $sName, $mDefault, $bOrig = false)
    {
        // キーは文字列にする
        $sKey       = (string) $sKey;
        if ( $sKey === '' ) {
            // 空文字はNGとする
            throw new \SC\exception\common\parameter\ZeroByteString('Key is zero byte string.');
        }
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        // キーがあるか
        $bRetCode   = array_key_exists($sKey, $this->{$sInput}[$sName]);
        if ( $bRetCode !== true ) {
            // なければデフォルト値を返す
            return $mDefault;
        }
        // あれば返す
        return $this->{$sInput}[$sName][$sKey];
    }

    /**
     * $_REQUESTの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getRequestAll($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValueAll('_REQUEST', $bOrig);
    }

    /**
     * $_GETの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getGetAll($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValueAll('_GET', $bOrig);
    }

    /**
     * $_POSTの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getPostAll($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValueAll('_POST', $bOrig);
    }

    /**
     * $_COOKIEの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getCookieAll($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValueAll('_COOKIE', $bOrig);
    }

    /**
     * $_SERVERの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getServerAll($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValueAll('_SERVER', $bOrig);
    }

    /**
     * $_ENVの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getEnvAll($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValueAll('_ENV', $bOrig);
    }

    /**
     * スーパーグローバルの値を取得
     *
     * @param   string  $sName          スーパーグローバル変数名
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _getValueAll($sName, $bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        // 配列はコピー
        $aValues    = (array) $this->{$sInput}[$sName];
        return $aValues;
    }

    /**
     * $_REQUESTのキーの配列を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     */
    public static function getRequestKeys($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getKeys('_REQUEST', $bOrig);
    }

    /**
     * $_GETのキーの配列を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     */
    public static function getGetKeys($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getKeys('_GET', $bOrig);
    }

    /**
     * $_POSTのキーの配列を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     */
    public static function getPostKeys($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getKeys('_POST', $bOrig);
    }

    /**
     * $_COOKIEのキーの配列を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     */
    public static function getCookieKeys($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getKeys('_COOKIE', $bOrig);
    }

    /**
     * $_SERVERのキーの配列を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     */
    public static function getServerKeys($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getKeys('_SERVER', $bOrig);
    }

    /**
     * $_ENVのキーの配列を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     */
    public static function getEnvKeys($bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getKeys('_ENV', $bOrig);
    }

    /**
     * スーパーグローバルのキーの配列を取得
     *
     * @param   string  $sName          スーパーグローバル変数名
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   キー配列
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _getKeys($sName, $bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        // キーを取得して返す
        $aKeys      = array_keys($this->{$sInput}[$sName]);
        return $aKeys;
    }

    /**
     * $_FILESの値を取得
     *
     * @param   string  $sName      form要素で指定した名前
     * @param   bool    $bOrig      オリジナルデータを取得するか否か
     * @return  array(array)    ファイル情報配列の配列
     */
    public static function getFiles($sName, $bOrig = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getFiles($sName, $bOrig);
    }

    /**
     * $_FILESの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  mixed   値
     */
    public static function getFilesAll($bOrig = false)
    {
        $oSelf              = static::getInstance();
        $aNames             = $oSelf->_getKeys('_FILES', $bOrig);
        $aFiles             = array();
        foreach ( $aNames as $sName ) {
            $aFiles[$sName] = $oSelf->_getFiles($sName, $bOrig);
        }
        return $aFiles;
    }

    /**
     * $_FILESの値を取得
     *
     * @param   string          $sName      form要素で指定した名前
     * @param   bool            $bOrig      オリジナルデータを取得するか否か
     * @return  array(array)    ファイル情報配列の配列
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _getFiles($sName, $bOrig = false)
    {
        // 名前は文字列にする
        $sName          = (string) $sName;
        if ( $sName === '' ) {
            // 空文字はNGとする
            throw new \SC\exception\common\parameter\ZeroByteString('Name is zero byte string.');
        }
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput     = 'aInputData';
        } else {
            $sInput     = 'aInputOrig';
        }
        // ファイル情報配列
        $aFiles         = array();
        // キーがあるか
        $bRetCode       = array_key_exists($sName, $this->{$sInput}['_FILES']);
        if ( $bRetCode !== true ) {
            // なければデフォルト値を返す
            $aFiles[]   = array(
                'name'     => '',
                'type'     => '',
                'size'     => 0,
                'tmp_name' => '',
                'error'    => UPLOAD_ERR_NO_FILE,
            );
            return $aFiles;
        }
        // あれば変換して返す
        $bRetCode       = is_array($this->{$sInput}['_FILES'][$sName]['error']);
        if ( $bRetCode !== true ) {
            // ファイルは１つ → そのまま追加
            $aFiles[]   = $this->{$sInput}['_FILES'][$sName];
            return $aFiles;
        }
        // ファイルは複数 → 変換
        foreach ( $this->{$sInput}['_FILES'][$sName]['error'] as $i => $sError ) {
            $aFiles[$i] = array(
                'name'     => $this->{$sInput}['_FILES'][$sName]['name'    ][$i],
                'type'     => $this->{$sInput}['_FILES'][$sName]['type'    ][$i],
                'size'     => $this->{$sInput}['_FILES'][$sName]['size'    ][$i],
                'tmp_name' => $this->{$sInput}['_FILES'][$sName]['tmp_name'][$i],
                'error'    => $this->{$sInput}['_FILES'][$sName]['error'   ][$i],
            );
        }
        return $aFiles;
    }

    /**
     * アップロードされたファイルかどうか
     *
     * @param   string  $sFilename  ファイル名
     * @return  bool    true/false
     */
    public static function is_uploaded_file($sFilename)
    {
        $oSelf = static::getInstance();
        return $oSelf->_is_uploaded_file($sFilename);
    }

    /**
     * アップロードされたファイルかどうか
     *
     * @param   string  $sFilename  ファイル名
     * @return  bool    true/false
     */
    protected function _is_uploaded_file($sFilename)
    {
        $sContentTypeRaw = (string) ArrayUtil::getValue($this->aInputData['_SERVER'], 'SC_CONTENT_TYPE', '');
        if ( $sContentTypeRaw === '' ) {
            return is_uploaded_file($sFilename);
        }
        foreach ( $this->aInputData['_FILES'] as $aFileInfo ){
            if ( $aFileInfo['tmp_name'] === $sFilename ) {
                return true;
            }
        }
        return false;
    }

    /**
     * アップロードされたファイルを移動する
     *
     * @param   string  $sSrcFile   移動元ファイル名
     * @param   string  $sDstFile   移動先ファイル名
     * @return  bool    true/false
     */
    public static function move_uploaded_file($sSrcFile, $sDstFile)
    {
        $oSelf = static::getInstance();
        return $oSelf->_move_uploaded_file($sSrcFile, $sDstFile);
    }

    /**
     * アップロードされたファイルを移動する
     *
     * @param   string  $sSrcFile   移動元ファイル名
     * @param   string  $sDstFile   移動先ファイル名
     * @return  bool    true/false
     */
    protected function _move_uploaded_file($sSrcFile, $sDstFile)
    {
        $sContentTypeRaw = (string) ArrayUtil::getValue($this->aInputData['_SERVER'], 'SC_CONTENT_TYPE', '');
        if ( $sContentTypeRaw === '' ) {
            return move_uploaded_file($sSrcFile, $sDstFile);
        }
        // アップロードされたファイルか？
        $bRetCode = $this->_is_uploaded_file($sSrcFile);
        if ( $bRetCode !== true ) {
            // アップロードされたファイルでなければ処理しない
            return false;
        }
        $oFile    = \SC\libs\FileBare::getInstance($sSrcFile);
        $bRetCode = $oFile->moveTo($sDstFile);
        return $bRetCode;
    }

    /**
     * リクエストヘッダの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   リクエストヘッダ配列
     */
    public static function getRequestHeaders($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['REQUEST_HEADERS'];
    }

    /**
     * POST生データの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  string  生POSTデータ
     */
    public static function getRawPostData($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['RAW_POST_DATA'];
    }

    /**
     * 生ヘッダデータを取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  string  生ヘッダデータ
     */
    public static function getRawHeaderData($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['RAW_HEADER_DATA'];
    }

    /**
     * $argcの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  int     引数の数
     */
    public static function getArgc($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['argc'];
    }

    /**
     * $argvの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  array   引数配列
     */
    public static function getArgv($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['argv'];
    }

    /**
     * パスとリクエストパラメータをリライトする
     *
     * @param   array   $aConfig
     * @return  bool    true
     */
    public function rewite(array $aConfig)
    {
        // 未実装
        // → mod_rewriteを使おう
        // → 画面から設定できない

        // 処理ロジック(RewriteRule, RewriteCondを参考にする)
        // １．対象URLか否か？
        // ２．リライト条件か？(条件＝チェック対象，マッチ方式，マッチ対象，補足条件)
        // ３．リライト(パス) / リライト(クエリ) / リライト(環境変数)
        // ４．補正($_SERVERの値を修正)
        return true;
    }

    /**
     * リクエストされたホスト名
     *
     * @return  string  ホスト名
     */
    public static function getHost()
    {
        $sHost = static::getServer('HTTP_HOST');
        return $sHost;
    }

    /**
     * リクエストされたポート番号
     *
     * @return  int     ポート番号
     */
    public static function getPort()
    {
        $iPort = static::getServer('SERVER_PORT');
        return $iPort;
    }

    /**
     * リクエストされたプロトコル
     *
     * @return  string  http or https
     */
    public static function getProto()
    {
        $sProto = static::getServer('HTTPS');
        if ( $sProto === 'on' ) {
            $sProto = 'https';
        } else {
            $sProto = 'http';
        }
        return $sProto;
    }

    /**
     * WEBROOT_PATHの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  string  WEBROOT_PATH
     */
    public static function getWebRootPath($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['WEBROOT_PATH'];
    }

    /**
     * WEBROOT_PATHの値を変更
     *
     * @param   string  $sWebRootPath   WEBROOT_PATH
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function setWebRootPath($sWebRootPath)
    {
        $bRetCode = \SC\libs\Validate::isStringNotZero($sWebRootPath);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('WEBROOT_PATH must be a non-zero byte string.');
        }
        $oSelf    = static::getInstance();
        $oSelf->aInputData['WEBROOT_PATH'] = rtrim((string) $sWebRootPath, '/');
        return true;
    }

    /**
     * ENTRY_POINTの値を取得
     *
     * @param   bool    $bOrig          オリジナルデータを取得するか否か
     * @return  string  ENTRY_POINT
     */
    public static function getEntryPoint($bOrig = false)
    {
        // オリジナルか否か
        if ( $bOrig !== true ) {
            $sInput = 'aInputData';
        } else {
            $sInput = 'aInputOrig';
        }
        $oSelf      = static::getInstance();
        return $oSelf->{$sInput}['ENTRY_POINT'];
    }

    /**
     * ENTRY_POINTの値を変更
     *
     * @param   string  $sEntryPoint    ENTRY_POINT
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    public static function setEntryPoint($sEntryPoint)
    {
        $bRetCode = \SC\libs\Validate::isStringNotZero($sEntryPoint);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('ENTRY_POINT must be a non-zero byte string.');
        }
        $oSelf    = static::getInstance();
        $oSelf->aInputData['ENTRY_POINT'] = rtrim((string) $sEntryPoint, '/');
        return true;
    }

    /**
     * previewの値を取得
     *
     * @return  string  previewの値
     */
    public static function getPreview()
    {
        $oSelf      = static::getInstance();
        return $oSelf->sPreview;
    }

    /**
     * previewの値を変更
     *
     * @param   string  $sPreview   previewの値
     * @return  bool    true
     * @throw   SC\exception\common\parameter\NotAString
     */
    public static function setPreview($sPreview)
    {
        $bRetCode = \SC\libs\Validate::isString($sPreview);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('preview must be a string.');
        }
        $oSelf    = static::getInstance();
        $oSelf->sPreview = (string) $sPreview;
        return true;
    }

    /**
     * アップロード一時ファイルの削除
     *
     * @return  bool    true
     */
    public function clean()
    {
        $this->_cleanTmpUploadFiles();
    }

    /**
     * アップロード一時ファイルの削除
     *
     * @return  bool    true
     */
    protected function _cleanTmpUploadFiles()
    {
        // 一旦キャッシュをクリア
        clearstatcache();
        foreach ( $this->aTmpUploadFiles as $sFilename ) {
            // ファイルが存在して書き込み可能か？
            $bRetCode = is_writable($sFilename);
            if ( $bRetCode === true ) {
                // 書き込み可能なら削除する
                unlink($sFilename);
            }
        }
        return true;
    }

    /**
     * urlencode
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _urlencode($sInput)
    {
        if ( $this->bUseRFC3982 === false ) {
            $sOutput = urlencode($sInput);
        } else {
            $sOutput = rawurlencode($sInput);
        }
        return $sOutput;
    }

    /**
     * urldecode
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _urldecode($sInput)
    {
        if ( $this->bUseRFC3982 === false ) {
            $sOutput = urldecode($sInput);
        } else {
            $sOutput = rawurldecode($sInput);
        }
        return $sOutput;
    }

    /**
     * URLエンコードされた文字列をRFC3986形式に修正
     *
     * PHPの関数のサポート状況
     *      urlencode        →  [^-._]      ※半角空白を「+」に置換する
     *      rawurlencode     →  [^-._~]     ※半角空白を「%20」に置換する
     *      RFC3986          →  [^-._~]     ※半角空白を「%20」に置換する
     *      http_build_query →  [^-._]      ※半角空白を「+」に置換する     ※urlencodeと同じ
     *  ※RFC3986準拠のhttp_build_query様関数はない
     *
     * @param   string  $sInput
     * @return  string  $sOutput
     */
    protected function _toRFC3982($sInput)
    {
        // 置換情報を生成
        $sOutput  = str_replace(array( '%7E', '+' ), array( '~', '%20' ), $sInput);
        return $sOutput;
    }
}
