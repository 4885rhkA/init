<?php
/**
 * ファイル取得モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイル取得モデルコントローラ
 */
class FileReadModel extends AbstractJSONModel
{
    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage    = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();

        // PATH_INFOからステージ種別を取得
        $sPathInfo       = $this->oRequest->getPathInfo();
        $sStage          = $this->oStage->getStageName($sPathInfo);

        // リクエストパラメータからファイル名を取得
        $sFilename       = $this->oRequest->getRequest('file');
        $aData           = $this->oStage->readFile($sStage, $sFilename);
        $this->aValues   = array(
            'content'    => $aData['content'],
            'modifytime' => $aData['modifytime'],
        );

        return parent::_process();
    }
}
