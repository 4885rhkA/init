<?php
/**
 * デバッグツール
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * デバッグツール
 */
class Debug
{
    /**
     * ダンプ出力を取得するメソッド
     *
     * @param   mixed   $mValue     ダンプ出力したい変数(必ずコピー)
     * @param   string  $sLabel
     * @param   bool    $bEchoFlg   画面に表示するフラグ
     * @return  string  ダンプ出力の文字列
     */
    public static function dump($mValue, $sLabel = '', $bEchoFlg = true)
    {
        // 出力のバッファリングを開始
        ob_start();
        // var_dumpによる出力 (型指定あり)
        var_dump($mValue);
        // ダンプ出力を取得してバッファリングクリア
        $sDumpOriginal =ob_get_clean();

        $sLabel = (string) $sLabel;
        if ( $sLabel !== '' ) {
            $sLabel .= ' ';
        } else {
            // このクラス名
            $sThisClass = get_called_class();
            // バックトレース情報を取得
            $aBackTrace = debug_backtrace(0);
            $aTraceInfo = static::extractTraceInfo($aBackTrace, $sThisClass, __FILE__);
            if ( $aTraceInfo['method'] !== '' ) {
                $sLeft  = $aTraceInfo['method'];
            } else {
                $sLeft  = $aTraceInfo['file'];
            }
            $sLabel     = $sLeft . '::' . $aTraceInfo['line'] . ': ';
        }

        // 必ず折り返されてしまう行をまとめ
        $sDump = $sLabel . preg_replace("#\\]\\=\\>\n(\\s+)#m", '] => ', $sDumpOriginal);

        if ( $bEchoFlg !== false ) {
             echo $sDump;
        }
        return $sDump;
    }

    /**
     * ダンプ出力を取得するメソッド (with pre要素)
     *
     * @param   mixed   $mValue     ダンプ出力したい変数(必ずコピー)
     * @param   string  $sLabel
     * @param   bool    $bEchoFlg   画面に表示するフラグ
     * @return  string  ダンプ出力の文字列
     */
    public static function dumppre($mValue, $sLabel = '', $bEchoFlg = true)
    {
        $sDump = '<pre>' . static::dump($mValue, $sLabel, false) . '</pre>';
        if ( $bEchoFlg !== false ) {
             echo $sDump;
        }
        return $sDump;
    }

    /**
     * バックトレースからトレース情報を取得
     *
     * @param   array   $aBackTrace     バックトレース情報
     * @param   string  $sExceptClass   除外対象クラス
     * @param   string  $sExceptFile    除外対象ファイル
     * @return  array   場所情報
     */
    final public static function extractTraceInfo(array $aBackTrace, $sExceptClass, $sExceptFile)
    {
        // 場所情報
        $aTraceInfo               = array(
            'file'   => '',
            'method' => '',
            'line'   => 0,
            'trace'  => array(),
        );
        // スタックの数だけ繰り返し
        $iMax                     = count($aBackTrace);
        // 常に先頭をチェック
        for ( $i=0 ; $i<$iMax ; $i++ ) {
            // ファイルの指定チェック
            $bRetCode             = isset($aBackTrace[0]['file']);
            if ( $bRetCode === true ) {
                // ファイル名の指定あり
                if ( $aBackTrace[0]['file'] !== $sExceptFile ) {
                    // 除外対象ファイルではない → 保持して抜ける
                    $aTraceInfo   = array(
                        'file'   => $aBackTrace[0]['file'],
                        'method' => '',
                        'line'   => $aBackTrace[0]['line'],
                        'trace'  => $aBackTrace,
                    );
                    break;
                }
            }
            array_shift($aBackTrace);
        }
        // メソッド・関数の指定チェック
        $bRetCode                 = isset($aBackTrace[1]['function']);
        if ( $bRetCode === true ) {
            $sMethod              = $aBackTrace[1]['function'];
            $bRetCode             = isset($aBackTrace[1]['class']);
            if ( $bRetCode === true ) {
                $sMethod          = $aBackTrace[1]['class'] . '::' . $sMethod;
            }
            $aTraceInfo['method'] = $sMethod;
        }
        return $aTraceInfo;
    }

    /**
     * バックトレース出力の情報を設定する
     *
     * @return  string  バックトレース情報
     */
    final public static function getBackTrace()
    {
        // このクラス名
        $sThisClass  = get_called_class();
        // バックトレース情報を取得
        $aBackTrace  = debug_backtrace(0);
        $aTraceInfo  = static::extractTraceInfo($aBackTrace, $sThisClass, __FILE__);
        return $aTraceInfo;
    }

    /**
     * バックトレース出力を取得するメソッド
     *
     * @param   bool    $bEchoFlg   面に表示するフラグ
     * @return  string  ダンプ出力の文字列
     */
    public static function bt($bEchoFlg = true)
    {
        $aTraceInfo = static::getBackTrace();
        $sDump = "{$aTraceInfo['file']} {$aTraceInfo['line']}:\n"
               . static::dump($aTraceInfo['trace'], 'BackTrace :', false);
        if ( $bEchoFlg !== false ) {
             echo $sDump;
        }
        return $sDump;
    }

    /**
     * バックトレース出力を取得するメソッド (with pre要素)
     *
     * @param   bool    $bEchoFlg   画面に表示するフラグ
     * @return  string  ダンプ出力の文字列
     */
    public static function btp($bEchoFlg = true)
    {
        $sDump = '<pre>' . static::bt(false) . '</pre>';
        if ( $bEchoFlg !== false ) {
             echo $sDump;
        }
        return $sDump;
    }
}
