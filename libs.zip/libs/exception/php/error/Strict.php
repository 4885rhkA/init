<?php
/**
 * 厳密性例外 (E_STRICT)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * 厳密性例外 (E_STRICT)
 */
class Strict extends \SC\exception\php\error
{
}
