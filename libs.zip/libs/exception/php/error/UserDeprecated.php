<?php
/**
 * ユーザ定義廃止予定例外 (E_USER_DEPRECATED)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * ユーザ定義廃止予定例外 (E_USER_DEPRECATED)
 */
class UserDeprecated extends \SC\exception\php\error
{
}
