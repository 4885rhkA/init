<?php
ini_set('date.timezone', 'Asia/Tokyo');

$_SERVER['SC_WEBROOT_PATH']      = '';
$_SERVER['SC_ENTRY_POINT']       = '';
$_SERVER['SC_STAGING']           = '0';
$_SERVER['SC_STAGING_SP']        = '0';
$_SERVER['SC_LOG_LEVEL']         = 7340043;
$_SERVER['SC_LOG_DISPALY_LEVEL'] = 2097163;

$_SERVER['HTTPS']                = '';
$_SERVER['HTTP_HOST']            = '127.0.0.1';
$_SERVER['SERVER_NAME']          = '127.0.0.1';
$_SERVER['SERVER_ADDR']          = '127.0.0.1';
$_SERVER['SERVER_PORT']          = '80';
$_SERVER['REMOTE_ADDR']          = '127.0.0.1';
$_SERVER['REMOTE_PORT']          = '61750';
$_SERVER['REQUEST_METHOD']       = 'GET';
$_SERVER['QUERY_STRING']         = '';
$_SERVER['REQUEST_URI']          = '/SC/webroot/index.php/';
$_SERVER['SCRIPT_NAME']          = '/SC/webroot/index.php';
$_SERVER['PATH_INFO']            = '/';

if ( !function_exists('apache_request_headers') ) {
    function apache_request_headers(){
        return array();
    }
}

require_once __DIR__ . '/../vendor/autoload.php';

\SC\base\Base::initialize();
// クラス別名をセット
\SC\libs\ClassAlias::set(array(
    'Log'       => 'SC\libs\Log',
    'Util'      => 'SC\libs\Util',
    'Request'   => 'SC\libs\Request',
    'Response'  => 'SC\libs\Response',
    'Session'   => 'SC\libs\Session',
    'Debug'     => 'SC\libs\Debug',
    'ArrayUtil' => 'SC\libs\ArrayUtil',
));

// rootをセットしてLog出力を行なわない場合LogRegistryが登録されず例外が発生する
// \Log::setLogRoot(__DIR__);
