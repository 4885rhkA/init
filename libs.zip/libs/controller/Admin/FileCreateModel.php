<?php
/**
 * ファイル作成モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * ファイル作成モデルコントローラ
 */
class FileCreateModel extends AbstractJSONModel
{
    /**
     * ステージ
     *
     * @var SC\model\Stage $oStage
     */
    protected $oStage = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログインチェック
        $this->_checkLogin();

        $this->oStage    = \SC\model\Stage::getInstance();
        $this->oStage->setNoWarningOn();

        // PATH_INFOからステージ種別を取得
        $sPathInfo       = $this->oRequest->getPathInfo();
        $sStage          = $this->oStage->getStageName($sPathInfo);

        // リクエストパラメータから作成先相対パスとファイル名を取得
        $sPath           = $this->oRequest->getRequest('path');
        $sName           = $this->oRequest->getRequest('name');
        $sName           = mb_convert_kana($sName, 'a'); // 「全角」英数字を「半角」に変換
        // Gitパラメータ
        $sAuthor         = $this->oLogin->getAuthor();
        $sMessage        = 'create file via control panel.';  // コミットメッセージは固定

        try {
            $aData           = $this->oStage->createFile($sStage, $sPath, $sName, $sAuthor, $sMessage);
            $this->aValues   = array(
                'content'    => $aData['content'],
                'modifytime' => $aData['modifytime'],
            );
        } catch (\Exception $oException) {
            $this->bHasError   = true;
            $this->sErrMessage = $oException->getMessage();
        }

        return parent::_process();
    }
}
