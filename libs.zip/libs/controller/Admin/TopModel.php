<?php
/**
 * コントロールパネルTOPページモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * コントロールパネルTOPページモデルコントローラ
 */
class TopModel extends StaticModel
{
    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // ログイン済ならサイト管理にリダイレクトする
        if ( $this->oLogin->isLogin() === true ) {

            $sRedirect = $this->oRequest->getEntryPoint() . '/site/';
            $this->oResponse->setRedirect($sRedirect, 301);
            return true;
        }

        $this->aTplValues = array(
            'login'   => $this->oLogin->getData(),
        );

        return parent::_process();
    }
}
