<?php
/**
 * ファイルが上書きできない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\File;

/**
 * ファイルが上書きできない場合の例外
 */
class CantBeOverwritten extends \SC\exception\libs\File
{
}
