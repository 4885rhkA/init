<?php
/**
 * リダイレクトモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * リダイレクトモデルコントローラ
 */
class RedirectModel extends \SC\controller\RedirectModel
{
}
