<?php
/**
 * Git
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * Git
 */
class Git
{
    /**
     * 作業ディレクトリ
     *
     * @var string $targetDir
     */
    protected $targetDir = '';

    /**
     * 警告をログ出力しないフラグ
     *
     * @var bool $bNoWarning
     */
    protected $bNoWarning = false;

    /**
     * コンストラクタ
     *
     * @param   string  $sDir   Gitリポジトリディレクトリ名
     */
    public function __construct($sDir)
    {
        $this->targetDir = $sDir;
    }

    /**
     * インスタンスを取得する
     *
     * @param   string  $sDir   リポジトリディレクトリ名
     * @return  SC\libs\File
     */
    public static function getInstance($sDir)
    {
        $oSelf = new static($sDir);
        return $oSelf;
    }

    /**
     * ターゲットディレクトリを設定する
     *
     * @param   string  $sDir   リポジトリディレクトリ名
     * @return  SC\libs\File
     */
    public function setTargetDir($sDir)
    {
        $this->targetDir = $sDir;
    }

    /**
     * add
     *
     * git add .
     *
     * @return  string  output
     */
    public function add()
    {
        $aArgs   = array('add', '.');
        $sOutput = $this->exec($aArgs);
        return $sOutput;
    }

    /**
     * commit
     *
     * git commit -a --author='$author' -m '$message'
     *
     * @param   string  commit author
     * @param   string  commit message
     * @return  string  output
     */
    public function commit($sAuthor, $sMessage)
    {
        $aArgs   = array('commit', '-a', '--author=' . $sAuthor,  '-m', $sMessage);
        $sOutput = $this->exec($aArgs);
        return $sOutput;
    }

    /**
     * pull
     *
     * @return  string  output
     */
    public function pull()
    {
        $aArgs   = array('pull');
        $sOutput = $this->exec($aArgs);
        return $sOutput;
    }

    /**
     * push
     *
     * @return  string  output
     */
    public function push()
    {
        $aArgs   = array('push');
        $sOutput = $this->exec($aArgs);
        return $sOutput;
    }

    /**
     * ファイルのオブジェクトIDを取得する
     *
     * git hash-object $path'
     *
     * @param   string  ファイルパス
     * @return  string  hash object id
     */
    public function getObjectId($path)
    {
        $aArgs   = array('hash-object', $path);
        $sOutput = $this->exec($aArgs);
        $sOutput = trim($sOutput);
        return $sOutput;
    }

    /**
     * status
     *
     * @return  string  output
     */
    public function status()
    {
        $aArgs   = array('status');
        $sOutput = $this->exec($aArgs);
        return $sOutput;
    }

    /**
     * checkout
     *
     * @param   string  ブランチ名
     * @return  string  output
     */
    public function checkout($sBranch)
    {
        $aArgs   = array('checkout', $sBranch);
        $sOutput = $this->exec($aArgs);
        return $sOutput;
    }

    /**
     * exec
     *
     * @param   array   gitに渡すコマンドライン引数
     * @return  string  output
     */
    public function exec(array $aArgs)
    {
        $sBaseDir = getcwd();
        chdir($this->targetDir);

        $sCommand = 'git ' . join(' ', array_map('escapeshellarg', $aArgs)) . ' 2>&1';
        \Log::trace("Git dump: [$sCommand] (dir: $this->targetDir)");
        exec($sCommand, $aOutput, $iStatus);
        $sOutput = join("\n", $aOutput);
        if ( $iStatus > 0 && $this->bNoWarning === false ) {
            // @todo JSONの場合に出力してほしくない
            \Log::dump($sOutput, "Git dump: [status=$iStatus]\n", \Log::LEVEL_WARNING);
        } else {
            \Log::dump($sOutput, 'Git dump: ', \Log::LEVEL_TRACE);
        }

        chdir($sBaseDir);
        return $sOutput;
    }

    /**
     * 警告をログ出力しないフラグを立てる
     *
     * @return  bool    true
     */
    public function setNoWarningOn()
    {
        return $this->setNoWarning(true);
    }

    /**
     * 警告をログ出力しないフラグを折る
     *
     * @return  bool    true
     */
    public function setNoWarningOff()
    {
        return $this->setNoWarning(false);
    }

    /**
     * 警告をログ出力しないフラグ
     *
     * @param   bool    $bNoWarning
     * @return  bool    true
     */
    public function setNoWarning($bNoWarning)
    {
        $this->bNoWarning = (bool) $bNoWarning;
        return true;
    }
}
