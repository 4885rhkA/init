<?php
/**
 * サイトリリース確認モデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * サイトリリース確認モデルコントローラ
 */
class SiteReleaseCheckModel extends AbstractJSONModel
{
    /**
     * サイト
     *
     * @var SC\model\Site $oSite
     */
    protected $oSite = NULL;

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        $this->oSite = \SC\model\Site::getInstance();
        $this->oSite->setNoWarningOn();

        $site = $this->oRequest->getGet('siteid');
        $host = $this->oRequest->getGet('hostname');
        // @todo validate
        // サイトID・host名をチェックする

        // リリース予約確認
        $result = $this->oSite->checkRelease($site, $host);
        if ( $result === false ) {
            $this->bHasError   = true;
            $this->sErrMessage = '';
        }

        return parent::_process();
    }
}
