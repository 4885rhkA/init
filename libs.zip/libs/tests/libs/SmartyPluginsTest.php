<?php
/**
 * SmartyPluginsTest
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

class SmartyPluginsTest extends \PHPUnit_Framework_TestCase
{
    protected function setUp()
    {
        // URLの調整
        $aUrlAdjust = array(
            'production'                =>  array(                  // for url-/relative-modifier
                'sample1'               =>  array(
                    'cond1'             =>  array(
                        'search'        =>  'example.jp',
                        'replace'       =>  'sp.example.jp',
                    ),
                ),
                'sample2'               =>  array(
                    'cond1'             =>  array(
                        'target'        =>  'host',                 // adjust target: 'url', 'scheme', 'host', 'port', 'user', 'pass', 'path', 'query', 'fragment'
                        'compare'       =>  '=',                    // matching type: '~' uses preg_match, '=' uses strcmp, '!=' or '<>' uses !strcmp
                        'search'        =>  'a.example.jp',         // search string
                        'replace'       =>  'sp-a.example.jp',      // replace string
                        'ignorecase'    =>  true,                   // ignore case sensitive to search
                    ),
                ),
            ),
            'staging-source'            =>  array(                  // for absolute-/stg-modifier  with env SC_STAGING=1
                'sample1'               =>  array(
                    'cond1'             =>  array(
                        'search'        =>  'a.example.jp',
                        'replace'       =>  'sp-a.example.jp',
                    ),
                    'cond2'             =>  array(
                        'target'        =>  'path',
                        'compare'       =>  '~',
                        'search'        =>  '^/',
                        'replace'       =>  '/stg/',
                        'ignorecase'    =>  false,
                    ),
                ),
            ),
            'staging-sp'                =>  array(                  // for url-/absolute-/stgsp-modifier  with env SC_STAGING_SP=1
                'sample1'               =>  array(
                    'cond1'             =>  array(
                        'search'        =>  'sp.example.jp',
                        'replace'       =>  'sp-example.smartconvert.info',
                    ),
                ),
                'sample2'               =>  array(
                    'cond1'             =>  array(
                        'search'        =>  'sp-z.example.jp',
                        'replace'       =>  'sp-z-example.smartconvert.info',
                    ),
                ),
            ),
        );
        Util::setAdjustURIConds($aUrlAdjust);
    }

    public function testResolveUrl()
    {
        // 【条件セット０１】 第２・第３引数型チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  ''
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象の限定を指定しない・空配列
        //  ７．置換対象の除外を指定しない・空配列

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();

        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        $aUrlList                        = array(
            // input                                    // expect
            'http://example.jp/path/to'            =>  "http://sp.example.jp{$sEntry}/path/to",
        );
        $oDummy                          = new \stdClass();
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource                   );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 1');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL             );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 2');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array()          );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 3');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy          );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 4');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL,    NULL    );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 5');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL,    array() );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 6');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL,    $oDummy );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 7');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array(), NULL    );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 8');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array(), array() );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 9');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array(), $oDummy );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 10');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy, NULL    );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 11');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy, array() );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 12');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy, $oDummy );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０１】 第２・第３引数型チェック 13');
        }

        // 【条件セット０２】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  ''
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp.example.jp{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp.example.jp/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
            'javascript:void(0);'                   =>  "javascript:void(0);",
            'mailto:mail@example.jp'                =>  "mailto:mail@example.jp",
            'mailto:mail@example.jp?title=test'     =>  "mailto:mail@example.jp?title=test",
            'tel:09012341234'                       =>  "tel:09012341234",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０２】 第１引数変換チェック');
        }

        // 【条件セット０３】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  ''
        //  ４．$_SERVER['SC_STAGING']      ===  '1'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '';
        $_SERVER['SC_STAGING']           = '1';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp.example.jp{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp.example.jp/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
            'javascript:void(0);'                   =>  "javascript:void(0);",
            'mailto:mail@example.jp'                =>  "mailto:mail@example.jp",
            'mailto:mail@example.jp?title=test'     =>  "mailto:mail@example.jp?title=test",
            'tel:09012341234'                       =>  "tel:09012341234",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット０３】 第１引数変換チェック');
        }

        // 【条件セット０４】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  ''
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '1'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
            'javascript:void(0);'                   =>  "javascript:void(0);",
            'mailto:mail@example.jp'                =>  "mailto:mail@example.jp",
            'mailto:mail@example.jp?title=test'     =>  "mailto:mail@example.jp?title=test",
            'tel:09012341234'                       =>  "tel:09012341234",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, '【条件セット０４】 第１引数変換チェック');
        }

        // 【条件セット０５】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  ''
        //  ４．$_SERVER['SC_STAGING']      ===  '1'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '1'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '';
        $_SERVER['SC_STAGING']           = '1';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
            'javascript:void(0);'                   =>  "javascript:void(0);",
            'mailto:mail@example.jp'                =>  "mailto:mail@example.jp",
            'mailto:mail@example.jp?title=test'     =>  "mailto:mail@example.jp?title=test",
            'tel:09012341234'                       =>  "tel:09012341234",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, '【条件セット０５】 第１引数変換チェック');
        }

        // 【条件セット１１】 第２・第３引数型チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  '/SC/webroot/index.php'  &&  $_SERVER['SC_STRIP_SCRIPT_NAME'] === '0'
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象の限定を指定しない・空配列
        //  ７．置換対象の除外を指定しない・空配列

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '/SC/webroot/index.php';
        $_SERVER['SC_STRIP_SCRIPT_NAME'] = '0';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        Request::setEntryPoint($sEntry);
        $aUrlList                        = array(
            // input                                    // expect
            'http://example.jp/path/to'             =>  "http://sp.example.jp{$sEntry}/path/to",
        );
        $oDummy                          = new \stdClass();
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource                   );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 1');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL             );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 2');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array()          );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 3');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy          );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 4');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL,    NULL    );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 5');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL,    array() );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 6');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, NULL,    $oDummy );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 7');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array(), NULL    );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 8');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array(), array() );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 9');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, array(), $oDummy );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 10');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy, NULL    );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 11');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy, array() );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 12');
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $oDummy, $oDummy );
            $this->assertEquals($sExpect, $sResult, '【条件セット１１】 第２・第３引数型チェック 13');
        }

        // 【条件セット１２】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  '/SC/webroot/index.php'  &&  $_SERVER['SC_STRIP_SCRIPT_NAME'] === '0'
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '/SC/webroot/index.php';
        $_SERVER['SC_STRIP_SCRIPT_NAME'] = '0';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        Request::setEntryPoint($sEntry);
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp.example.jp{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp.example.jp/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
            'javascript:void(0);'                   =>  "javascript:void(0);",
            'mailto:mail@example.jp'                =>  "mailto:mail@example.jp",
            'mailto:mail@example.jp?title=test'     =>  "mailto:mail@example.jp?title=test",
            'tel:09012341234'                       =>  "tel:09012341234",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, '【条件セット１２】 第１引数変換チェック');
        }

        // 【条件セット１３】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  '/SC/webroot/index.php'  &&  $_SERVER['SC_STRIP_SCRIPT_NAME'] === '0'
        //  ４．$_SERVER['SC_STAGING']      ===  '1'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '/SC/webroot/index.php';
        $_SERVER['SC_STRIP_SCRIPT_NAME'] = '0';
        $_SERVER['SC_STAGING']           = '1';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        Request::setEntryPoint($sEntry);
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp.example.jp{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp.example.jp/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, '【条件セット１３】 第１引数変換チェック');
        }

        // 【条件セット１４】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  '/SC/webroot/index.php'  &&  $_SERVER['SC_STRIP_SCRIPT_NAME'] === '0'
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '1'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '/SC/webroot/index.php';
        $_SERVER['SC_STRIP_SCRIPT_NAME'] = '0';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        Request::setEntryPoint($sEntry);
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, '【条件セット１４】 第１引数変換チェック');
        }

        // 【条件セット１５】 第１引数変換チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //      't.example.jp' => 'sp-t.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  '/SC/webroot/index.php'  &&  $_SERVER['SC_STRIP_SCRIPT_NAME'] === '0'
        //  ４．$_SERVER['SC_STAGING']      ===  '1'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '1'
        //  ６．置換対象を限定しない
        //  ７．置換対象を除外しない

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '/SC/webroot/index.php';
        $_SERVER['SC_STRIP_SCRIPT_NAME'] = '0';
        $_SERVER['SC_STAGING']           = '1';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        Request::setEntryPoint($sEntry);
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0{$sEntry}/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3{$sEntry}/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1{$sEntry}/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3{$sEntry}/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1{$sEntry}/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2{$sEntry}/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost{$sEntry}/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain{$sEntry}/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://sp-a.example.jp{$sEntry}/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "{$sEntry}/path/to",
            'path/to'                               =>  "path/to",
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, '【条件セット１５】 第１引数変換チェック');
        }

        // 【条件セット２１】 第２・第３引数型チェック
        //  １．置換指定:
        //      'example.jp'   => 'sp.example.jp'
        //  ２．$_SERVER['HTTPS']           !==  'on'
        //  ３．$_SERVER['SC_ENTRY_POINT']  ===  '/SC/webroot/index.php'  &&  $_SERVER['SC_STRIP_SCRIPT_NAME'] === '0'
        //  ４．$_SERVER['SC_STAGING']      ===  '0'
        //  ５．$_SERVER['SC_STAGING_SP']   ===  '0'
        //  ６．置換対象の限定を指定しない・空配列
        //  ７．置換対象の除外を指定しない・空配列

        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['SC_ENTRY_POINT']       = '/SC/webroot/index.php';
        $_SERVER['SC_STRIP_SCRIPT_NAME'] = '0';
        $_SERVER['SC_STAGING']           = '0';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        $sEntry                          = $_SERVER['SC_ENTRY_POINT'];
        Request::setEntryPoint($sEntry);
        $aUrlList                        = array(
            // input                                    // expect
            'http://0.0.0.0/path/to'                =>  "http://0.0.0.0/path/to",
            'http://0.1.2.3/path/to'                =>  "http://0.1.2.3/path/to",
            'http://1.2.3.4/path/to'                =>  "http://1.2.3.4/path/to",
            'http://127.0.0.1/path/to'              =>  "http://127.0.0.1/path/to",
            'http://127.1.2.3/path/to'              =>  "http://127.1.2.3/path/to",
            'http://169.254.0.1/path/to'            =>  "http://169.254.0.1/path/to",
            'http://169.254.1.2/path/to'            =>  "http://169.254.1.2/path/to",
            'http://123.456.789.012/path/to'        =>  "http://123.456.789.012/path/to",
            'http://localhost/path/to'              =>  "http://localhost/path/to",
            'http://localhost.localdomain/path/to'  =>  "http://localhost.localdomain/path/to",
            'http://localdomain/path/to'            =>  "http://localdomain/path/to",
            'http://example.jp/path/to'             =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://a.example.jp/path/to'           =>  "http://a.example.jp/path/to",
            'http://sp.example.jp/path/to'          =>  "http://sp-example.smartconvert.info{$sEntry}/path/to",
            'http://sp-a.example.jp/path/to'        =>  "http://sp-a.example.jp/path/to",
            'http://bc.example.jp/path/to'          =>  "http://bc.example.jp/path/to",
            'http://de.fg.example.jp/path/to'       =>  "http://de.fg.example.jp/path/to",
            'http://hi.sp.example.jp/path/to'       =>  "http://hi.sp.example.jp/path/to",
            'http://sp.jk.example.jp/path/to'       =>  "http://sp.jk.example.jp/path/to",
            '/path/to'                              =>  "/path/to",
            'path/to'                               =>  "path/to",
        );
        $aPatterns                       = array(
            '^http://(.*\.)?example\.jp/',
        );
        $aExcludes                       = array(
            '^http://a\.example\.jp/',
        );
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::resolveUrl( $sSource, $aPatterns, $aExcludes );
            $this->assertEquals($sExpect, $sResult, '【条件セット２１】 第２・第３引数型チェック');
        }

        $this->markTestIncomplete(
            join("\n", array(
                '@todo 追加でテストすべき内容',
                '・入力値の型テスト・文字列長テスト',
                '・対象指定の文字列長テスト',
                '・除外指定の文字列長テスト',
            )) . "\n"
        );
    }

    public function testAbsoluteUrl()
    {
        // 【条件セット１】
        //  １．$_SERVER['HTTPS']           !==  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '0'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "http://sp.example.jp/path/to",
            'path/to'                   =>  "http://sp.example.jp/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット１】');
        }

        // 【条件セット２】
        //  １．$_SERVER['HTTPS']           ===  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '0'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "https://sp.example.jp/path/to",
            'path/to'                   =>  "https://sp.example.jp/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = 'on';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '0';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット２】');
        }

        // 【条件セット３】
        //  １．$_SERVER['HTTPS']           !==  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp' → 'sp-example.smartconvert.info'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '1'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "http://sp-example.smartconvert.info/path/to",
            'path/to'                   =>  "http://sp-example.smartconvert.info/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット３】');
        }

        // 【条件セット４】
        //  １．$_SERVER['HTTPS']           ===  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp' → 'sp-example.smartconvert.info'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '1'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "https://sp-example.smartconvert.info/path/to",
            'path/to'                   =>  "https://sp-example.smartconvert.info/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = 'on';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '1';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット４】');
        }

        // 【条件セット５】
        //  １．$_SERVER['HTTPS']           !==  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '0'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "http://sp-z.example.jp/path/to",
            'path/to'                   =>  "http://sp-z.example.jp/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '0';
        $sTarget                         = 'sp-z.example.jp';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource , $sTarget );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット５】');
        }

        // 【条件セット６】
        //  １．$_SERVER['HTTPS']           ===  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '0'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "https://sp-z.example.jp/path/to",
            'path/to'                   =>  "https://sp-z.example.jp/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = 'on';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '0';
        $sTarget                         = 'sp-z.example.jp';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource , $sTarget );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット６】');
        }

        // 【条件セット７】
        //  １．$_SERVER['HTTPS']           !==  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp' → 'sp-example.smartconvert.info'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '1'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "http://sp-z-example.smartconvert.info/path/to",
            'path/to'                   =>  "http://sp-z-example.smartconvert.info/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = '';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '1';
        $sTarget                         = 'sp-z.example.jp';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource , $sTarget );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット７】');
        }

        // 【条件セット８】
        //  １．$_SERVER['HTTPS']           ===  'on'
        //  ２．$_SERVER['HTTP_HOST']       ===  'sp.example.jp' → 'sp-example.smartconvert.info'
        //  ３．$_SERVER['SC_STAGING_SP']   ===  '1'
        $aUrlList                        = array(
            // input                        // expect
            'http://example.jp/path/to' =>  "http://example.jp/path/to",
            '//example.jp/path/to'      =>  "//example.jp/path/to",
            '/path/to'                  =>  "https://sp-z-example.smartconvert.info/path/to",
            'path/to'                   =>  "https://sp-z-example.smartconvert.info/path/to",
        );
        // 条件変更
        $_SERVER['HTTPS']                = 'on';
        $_SERVER['HTTP_HOST']            = 'sp.example.jp';
        $_SERVER['SC_STAGING_SP']        = '1';
        $sTarget                         = 'sp-z.example.jp';
        Request::reload();
        Util::reload();
        // 相対パスを絶対パスに変換する
        foreach ( $aUrlList as $sSource => $sExpect ) {
            $sResult                     = SmartyPlugins::absoluteUrl( $sSource , $sTarget );
            $this->assertEquals($sExpect, $sResult, 'NG:【条件セット８】');
        }

        $this->markTestIncomplete(
            join("\n", array(
                '@todo 追加でテストすべき内容',
                '・相対パス補完テスト',
                '    PATH_INFOが "/abc/def/ghi" でinputが "path/to" であった場合に',
                '        input          // expect',
                '        "path/to"  =>  "https://sp.example.jp/abc/def/path/to"',
                '    となるようなテスト',
                '',
                '・入力値の型テスト・文字列長テスト',
                '・ホスト名指定の型テスト・文字列長テスト',
            )) . "\n"
        );
    }
}

