<?php
/**
 * UtilTest
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
class UtilTest extends PHPUnit_Framework_TestCase
{
    protected $obj;

    protected static function getMethod($name)
    {
        $class = new ReflectionClass('SC\libs\Util');
        $method = $class->getMethod($name);
        $method->setAccessible(true);
        return $method;
    }

    protected function setUp()
    {
    }

    public function testFormatFileSize()
    {
        $method = self::getMethod('formatFileSize');
        $base = 1024;

        // -1024 byte
        $size = $method->invokeArgs($this->obj, array(-1024));
        $this->assertEquals($size, '-1024B');

        // 0 byte
        $size = $method->invokeArgs($this->obj, array(0));
        $this->assertEquals($size, '0B');

        $size = $method->invokeArgs($this->obj, array(1023));
        $this->assertEquals($size, '1023B');

        $size = $method->invokeArgs($this->obj, array($base));
        $this->assertEquals($size, '1KB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 2) - 1));
        $this->assertEquals($size, '1024KB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 2)));
        $this->assertEquals($size, '1MB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 3)));
        $this->assertEquals($size, '1GB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 4)));
        $this->assertEquals($size, '1TB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 5)));
        $this->assertEquals($size, '1PB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 6)));
        $this->assertEquals($size, '1EB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 7)));
        $this->assertEquals($size, '1ZB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 8)));
        $this->assertEquals($size, '1YB');

        $size = $method->invokeArgs($this->obj, array(pow($base, 9)));
        $this->assertEquals($size, '1024YB');
    }
}

