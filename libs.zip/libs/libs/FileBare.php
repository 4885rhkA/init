<?php
/**
 * FileBare
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * FileBare
 */
class FileBare extends File
{
    /**
     * セキュリティチェック
     *
     * @var string SECURE
     */
    const SECURE = false;
}
