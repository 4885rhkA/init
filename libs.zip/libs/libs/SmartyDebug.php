<?php
/**
 * SmartyDebug
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * SmartyDebug
 */
class SmartyDebug
{
    /**
     * インスタンス
     *
     * @var SC\libs\SmartyDebug $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * デバッグモードか否か
     *
     * @var bool $bDebugging
     */
    protected $bDebugging = false;

    /**
     * デバッグテンプレート
     *
     * @var string $sTemplate
     */
    protected $sTemplate = '';

    /**
     * デバッグテンプレートディレクトリ
     *
     * @var array $aTemplateDirs
     */
    protected $aTemplateDirs = array();

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        // デバッグフラグ
        $sDebugging           = strtolower(\Request::getServer('SC_SMARTY_DEBUGGING', '0'));
        if ( $sDebugging === '1' || $sDebugging === 'on' || $sDebugging === 'true' ) {
            $this->bDebugging = true;
        } else {
            $this->bDebugging = false;
        }
        // デバッグテンプレートの指定
        $sTemplate            = trim(\Request::getServer('SC_SMARTY_DEBUG_TEMPLATE', ''));
        if ( $sTemplate !== '' ) {
            $this->sTemplate  = $sTemplate;
        }
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\SmartyDebug
     */
    public static function getInstance()
    {
        if ( static::$oInstance === NULL ) {
            // インスタンス生成前に別名を付与する
            static::load();
            // インスタンス生成
            static::$oInstance = new static();
        }
        return static::$oInstance;
    }

    /**
     * ロード(インスタンスは生成しない)
     *
     * @return  bool    true
     */
    public static function load()
    {
        // インスタンスがあるか？
        if ( static::$oInstance !== NULL ) {
            // インスタンスがあればなしもしない
            return true;
        }
        // インスタンスがないならば別名を付与する
        $sThisClass     = get_called_class();
        $sSmartyClass   = 'Smarty_Internal_Debug';
        $bRetCode       = class_exists($sSmartyClass, false);
        if ( $bRetCode !== true ) {
            $bRetCode   = class_alias($sThisClass, $sSmartyClass, false);
        }
        return $bRetCode;
    }

    /**
     * デバッグテンプレートの対象ディレクトリ
     *
     * @param   array   $aPlus          追加情報
     * @return  bool    true
     */
    public static function setTemplateDir(array $aDirs)
    {
        $oSelf = static::getInstance();
        return $oSelf->_setTemplateDir($aDirs);
    }

    /**
     * デバッグテンプレートの対象ディレクトリ
     *
     * @param   array   $aPlus          追加情報
     * @return  bool    true
     */
    protected function _setTemplateDir(array $aDirs)
    {
        $this->aTemplateDirs = $aDirs;
        return true;
    }

    /**
     * デバッグテンプレートの出力(display)
     *
     * @param   object  $oResource      SC\libs\SmartyオブジェクトもしくはSmarty_Internal_TemplateBase
     * @param   string  $sTemplate      デバッグテンプレート
     * @param   array   $aPlus          追加情報
     * @return  bool    true
     */
    public static function display_debug($oResource, $sTemplate = '', array $aPlus = array())
    {
        $oSelf = static::getInstance();
        echo $oSelf->_fetch($oResource, $sTemplate, $aPlus);
        return true;
    }

    /**
     * デバッグテンプレートの出力(fetch)
     *
     * @param   object  $oResource      SC\libs\SmartyオブジェクトもしくはSmarty_Internal_TemplateBase
     * @param   string  $sTemplate      デバッグテンプレート
     * @param   array   $aPlus          追加情報
     * @return  bool    true
     */
    public static function fetch($oResource, $sTemplate = '', array $aPlus = array())
    {
        $oSelf = static::getInstance();
        return $oSelf->_fetch($oResource, $sTemplate, $aPlus);
    }

    /**
     * デバッグテンプレートの出力(fetch)
     *
     * @param   object  $oResource      SC\libs\SmartyオブジェクトもしくはSmarty_Internal_TemplateBase
     * @param   string  $sTemplate      デバッグテンプレート
     * @param   array   $aPlus          追加情報
     * @return  bool    true
     */
    protected function _fetch($oResource, $sTemplate = '', array $aPlus = array())
    {
        // デバッグモードか否か
        if ( $this->bDebugging !== true ) {
            return '';
        }
        // テンプレートの値は一番最初に取得する
        $aRawVals                       = $this->_getTplVals($oResource);
        $aRawConstants                  = SmartyConstants::get();
        // Smartyクラスかどうか
        $oSmarty                        = $this->_cloneSmarty($oResource);
        // プロパティ
        $oSmarty->registered_filters    = array();
        $oSmarty->autoload_filters      = array();
        $oSmarty->default_modifiers     = array();
        $oSmarty->force_compile         = false;
        $oSmarty->left_delimiter        = '<!--{';
        $oSmarty->right_delimiter       = '}-->';
        $oSmarty->debugging             = false;
        $oSmarty->force_compile         = false;
        // デバッグテンプレート
        $oSmarty->template_dir          = str_replace(array('/', '\\'), array(DIRECTORY_SEPARATOR, DIRECTORY_SEPARATOR), $this->aTemplateDirs);
        if ( $sTemplate === '' ) {
            if ( $this->sTemplate !== '' ) {
                $sTemplate              = $this->sTemplate;
            } else {
                $sTemplate              = $oSmarty->debug_tpl;
            }
        }
        $oDebug                         = new \Smarty_Internal_Template($sTemplate, $oSmarty);
        $oDebug->caching                = false;
        $oDebug->disableSecurity();
        $oDebug->cache_id               = NULL;
        $oDebug->compile_id             = NULL;
        $aTplVals                       = array(
            'general'            => array(
                'AccessKey'      => \Log::getAccessKey(),
                'AccessId'       => \Log::getAccessId(),
                'UniqId'         => \Log::getUniqId(),
                'Selected'       => LogRegistry::getValue('sc:request', 'SELECTED_MODEL', '*empty*'),
                'Chain'          => LogRegistry::getValue('sc:request', 'CHAINED_MODEL',  array()),
                'SelectedRank'   => LogRegistry::getValue('sc:request', 'SELECTED_RANK',  -1),
                'Templates'      => $aRawVals['templates'],
                'AccessTime'     => \Log::getAccessSec(),
                'ProcTime'       => sprintf('%3.9f', microtime(true) - \Log::getAccessSec()),
            ),
            'constants'          => array(),
            'parameters'         => array(),
        );
        $aTplVals                       = ArrayUtil::unite($aTplVals, $aPlus, false);
        $aConstants                     = array();
        $aParameters                    = array();
        foreach ( $aRawVals['vals'] as $sKey => $mValue ) {
            if ( $sKey === 'smarty' ) {
                continue;
            }
            $bRetCode                   = isset($aRawConstants[$sKey]);
            if ( $bRetCode === true ) {
                $aConstants[$sKey]      = $mValue;
            } else {
                $aParameters[$sKey]     = $mValue;
            }
        }
        ArrayUtil::natksort($aConstants);
        ArrayUtil::natksort($aParameters);
        $aTplVals['constants']          = $aConstants;
        $aTplVals['parameters']         = $aParameters;
        $oDebug->assign('__SC_DEBUG__', $aTplVals);
        return $oDebug->fetch();
    }

    /**
     * Smartyクラスを取得
     *
     * @param   object  $oResource      Smarty_Internal_TemplateBase
     * @return  Smarty  $oSmarty
     */
    protected function _cloneSmarty($oResource)
    {
        // Smartyクラスかどうか
        $bRetCode = Util::is_a($oResource, 'Smarty', false);
        if ( $bRetCode === true ) {
            return clone $oResource;
        }
        $bRetCode = property_exists($oResource, 'smarty');
        if ( $bRetCode === true ) {
            return clone $oResource->smarty;
        }
        return NULL;
    }

    /**
     * テンプレートの値を取得
     *
     * @param   object  $oResource      Smarty
     * @return  array   テンプレートの値
     */
    protected function _getTplVals($oResource)
    {
        $aTplVals                 = array(
            'vals'      => array(),
            'templates' => array(),
        );
        // Smartyクラスかどうか
        $bRetCode                 = Util::is_a($oResource, 'Smarty', false);
        if ( $bRetCode === true ) {
            $oSmarty              = $oResource;
        } else {
            $bRetCode             = property_exists($oResource, 'smarty');
            if ( $bRetCode !== true ) {
                return $aTplVals;
            }
            $oSmarty              = $oResource->smarty;
        }
        // テンプレートオブジェクトを取得
        $bRetCode                 = property_exists($oSmarty, 'template_objects');
        if ( $bRetCode !== true ) {
            return $aTplVals;
        }
        // オブジェクトがなければ空
        if ( $oSmarty->template_objects === array() ) {
            return $aTplVals;
        }
        $aVals                    = $oSmarty->tpl_vars;
        $aNodes                   = array();
        foreach ( $oSmarty->template_objects as $oTpl ) {
            // テンプレート情報を取得
            $aFiles               = $oTpl->properties['file_dependency'];
            array_shift($aFiles);
            $aChildren            = array();
            foreach ( $aFiles as $sUID => $aEach ) {
                $aChildren[$sUID] = $sUID;
            }
            $sUID                 = $oTpl->source->uid;
            $aNodes[$sUID]        = array(
                'resource' => $oTpl->template_resource,
                'children' => $aChildren,
                'composed' => false,
            );
            $aVals                = ArrayUtil::unite($aVals, $oTpl->tpl_vars, true);
        }
        foreach ( $aVals as $sKey => $oValue ) {
            $aVals[$sKey]         = $oValue->value;
        }
        $aTplVals                 = array(
            'vals'      => $aVals,
            'templates' => $this->_composeTplTree($aNodes, $aNodes),
        );
        return $aTplVals;
    }

    /**
     * ツリーを構成
     *
     * @param   array   $aChildren      uidの配列
     * @param   array   $aNodes         ノードの配列
     * @return  array   ツリーを構成
     */
    protected function _composeTplTree(array $aChildren, array &$aNodes)
    {
        $aTplTree                      = array();
        foreach ( $aChildren as $sUID => $mValue ) {
            // テンプレートのノードがあるか？
            $bRetCode                  = isset($aNodes[$sUID]);
            if ( $bRetCode !== true ) {
                continue;
            }
            if ( $aNodes[$sUID]['composed'] === true ) {
                continue;
            }
            // ノードがあればノードの子を再帰構成
            $aEach                     = array(
                'resource' => $aNodes[$sUID]['resource'],
                'children' => $this->_composeTplTree($aNodes[$sUID]['children'], $aNodes),
            );
            // 構成済み
            $aNodes[$sUID]['composed'] = true;
            $aTplTree[]                = $aEach;
        }
        return $aTplTree;
    }

    /**
     * Compiles code for the {debug} tag
     *
     * @param array                                 $args      array with attributes from parser
     * @param Smarty_Internal_TemplateCompilerBase  $oCompiler compiler object
     * @return string compiled code
     */
    public function compile(array $aArgs, \Smarty_Internal_TemplateCompilerBase $oCompiler)
    {
        // 属性チェック
        $this->optional_attributes = array('assign', 'var');
        $aAttrs = $this->getAttributes($oCompiler, $aArgs);
        // compile always as nocache
        $oCompiler->tag_nocache = true;
        // display debug template
        $_output = "<?php echo 'SC\\libs\\SmartyDebug::display_debug(\$_smarty_tpl)'; ?>";
        return $_output;
    }
}
