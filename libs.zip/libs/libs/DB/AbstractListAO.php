<?php
/**
 * 抽象ListAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * 抽象ListAO
 */
abstract class AbstractListAO extends \SC\libs\ArrayObject
{
    /**
     * プロパティ型指定があるもののみ保持できる
     *
     * $this->aPropTypesにて指定があるプロパティのみ保持するか否かを判定する
     *
     * @var bool CAN_STORE_ONLY_RESERVED_KEY
     */
    const CAN_STORE_ONLY_RESERVED_KEY = false;

    /**
     * プロパティキー名指定があるもののみ保持できる
     *
     * インクリメント方式(キー名無指定)で値を保持するか否かを判定する
     * true:  キー名の指定が必須
     * false: キー名の指定がない→インクリメント方式
     *
     *  (ex) true: $arr[] = value; → 例外 \SC\exception\libs\ArrayObject\EmptyPropertyName
     *
     * @var bool CAN_STORE_ONLY_SPECIFIED_KEY
     */
    const CAN_STORE_ONLY_SPECIFIED_KEY = false;

    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array();

}
