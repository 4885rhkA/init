<?php
/**
 * BindAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * BindAO
 */
class BindAO extends AbstractAO
{
    /**
     * プロパティ型指定
     *
     *  キー    配列のキー名
     *  値      型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var array $aPropTypes
     */
    protected $aPropTypes = array(
        'name'       => 'string',   // BINDネーム
        'type'       => 'string',   // BIND値の型
        'int'        => 'int',      // BIND値   PDO::PARAM_INT
        'bool'       => 'bool',     // BIND値   PDO::PARAM_BOOL
        'string'     => 'string',   // BIND値   PDO::PARAM_STR
    );
}
