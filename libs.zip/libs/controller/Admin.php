<?php
/**
 * コントロールパネルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller;

/**
 * コントロールパネルコントローラクラス
 */
class Admin extends AbstractInput
{
    /**
     * 画面処理
     *
     * @var bool PROCESS
     */
    const PROCESS = self::PROCESS_ADMIN;

    /**
     * エラーハンドラ
     *
     * @var string ERRORHANDLER
     */
    const ERRORHANDLER = 'SC\libs\ErrorHandler::showAdmin';

    /**
     * 処理
     *
     * @return true
     */
    protected function _process()
    {
        // モデルセレクト
        $sPath                = $this->oRequest->getPathInfo();
        $bFound               = (bool) preg_match('#^(/preview/(live|verify|develop))(/.*)?$#u', $sPath, $aMatches);
        if ( $bFound !== true ) {
            // 管理画面モデルのセレクト
            $aSelector        = \SC\libs\ModelSelectorAdmin::select();
            $sModel           = "SC\\controller\\Admin\\{$aSelector['model']}Model";
        } else {
            // ステージプレビュー用にパスを調整
            $sPrefix          = (string) \ArrayUtil::getValue($aMatches, 1, '');
            $sStage           = (string) \ArrayUtil::getValue($aMatches, 2, '');
            $sNewPath         = (string) \ArrayUtil::getValue($aMatches, 3, '/');
            $sStage           = ucfirst(strtolower($sStage));
            $sEntryPoint      = $this->oRequest->getEntryPoint();
            $this->oRequest->setEntryPoint($sEntryPoint . $sPrefix);
            $sWebRootPath     = $this->oRequest->getWebRootPath();
            $this->oRequest->setWebRootPath($sWebRootPath . $sPrefix);
            $this->oRequest->setPathInfo($sNewPath);
            $this->oRequest->setOrigPathInfo($sNewPath);
            $sNewPath         = $this->oRequest->getPathInfo();
            // ログ出力する
            \Log::info("New URI Info: PATH_INFO=[$sNewPath] <= [$sPath]");
            // ステージプレビューモデルのセレクト
            $aSelector        = call_user_func("SC\\libs\\ModelSelector{$sStage}::select");
            $sModel           = "SC\\controller\\{$aSelector['model']}Model";
        }
        // モデルコントローラを駆動
        $oModel               = $sModel::getInstance();
        $oModel->setSelector($aSelector);
        $oModel->execute();
        return true;
    }
}
