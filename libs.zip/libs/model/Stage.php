<?php
/**
 * ステージ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\model;

/**
 * ステージ
 */
class Stage
{
    /**
     * インスタンス
     *
     * @var SC\model\Stage $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * リクエスト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * ファイル
     *
     * @var SC\libs\File $oFile
     */
    protected $oFile = NULL;

    /**
     * Git
     *
     * @var SC\libs\Git $oGit
     */
    protected $oGit = NULL;

    /**
     * 警告をログ出力しないフラグ
     *
     * @var bool $bNoWarning
     */
    protected $bNoWarning = false;

    /**
     * 管理画面のパス
     *
     * @var string $sStagePath
     */
    protected $sStagePath = '';

    /**
     * ステージタイプ
     *
     * @var array $stageType
     */
    protected $stageType = array('live', 'verify', 'develop');

    /**
     * ディレクトリタイプ
     *
     * @var array $dirType
     */
    protected $dirType = array('config', 'public', 'template');

    /**
     * 編集可ファイルタイプ
     *
     * @var array $editableType
     */
    protected $editableFileType = array('yaon', 'html', 'css', 'js');

    /**
     * リネーム・削除不可リスト
     *
     * @var array $noneditableType
     */
    protected $noneditableType = array(
        'config', 'config/global.yaon',
        'public', 'public/css', 'public/images', 'public/js',
        'template'
    );

    /**
     * ファイルアップロードベースディレクトリ
     *
     * @var string UPLOAD_BASE
     */
    const UPLOAD_BASE = 'tmp/upload';

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
        $this->oRequest = \SC\libs\Request::getInstance();
        // ステージングのパス
        $sStagePath            = $this->oRequest->getServer('SC_STAGING_PATH', realpath(AP_DIR . '/..'));
        if ( is_dir($sStagePath) !== true ) {
            $this->sStagePath  = realpath(AP_DIR . '/..');
        } else {
            $this->sStagePath  = $sStagePath;
        }
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\model\Stage
     */
    public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * PATH_INFOからステージ名を取得する
     *
     * @param   string  PATH_INFO
     * @return  string  ステージ名
     * @throw   SC\exception\model\Stage\EmptyStage
     */
    public function getStageName($sPathInfo)
    {
        // PATH_INFOからステージ種別を取得
        // ex.) /stage/live/file/create.json
        $bFound = (bool) preg_match('#^/stage/(live|verify|develop)#u', $sPathInfo, $aMatches);
        if ( $bFound !== true ) {
            throw new \SC\exception\model\Stage\EmptyStage("Empty stage in PATH_INFO as '{$sPathInfo}'");
        }
        $sStage = $aMatches[1];
        return $sStage;
    }

    /**
     * ステージ情報を取得する
     *
     * @param   string  $sStage     ステージ名
     * @return  array   ステージ情報
     */
    public function getData($sStage)
    {
        $aStageInfo = array();
        // @todo 変換元サイト
        // @todo サイト公開ステータス
        // @todo 認証状態

        $sBaseDir    = getcwd();
        $sDirname    = AP_DIR . '/contents/stage.' . $sStage;
        chdir($sDirname);

        // ファイル数 (.gitディレクトリ以外)
        $aFileList   = array();
        $aFileList   = array_merge($aFileList, \Util::getFileList('template', '*', true, false));
        $aFileList   = array_merge($aFileList, \Util::getFileList('config',   '*', true, false));
        $aFileList   = array_merge($aFileList, \Util::getFileList('public',   '*', true, false));
        $aStageInfo['fileCount'] = count($aFileList);

        // ファイルサイズ (.gitディレクトリ以外)
        $iFileSize = 0;
        foreach ( $aFileList as $oFile ) {
            $iFileSize += $oFile->getSize();
        }
        $aStageInfo['fileSize'] = \Util::formatFileSize($iFileSize);

        // 最終更新者・日時
        // exec.  ) $ git log -1 --branches=$sStage --no-merges
        // output.) commit a4a1ebb59435d6528c85e2a5d8ccd70a10596c76
        //          Author: hogehoge
        //          Date:   Fri Apr 1 12:34:56 2012 +0900
        //          commit comment．
        $this->oGit = \SC\libs\Git::getInstance($sDirname);
        $this->oGit->setNoWarning($this->bNoWarning);
        $aArgs      = array('log', '-1', '--branches=' . $sStage, '--no-merges');
        $sOutput    = $this->oGit->exec($aArgs);
        if ( (bool) preg_match('#Date:.*\n#u', $sOutput, $aMatches) !== false ) {
            $sValue = trim($aMatches[0], 'Date:');
            $sValue = trim($sValue);
            $aStageInfo['lastTime'] = date('Y-m-d H:i:s', strtotime($sValue));
        }
        if ( (bool) preg_match('#Author:.*\n#u', $sOutput, $aMatches) !== false ) {
            $sValue = trim($aMatches[0], 'Author:');
            $sValue = trim($sValue);
            $iPos   = strpos($sValue, ' <');
            if ( $iPos !== false ) {
                $sValue = substr($sValue, 0, $iPos);   // メアドより前を取得
            }
            $aStageInfo['lastAuthor'] = $sValue;
        }

        chdir($sBaseDir);
        return $aStageInfo;
    }

    /**
     * リリースされていないファイル一覧を取得する
     *
     * @param   string  $sStage     ステージ名
     * @return  array   ファイル一覧
     */
    public function getUnreleasedFiles($sStage)
    {
        $sBaseDir    = getcwd();
        $sDirname    = AP_DIR . '/contents/stage.' . $sStage;
        chdir($sDirname);

        // 最終リリース以降の編集済みファイル一覧
        // exec.  ) $ git diff --name-only origin/release origin/live
        // output.) public/js/mobile-switcher.js
        //          template/index.html
        //          template/test.html
        $this->oGit = \SC\libs\Git::getInstance($sDirname);
        $this->oGit->setNoWarning($this->bNoWarning);
        $sOriginRelease      = 'origin/' . \SC\model\Site::RELEASE_BRANCH;
        $sOriginTargetBranch = 'origin/' . $sStage;
        // @todo origin/release < origin/$sStage をチェック
        $aArgs               = array('diff', '--name-only', $sOriginRelease, $sOriginTargetBranch);
        $sOutput             = $this->oGit->exec($aArgs);
        $aUnreleasedFiles    = explode("\n", $sOutput);

        chdir($sBaseDir);
        return $aUnreleasedFiles;
    }

    /**
     * ステージングの現在のブランチ名を取得する
     *
     * @return  string  ブランチ名
     */
    public function getCurrentBranchName()
    {
        $sProductionPath = $this->sStagePath . '/contents.production';
        if ( is_link($sProductionPath) === true ) {
            $sProductionPath = readlink($sProductionPath);
        }
        $aBasenameSplited = explode('.', basename($sProductionPath));
        if ( count($aBasenameSplited) > 1 ) {
            $sBranch = $aBasenameSplited[1];
        } else {
            $sBranch = "";
        }
        return $sBranch;
    }

    /**
     * ステージングの現在のブランチを切り替える
     *
     * @param   string  ブランチ名
     * @return  boolean 切り替えの成功 or 失敗
     */
    public function switchBranch($sBranch)
    {
        $sScriptPath = $this->sStagePath . '/x.42change.production.sh';
        if ( is_executable($sScriptPath) !== true ) {
            return false;
        }
        $sCommand = $sScriptPath . ' ' . $sBranch;
        exec($sCommand, $output, $return_var);
        if ( $return_var === 0 ) {
            $result = true;
        } else {
            $result = false;
        }
        return $result;
    }

    /**
     * ステージングの変換元ソースの一覧を取得する
     *
     * @return  array  変換元ソースの情報
     */
    public function getStagingSources()
    {
        $aSources = array(
            array(
                'name'   => 'default',
                'active' => true,
            )
        );
        $aSourceFiles = glob($this->sStagePath . '/staging-source-*.yaon');
        if ( empty($aSourceFiles) !== true ) {
            // 現在のstaging.yaonのシンボリックリンク元を取得
            $sActiveSourceName = 'default';
            $sConfigFilePath   = $this->sStagePath . '/contents.production/config/staging.yaon';
            if ( is_link($sConfigFilePath) === true ) {
                $sConfigFilePath = readlink($sConfigFilePath);
                $bRetCode        = (bool) preg_match('#/staging-source-(.+)\.yaon$#', $sConfigFilePath, $aMatches);
                if ( $bRetCode === true && count($aMatches) > 1 ) {
                    $sActiveSourceName = $aMatches[1];
                }
            }
            // staging-source-*.yaon の名前を配列に格納
            foreach ($aSourceFiles as $sFile) {
                preg_match('#/staging-source-(.+)\.yaon$#', $sFile, $aMatches);
                $sSourceName = $aMatches[1];
                if ( $sSourceName === 'default' ) {
                    // staging-source-default.yaon は除外
                    continue;
                }
                $bActive     = false;
                if ( $sSourceName === $sActiveSourceName ) {
                    $bActive = true;
                    $aSources[0]['active'] = false;
                }
                $aSource = array(
                    'name'   => $sSourceName,
                    'active' => $bActive,
                );
                array_push($aSources, $aSource);
            }
        }
        return $aSources;
    }

    /**
     * ステージングの現在の変換元ソースを切り替える
     *
     * @param   string  変換元ソース名
     * @return  boolean 切り替えの成功 or 失敗
     */
    public function switchStagingSource($sSource)
    {
        $sTarget = $this->sStagePath . '/contents.production/config/staging.yaon';
        if ( is_link($sTarget) === true ) {
            $bRetCode = unlink($sTarget);
            if ( $bRetCode === false ) {
                return false;
            }
        }
        if ( $sSource === 'default' ) {
            return true;
        }
        $sOriginalFile = $this->sStagePath . '/staging-source-' . $sSource . '.yaon';
        $result = symlink($sOriginalFile, $sTarget);
        return $result;
    }

    /**
     * ファイルツリーを取得する
     *
     * @param   string  ステージ名
     * @param   string  ディレクトリ
     * @return  array   ステージ情報
     */
    public function getFileTree($sStage, $sDir, $bExcludeDotfiles = false)
    {
        // 入力チェック
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        if ( $sDir === '' ) {
            throw new \SC\exception\common\returnvalue();
        }
        $sRootDir = $this->_getRootDir($sDir);
        if ( in_array($sRootDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }

        $sBaseDir   = getcwd();
        $sTargetDir = AP_DIR . '/contents/stage.' . $sStage;

        chdir($sTargetDir);
        $aTree = array();
        if ($bExcludeDotfiles === true) {
          $aFileList   = \Util::getFileList($sDir, '/^[^.].*$/', true, false, NULL, true);
        } else {
          $aFileList   = \Util::getFileList($sDir, '*', true, false);
        }
        foreach ( $aFileList as $oFile ) {
            $sParent   = $oFile->getParent();
            $sPathName = $oFile->getPathname();
            $sFilename = $oFile->getFilename();
            $aLeaf = array(
                'id'    => $sPathName,
                'key'   => $sParent,   // ツリー組み立て用
                'label' => $sFilename,
                'leaf'  => ( $oFile->isDir() === true ) ? false : true,
            );

            if ( $sParent === $sDir ) {
                // 直下のファイル → 無条件に追加
                $aTree[] = $aLeaf;
            } else {
                $this->_addLeaf($aTree, $aLeaf);
            }
        }

        chdir($sBaseDir);
        return $aTree;
    }

    /**
     * 子をツリーに追加する
     *
     * @param $aTree    ツリー配列
     * @param $aLeaf    子要素
     */
    private function _addLeaf(array &$aTree, array $aLeaf)
    {
        $sParent = $aLeaf['key'];// 親の相対パス
        foreach ( $aTree as $sKey => $aValue ) {
            // 親かどうか
            if ( $aValue['id'] === $sParent ) {
                // 親だった → 子として追加
                $aTree[$sKey]['children'][] = $aLeaf;
                return;
            }
            // ディレクトリかどうか
            if ( $aValue['leaf'] === false ) {
                // 再帰処理
                if ( isset($aTree[$sKey]['children']) === true ) {
                    $this->_addLeaf($aTree[$sKey]['children'], $aLeaf);
                }
            }
        }
    }

    /**
     * ファイル内容を取得する
     *
     * @param   string  $sStage ステージ名
     * @param   string  $sPath  相対ファイルパス
     * @return  string  ファイルデータ
     */
    public function readFile($sStage, $sPath)
    {
        // 入力チェック
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        $sDir = substr($sPath, 0, strpos($sPath, '/'));
        if ( in_array($sDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }

        $sFilename = AP_DIR . '/contents/stage.' . $sStage . '/' . $sPath;
        $this->oFile = \SC\libs\File::getInstance($sFilename);

        $aData                = array();
        $sMimeType            = $this->oFile->getMimeType();
        $bRetCode             = (bool) preg_match('#^(?:text/|application/(?:(?:.+[-\+])?xml(?:[-\+].+)?|(?:x-)?javascript|jsonp?)$)#S', $sMimeType);
        if ( $bRetCode === true ) {
            // テキストファイル → 取得してセット
            $aData['content'] = $this->oFile->read();
        } else {
            // バイナリファイル → クライアント側で使用しないのでセットしない
            $aData['content'] = NULL;
        }
        $aData['mime']        = $sMimeType;
        $aData['size']        = $this->oFile->getSize();
        $aData['modifytime']  = $this->oFile->getMTime();
        $aData['md5']         = md5($aData['content']);
        return $aData;
    }

    /**
     * ファイルを作成する
     *
     * @param   string  $sStage      ステージ名
     * @param   string  $sPath       作成先相対パス
     * @param   string  $sName       作成ファイル名
     * @param   string  $sAuthor     変更ユーザ名
     * @param   string  $sMessage    コミットメッセージ
     * @return  boolean 作成の成功 or 失敗
     */
    public function createFile($sStage, $sPath, $sName, $sAuthor, $sMessage)
    {
        // ステージ種別が正しいかどうか
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue("ステージ種別「{$sStage}」が正しくありません。");
        }
        // ファイル名が入力されているかどうか
        if ( $sName === NULL || $sName === '' ) {
            throw new \SC\exception\common\returnvalue("ファイル名が入力されていません。");
        }
        // ファイル名に使用されている文字種が正しいかどうか
        $bFound = (bool) preg_match('/^[a-zA-Z0-9_\.\-]+$/', $sName);
        if ( $bFound !== true ) {
            throw new \SC\exception\common\returnvalue("ファイル名「{$sName}」が正しくありません。");
        }
        // 作成可能な拡張子かどうか
        $sExt = substr($sName, strrpos($sName, '.') + 1);
        if ( in_array($sExt, $this->editableFileType) === false ) {
            throw new \SC\exception\common\returnvalue("指定された拡張子「{$sExt}」は有効ではありません。");
        }
        $sRootDir = $this->_getRootDir($sPath);
        if ( in_array($sRootDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        // ルートディレクトリ別に作成可能な拡張子かどうか
        $this->_validateExtension($sRootDir, $sName);

        $sDirPath  = AP_DIR . '/contents/stage.' . $sStage . '/' . $sPath;
        $sFilePath = $sDirPath . '/' . $sName;

        // 既に存在しているファイルかどうか
        $bRetCode = file_exists($sFilePath);
        if ( $bRetCode === true ) {
            throw new \SC\exception\common\returnvalue('既に同じファイル名が存在しています。');
        }

        $this->oFile = \SC\libs\File::getInstance($sFilePath);
        $bRetCode = $this->oFile->touch();

        $this->oGit = \SC\libs\Git::getInstance($sDirPath);
        $this->oGit->setNoWarning($this->bNoWarning);
        $this->oGit->add();
        $this->oGit->commit($sAuthor, $sMessage);
        $this->oGit->push();

        return $bRetCode;
    }

    /**
     * ディレクトリを作成する
     *
     * @param   string  $sStage      ステージ名
     * @param   string  $sPath       作成先相対パス
     * @param   string  $sName       作成ディレクトリ名
     * @return  boolean 作成の成功 or 失敗
     */
    public function createDir($sStage, $sPath, $sName)
    {
        // ステージ種別が正しいかどうか
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue("ステージ種別「{$sStage}」が正しくありません。");
        }
        // ディレクトリ名が入力されているかどうか
        if ( $sName === NULL || $sName === '' ) {
            throw new \SC\exception\common\returnvalue("ディレクトリ名が入力されていません。");
        }
        // ディレクトリ名に使用されている文字種が正しいかどうか
        $bFound = (bool) preg_match('/^[a-zA-Z0-9_\.\-]+$/', $sName);
        if ( $bFound !== true ) {
            throw new \SC\exception\common\returnvalue("ディレクトリ名「{$sName}」が正しくありません。");
        }

        $sDirPath   = AP_DIR . '/contents/stage.' . $sStage . '/' . $sPath;
        $sRealPath  = $sDirPath . '/' . $sName;

        // 既に存在しているディレクトリかどうか
        $bRetCode  = file_exists($sRealPath);
        if ( $bRetCode === true ) {
            throw new \SC\exception\common\returnvalue('既に同じディレクトリ名が存在しています。');
        }

        $bRetCode = mkdir($sRealPath, 0777);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\returnvalue('ディレクトリが作成できませんでした。');
        }
        return $bRetCode;
    }

    /**
     * ファイルを更新する
     *
     * @param   string  $sStage      ステージ名
     * @param   string  $sPath       相対ファイルパス
     * @param   string  $sData       ファイルデータ
     * @param   string  $sAuthor     変更ユーザ名
     * @param   string  $sMessage    コミットメッセージ
     */
    public function updateFile($sStage, $sPath, $sData, $sAuthor, $sMessage)
    {
        // 入力チェック
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        $sDir = substr($sPath, 0, strpos($sPath, '/'));
        if ( in_array($sDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        $sExt = substr($sPath, strrpos($sPath, '.') + 1);
        if ( in_array($sExt, $this->editableFileType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }

        $sDirname  = AP_DIR . '/contents/stage.' . $sStage;
        $sFilename = $sDirname . '/' . $sPath;
        $this->oFile = \SC\libs\File::getInstance($sFilename);
        $this->oGit  = \SC\libs\Git::getInstance($sDirname);
        $this->oGit->setNoWarning($this->bNoWarning);

        $sOldId = $this->oGit->getObjectId($sFilename);
        $this->oGit->pull();
        $sNewId = $this->oGit->getObjectId($sFilename);
        if ( $sOldId === $sNewId ) {
            // 編集中にファイル変更なし → 更新処理
            $this->oFile->write($sData);
            $this->oGit->commit($sAuthor, $sMessage);
            $this->oGit->push();
        } else {
            // 編集中にファイル変更あり → エラー表示して更新しない
            throw new \SC\exception\common\returnvalue('編集中にファイルが変更されました。システム管理者まで連絡してください。');
        }
        return true;
    }

    /**
     * ファイルを削除する
     *
     * @param   string  $sStage     ステージ名
     * @param   string  $sPath      相対ファイルパス
     * @param   string  $sAuthor    変更ユーザ名
     * @param   string  $sMessage   コミットメッセージ
     * @return  boolean 削除の成功 or 失敗
     */
    public function deleteFile($sStage, $sPath, $sAuthor, $sMessage)
    {
        // ステージ種別が正しいかどうか
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue("ステージ種別「{$sStage}」が正しくありません。");
        }
        // 削除不可対象かどうか
        if ( in_array($sPath, $this->noneditableType) === true ) {
            throw new \SC\exception\common\returnvalue("「{$sPath}」は削除できません。");
        }

        $sFilePath = AP_DIR . '/contents/stage.' . $sStage . '/' . $sPath;
        $sDirPath  = dirname($sFilePath);

        $this->oGit = \SC\libs\Git::getInstance($sDirPath);
        $this->oGit->setNoWarning($this->bNoWarning);
        $this->oGit->pull();

        $this->oFile = \SC\libs\File::getInstance($sFilePath);
        $bRetCode = $this->oFile->remove();
        if ( $bRetCode === 0 ) {
            throw new \SC\exception\common\returnvalue('ファイルを削除できませんでした。');
        }

        $this->oGit->commit($sAuthor, $sMessage);
        $this->oGit->push();

        return $bRetCode;
    }

    /**
     * ファイルをリネームする
     *
     * @param   string  $sStage     ステージ名
     * @param   string  $sPath      相対ファイルパス
     * @param   string  $sName      新しいディレクトリ・ファイル名
     * @param   string  $sAuthor    変更ユーザ
     * @param   string  $sMessage   コミットメッセージ
     * @return  boolean リネームの成功 or 失敗
     */
    public function renameFile($sStage, $sPath, $sName, $sAuthor, $sMessage)
    {
        // ステージ種別が正しいかどうか
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue("ステージ種別「{$sStage}」が正しくありません。");
        }
        // リネーム不可対象かどうか
        if ( in_array($sPath, $this->noneditableType) === true ) {
            throw new \SC\exception\common\returnvalue("「{$sPath}」はリネームできません。");
        }
        // ディレクトリ・ファイル名が入力されているかどうか
        if ( $sName === NULL || $sName === '' ) {
            throw new \SC\exception\common\returnvalue("新しい名前が入力されていません。");
        }
        // ディレクトリ・ファイル名に使用されている文字種が正しいかどうか
        $bFound = (bool) preg_match('/^[a-zA-Z0-9_\.\-]+$/', $sName);
        if ( $bFound !== true ) {
            throw new \SC\exception\common\returnvalue("新しい名前「{$sName}」が正しくありません。");
        }

        $sOldPath = AP_DIR . '/contents/stage.' . $sStage . '/' . $sPath;
        $sDirPath = dirname($sOldPath);
        $sNewPath = $sDirPath . '/' . $sName;

        // ファイルの場合は，拡張子が正しいかどうか
        if ( is_dir($sOldPath) === false ) {
            $sExt = substr($sName, strrpos($sName, '.') + 1);
            if ( in_array($sExt, $this->editableFileType) === false ) {
                throw new \SC\exception\common\returnvalue("指定された拡張子「{$sExt}」は有効ではありません。");
            }
        }

        $this->oGit = \SC\libs\Git::getInstance($sDirPath);
        $this->oGit->setNoWarning($this->bNoWarning);
        $this->oGit->pull();

        // 既に存在しているファイルかどうか
        $bRetCode = file_exists($sNewPath);
        if ( $bRetCode === true ) {
            throw new \SC\exception\common\returnvalue('既に同じディレクトリ・ファイル名が存在しています。');
        }

        $bRetCode = rename($sOldPath, $sNewPath);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\returnvalue('ファイルをリネームできませんでした。');
        }

        $this->oGit->add();
        $this->oGit->commit($sAuthor, $sMessage);
        $this->oGit->push();

        return $bRetCode;
    }

    /**
     * ファイルをダウンロード可能な場合のファイル名を返す
     *
     * @param   string          $sStage     ステージ名
     * @param   string          $sPath      相対ファイルパス
     * @return  string|NULL     絶対パス
     */
    public function downloadFile($sStage, $sPath)
    {
        // 入力チェック
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        $sDir = substr($sPath, 0, strpos($sPath, '/'));
        if ( in_array($sDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }

        $sDirname  = 'stage.' . $sStage;
        $sFilename = $sDirname . '/' . $sPath;

        if ( file_exists(AP_DIR . '/contents/' . $sFilename) === false ) {
            return NULL;
        }
        return $sFilename;
    }

    /**
     * ファイルをテンポラリディレクトリにアップロードする
     *
     * @param   string  $sSiteId     サイトID
     * @param   string  $sStage      ステージ名
     * @param   string  $sPath       アップロード先相対パス
     * @param   array   $aFile       アップロードファイル
     * @return  boolean アップロードの成功 or 失敗
     */
    public function prepareUploadFile($sSiteId, $sStage, $sPath, $aFile)
    {
        $sName = \ArrayUtil::getValue($aFile, 'name');
        // ステージ種別が正しいかどうか
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue("ステージ種別「{$sStage}」が正しくありません。");
        }
        // アップロードファイル名が入力されているかどうか
        if ( $sName === NULL || $sName === '' ) {
            throw new \SC\exception\common\returnvalue("アップロードファイル名が入力されていません。");
        }
        // アップロードファイル名に使用されている文字種が正しいかどうか
        $bFound = (bool) preg_match('/^[a-zA-Z0-9_\.\-\s]+$/', $sName);
        if ( $bFound !== true ) {
            throw new \SC\exception\common\returnvalue("アップロードファイル名「{$sName}」が正しくありません。");
        }
        $sRootDir = $this->_getRootDir($sPath);
        if ( in_array($sRootDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        // ルートディレクトリ別に作成可能な拡張子かどうか
        $this->_validateExtension($sRootDir, $sName);

        $sTmpName = \ArrayUtil::getValue($aFile, 'tmp_name');
        if ( $this->oRequest->is_uploaded_file($sTmpName) !== true ) {
            throw new \SC\exception\common\returnvalue("アップロードファイル「{$sName}」はHTTP POST でアップロードされたファイルではありません。");
        }

        $sDirPath = join('/', array(AP_DIR, static::UPLOAD_BASE, $sSiteId, $sStage, $sPath));
        if ( file_exists($sDirPath) !== true ) {
            mkdir($sDirPath, 0777, true);
        }
        $bRetCode = $this->oRequest->move_uploaded_file($sTmpName, $sDirPath . '/' . $sName);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\returnvalue('ファイルのアップロードができませんでした。');
        }
        return $bRetCode;
    }

    /**
     * アップロードファイルで上書きする
     *
     * @param   string  $sSiteId    サイトID
     * @param   string  $sStage     ステージ名
     * @param   string  $sPath      アップロード先相対パス
     * @param   string  $sName      アップロードファイル名
     * @param   string  $sAuthor    アップロードユーザ
     * @param   string  $sMessage   コミットメッセージ
     * @return  boolean 上書きの成功 or 失敗
     */
    public function runUploadFile($sSiteId, $sStage, $sPath, $sName, $sAuthor, $sMessage)
    {
        // ステージ種別が正しいかどうか
        if ( in_array($sStage, $this->stageType) === false ) {
            throw new \SC\exception\common\returnvalue("ステージ種別「{$sStage}」が正しくありません。");
        }
        // アップロードファイル名が入力されているかどうか
        if ( $sName === NULL || $sName === '' ) {
            throw new \SC\exception\common\returnvalue("アップロードファイル名が入力されていません。");
        }
        // アップロードファイル名に使用されている文字種が正しいかどうか
        $bFound = (bool) preg_match('/^[a-zA-Z0-9_\.\-\s]+$/', $sName);
        if ( $bFound !== true ) {
            throw new \SC\exception\common\returnvalue("アップロードファイル名「{$sName}」が正しくありません。");
        }
        $sRootDir = $this->_getRootDir($sPath);
        if ( in_array($sRootDir, $this->dirType) === false ) {
            throw new \SC\exception\common\returnvalue();
        }
        // ルートディレクトリ別に作成可能な拡張子かどうか
        $this->_validateExtension($sRootDir, $sName);

        $sTmpPath          = join('/', array(AP_DIR, static::UPLOAD_BASE, $sSiteId, $sStage, $sPath, $sName));
        $sContentsDirPath  = join('/', array(AP_DIR, '/contents/stage.' . $sStage, $sPath));
        $sContentsFilePath = $sContentsDirPath . '/' . $sName;

        $this->oFile = \SC\libs\File::getInstance($sTmpPath);
        $bRetCode = $this->oFile->moveTo($sContentsFilePath, true);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\returnvalue('アップロードしたファイルで上書きできませんでした。');
        }

        $this->oGit = \SC\libs\Git::getInstance($sContentsDirPath);
        $this->oGit->setNoWarning($this->bNoWarning);
        $sOldId = $this->oGit->getObjectId($sContentsFilePath);
        $this->oGit->pull();

        if ( file_exists($sContentsFilePath) !== false ) {
            $sNewId = $this->oGit->getObjectId($sContentsFilePath);
            // 更新ファイルのアップロード
            if ( $sOldId !== $sNewId ) {
                // アップロード中にファイル変更あり → エラー表示してコミットしない
                throw new \SC\exception\common\returnvalue('アップロード中にファイルが変更されました。システム管理者まで連絡してください。');
            }
        }

        $this->oGit->add();
        // アップロード中にファイル変更なし → コミット
        $this->oGit->commit($sAuthor, $sMessage);
        $this->oGit->push();
        return true;
    }

     /**
     * パスからルートディレクトリを取得する
     *
     * @param   string  $sPath      アップロード先相対パス
     * @return  string  ルートディレクトリ名
     */
    protected function _getRootDir($sDir)
    {
        if ( $sDir === '' ) {
            return NULL;
        }

        $sSlash = strpos($sDir, '/');
        $sRootDir = $sDir;
        if ( $sSlash !== false ) {
            $sRootDir = substr($sDir, 0, $sSlash);
        }
        return $sRootDir;
    }

    /**
     * ディレクトリ毎に作成可能なファイルかどうかを確認する
     *
     * @param   string  $sRootDir   ルートディレクトリ
     * @param   string  $sName      ファイル名
     * @return  boolean 上書きの成功 or 失敗
     */
    protected function _validateExtension($sRootDir, $sName)
    {
        if ( $sRootDir === '' || $sName === '' ) {
            throw new \SC\exception\common\returnvalue();
        }

        // 拡張子が正しいかどうか
        $sExt = substr($sName, strrpos($sName, '.') + 1);
        $sExt = strtolower($sExt);
        // templateディレクトリはhtmlのみ
        if ( $sRootDir === 'template' && $sExt !== 'html' ) {
            throw new \SC\exception\common\returnvalue("「template」ディレクトリに「{$sExt}」ファイルは作成できません。");
        }
        // configディレクトリはyaonのみ
        if ( $sRootDir === 'config' && $sExt !== 'yaon' ) {
            throw new \SC\exception\common\returnvalue("「config」ディレクトリに「{$sExt}」ファイルは作成できません。");
        }

        return true;
    }

    /**
     * 警告をログ出力しないフラグを立てる
     *
     * @return  bool    true
     */
    public static function setNoWarningOn()
    {
        $oSelf = static::getInstance();
        return $oSelf->setNoWarning(true);
    }

    /**
     * 警告をログ出力しないフラグを折る
     *
     * @return  bool    true
     */
    public static function setNoWarningOff()
    {
        $oSelf = static::getInstance();
        return $oSelf->setNoWarning(false);
    }

    /**
     * 警告をログ出力しないフラグ
     *
     * @param   bool    $bNoWarning
     * @return  bool    true
     */
    public static function setNoWarning($bNoWarning)
    {
        $oSelf             = static::getInstance();
        $oSelf->bNoWarning = (bool) $bNoWarning;
        return true;
    }
}
