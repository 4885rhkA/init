<?php
/**
 * ログレジストリ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ログレジストリ
 */
class LogRegistry
{
    /**
     * ログレジストリを使うか否か
     *
     * @var bool $bUseRegistry
     */
    protected $bUseRegistry = false;

    /**
     * データ
     *
     * @var array $aData
     */
    protected $aData = array(
        'sc:request'     => array(),
        'sc:send'        => array(),
        'sc:recv'        => array(),
        'sc:display'     => array(),
        'header:request' => array(),
        'header:send'    => array(),
        'header:recv'    => array(),
        'header:display' => array(),
        'cookie:request' => array(),
        'cookie:send'    => array(),
        'cookie:recv'    => array(),
        'cookie:display' => array(),
    );

    /**
     * ストア
     *
     *  予約キーワード
     *      Apache2.2互換
     *          %a          %{S:REMOTE_ADDR}n                           リモート IP アドレス
     *          %b          %{#:CONTENT_LENGTH}n                        出力サイズ
     *          %{Foobar}C  %{Cr:Foobar}n                               サーバに送られたリクエスト中のクッキー Foobar の値
     *          %{Foobar}e  %{E:Foobar}n                                環境変数 FOOBAR の内容
     *          %{Foobar}i  %{Hr:Foobar}n                               サーバに送られたリクエストの Foobar: ヘッダの内容
     *          %{Foobar}o  %{Hd:Foobar}n                               応答の Foobar: ヘッダの内容
     *          %h          %{S:REMOTE_ADDR}n                           リモートホスト
     *          %H          %{#r:URI_PROTO}n                            リクエストプロトコル
     *          %l          -                                           (identd からもし提供されていれば) リモートログ名。 これは mod_ident がサーバに存在して、 IdentityCheck ディレクティブが On に設定されていない限り、 - になります。
     *          %m          %{S:REQUEST_METHOD}n                        リクエストメソッド
     *          %p          %{S:SERVER_PORT}n                           リクエストを扱っているサーバの正式なポート
     *          %U          %{S:PATH_INFO}n                             リクエストされた URL パス。クエリ文字列は含まない
     *          %q          %{S:QUERY_STRING}n                          問い合せ文字列 (存在する場合は前に ? が追加される。 そうでない場合は空文字列)
     *          %r          "%{S:REQUEST_METHOD}n %{S:REQUEST_URI}n"    リクエストの最初の行
     *          %u          %{S:PHP_AUTH_USER}n                         リモートユーザ (認証によるもの。ステータス (%s) が 401 のときは意味がないものである可能性がある)
     *          %s          %{#:STATUS}n                                ステータス
     *          %>s         %{#:STATUS}n                                ステータス
     *          %t          %{S:REQUEST_TIME|t:[%d/%b/%Y:%T %z]}n       リクエストを受付けた時刻。 CLF の時刻の書式 (標準の英語の書式)
     *          %{Foobar}t  %{S:REQUEST_TIME|t:Foobar}n                 Foobar で与えられた書式による時刻。format は strftime (3) の 書式である必要がある。(地域化されている可能性がある)
     *          %T          %{#:PROCESSTIME}n                           リクエストを扱うのにかかった時間、秒単位
     *      SmartConvert拡張
     *          %{key}n     キーに応じた値
     *
     *  SmartConvertキー
     *      書式
     *          引用符なし  [from[when]:]name[|options]
     *          引用符あり  [from[when]:]"name"[|options]
     *      説明
     *          from        データ取得元(default:S)
     *              S           $_SERVERの情報
     *              G           $_GETの情報
     *              P           $_POSTの情報
     *              C           $_COOKIEの情報もしくはSet-Cookieの情報
     *              R           $_REQUESTの情報
     *              F           $_FILESの情報
     *              E           $_ENVの情報(ただし現在は指定不可)
     *              H           HTTP通信ヘッダの情報
     *              #           SmartConverの情報
     *          when        Convertモデルの場合のタイミング(default:r)
     *              r           デバイス→SCへのリクエスト情報
     *              s           SC→変換元へのリクエスト情報
     *              v           変換元→SCへのレスポンス情報
     *              d           SC→デバイスへのレスポンス情報
     *          name        データ取得元から取得したい値の名前
     *              GPCRFH:任意                     任意の値を指定できる
     *              E:不可                          常に-を出力
     *              S:HTTP_HOST                     リクエストされたサーバのホスト名
     *              S:SERVER_PORT                   リクエストされたサーバのポート番号
     *              S:PATH_INFO                     リクエストされたパス
     *              S:QUERY_STRING                  リクエストされたクエリ
     *              S:REQUEST_URI                   リクエストされたURI
     *              S:HTTPS                         HTTPS通信の場合にはon，それ以外ではNULL
     *              S:HTTP_USER_AGENT               リクエストされたHTTPヘッダのUser-Agent
     *              S:HTTP_REFERER                  リクエストされたHTTPヘッダのReferer
     *              S:REQUEST_METHOD                リクエストされたHTTPメソッド (ex: GET, POST)
     *              S:REMOTE_ADDR                   リクエストしてきたIPアドレス (ex: 192.168.1.1)
     *              S:REMOTE_ADDRS                  リクエストしてきたIPアドレス (X-Forwarded-ForとREMOTE_ADDRのCSV)
     *              S:HTTP_X_FORWARDED_FOR          リクエストされたHTTPヘッダのX-Forwarded-For
     *              S:REMOTE_PORT                   リクエストしてきたポート番号
     *              S:REMOTE_USER                   リクエストしてきた認証ユーザ
     *              S:AUTH_TYPE                     認証タイプ (ex: Basic, Digest)
     *              S:PHP_AUTH_USER                 認証ユーザ
     *              S:PHP_AUTH_PW                   認証パスワード
     *              S:PHP_AUTH_DIGEST               認証ダイジェスト
     *              S:SERVER_PROTOCOL               リクエストされたHTTPプロトコル (ex: HTTP/1.1)
     *              S:GATEWAY_INTERFACE             レスポンスするインタフェース (ex: CGI/1.1)
     *              S:REQUEST_TIME                  リクエストされたUNIXタイムスタンプ
     *              S:HOSTNAME                      サーバのHOSTNAME
     *              S:SC_PRODUCT_NAME               SmartConvertの製品名
     *              S:SC_PRODUCT_VERSION            SmartConvertのバージョン
     *              S:SC_SOURCE_HOST                変換元ホスト
     *              S:SC_STAGING                    変換元がステージングか否か
     *              S:SC_STAGING_SP                 SC環境がステージングか否か
     *              S:SC_SHOW_HIDDEN_PAGE           非表示ページを表示するか否か
     *              #:SC_PRODUCT_NAME               SmartConvertの製品名
     *              #:SC_PRODUCT_VERSION            SmartConvertのバージョン
     *              #:ACCESSKEY                     アクセスキー
     *              #:ACCESSID                      アクセスID
     *              #:UNIQUEID                      ユニークID
     *              #:URI_PROTO                     リクエストされたURIのプロトコル
     *              #:URI_HOST                      リクエストされたURIのホスト名
     *              #:URI_PORT                      リクエストされたURIのポート番号
     *              #:URI_PATH                      リクエストされたURIのパス
     *              #:URI_QUERY                     リクエストされたURIのクエリ
     *              #:URI_FRAGMENT                  リクエストされたURIのフラグメント
     *              #:URI_AUTH_USER                 リクエストされたURIの認証ユーザ
     *              #:URI_AUTH_PASS                 リクエストされたURIの認証パスワード
     *              #:URL                           リクエストされたURL
     *              #:SELECTED_MODEL                選択モデル名
     *              #:CHAINED_MODEL                 チェインモデル名
     *              #:MODEL_NAME                    処理モデル名
     *              #:SELECTED_RANK                 モデルが選択された順番
     *              #:SELECTED_TIME                 モデルが選択されるまでにかかった秒
     *              #:EXTRACTOR                     データ抽出エンジン
     *              #:TEMPLATE                      出力時のテンプレート
     *              #:TEMPLATE_ENGINE               出力時のテンプレートエンジン
     *              #:STATUS                        出力時のHTTPステータス
     *              #:STATUS_MESSAGE                出力時のHTTPステータスメッセージ
     *              #:CONTENT_TYPE                  出力時のHTTPヘッダのContent-Typeフィールド値
     *              #:CHARSET                       出力時の文字コード
     *              #:CONTENT_LENGTH                出力時のサイズ
     *              #:ACCESSSEC                     アクセスタイムスタンプ
     *              #:ACCESSTIME                    アクセス時刻
     *              #:PROCESSTIME                   アクセス時刻からの経過秒
     *              #:SMARTCONVERT_SID              セッションID
     *              #:SESSION_STARTED               セッションを開始したか否か
     *              #:CURL_ERROR                    Convertモデルの通信情報:エラーメッセージ
     *              #:CURL_ERRNO                    Convertモデルの通信情報:エラーコード
     *              #:CURL_METHOD                   Convertモデルの通信情報:HTTPメソッド
     *              #:CURL_URL                      Convertモデルの通信情報:リクエストURL
     *              #:CURL_BINARY                   Convertモデルの通信情報:レスポンスがバイナリか否か
     *              #:CURL_CHARSET                  Convertモデルの通信情報:レスポンスの文字コード
     *              #:CURL_CERTINFO                 Convertモデルの通信情報:証明書情報
     *              #:CURL_CONNECT_TIME             Convertモデルの通信情報:接続までにかかった時間
     *              #:CURL_CONTENT_TYPE             Convertモデルの通信情報:レスポンスのContent-Type
     *              #:CURL_DOWNLOAD_CONTENT_LENGTH  Convertモデルの通信情報:ダウンロードコンテンツ長
     *              #:CURL_FILETIME                 Convertモデルの通信情報:ドキュメントの更新日時
     *              #:CURL_HEADER_SIZE              Convertモデルの通信情報:リクエストヘッダサイズ
     *              #:CURL_HTTP_CODE                Convertモデルの通信情報:HTTPステータスコード
     *              #:CURL_NAMELOOKUP_TIME          Convertモデルの通信情報:正引き名前解決までにかかった時間
     *              #:CURL_PRETRANSFER_TIME         Convertモデルの通信情報:リクエスト開始までにかかった時間
     *              #:CURL_REDIRECT_COUNT           Convertモデルの通信情報:リダイレクト回数
     *              #:CURL_REDIRECT_TIME            Convertモデルの通信情報:リダイレクトにかかった時間
     *              #:CURL_REQUEST_SIZE             Convertモデルの通信情報:リクエストボディサイズ
     *              #:CURL_SIZE_DOWNLOAD            Convertモデルの通信情報:ダウンロードサイズ
     *              #:CURL_SIZE_UPLOAD              Convertモデルの通信情報:アップロードサイズ
     *              #:CURL_SPEED_DOWNLOAD           Convertモデルの通信情報:ダウンロード速度
     *              #:CURL_SPEED_UPLOAD             Convertモデルの通信情報:アップロード速度
     *              #:CURL_SSL_VERIFY_RESULT        Convertモデルの通信情報:SSL確認結果
     *              #:CURL_STARTTRANSFER_TIME       Convertモデルの通信情報:レスポンス開始までにかかった時間
     *              #:CURL_TOTAL_TIME               Convertモデルの通信情報:トータル時間
     *              #:CURL_UPLOAD_CONTENT_LENGTH    Convertモデルの通信情報:アップロードコンテンツ長
     *          options     オプション(default:指定なし)
     *              c           複数の値が取れる場合にCSV型式で出力
     *              f           複数の値が取れる場合に最初の1項目のみ出力
     *              t           値を時刻として扱って:に続けて書式を指定できる(date)
     *
     *  具体例
     *      リモートIPアドレス          %{S:REMOTE_ADDR}n
     *      転送元のIPアドレス          %{H:X-Forwarded-For}n
     *      全部のリモートIPアドレス    %{S:REMOTE_ADDRS}n
     *      リクエストされたJSESSIONID  %{Cr:JSESSIONID}n
     *      レスポンスするJSESSIONID    %{Cd:JSESSIONID}n
     *
     * see also: http://httpd.apache.org/docs/2.2/mod/mod_log_config.html#formats
     *
     * @var array $aStores
     */
    protected $aStores = array();

    /**
     * $_SERVERの有効なキー
     *
     * @var array $aNamesServer
     */
    protected $aNamesFromServer = array(
        'HTTP_HOST'            => true,     // host
        'SERVER_PORT'          => true,     // port
        'PATH_INFO'            => true,     // path
        'QUERY_STRING'         => true,     // query
        'REQUEST_URI'          => true,     // request uri
        'HTTPS'                => true,     // on
        'HTTP_USER_AGENT'      => true,     // Android
        'HTTP_REFERER'         => true,     // Referer
        'REQUEST_METHOD'       => true,     // GET/POST
        'REMOTE_ADDR'          => true,     // 192.168.1.1
        'REMOTE_ADDRS'         => true,     // 192.168.1.1
        'HTTP_X_FORWARDED_FOR' => true,     // 192.168.1.1
        'REMOTE_PORT'          => true,     // 65457
        'REMOTE_USER'          => true,     // username
        'AUTH_TYPE'            => true,     // Basic , Digest
        'PHP_AUTH_USER'        => true,     // auth username
        'PHP_AUTH_PW'          => true,     // auth passowrd
        'PHP_AUTH_DIGEST'      => true,     // auth digest
        'SERVER_PROTOCOL'      => true,     // HTTP/1.1
        'GATEWAY_INTERFACE'    => true,     // CGI/1.1
        'REQUEST_TIME'         => true,     // UNIX Epoch
        'HOSTNAME'             => true,     // hostname
        // SmartConvert Environment Variables
        'SC_PRODUCT_NAME'      => true,     // SmartConvert
        'SC_PRODUCT_VERSION'   => true,     // version of SmartConvert
        'SC_SOURCE_HOST'       => true,     // source host
        'SC_STAGING'           => true,     // is staging for Source-site
        'SC_STAGING_SP'        => true,     // is staging for SP-site
        'SC_SHOW_HIDDEN_PAGE'  => true,     // hidden page
    );

    /**
     * $_SERVERの有効なキー
     *
     * @var array $aNamesServerPrefix
     */
    protected $aNamesServerPrefix = array(
        // SmartConvert Environment Variables
        'SC_OPT_'              => true,     // optional
    );

    /**
     * 予約語の別名
     *
     * @var array $aAliases
     */
    protected $aAliases = array(
        '(^|(?<!%))(%%)*%a'                      => '%{S:REMOTE_ADDR}n',
        '(^|(?<!%))(%%)*%b'                      => '%{#:CONTENT_LENGTH}n',
        '(^|(?<!%))(%%)*%h'                      => '%{S:REMOTE_ADDR}n',
        '(^|(?<!%))(%%)*%H'                      => '%{#r:URI_PROTO}n',
        '(^|(?<!%))(%%)*%l'                      => '-',
        '(^|(?<!%))(%%)*%m'                      => '%{S:REQUEST_METHOD}n',
        '(^|(?<!%))(%%)*%p'                      => '%{S:SERVER_PORT}n',
        '(^|(?<!%))(%%)*%U'                      => '%{S:PATH_INFO}n',
        '(^|(?<!%))(%%)*%q'                      => '%{S:QUERY_STRING}n',
        '(^|(?<!%))(%%)*%r'                      => '%{S:REQUEST_METHOD}n %{S:REQUEST_URI}n',
        '(^|(?<!%))(%%)*%u'                      => '%{S:PHP_AUTH_USER}n',
        '(^|(?<!%))(%%)*%>?s'                    => '%{#:STATUS}n',
        '(^|(?<!%))(%%)*%T'                      => '%{#:PROCESSTIME}n',
        '(^|(?<!%))(%%)*%t'                      => '%{S:REQUEST_TIME|t:[d/M/Y:H:i:s O]}n',
        '(^|(?<!%))(%%)*%\\x7b([^\\x7d]+)\\x7dt' => '%{S:REQUEST_TIME|t:"\\1"}n',
        '(^|(?<!%))(%%)*%\\x7b([^\\x7d]+)\\x7dC' => '%{Cr:"\\1"}n',
        '(^|(?<!%))(%%)*%\\x7b([^\\x7d]+)\\x7de' => '%{E:"\\1"}n',
        '(^|(?<!%))(%%)*%\\x7b([^\\x7d]+)\\x7di' => '%{Hr:"\\1"}n',
        '(^|(?<!%))(%%)*%\\x7b([^\\x7d]+)\\x7do' => '%{Hd:"\\1"}n',
    );

    /**
     * データ取得元の指定
     *
     * @var array $aReplaceFroms
     */
    protected $aReplaceFroms = array(
        'S' => '_getValueFromServer',       // $_SERVERの情報
        'G' => '_getValueFromGet',          // $_GETの情報
        'P' => '_getValueFromPost',         // $_POSTの情報
        'C' => '_getValueFromCookie',       // $_COOKIEの情報もしくはSet-Cookieの情報
        'R' => '_getValueFromRequest',      // $_REQUESTの情報
        'F' => '_getValueFromFiles',        // $_FILESの情報
        'E' => '_getValueFromEnv',          // $_ENVの情報(ただし現在は指定不可)
        'H' => '_getValueFromHeader',       // HTTP通信ヘッダの情報
        '#' => '_getValueFromSmartConvert', // SmartConverの情報
    );

    /**
     * データ取得元の指定
     *
     * @var array $aFromWhens
     */
    protected $aFromWhens = array(
        'r' => 'request',
        's' => 'send',
        'v' => 'recv',
        'd' => 'display',
    );

    /**
     * ログ出力時に値を除去するか否か
     *
     * @var bool $bLogStrippedValue
     */
    protected $bLogStrippedValue = true;

    /**
     * インスタンス
     *
     * @var SC\libs\LogRegistry $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * コンストラクタ
     */
    protected function __construct()
    {
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\LogRegistry
     */
    public static function getInstance()
    {
        if ( static::$oInstance === NULL ) {
            static::$oInstance = new static();
            static::$oInstance->_initialize();
        }
        return static::$oInstance;
    }

    /**
     * 初期化処理
     *
     * @return  bool    true
     */
    protected function _initialize()
    {
        $sLogRegistry                = trim(Request::getServer('SC_LOG_REGISTRY', ''));
        if ( $sLogRegistry === '' ) {
            $this->bUseRegistry      = false;
        } else {
            $aStores                 = array_diff(str_getcsv($sLogRegistry, ' ', '"', "\\"), array(''));
            $this->_setNames($aStores);
        }
        // 値をストリップするか
        $sLogStrippedValue           = strtolower(Request::getServer('SC_LOG_STRIPPED_VALUE', '1'));
        if ( $sLogStrippedValue === '0' || $sLogStrippedValue === 'false' || $sLogStrippedValue === 'off' ) {
            $this->bLogStrippedValue = false;
        } else {
            $this->bLogStrippedValue = true;
        }
        // レジストリにストア
        $this->_save('sc:request', 'SC_PRODUCT_NAME',    SC_PRODUCT_NAME);
        $this->_save('sc:request', 'SC_PRODUCT_VERSION', SC_PRODUCT_VERSION);
        return true;
    }

    /**
     * データ定義のセット
     *
     * @param   array   $aStores    データ定義
     * @return  bool    true
     */
    public static function setNames(array $aStores)
    {
        $oSelf = static::getInstance();
        return $oSelf->_setNames($aStores);
    }

    /**
     * データ定義のセット
     *
     * @param   array   $aStores    データ定義
     * @return  bool    true
     */
    protected function _setNames(array $aStores)
    {
        foreach ( $aStores as $sKey => $mValue ) {
            $bRetCode           = Validate::isStringNotZero($mValue);
            if ( $bRetCode === true ) {
                $aStores[$sKey] = (string) $mValue;
            } else {
                unset($aStores[$sKey]);
            }
        }
        if ( $aStores === array() ) {
            $this->bUseRegistry = false;
        } else {
            $this->bUseRegistry = true;
            $this->aStores      = $aStores;
        }
        return true;
    }

    /**
     * データ定義の追加
     *
     * @param   string  $sStore     データ定義
     * @return  bool    true
     */
    public static function addName($sStore)
    {
        $oSelf = static::getInstance();
        return $oSelf->_addName($sStore);
    }

    /**
     * データ定義の追加
     *
     * @param   string  $sStore     データ定義
     * @return  bool    true
     */
    protected function _addName($sStore)
    {
        $bRetCode           = Validate::isStringNotZero($sStore);
        if ( $bRetCode !== true ) {
            return false;
        }
        $this->bUseRegistry = true;
        $this->aStores[]    = (string) $sStore;
        return true;
    }

    /**
     * データの保存
     *
     * @param   string  $sFrom          データネームスペース
     * @param   string  $sName          データ名
     * @param   mixed   $mValue         データ
     * @param   bool    $bStripValue    値の除去をするか否か
     * @return  bool    true
     */
    public static function save($sFrom, $sName, $mValue, $bStripValue = false)
    {
        $oSelf = static::getInstance();
        return $oSelf->_save($sFrom, $sName, $mValue, $bStripValue);
    }

    /**
     * データの保存
     *
     * @param   string  $sFrom          データネームスペース
     * @param   string  $sName          データ名
     * @param   mixed   $mValue         データ
     * @param   bool    $bStripValue    値の除去をするか否か
     * @return  bool    true
     */
    protected function _save($sFrom, $sName, $mValue, $bStripValue = false)
    {
        $bRetCode                    = isset($this->aData[$sFrom]);
        if ( $bRetCode !== true ) {
            $this->aData[$sFrom]     = array();
        }
        if ( $bStripValue === true ) {
            $mValue                  = Util::stripValueString($mValue);
        }
        $this->aData[$sFrom][$sName] = $mValue;
        return true;
    }

    /**
     * データの値の取得
     *
     * @param   string  $sFrom          データネームスペース
     * @param   string  $sName          データ名
     * @param   mixed   $mDefault       デフォルト値
     * @return  mixed   データ
     */
    public static function getValue($sFrom, $sName, $mDefault = NULL)
    {
        $oSelf = static::getInstance();
        return $oSelf->_getValue($sFrom, $sName, $mDefault);
    }

    /**
     * データの値の取得
     *
     * @param   string  $sFrom          データネームスペース
     * @param   string  $sName          データ名
     * @param   mixed   $mDefault       デフォルト値
     * @return  mixed   データ
     */
    protected function _getValue($sFrom, $sName, $mDefault = NULL)
    {
        $aSource = ArrayUtil::getValue($this->aData, $sFrom, array());
        $mValue  = ArrayUtil::getValue($aSource,     $sName, $mDefault);
        return $mValue;
    }

    /**
     * データの取得
     *
     * @return  array   データ
     */
    public static function get()
    {
        $oSelf = static::getInstance();
        return $oSelf->_get();
    }

    /**
     * データの取得
     *
     * @return  array   データ
     */
    protected function _get()
    {
        // 書式の正規表現
        $sFormatRE = "
            %
            (?:
                (?P<percent> % )
                |
                (?:
                    \\x7b
                    (?: (?P<from> [A-Z\\x23] ) (?P<when> [a-z]? ) \\x3a )?
                    (?: ( \\x22 )? (?P<name> (?(4) [^\\x22]+ | [^\\x22\\x7c\\x7d]+ ) ) (?(4) \\x22 ) )
                    (?: \\x7c (?: (?P<option> [a-su-z] ) | t \\x3a ( \\x22 )? (?P<format> (?(6) [^\\x22]+ | [^\\x22\\x7d]+ ) ) (?(6) \\x22 ) ) )?
                    \\x7d
                    n
                )
            )
        ";
        // 取得可能パラメータ
        //  0:          マッチ文字列
        //  percent:    %
        //  from        取得元
        //  when        取得データの生成タイミング
        //  name        キー名
        //  option      オプション名
        //  format      tオプションの場合の書式
        $aAliasSearches = Util::validatePCRE(array_keys($this->aAliases), false, '#', '');
        $aAliasReplaces = array_values($this->aAliases);
        $aStores        = preg_replace($aAliasSearches, $aAliasReplaces, $this->aStores);
        $sSearch        = Util::validatePCRE($sFormatRE, false, '#', 'x');
        $aStores        = preg_replace_callback($sSearch, array(&$this, '_replaceKeywords'), $aStores, -1, $iCount);
        return $aStores;
    }

    /**
     * データ取得コールバック
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _replaceKeywords(array $aMatches)
    {
        // バックトラックされないために%%にマッチしたか？
        if ( $aMatches['percent'] !== '' ) {
            // マッチしたら%に置換
            return '%';
        }
        $sMethod          = ArrayUtil::getValue($this->aReplaceFroms, ArrayUtil::getValue($aMatches, 'from', ''), '');
        if ( $sMethod === '' ) {
            // 取得元なし → そのまま返す
            return $aMatches[0];
        }
        $aMatches['when'] = (string) ArrayUtil::getValue($aMatches, 'when', 'r');
        foreach ( $aMatches as $k => $v ) {
            if ( $k>0 ) {
                unset($aMatches[$k]);
            }
        }
        return $this->$sMethod($aMatches);
    }

    /**
     * データ取得 from $_SERVER
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromServer(array $aMatches)
    {
        $sName               = (string) ArrayUtil::getValue($aMatches, 'name', '');
        // キー名の有効性チェック
        $bRetCode            = isset($this->aNamesFromServer[$sName]);
        if ( $bRetCode !== true ) {
            $bFound          = false;
            foreach ( $this->aNamesFromServerPrefix as $sPrefix => $bRetCode ) {
                $iCmp        = strncmp($sPrefix, $sName, strlen($sPrefix));
                if ( $iCmp === 0 ) {
                    $bFound  = true;
                    break;
                }
            }
            if ( $bFound !== true ) {
                // 無効
                return '-';
            }
        }
        // 有効なら取得
        $sOutput             = $this->_getValueFromGlobals('server', $sName, $aMatches);
        if ( $sName === 'QUERY_STRING' ) {
            $sPrefix         = '?';
        } else {
            $sPrefix         = '';
        }
        // 値の除去が必要か？
        if ( $this->bLogStrippedValue === true ) {
            // キー名によっては値を除去する
            switch ( $sName ) {
                case 'QUERY_STRING':
                case 'REQUEST_URI':
                case 'HTTP_REFERER':
                    $sOutput = Util::stripValueString($sOutput, '&');
                    break;

                case 'REMOTE_USER':
                case 'PHP_AUTH_USER':
                case 'PHP_AUTH_PW':
                    $sOutput = '*';
                    break;

                default:
                    break;
            }
        }
        return $sPrefix . $sOutput;
    }

    /**
     * データ取得 from $_GET
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromGet(array $aMatches)
    {
        $sName = (string) ArrayUtil::getValue($aMatches, 'name', '');
        return $this->_getValueFromGlobals('get', $sName, $aMatches);
    }

    /**
     * データ取得 from $_POST
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromPost(array $aMatches)
    {
        $sName = (string) ArrayUtil::getValue($aMatches, 'name', '');
        return $this->_getValueFromGlobals('post', $sName, $aMatches);
    }

    /**
     * データ取得 from $_REQUEST
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromRequest(array $aMatches)
    {
        $sName = (string) ArrayUtil::getValue($aMatches, 'name', '');
        return $this->_getValueFromGlobals('request', $sName, $aMatches);
    }

    /**
     * データ取得 from $_ENV
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromEnv(array $aMatches)
    {
        // $_ENVは現在非対応
        return '-';
    }

    /**
     * データ取得 from $_FILES
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromFiles(array $aMatches)
    {
        $sName            = (string) ArrayUtil::getValue($aMatches, 'name', '');
        // キー名の有効性チェック
        $aFiles           = Request::getFiles($sName);
        $aEach            = reset($aFiles);
        if ( $aEach['error'] === UPLOAD_ERR_NO_FILE ) {
            // ファイルなし
            return '-';
        }
        $aOutData         = array();
        foreach ( $aFiles as $i => $aEach ) {
            $aInfo        = array();
            foreach ( $aEach as $sKey => $sValue ) {
                if ( $sKey === 'tmp_name' ) {
                    // テンポラリファイルは出力しない
                    continue;
                }
                $aInfo[]  = $sKey . '="' . str_replace('"', '\\"', $sValue) . '"';
            }
            $aOutData[$i] = join('; ', $aInfo);
        }
        if ( $aOutData === array() ) {
            // ファイルなしはないはずだがないなら返す
            return '-';
        }
        $sOption          = (string) ArrayUtil::getValue($aMatches, 'option', '');
        switch ($sOption) {
            case 'f':
                // 先頭の値を取得
                $sOutput  = (string) reset($aOutData);
                break;
            case 'c':
            default:
                // CSVとしてつなげる
                $sOutput  = Util::build_csv((array) $aOutData, ',', '"', "\\");
                break;
        }
        if ( $sOutput === '' ) {
            $sOutput      = '-';
        }
        return $sOutput;
    }

    /**
     * データ取得 from $_COOKIE もしくはSet-Cookie
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromCookie(array $aMatches)
    {
        $sName           = (string) ArrayUtil::getValue($aMatches, 'name', '');
        switch ( $aMatches['when'] ) {
            // タイミング指定があれば保持データから取得
            case 's':
                $sMethod = '_getValueFromData';
                $sFrom   = 'cookie:send';
                break;

            case 'v':
                $sMethod = '_getValueFromData';
                $sFrom   = 'cookie:recv';
                break;

            case 'd':
                $sMethod = '_getValueFromData';
                $sFrom   = 'cookie:display';
                break;

            // リクエストから取得
            case 'r':
            default:
                $sMethod = '_getValueFromGlobals';
                $sFrom   = 'cookie';
                break;
        }
        return $this->$sMethod($sFrom, $sName, $aMatches);
    }

    /**
     * データ取得 from $_SERVER , $_GET , $_POST , $_REQUEST , $_ENV
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @param   string  $sFrom      データネームスペース
     * @param   string  $sName      データ名
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromGlobals($sFrom, $sName, array $aMatches)
    {
        // リクエストからしか取得できない
        $sMethod = 'get' . ucfirst(strtolower($sFrom));
        $mValue  = Request::$sMethod($sName, NULL);
        return $this->_getValueWithOption($mValue, $aMatches);
    }

    /**
     * データ取得 from HTTP通信ヘッダ
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromHeader(array $aMatches)
    {
        $sName = (string) ArrayUtil::getValue($aMatches, 'name', '');
        $sWhen = (string) ArrayUtil::getValue($this->aFromWhens, $aMatches['when'], $this->aFromWhens['r']);
        return $this->_getValueFromData("header:$sWhen", $sName, $aMatches);
    }

    /**
     * データ取得 from SmartConvert特有データ
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromSmartConvert(array $aMatches)
    {
        $sName = (string) ArrayUtil::getValue($aMatches, 'name', '');
        $sWhen = (string) ArrayUtil::getValue($this->aFromWhens, $aMatches['when'], $this->aFromWhens['r']);
        return $this->_getValueFromData("sc:$sWhen", $sName, $aMatches);
    }

    /**
     * データ取得 from $_SERVER , $_GET , $_POST , $_REQUEST , $_ENV
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @param   string  $sFrom      データネームスペース
     * @param   string  $sName      データ名
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueFromData($sFrom, $sName, array $aMatches)
    {
        $aValues            = (array) ArrayUtil::getValue($this->aData, (string) $sFrom, array());
        $mValue             =         ArrayUtil::getValue($aValues,     (string) $sName, NULL);
        // 値の除去が必要か？
        if ( $this->bLogStrippedValue === true ) {
            // キー名によっては値を除去する
            switch ( $sName ) {
                case 'URL':
                case 'URI_QUERY':
                case 'CURL_URL':
                    $mValue = Util::stripValueString($mValue, '&');
                    break;

                case 'REMOTE_USER':
                case 'URI_AUTH_USER':
                case 'URI_AUTH_PASS':
                    $mValue = '*';
                    break;

                default:
                    break;
            }
        }
        return $this->_getValueWithOption($mValue, $aMatches);
    }

    /**
     * データ取得 from $_SERVER , $_GET , $_POST , $_REQUEST , $_ENV
     *
     *  マッチしたキー対応
     *      0:          マッチ文字列
     *      percent:    %
     *      from        取得元
     *      when        取得データの生成タイミング
     *      name        キー名
     *      option      オプション名
     *      format      tオプションの場合の書式
     *
     * @param   mixed   $mValue     データ
     * @return  array   $aMatches   PCREでマッチした配列
     * @return  string  データ
     */
    protected function _getValueWithOption($mValue, array $aMatches)
    {
        if ( $mValue === NULL ) {
            return '-';
        }
        $sOption              = (string) ArrayUtil::getValue($aMatches, 'option', '');
        $sFormat              = (string) ArrayUtil::getValue($aMatches, 'format', '');
        if ( $sOption === '' ) {
            if ( $sFormat !== '' ) {
                $sOption      = 't';
            } else {
                $bRetCode     = is_array($mValue);
                if ( $bRetCode === true ) {
                    $sOption  = 'c';
                }
            }
        }
        switch ($sOption) {
            case 'c':
                // CSVとしてつなげる
                $sOutput     = Util::build_csv((array) $mValue, ',', '"', "\\");
                break;
            case 'f':
                // 先頭の値を取得
                $aValues     = (array) $mValue;
                $sOutput     = (string) reset($aValues);
                break;
            case 't':
                // タイムスタンプと仮定
                $sOutput     = Util::date($sFormat, (int) $mValue);
                break;
            default:
                // その他はそのまま
                $sOutput     = (string) $mValue;
                break;
        }
        if ( $sOutput === '' ) {
            return '-';
        }
        return $sOutput;
    }
}
