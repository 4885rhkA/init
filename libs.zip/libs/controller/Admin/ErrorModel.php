<?php
/**
 * エラーページモデルコントローラ
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\controller\Admin;

/**
 * エラーページモデルコントローラ
 */
class ErrorModel extends StaticModel
{
}
