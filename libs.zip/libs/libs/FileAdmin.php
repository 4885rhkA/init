<?php
/**
 * FileAdmin
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * FileAdmin
 */
class FileAdmin extends File
{
    /**
     * ベース
     *
     * @var string BASE
     */
    const BASE = FW_DIR;
}
