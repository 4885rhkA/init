<?php
/**
 * errorの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php;

/**
 * errorの例外
 *
 * PHPのエラー用の例外に限って以下のメソッドを実装
 *      setMessage
 *      setCode
 *      setFile
 *      setLine
 *
 */
class error extends \SC\exception\php
{
    /**
     * メッセージのセッター
     *
     * @param   string  $sMessage
     * @return  bool    true
     */
    final public function setMessage($sMessage)
    {
        $this->message = (string) $sMessage;
        return true;
    }

    /**
     * コードのセッター
     *
     * @param   int     $iCode
     * @return  bool    true
     */
    final public function setCode($iCode)
    {
        $this->code = (int) $iCode;
        return true;
    }

    /**
     * ファイルのセッター
     *
     * @param   string  $sFile
     * @return  bool    true
     */
    final public function setFile($sFile)
    {
        $this->file = (string) $sFile;
        return true;
    }

    /**
     * 行番号のセッター
     *
     * @param   int     $iLine
     * @return  bool    true
     */
    final public function setLine($iLine)
    {
        $this->line = (int) $iLine;
        return true;
    }
}
