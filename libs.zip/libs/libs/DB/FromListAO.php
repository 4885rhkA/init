<?php
/**
 * FromListAO
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * FromListAO
 */
class FromListAO extends AbstractListAO
{
    /**
     * プロパティ型指定(インクリメント式)
     *
     *  型名： bool, int, float, string, array, クラス名, self, static, mixed
     *
     * @var string $sPropType
     */
    protected $sPropType = 'SC\\libs\\DB\\FromAO';

    /**
     * ArrayObjectクラス名
     *
     * @var string $sArrayClass
     */
    protected $sArrayClass = 'SC\\libs\\DB\\FromAO';
}
