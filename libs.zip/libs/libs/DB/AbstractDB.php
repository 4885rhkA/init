<?php
/**
 * 抽象DB
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs\DB;

/**
 * 抽象DB
 */
abstract class AbstractDB
{
    /**
     * データソースネーム接頭辞
     *
     * @var string DSN_PREFIX
     */
    const DSN_PREFIX = '';

    /**
     * データベース
     *
     * @var string DATABASE
     */
    const DATABASE = '';

    /**
     * データベース名
     *
     * @var string $sDataBase
     */
    protected $sDataBase = self::DATABASE;

    /**
     * データソースネーム
     *
     * @var string $sDSN
     */
    protected $sDSN = '';

    /**
     * データベース接続ユーザ
     *
     * @var string $sUser
     */
    protected $sUser = '';

    /**
     * データベース接続パスワード
     *
     * @var string $sPass
     */
    protected $sPass = '';

    /**
     * データソースネーム
     *
     * @var array $aOptions
     */
    protected $aOptions = array();

    /**
     * DBをopen済みか否か
     *
     * @var bool $bOpened
     */
    protected $bOpened = false;

    /**
     * ATTR_CASE: 強制的にカラム名を指定したケースにする設定
     *
     *  PDO::CASE_LOWER: 強制的にカラム名を小文字にする
     *  PDO::CASE_NATURAL: データベースドライバによって返されるカラム名をそのままにする
     *  PDO::CASE_UPPER: 強制的にカラム名を大文字にする
     *
     * @var int ATTR_CASE
     */
    const ATTR_CASE = \PDO::CASE_LOWER;

    /**
     * ATTR_ERRMODE: エラーレポートの設定
     *
     *  PDO::ERRMODE_SILENT: エラーコードのみ設定する
     *  PDO::ERRMODE_WARNING: E_WARNING を発生させる
     *  PDO::ERRMODE_EXCEPTION: 例外 を投げる
     *
     * @var int ATTR_ERRMODE
     */
    const ATTR_ERRMODE = \PDO::ERRMODE_EXCEPTION;

    /**
     * ATTR_ORACLE_NULLS (Oracle だけでなく、全てのドライバで利用可能) NULLと空文字列の変換の設定
     *
     *  PDO::NULL_NATURAL: 変換しない
     *  PDO::NULL_EMPTY_STRING: 空文字は NULL に変換される
     *  PDO::NULL_TO_STRING: NULL は空文字に変換される
     *
     * @var int ATTR_ORACLE_NULLS
     */
    const ATTR_ORACLE_NULLS = \PDO::NULL_EMPTY_STRING;

    /**
     * ATTR_STRINGIFY_FETCHES フェッチする際、数値を文字列に変換するか否かの設定
     *
     * @var bool ATTR_STRINGIFY_FETCHES
     */
    const ATTR_STRINGIFY_FETCHES = false;

    /**
     * ATTR_TIMEOUT タイムアウト秒数
     *
     * @var int ATTR_TIMEOUT
     */
    const ATTR_TIMEOUT = 10;

    /**
     * ATTR_AUTOCOMMIT それぞれの単一文で自動コミットするか否かの設定
     *
     * @var bool ATTR_AUTOCOMMIT
     */
    const ATTR_AUTOCOMMIT = false;

    /**
     * ATTR_DEFAULT_FETCH_MODE デフォルトのフェッチモードの設定
     *
     *  PDO::FETCH_ASSOC: は、結果セットに 返された際のカラム名で添字を付けた配列を返します。
     *  PDO::FETCH_BOTH (デフォルト): 結果セットに返された際のカラム名と 0 で始まるカラム番号で添字を付けた配列を返します。
     *  PDO::FETCH_BOUND: TRUE を返し、結果セットのカラムの値を PDOStatement::bindColumn() メソッドでバインドされた PHP 変数に代入します。
     *  PDO::FETCH_CLASS: 結果セットのカラムがクラス内の名前付けされたプロパティにマッピングされている、要求されたクラスの新規インスタンスを返します。
     *  PDO::FETCH_INTO: 結果セットのカラムがクラス内の名前付けされたプロパティに マッピングされている要求された既存インスタンスを更新します。
     *  PDO::FETCH_LAZY: PDO::FETCH_BOTH とPDO::FETCH_OBJの 組合せで、オブジェクト変数名を作成します。
     *  PDO::FETCH_NUM: 結果セットに返された際の 0 から始まるカラム番号を添字とする配列を返します。
     *  PDO::FETCH_OBJ: 結果セットに返された際のカラム名と同名のプロパティを有する 匿名のオブジェクトを返します。
     *
     * @var bool ATTR_DEFAULT_FETCH_MODE
     */
    const ATTR_DEFAULT_FETCH_MODE = \PDO::FETCH_ASSOC;

    /**
     * PDO属性の指定
     *
     * @var array $aPDOAttrs
     */
    protected $aPDOAttrs = array();

    /**
     * 取得しない
     *
     * @var int FETCH_NONE
     */
    const FETCH_NONE = 0;

    /**
     * 全行取得
     *
     * @var int FETCH_ALL
     */
    const FETCH_ALL = 1;

    /**
     * 1行だけ取得
     *
     * @var int FETCH_ONE
     */
    const FETCH_ONE = 2;

    /**
     * トランザクション開始SQL
     *
     * @var string SQL_BEGIN
     */
    const SQL_BEGIN = 'BEGIN IMMEDIATE TRANSACTION';

    /**
     * トランザクション完了SQL
     *
     * @var string SQL_COMMIT
     */
    const SQL_COMMIT = 'COMMIT TRANSACTION';

    /**
     * トランザクションロールバックSQL
     *
     * @var string SQL_ROLLBACK
     */
    const SQL_ROLLBACK = 'ROLLBACK TRANSACTION';

    /**
     * datetime型を時刻文字列に変換する際のフォーマット
     *
     * @var string
     */
    const DATETIME_TO_STRING = '%Y/%m/%d %H:%M:%S';

    /**
     * インスタンス配列
     *
     * @var array(SC\libs\DB\AbstractDB) $aInstances
     */
    protected static $aInstances = array();

    /**
     * PDO
     *
     * @var PDO $oPDO
     */
    protected $oPDO = NULL;

    /**
     * PDOステートメント
     *
     * @var array $aPDOStatement
     */
    protected $aPDOStatement = array();

    /**
     * トランザクション中か否か
     *
     * @var bool $bInTransaction
     */
    protected $bInTransaction = false;

    /**
     * 抽出結果レコードリストAO
     *
     * @var SC\libs\DB\RecordListAO $aRecordList
     */
    protected $aRecordList = NULL;

    /**
     * 影響行数
     *
     * @var int $iAffectedRows
     */
    protected $iAffectedRows = 0;

    /**
     * エラーが発生したか否か
     *
     * @var bool $bHasError
     */
    protected $bHasError = false;

    /**
     * エラーコード
     *
     * @var mixed $mErrorCode
     */
    protected $mErrorCode = '';

    /**
     * エラー情報
     *
     * @var array $aErrorInfo
     */
    protected $aErrorInfo = array();

    /**
     * 最終実行時クエリストリング
     *
     * @var string $sLastQueryString
     */
    protected $sLastQueryString = '';

    /**
     * 最終実行時バインドパラメータ
     *
     * @var array $aLastBindParams
     */
    protected $aLastBindParams = array();

    /**
     * 型リスト
     *
     * @var array $aTypeList
     */
    protected $aTypeList = array(
        's'         => 'string',
        'str'       => 'string',
        'string'    => 'string',
        'c'         => 'string',
        'char'      => 'string',
        'text'      => 'string',
        'varchar'   => 'string',
        'varchar2'  => 'string',
        'clob'      => 'string',
        'b'         => 'bool',
        'bool'      => 'bool',
        'boolean'   => 'bool',
        'i'         => 'int',
        'int'       => 'int',
        'integer'   => 'int',
        'long'      => 'int',
        'short'     => 'int',
        'tinyint'   => 'int',
        'smallint'  => 'int',
        'bigint'    => 'int',
        'hex'       => 'hex',
        'f'         => 'float',
        'float'     => 'float',
        'double'    => 'float',
        'number'    => 'float',
        'numeric'   => 'float',
        'real'      => 'float',
        'decimal'   => 'float',
        'd'         => 'datetime',
        'date'      => 'datetime',
        'time'      => 'datetime',
        'datetime'  => 'datetime',
        'timestamp' => 'datetime',
    );

    /**
     * 型変換メソッドリスト
     *
     * @var array $aConvFuncs
     */
    protected $aConvFuncs = array(
        'string'    => '_parseString',
        'bool'      => '_parseBool',
        'int'       => '_parseInt',
        'hex'       => '_parseHex',
        'float'     => '_parseFloat',
        'datetime'  => '_parseDateTime',
    );

    /**
     * 結合リスト
     *
     * @var array $aJoinList
     */
    protected $aJoinList = array(
        'INNER JOIN'       => 'INNER JOIN',
        'JOIN'             => 'INNER JOIN',
        'LEFT JOIN'        => 'LEFT OUTER JOIN',
        'LEFT OUTER JOIN'  => 'LEFT OUTER JOIN',
        'OUTER JOIN'       => 'LEFT OUTER JOIN',
        'RIGHT JOIN'       => 'RIGHT OUTER JOIN',
        'RIGHT OUTER JOIN' => 'RIGHT OUTER JOIN',
        'CROSS JOIN'       => 'CROSS JOIN',
        'FULL OUTER JOIN'  => 'FULL OUTER JOIN',
    );

    /**
     * PDO::PARAM_*の配列
     *
     * @var array $aPDOParams
     */
    protected $aPDOParams = array(
        \PDO::PARAM_BOOL         => 'PDO::PARAM_BOOL',
        \PDO::PARAM_NULL         => 'PDO::PARAM_NULL',
        \PDO::PARAM_INT          => 'PDO::PARAM_INT',
        \PDO::PARAM_STR          => 'PDO::PARAM_STR',
        \PDO::PARAM_LOB          => 'PDO::PARAM_LOB',
        \PDO::PARAM_STMT         => 'PDO::PARAM_STMT',
        \PDO::PARAM_INPUT_OUTPUT => 'PDO::PARAM_INPUT_OUTPUT',
    );

    /**
     * PDO::PARAM_*用の型リスト
     *
     * @var array $aPDOParamTypeList
     */
    protected $aPDOParamTypeList = array(
        'bool'     => \PDO::PARAM_BOOL,
        'int'      => \PDO::PARAM_INT,
        'string'   => \PDO::PARAM_STR,
    );

    /**
     * SQLログを出力するか否か
     *
     * @var bool $bSqlLog
     */
    protected $bSqlLog = false;

    /**
     * アクセスキー
     *
     * @var string $sAccessKey
     */
    protected $sAccessKey = '';

    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
        // アクセスキー
        $this->sAccessKey = \Log::getAccessKey();
        // SQLのログを取得するか否か
        $this->bSqlLog    = (bool) \Request::getServer('SC_LOG_SQL', false);
        // DBを保持
        $this->sDataBase  = static::DATABASE;
    }

    /**
     * デストラクタ
     */
    final public function __destruct()
    {
        // VACUUM
        $this->_doVacuum();
    }

    /**
     * インスタンスの取得
     *
     * @param   bool    $bWillOpen      DBを開くか否か
     * @return  SC\libs\DB\AbstractDB
     */
    final protected static function _getInstance($bWillOpen = true)
    {
        // クラス名の取得
        $sClassName = get_called_class();
        // インスタンスの存在チェック
        $bRetCode   = isset(self::$aInstances[$sClassName]);
        if ( $bRetCode !== true ) {
            // 存在しなければ生成する
            $oSelf  = new static();
            if ( $bWillOpen !== false ) {
                // PDOを生成
                $oSelf->_open();
            }
            self::$aInstances[$sClassName] = $oSelf;
        } else {
            $oSelf = self::$aInstances[$sClassName];
        }
        // DBを開く指定でかつ開かれていないなら開く
        if ( $bWillOpen !== false && $oSelf->bOpened !== true ) {
            $oSelf->_open();
        }
        return $oSelf;
    }

    /**
     * データベース接続情報の収集
     *
     * @return  bool    true
     * @throw   SC\exception\libs\DB\AbstractDB\EmptyDataBase
     */
    protected function _collect()
    {
        if ( $this->sDSN === '' ) {
            if ( $this->sDataBase === '' ) {
                throw new \SC\exception\libs\DB\AbstractDB\EmptyDataBase("DataBase must not be empty.");
            }
            // データソースネームの指定がなければセットする
            $this->sDSN  = static::DSN_PREFIX . ':' . $this->sDataBase;
        }
        // 属性指定
        $this->aPDOAttrs = array(
            \PDO::ATTR_CASE              => static::ATTR_CASE,
            \PDO::ATTR_ERRMODE           => static::ATTR_ERRMODE,
            \PDO::ATTR_ORACLE_NULLS      => static::ATTR_ORACLE_NULLS,
            \PDO::ATTR_STRINGIFY_FETCHES => static::ATTR_STRINGIFY_FETCHES,
            \PDO::ATTR_TIMEOUT           => static::ATTR_TIMEOUT,
        );
        return true;
    }

    /**
     * データベースの開始
     *
     * @return  bool    true
     */
    protected function _open()
    {
        // PDOを生成
        try {
            // 接続情報の収集
            $this->_collect();
            // PDO生成
            $this->oPDO           = new \PDO($this->sDSN, $this->sUser, $this->sPass, $this->aOptions);
            // 必ずセットする
            foreach ( $this->aPDOAttrs as $iAttr => $mValue ) {
                $this->oPDO->setAttribute($iAttr, $mValue);
            }
            $this->bInTransaction = false;
            $this->bOpened        = true;
        } catch (\PDOException $oPrevious) {
            // DB接続が失敗したはず
            $this->bHasError      = true;
            \Log::dump($this->aOptions, "Connection failure: DSN = '{$this->sDSN}', USER = '{$this->sUser}', PASS = '{$this->sPass}', OPTIONS =", \Log::LEVEL_ERROR);
            throw new \SC\exception\libs\DB\AbstractDB\ConnectionFailure("Connection failure: message={$oPrevious->getMessage()}", $oPrevious->getCode(), $oPrevious);
        }
        return true;
    }

    /**
     * データベースをセットする
     *
     * @param   string  $sDataBase  データベース
     * @return  bool    true
     */
    public static function setDataBase($sDataBase)
    {
        // DBのセットのみならばopenしない
        $oSelf = static::_getInstance(false);
        return $oSelf->_setDataBase($sDataBase);
    }

    /**
     * DB接続ユーザをセットする
     *
     * @param   string  $sDataBase  データベース
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _setDataBase($sDataBase)
    {
        // 文字列か？
        $bRetCode        = \SC\libs\Validate::isStringNotZero($sDataBase);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('DataBase must be a non-zero byte string.');
        }
        $this->sDataBase = (string) $sDataBase;
        return true;
    }

    /**
     * DSNをセットする
     *
     * @param   string  $sDSN       DSN
     * @return  bool    true
     */
    public static function setDSN($sDSN)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setDSN($sDSN);
    }

    /**
     * DSNをセットする
     *
     * @param   string  $sDSN       DSN
     * @return  bool    true
     * @throw   SC\exception\common\parameter\ZeroByteString
     * @throw   SC\exception\libs\DB\AbstractDB\MismatchPrefix
     */
    protected function _setDSN($sDSN)
    {
        // 文字列か？
        $bRetCode   = \SC\libs\Validate::isStringNotZero($sDSN);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\ZeroByteString('Data source name must be a non-zero byte string.');
        }
        // 接頭辞チェック
        if ( static::DSN_PREFIX !== '') {
            $iPos   = strpos($sDSN, static::DSN_PREFIX);
            if ( $iPos !== 0 ) {
                throw new \SC\exception\libs\DB\AbstractDB\MismatchPrefix("Data source name must begin with prefix as '" . static::DSN_PREFIX . "'.");
            }
        }
        $this->sDSN = (string) $sDSN;
        return true;
    }

    /**
     * DB接続ユーザをセットする
     *
     * @param   string  $sUser      ユーザ名
     * @return  bool    true
     */
    public static function setUser($sUser)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setUser($sUser);
    }

    /**
     * DB接続ユーザをセットする
     *
     * @param   string  $sUser      ユーザ名
     * @return  bool    true
     * @throw   SC\exception\common\parameter\NotAString
     */
    protected function _setUser($sUser)
    {
        // 文字列か？
        $bRetCode    = \SC\libs\Validate::isString($sUser);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('User must be a string.');
        }
        $this->sUser = (string) $sUser;
        return true;
    }

    /**
     * DB接続パスワードをセットする
     *
     * @param   string  $sPass      パスワード
     * @return  bool    true
     */
    public static function setPass($sPass)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setPass($sPass);
    }

    /**
     * DB接続パスワードをセットする
     *
     * @param   string  $sPass      パスワード
     * @return  bool    true
     * @throw   SC\exception\common\parameter\NotAString
     */
    protected function _setPass($sPass)
    {
        // 文字列か？
        $bRetCode    = \SC\libs\Validate::isString($sPass);
        if ( $bRetCode !== true ) {
            throw new \SC\exception\common\parameter\NotAString('Pass must be a string.');
        }
        $this->sPass = (string) $sPass;
        return true;
    }

    /**
     * DB接続オプションをセットする
     *
     * @param   array   $aOptions   オプション
     * @return  bool    true
     */
    public static function setOptions(array $aOptions)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_setOptions($aOptions);
    }

    /**
     * DB接続オプションをセットする
     *
     * @param   array   $aOptions   オプション
     * @return  bool    true
     */
    protected function _setOptions(array $aOptions)
    {
        $this->aOptions = $aOptions;
        return true;
    }

    /**
     * SELECT実行
     *
     * @param   mixed   $mInfo      SELECT条件
     * @param   array   $aBinds     バインド変数値
     * @return  array   抽出レコード配列
     */
    public static function select($mInfo, array $aBinds = array())
    {
        $oSelf = static::_getInstance();
        return $oSelf->_select($mInfo, $aBinds);
    }

    /**
     * SELECT実行
     *
     * @param   mixed   $mInfo      SELECT条件
     * @param   array   $aBinds     バインド変数値
     * @return  array   抽出レコード配列
     * @throw   SC\exception\libs\DB\AbstractDB\NotASelectAONorSQL
     */
    protected function _select($mInfo, array $aBinds = array())
    {
        // ---------------------------------------------------------
        // SQLを生成
        $sSql                         = '';
        $bRetCode                     = is_array($mInfo);
        if ( $bRetCode !== true ) {
            // 配列ではない
            $bRetCode                 = \SC\libs\Validate::isString($mInfo);
            if ( $bRetCode === true ) {
                // 文字列 → SQL
                $sSql                 = trim($mInfo);
                if ( $sSql === '' ) {
                    // SQLでもない
                    throw new \SC\exception\libs\DB\AbstractDB\NotASelectAONorSQL('Not a SelectAO nor SQL.');
                }
                // SQL
                $aBinds               = $aBinds;
                $bForUpdate           = (bool) preg_match('#\sFOR\s*UPDATE$#uSsi', $sSql);
                $aConvFuncs           = array();
                $sRecordKey           = '';
                $bOneRecord           = false;
            } else {
                // SelectAOか？
                $bRetCode             = \Util::is_a($mInfo, __NAMESPACE__ . '\SelectAO');
                if ( $bRetCode !== true ) {
                    // SelectAOでもない
                    throw new \SC\exception\libs\DB\AbstractDB\NotASelectAONorSQL('Not a SelectAO nor SQL.');
                }
                // SELECT文をビルド
                $aBuilt               = $this->_buildSelectSql($mInfo, $aBinds);
                $sSql                 = $aBuilt['sql'];
                $aBinds               = $aBuilt['binds'];
                $bForUpdate           = $aBuilt['update'];
                $aConvFuncs           = $aBuilt['convs'];
                $sRecordKey           = $aBuilt['recordkey'];
                $bOneRecord           = $aBuilt['onerecord'];
            }
        } else {
            // SELECT文をビルド
            $aBuilt                   = $this->_buildSelectSql(new SelectAO($mInfo), $aBinds);
            $sSql                     = $aBuilt['sql'];
            $aBinds                   = $aBuilt['binds'];
            $bForUpdate               = $aBuilt['update'];
            $aConvFuncs               = $aBuilt['convs'];
            $sRecordKey               = $aBuilt['recordkey'];
            $bOneRecord               = $aBuilt['onerecord'];
        }
        // ---------------------------------------------------------
        // SQLの実行 ※失敗時には例外が投げられる
        if ( $bForUpdate === true ) {
            $this->_beginTransaction();
        }
        if ( $bOneRecord === true ) {
            $iFetch                   = static::FETCH_ONE;
        } else {
            $iFetch                   = static::FETCH_ALL;
        }
        $this->_execute($sSql, $aBinds, $iFetch);
        // ---------------------------------------------------------
        // 抽出結果配列のリフォーム ※失敗時には例外が投げられる
        $this->_fixRecordListType($aConvFuncs, $sRecordKey);
        // ---------------------------------------------------------
        if ( $bOneRecord === true ) {
            if ( $this->iAffectedRows <= 0 ) {
                $this->aRecordList[0] = new RecordAO(array());
            }
            $aResult                  = $this->aRecordList[0];
        } else {
            $aResult                  = $this->aRecordList;
        }
        return $aResult;
    }

    /**
     * SELECT文の生成
     *
     * @param   mixed   $mInfo      SELECT条件
     * @return  string              SQL文
     */
    public static function buildSelectSql($mInfo)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_buildSelectSqlDirect($mInfo);
    }

    /**
     * SELECT文の生成
     *
     * @param   mixed   $mInfo      SELECT条件(配列もしくはSelectAO)
     * @return  string              SQL文
     * @throw   SC\exception\libs\DB\AbstractDB\NotASelectAO
     */
    protected function _buildSelectSqlDirect($mInfo)
    {
        // オブジェクトか？
        $bRetCode            = is_object($mInfo);
        if ( $bRetCode === true ) {
            // SelectAOか？
            $bRetCode        = \Util::is_a($mInfo, __NAMESPACE__ . '\SelectAO');
            if ( $bRetCode !== true ) {
                // SelectAOではない
                throw new \SC\exception\libs\DB\AbstractDB\NotASelectAO('Not a SelectAO.');
            }
            $aSelectAO       = $mInfo;
        } else {
            // 配列か？
            $bRetCode        = is_array($mInfo);
            if ( $bRetCode !== true ) {
                // SelectAOではない
                throw new \SC\exception\libs\DB\AbstractDB\NotASelectAO('Not a SelectAO.');
            }
            $aSelectAO       = new SelectAO($mInfo);
        }
        // SELECT文をビルド
        $aBuilt      = $this->_buildSelectSql($aSelectAO, array());
        return $aBuilt['sql'];
    }

    /**
     * SELECT文の生成
     *
     * @param   SC\libs\DB\SelectAO     $aInfo      SELECT条件
     * @param   array                   $aBinds     バインド変数値
     * @return  string                  SELECT情報配列
     * @throw   \SC\exception\libs\DB\AbstractDB\EmptyFieldList
     * @throw   \SC\exception\libs\DB\AbstractDB\EmptyFromList
     */
    protected function _buildSelectSql(SelectAO $aInfo, array $aBinds)
    {
        // ---------------------------------------------------------
        // 必須項目チェック
        if ( $aInfo['fields'] === NULL ) {
            throw new \SC\exception\libs\DB\AbstractDB\EmptyFieldList('Field list must not be empty.');
        }
        if ( $aInfo['froms'] === NULL && $aInfo['from'] === NULL ) {
            throw new \SC\exception\libs\DB\AbstractDB\EmptyFromList('From list must not be empty.');
        }

        // SQLの構成
        $aConv                     = array();
        $sRecordKey                = '';
        // ---------------------------------------------------------
        // SELECT句の生成
        $aSelect                   = array();
        foreach ( $aInfo['fields'] as $sAlias => $aFieldAO ) {
            // フィールドを生成
            $aFieldInfo            = $this->_buildSelectField($sAlias, $aFieldAO);
            $aSelect[]             = $aFieldInfo['name'];
            $aConv[$sAlias]        = $aFieldInfo['conv'];
            if ( $aFieldAO['key'] === true ) {
                $sRecordKey        = $sAlias;
            }
        }
        // ---------------------------------------------------------
        // FROM句の生成
        $aFroms                    = array();
        if ( $aInfo['froms'] !== NULL ) {
            // 複数FROM
            $bFirst                = true;
            foreach ( $aInfo['froms'] as $sAlias => $aFromAO ) {
                // 抽出元を生成
                $aFroms[]          = $this->_buildFrom($sAlias, $aFromAO, $bFirst);
                $bFirst            = false;
            }
        } else {
            // 単数FROM
            $aFroms[]              = trim($aInfo['from']);
        }
        // ---------------------------------------------------------
        // 追加条件句の指定
        $sConditions               = '';
        if ( $aInfo['conditions'] !== NULL ) {
            $aConditions           = array();
            $aCondKeys             = array(
                'where'   => 'WHERE',
                'groupby' => 'GROUP BY',
                'having'  => 'HAVING',
                'orderby' => 'ORDER BY',
            );
            foreach ( $aCondKeys as $sKey => $sPrefix ) {
                if ( $aInfo['conditions'][$sKey] !== NULL ) {
                    $aConditions[] = $sPrefix . ' ' . trim($aInfo['conditions'][$sKey]);
                }
            }
            $iLimit                = (int) $aInfo['conditions']['limit'];
            if ( $iLimit > 0 ) {
                $aConditions[]     = 'LIMIT ' . $iLimit;
                $iOffset           = (int) $aInfo['conditions']['offset'];
                if ( $iOffset > 0 ) {
                    $aConditions[] = 'OFFSET ' . $iOffset;
                }
            }
            $iCount                = count($aConditions);
            if ( $iCount > 0 ) {
                $sConditions       = ' ' . join(' ', $aConditions);
            }
        }
        // ---------------------------------------------------------
        // トランザクションを開始
        if ( $aInfo['update'] === true &&false) { // @todo
            $sForUpdate            = ' FOR UPDATE'; // @todo SQLiteでは"FOR UPDATE"は効かない→BEGIN IMMEDIATE
            $bForUpdate            = true;
        } else {
            $sForUpdate            = '';
            $bForUpdate            = false;
        }
        // ---------------------------------------------------------
        // SQLの構成
        $sSql                      = rtrim('SELECT ' . join(',', $aSelect) . ' FROM ' . join(' ', $aFroms) . $sConditions . $sForUpdate);
        // bindパラメータの指定
        if ( $aInfo['binds'] !== NULL ) {
            foreach ( $aInfo['binds'] as $sName => $mValue ) {
                $aBinds[$sName]    = $mValue;
            }
        }
        // 情報を構成
        $aResult                   = array(
            'sql'       => $sSql,
            'binds'     => $aBinds,
            'update'    => $bForUpdate,
            'convs'     => $aConv,
            'recordkey' => $sRecordKey,
            'onerecord' => (bool) $aInfo['onerecord'],
        );
        return $aResult;
    }

    /**
     * フィールド情報の構成
     *
     * @param   string              $sAlias     別名
     * @param   SC\libs\DB\FieldAO  $aFieldAO   フィールド情報
     * @return  array               フィールド情報
     */
    protected function _buildSelectField($sAlias, FieldAO $aFieldAO)
    {
        // 抽出元指定
        if ( $aFieldAO['name'] !== NULL ) {
            $sField      = $aFieldAO['name'];
        } else {
            $sField      = $sAlias;
        }
        // 型指定 → 変換関数指定
        if ( $aFieldAO['type'] === NULL ) {
            $sType       = 'string';
        } else {
            $sType       = \ArrayUtil::getValue($this->aTypeList, strtolower(trim($aFieldAO['type'])), 'string');
            if ( $sType === 'datetime' ) {
                $sField  = $this->formatDateTimeToString($sField);
            }
        }
        // 別名指定
        if ( $sField === $sAlias ) {
            $sSelect     = $sAlias;
        } else {
            $sSelect     = trim($sField) . ' AS ' . trim($sAlias);
        }
        // フィールド情報を構成
        $aFieldInfo      = array(
            'name' => $sSelect,
            'conv' => $this->aConvFuncs[$sType],
        );
        return $aFieldInfo;
    }

    /**
     * 抽出元情報の構成
     *
     * @param   string              $sAlias     別名
     * @param   SC\libs\DB\FromAO   $aFromAO    抽出元情報
     * @param   bool                $bFirst     初回かどうか
     * @return  string              抽出元情報
     * @throw   \SC\exception\libs\DB\AbstractDB\EmptySelectSource
     * @throw   \SC\exception\libs\DB\AbstractDB\EmptyJoinCondition
     */
    protected function _buildFrom($sAlias, FromAO $aFromAO, $bFirst)
    {
        // 抽出元の指定チェック
        if ( $aFromAO['name'] === NULL ) {
            // 抽出元の指定がない
            throw new \SC\exception\libs\DB\AbstractDB\EmptySelectSourceName('Select source name must not be empty.');
        }
        // 抽出元の保持
        $sFrom          = trim($aFromAO['name']) . ' ' . trim($sAlias);
        if ( $bFirst === true ) {
            // 最初の抽出元は結合しない → 終わり
            return $sFrom;
        }
        // 2つ目以降は結合条件を指定
        $aJoin          = array();
        if ( $aFromAO['type'] === NULL ) {
            // 結合タイプ指定なし
            $sJoinType  = 'LEFT OUTER JOIN';
        } else {
            $sJoinType  = \ArrayUtil::getValue($this->aJoinList, preg_replace('#\s+#', ' ', strtoupper(trim($aFromAO['type']))), 'LEFT OUTER JOIN');
        }
        // 結合タイプ指定あり → チェック
        $aJoin[]        = $sJoinType;
        // 結合条件あり
        $aJoin[]        = $sFrom;
        if ( $sJoinType !== 'CROSS JOIN') {
            // 結合条件の指定があるか？
            if ( $aFromAO['condition'] === NULL ) {
                // 結合条件指定なし → 異常
                throw new \SC\exception\libs\DB\AbstractDB\EmptyJoinCondition("Empty join condition for $sJoinType.");
            }
            // 結合条件は文字列である
            $aJoin[]    = trim($aFromAO['condition']);
        }
        // 抽出元を生成
        $sFrom          = join(' ', $aJoin);
        return $sFrom;
    }

    /**
     * INSERT実行
     *
     * @param   mixed   $mInfo      INSERT条件
     * @param   array   $aBinds     バインド変数値
     * @return  int     挿入レコードID(主キー)
     */
    public static function insert($mInfo, array $aBinds = array())
    {
        $oSelf = static::_getInstance();
        return $oSelf->_insert($mInfo);
    }

    /**
     * INSERT実行
     *
     * @param   mixed   $mInfo      INSERT条件
     * @param   array   $aBinds     バインド変数値
     * @return  int     挿入レコードID(主キー)
     * @throw   SC\exception\libs\DB\AbstractDB\NotAInsertAONorSQL
     */
    protected function _insert($mInfo, array $aBinds = array())
    {
        // ---------------------------------------------------------
        // SQLを生成
        $sSql             = '';
        $bRetCode         = is_array($mInfo);
        if ( $bRetCode !== true ) {
            // 配列ではない
            $bRetCode     = \SC\libs\Validate::isString($mInfo);
            if ( $bRetCode === true ) {
                // 文字列 → SQL
                $sSql     = trim($mInfo);
                if ( $sSql === '' ) {
                    // SQLでもない
                    throw new \SC\exception\libs\DB\AbstractDB\NotAInsertAONorSQL('Not a InsertAO nor SQL.');
                }
                // SQL
                $aBinds   = $aBinds;
                $sSeqName = NULL;
            } else {
                // InsertAOか？
                $bRetCode = \Util::is_a($mInfo, __NAMESPACE__ . '\InsertAO');
                if ( $bRetCode !== true ) {
                    // SelectAOでもない
                    throw new \SC\exception\libs\DB\AbstractDB\NotAInsertAONorSQL('Not a InsertAO nor SQL.');
                }
                // INSERT文をビルド
                $aBuilt   = $this->_buildInsertSql($mInfo, $aBinds);
                $sSql     = $aBuilt['sql'];
                $aBinds   = $aBuilt['binds'];
                $sSeqName = $aBuilt['seqname'];
            }
        } else {
            // INSERT文をビルド
            $aBuilt       = $this->_buildInsertSql(new InsertAO($mInfo), $aBinds);
            $sSql         = $aBuilt['sql'];
            $aBinds       = $aBuilt['binds'];
            $sSeqName     = $aBuilt['seqname'];
        }
        // ---------------------------------------------------------
        // SQLの実行 ※失敗時には例外が投げられる
        if ( $this->bInTransaction === true ) {
            $this->_beginTransaction();
        }
        $this->_execute($sSql, $aBinds, static::FETCH_NONE);
        // ---------------------------------------------------------
        // 取得できたなら挿入レコードID(主キー)を取得して返す
        $iLastId          = $this->oPDO->lastInsertId($sSeqName);
        // ---------------------------------------------------------
        return $iLastId;
    }

    /**
     * INSERT文の生成
     *
     * @param   mixed   $mInfo      INSERT条件
     * @return  string              SQL文
     */
    public static function buildInsertSql($mInfo)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_buildInsertSqlDirect($mInfo);
    }

    /**
     * INSERT文の生成
     *
     * @param   mixed   $mInfo      INSERT条件
     * @return  string              SQL文
     * @throw   SC\exception\libs\DB\AbstractDB\NotAInsertAO
     */
    protected function _buildInsertSqlDirect($mInfo)
    {
        // オブジェクトか？
        $bRetCode            = is_object($mInfo);
        if ( $bRetCode === true ) {
            // InsertAOか？
            $bRetCode        = \Util::is_a($mInfo, __NAMESPACE__ . '\InsertAO');
            if ( $bRetCode !== true ) {
                // InsertAOではない
                throw new \SC\exception\libs\DB\AbstractDB\NotAInsertAO('Not a InsertAO.');
            }
            $aInsertAO       = $mInfo;
        } else {
            // 配列か？
            $bRetCode        = is_array($mInfo);
            if ( $bRetCode !== true ) {
                // InsertAOではない
                throw new \SC\exception\libs\DB\AbstractDB\NotAInsertAO('Not a InsertAO.');
            }
            $aInsertAO       = new InsertAO($mInfo);
        }
        // INSERT文をビルド
        $aBuilt      = $this->_buildInsertSql($aInsertAO, array());
        return $aBuilt['sql'];
    }

    /**
     * INSERT文の生成
     *
     * @param   SC\libs\DB\InsertAO     $aInfo      INSERT条件
     * @param   array                   $aBinds     バインド変数値
     * @return  string                  INSERT情報配列
     * @throw   \SC\exception\libs\DB\AbstractDB\EmptyTable
     * @throw   \SC\exception\libs\DB\AbstractDB\EmptyFieldList
     */
    protected function _buildInsertSql(InsertAO $aInfo, array $aBinds)
    {
        // ---------------------------------------------------------
        // 必須項目チェック
        if ( $aInfo['table'] === NULL ) {
            throw new \SC\exception\libs\DB\AbstractDB\EmptyTable('Table must not be empty.');
        }
        if ( $aInfo['fields'] === NULL ) {
            throw new \SC\exception\libs\DB\AbstractDB\EmptyFieldList('Field list must not be empty.');
        }
        // ---------------------------------------------------------
        // Field情報の生成
        $aNames                    = array();
        $aValues                   = array();
        $aParams                   = array();
        foreach ( $aInfo['fields'] as $sAlias => $aFieldAO ) {
            // フィールド名をストア
            $sName                 = $aFieldAO['name'];
            $aNames[]              = $sName;
            if ( $aFieldAO['expr'] === true ) {
                if ( $aFieldAO['value'] !== NULL ) {
                    $sType         = \ArrayUtil::getValue($this->aTypeList,         strtolower(trim($aFieldAO['type'])), 'string');
                    $iPDOParam     = \ArrayUtil::getValue($this->aPDOParamTypeList, $sType,                              $this->aPDOParamTypeList['string']);
                    $aValues[]     = $this->oPDO->quote($aFieldAO['value'], $iPDOParam);
                } else {
                    $aValues[]     = 'NULL';
                }
            } else {
                $sName             = ':' . $sName;
                $aParams[$sName]   = $aFieldAO['value'];
                $aValues[]         = $sName;
            }
        }
        // ---------------------------------------------------------
        // SQLの構成
        $sSql                      = 'INSERT INTO ' . $aInfo['table'] . ' (' . join(',', $aNames) . ') VALUES (' . join(',', $aValues) . ')';
        // bindパラメータの指定
        if ( $aInfo['binds'] !== NULL ) {
            foreach ( $aInfo['binds'] as $sName => $mValue ) {
                $aBinds[$sName]    = $mValue;
            }
        }
        $aParams                   = \ArrayUtil::unite($aBinds, $aParams, true);
        $sSeqName                  = trim($aInfo['seqname']);
        if ( $sSeqName === '' ) {
            $sSeqName              = NULL;
        }
        // 情報を構成
        $aResult                   = array(
            'sql'       => $sSql,
            'binds'     => $aParams,
            'seqname'   => $sSeqName,
        );
        return $aResult;
    }

    /**
     * UPDATE実行
     *
     * @param   SC\libs\DB\UpdateVO $oInfo      条件情報
     * @return  bool                true/false
     */
    public static function update(UpdateVO $oInfo)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_update($oInfo);
    }

    /**
     * UPDATE実行
     *
     * @param   SC\libs\DB\UpdateVO $oInfo      条件情報
     * @return  bool                true/false
     */
    protected function _update(UpdateVO $oInfo)
    {
// @todo
        throw new \Exception('not implemented');
        return true;
    }

    /**
     * DELETE実行
     *
     * @param   SC\libs\DB\DeleteVO $oInfo      条件情報
     * @return  bool                true/false
     */
    public static function delete(DeleteVO $oInfo)
    {
        $oSelf = static::_getInstance();
        return $oSelf->_delete($oInfo);
    }

    /**
     * DELETE実行
     *
     * @param   SC\libs\DB\DeleteVO $oInfo      条件情報
     * @return  bool                true/false
     */
    protected function _delete(DeleteVO $oInfo)
    {
// @todo
        throw new \Exception('not implemented');
        return array();
    }

    /**
     * SQL文の実行
     *
     *  $iFetchの指定によって実行結果の型が違う
     *      static::FETCH_NONE      bool                        実行成否
     *      static::FETCH_ALL       SC\libs\DB\RecordListAO     レコード配列
     *      static::FETCH_ONE       SC\libs\DB\RecordAO         レコード
     *
     * @param   string  $sSql       SQL
     * @param   array   $aBinds     バインドパラメータ
     * @param   int     $iFetch     行取得指定
     * @return  bool    true
     * @throw   \SC\exception\libs\DB\AbstractDB\BindFailure
     * @throw   \SC\exception\libs\DB\AbstractDB\ExecStatementFailure
     */
    protected function _execute($sSql, array $aBinds, $iFetch = self::FETCH_NONE)
    {
        try {
            $aChecked = $this->_checkBinds($sSql, $aBinds);
            $sSql     = $aChecked['sql'];
            $aBinds   = $aChecked['binds'];
            // SQLログを生成
            $this->_log($sSql);
            // SQL実行準備
            $sHash                               = $this->_hash($sSql);
            $oStatement                          = $this->_getStatement($sSql);
            // パラメータのバインド
            foreach ( $aBinds as $sName => $mValue ) {
                // DateTimeオブジェクトであれば定型フォーマット化する
                if ( ( $mValue instanceof \DateTime ) === true ) {
                    $mParam                      = $mValue->format('Y-m-d H:i:s.u');
                } else {
                    $mParam                      = $mValue;
                }
                $iParamType                      = $this->_getPDOParamType($mParam);
                // ログ出力
                if ( $this->bSqlLog === true ) {
                    \Log::trace("SQL dump [$sHash]: [$sName] => [" . trim(\Debug::dump($mParam, '', false)) . "] (Type: $iParamType={$this->aPDOParams[$iParamType]})");
                }
                $bRetCode                        = $oStatement->bindValue($sName, $mParam, $iParamType);
                if ( $bRetCode !== true ) {
                    // バインドに失敗
                    $this->bHasError             = true;
                    $this->mErrorCode            = $oStatement->errorCode();
                    $this->aErrorInfo            = $oStatement->errorInfo();
                    throw new \SC\exception\libs\DB\AbstractDB\BindFailure("Bind failure: [$sName] => [" . trim(\Debug::dump($mParam, '', false)) . "] ($iParamType={$this->aPDOParams[$iParamType]})");
                }
            }
            // SQLの実行
            $bRetCode                            = $oStatement->execute();
            if ( $bRetCode !== true ) {
                // SQLの実行エラー → 例外だろ？
                $this->bHasError                 = true;
                $this->mErrorCode                = $oStatement->errorCode();
                $this->aErrorInfo                = $oStatement->errorInfo();
                throw new \SC\exception\libs\DB\AbstractDB\ExecutionFailure('Execute statement failure: code=[{$this->mErrorCode}] ({$this->aErrorInfo[0]}: {$this->aErrorInfo[1]}: {$this->aErrorInfo[2]})');
            }
            // 結果の取得の指定がある場合には取得
            switch ( $iFetch ) {
                case static::FETCH_ALL:
                    // 指定があれば取得
                    $aRecordList                 = $oStatement->fetchAll(\PDO::FETCH_ASSOC);
                    // SQLの実行による影響行数
                    $this->iAffectedRows         = count($aRecordList);
                    break;

                case static::FETCH_ONE:
                    // 指定があれば取得
                    $aRecord                     = $oStatement->fetch(\PDO::FETCH_ASSOC);
                    if ( $aRecord !== false ) {
                        $aRecordList             = array($aRecord);
                    } else {
                        $aRecordList             = array();
                    }
                    // SQLの実行による影響行数
                    $this->iAffectedRows         = count($aRecordList);
                    break;

                default:
                    $aRecordList                 = array();
                    // SQLの実行による影響行数
                    $this->iAffectedRows         = $oStatement->rowCount();
                    break;
            }
            // レコードリストを生成
            $this->aRecordList                   = new RecordListAO($aRecordList);
            // ログ出力
            if ( $this->bSqlLog === true ) {
                \Log::trace("SQL dump [$sHash]: Affected rows = [{$this->iAffectedRows}]");
            }
        } catch (\PDOException $oPrevious) {
            // SQLの実行が失敗したはず
            $this->bHasError                     = true;
            $this->mErrorCode                    = $oStatement->errorCode();
            $this->aErrorInfo                    = $oStatement->errorInfo();
            $sMessage                            = "Statement execute failure: code=[{$this->mErrorCode}] ({$this->aErrorInfo[0]}: {$this->aErrorInfo[1]}: {$this->aErrorInfo[2]})' [$sSql] [$sHash]";
            throw new \SC\exception\libs\DB\AbstractDB\ExecutionFailure($sMessage, $oPrevious->getCode(), $oPrevious);
        }
        return true;
    }

    /**
     * BINDパラメータのチェック
     *
     * @param   string  $sSql       SQL
     * @param   array   $aBinds     BINDパラメータの配列
     * @return  array   チェック後の情報
     * @throw
     */
    protected function _checkBinds($sSql, array $aBinds)
    {
        // SQL中にあるバインドパラメータを抽出
        $aParts                       = preg_split('#(:[0-9a-z_]{2,})(?=[^0-9a-z_]|$)#uS', $sSql, -1, PREG_SPLIT_NO_EMPTY|PREG_SPLIT_DELIM_CAPTURE);
        $iCount                       = count($aParts);
        if ( $iCount < 2 ) {
            // バインドパラメータがなかった
            $aChecked                 = array(
                'sql'   => $sSql,
                'binds' => array(),
            );
            return $aChecked;
        }
        $aUniq                        = array();
        $aPos                         = array();
        foreach ( $aParts as $iPos => $sPart ) {
            // プレースホルダか？
            $bFound                   = (bool) preg_match('#^:([0-9a-z_]{2,})$#uS', $sPart, $aMatches);
            if ( $bFound !== true ) {
                // プレースホルダではない → 次へ
                continue;
            }
            $sPHolder                 = $aMatches[0];
            $sName                    = $aMatches[1];
            // 既に同名を保持しているか？
            $bRetCode                 = array_key_exists($sPHolder, $aUniq);
            if ( $bRetCode !== true ) {
                // バインドパラメータがあるか
                $bRetCode             = array_key_exists($sPHolder, $aBinds);
                if ( $bRetCode === true ) {
                    $mValue           = $aBinds[$sPHolder];
                } else {
                    $bRetCode         = array_key_exists($sName, $aBinds);
                    if ( $bRetCode === true ) {
                        $mValue       = $aBinds[$sName];
                    } else {
                        $mValue       = NULL;
                    }
                }
                unset($aBinds[$sPHolder]);
                unset($aBinds[$sName]);
                // ストア
                $aUniq[$sPHolder]     = $mValue;
            }
            $aList                    = \ArrayUtil::getValue($aPos, $sPHolder, array());
            $aList[]                  = $iPos;
            $aPos[$sPHolder]          = $aList;
        }
        $aBinds                       = array();
        foreach ( $aPos as $sPHolder => $aList ) {
            $i                        = 0;
            foreach ( $aList as $iPos ) {
                $sNewPHolder          = $sPHolder . '_' . $i;
                $aParts[$iPos]        = $sNewPHolder;
                $aBinds[$sNewPHolder] = $aUniq[$sPHolder];
                $i++;
            }
        }
        // チェック後の情報を配列化
        $aChecked  = array(
            'sql'   => join('', $aParts),
            'binds' => $aBinds,
        );
        return $aChecked;
    }

    /**
     * SQL文の実行準備
     *
     * @param   string          $sSql       SQL
     * @return  \PDOStatement   生成したPDOステートメント
     * @throw   \SC\exception\libs\DB\AbstractDB\PrepareFailure
     */
    protected function _getStatement($sSql)
    {
        // ステートメントチェック
        $sHash                               = $this->_hash($sSql);
        $bRetCode                            = isset($this->aPDOStatement[$sHash]);
        if ( $bRetCode !== true ) {
            // 存在しないので生成
            try {
                // ステートメントを生成
                $oStatement                  = $this->oPDO->prepare($sSql);
                $this->aPDOStatement[$sHash] = $oStatement;
            } catch (\PDOException $oPrevious) {
                // 生成失敗
                $this->bHasError             = true;
                $this->mErrorCode            = $this->oPDO->errorCode();
                $this->aErrorInfo            = $this->oPDO->errorInfo();
                $sMessage                    = "Statement prepare failure: code=[{$this->mErrorCode}] ({$this->aErrorInfo[0]}: {$this->aErrorInfo[1]}: {$this->aErrorInfo[2]})' [$sSql] [$sHash]";
                throw new \SC\exception\libs\DB\AbstractDB\PrepareFailure($sMessage, $oPrevious->getCode(), $oPrevious);
            }
        }
        // ステートメントを返却
        return $this->aPDOStatement[$sHash];
    }

    /**
     * 型を判定してPDO::PRAM_*を返す
     *
     * 論理型   → PDO::PARAM_BOOL
     * 整数型   → PDO::PARAM_INT
     * NULL型   → PDO::PARAM_NULL
     * それ以外 → PDO::PARAM_STR
     *
     * @param   mixed   $mValue
     * @return  int     PDO::PARAM_*
     */
    protected function _getPDOParamType($mValue)
    {
        $bRetCode = is_bool($mValue);
        if ( $bRetCode === true ) {
            return \PDO::PARAM_BOOL;
        }
        $bRetCode = is_int($mValue);
        if ( $bRetCode === true ) {
            return \PDO::PARAM_INT;
        }
        $bRetCode = is_null($mValue);
        if ( $bRetCode === true ) {
            return \PDO::PARAM_NULL;
        }
        return \PDO::PARAM_STR;
    }

    /**
     * 抽出結果の型補正
     *
     * @param   array   $aConvFuncs     型変換情報
     * @param   string  $sRecordsKey    指定キーを配列のキーにする
     * @return  bool    true/false
     */
    protected function _fixRecordListType(array $aConvFuncs, $sRecordKey)
    {
        $aRecordList                = new RecordListAO();
        foreach ( $this->aRecordList as $aRecord ) {
            $sKey                   = '';
            foreach ( $aRecord as $sField => $mValue ) {
                $sMethod            = \ArrayUtil::getValue($aConvFuncs, $sField, '_parseString');
                $aRecord[$sField]   = $this->$sMethod($mValue);
                if ( $sField === $sRecordKey ) {
                    $sKey           = $aRecord[$sField];
                }
            }
            if ( $sKey !== '' && $sKey !== NULL ) {
                $aRecordList[$sKey] = $aRecord;
            } else {
                $aRecordList[]      = $aRecord;
            }
        }
        $this->aRecordList          = $aRecordList;
        return true;
    }

    /**
     * SQLログを取得
     *
     * @param   string  $sSql       ログを取得するSQL
     * @param   array   $aBinds     バインドパラメータ
     * @return  bool    true
     */
    protected function _log($sSql, array $aBinds = array())
    {
        $this->sLastQueryString = $sSql;
        $this->aLastBindParams  = $aBinds;
        if ( $this->bSqlLog === true ) {
            if ( $aBinds !== array() ) {
                $sBindsDump     = \Debug::dump($aBinds, ' with', false);
            } else {
                $sBindsDump     = '';
            }
            $sHash              = $this->_hash($sSql);
            \Log::trace("SQL dump [$sHash]: [$sSql]{$sBindsDump}");
        }
        return true;
    }

    /**
     * トランザクションを開始する
     *
     * @return  bool    true
     */
    public static function beginTransaction()
    {
        $oSelf = static::_getInstance();
        return $oSelf->_beginTransaction();
    }

    /**
     * トランザクションを完了する
     *
     * @return  bool    true
     */
    public static function commit()
    {
        $oSelf = static::_getInstance();
        return $oSelf->_commitTransaction();
    }

    /**
     * トランザクションをロールバックする
     *
     * @return  bool    true
     */
    public static function rollback()
    {
        $oSelf = static::_getInstance();
        return $oSelf->_rollbackTransaction();
    }

    /**
     * トランザクション内か否か
     *
     * @return  bool    true/false
     */
    public static function inTransaction()
    {
        $oSelf = static::_getInstance();
        return $oSelf->bInTransaction;
    }

    /**
     * エラーが発生したか否か
     *
     * @return  bool    true/false
     */
    public static function hasError()
    {
        $oSelf = static::_getInstance();
        return $oSelf->bHasError;
    }

    /**
     * エラーコードを取得する
     *
     * @return  mixed   error code
     */
    public static function errorCode()
    {
        $oSelf = static::_getInstance();
        return $oSelf->mErrorCode;
    }

    /**
     * エラー情報を取得する
     *
     * @return  array   error info
     */
    public static function errorInfo()
    {
        $oSelf = static::_getInstance();
        return $oSelf->aErrorInfo;
    }

    /**
     * PDOのエラーコードを取得する
     *
     * @return  mixed   error code
     */
    public static function errorCodePDO()
    {
        $oSelf = static::_getInstance();
        return $oSelf->oPDO->errorCode();
    }

    /**
     * PDOのエラー情報を取得する
     *
     * @return  array   error info
     */
    public static function errorInfoPDO()
    {
        $oSelf = static::_getInstance();
        return $oSelf->oPDO->errorInfo();
    }

    /**
     * PDOStatementのエラーコードを取得する
     *
     * @param   string  $sSql   SQL文
     * @return  mixed   error code
     */
    public static function errorCodeStatement($sSql)
    {
        $oSelf = static::_getInstance();
        $sHash = $oSelf->_hash($sSql);
        return $oSelf->oPDOStatement[$sHash]->errorCode();
    }

    /**
     * PDOStatementのエラー情報を取得する
     *
     * @param   string  $sSql   SQL文
     * @return  array   error info
     */
    public static function errorInfoStatement($sSql)
    {
        $oSelf = static::_getInstance();
        $sHash = $oSelf->_hash($sSql);
        return $oSelf->oPDOStatement[$sHash]->errorInfo();
    }

    /**
     * トランザクションを開始する
     *
     * @return  bool    true
     * @throw   SC\exception\libs\AbstractDB\CantBeginTransaction
     */
    protected function _beginTransaction()
    {
        if ( $this->bInTransaction === true ) {
            // トランザクションは開始中
            return true;
        }
        $this->bInTransaction = true;
        try {
            // トランザクションを開始する
            $sSql             = static::SQL_BEGIN;
            $this->_log($sSql);
            $iRetValue        = $this->oPDO->exec($sSql);
            if ( $iRetValue === false ) {
                // トランザクションが開始されなかった
                throw new \SC\exception\libs\DB\AbstractDB\CantBeginTransaction("Can't begin transaction: [SQL=$sSql]", -1);
            }
        } catch (\PDOException $oPrevious) {
            // トランザクションが開始されなかったはず
            $this->bHasError  = true;
            $this->mErrorCode = $this->oPDO->errorCode();
            $this->aErrorInfo = $this->oPDO->errorInfo();
            throw new \SC\exception\libs\DB\AbstractDB\CantBeginTransaction("Can't begin transaction: message='{$oPrevious->getMessage()}' [SQL=$sSql]", $oPrevious->getCode(), $oPrevious);
        }
        return true;
    }

    /**
     * datetimeフィールドを時刻文字列にフォーマットする
     *
     * @param   string  $sField     フィールド名
     * @return  string  フォーマット後の時刻文字列
     */
    public static function formatDateTimeToString($sField, $sFormat = '', $sModifier = 'localtime')
    {
        $sClass   = get_class($this);
        $sMethod  = $sClass . '::' . __FUNCTION__;
        $aBTrace  = debug_backtrace(2);
        $sMessage = "Call to undefined method {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
        trigger_error($sMessage, E_USER_ERROR);
    }

    /**
     * 論理型へ変換
     *
     * @return  mixed       $mInput
     * @return  bool        変換後の値
     */
    protected function _parseBool($mInput)
    {
        // NULLはNULLで返す (スカラ変数以外はNULLで返す)
        $bRetCode = is_scalar($mInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        // 数値の場合は一旦浮動小数点へキャストしてから変換する
        $bRetCode = is_numeric($mInput);
        if ( $bRetCode === true ) {
            return (bool) (float) $mInput;
        }
        // "true" を true ， "false" を false ， "NULL" を NULL にしたいので一旦小文字化する
        $mInput   = strtolower(trim($mInput));
        $bRetCode = false;
        switch ( $mInput ) {
            case 'null':
                $bRetCode = NULL;
                break;

            case 'false':
                $bRetCode = false;
                break;

            case 'true':
            default:
                $bRetCode = true;
                break;
        }
        return $bRetCode;
    }

    /**
     * DateTime型へ変換
     *
     * @return  mixed       $mInput
     * @return  \DateTime   変換後の値
     */
    protected function _parseDateTime($mInput)
    {
        // NULLはNULLで返す (スカラ変数以外はNULLで返す)
        $bRetCode = is_scalar($mInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        return new \DateTime($mInput);
    }

    /**
     * 浮動小数点型へ変換
     *
     * @return  mixed       $mInput
     * @return  float       変換後の値
     */
    protected function _parseFloat($mInput)
    {
        // NULLはNULLで返す (スカラ変数以外はNULLで返す)
        $bRetCode = is_scalar($mInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        return (float) $mInput;
    }

    /**
     * 整数型へ変換(16進数)
     *
     * @return  mixed       $mInput
     * @return  int         変換後の値
     */
    protected function _parseHex($mInput)
    {
        // NULLはNULLで返す (スカラ変数以外はNULLで返す)
        $bRetCode = is_scalar($mInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        $mInput   = base_convert($mInput, 16, 10);
        return $this->_parseInt($mInput);
    }

    /**
     * 整数型へ変換
     *
     * @return  mixed       $mInput
     * @return  int         変換後の値
     */
    protected function _parseInt($mInput)
    {
        // NULLはNULLで返す (スカラ変数以外はNULLで返す)
        $bRetCode = is_scalar($mInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        return (int) $mInput;
    }

    /**
     * 文字列型へ変換
     *
     * @return  mixed       $mInput
     * @return  string      変換後の値
     */
    protected function _parseString($mInput)
    {
        // NULLはNULLで返す (スカラ変数以外はNULLで返す)
        $bRetCode = is_scalar($mInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        return (string) $mInput;
    }

    /**
     * VACUUMを実行する
     *
     * @return  bool    true
     */
    protected function _doVacuum()
    {
        // @todo 1日1回のvacuumで十分 → 1日1回はどうする？
        $this->_vacuum();
    }

    /**
     * VACUUM
     *
     * @return  bool    true
     */
    protected function _vacuum()
    {
        $sClass   = get_class($this);
        $sMethod  = $sClass . '::' . __FUNCTION__;
        $aBTrace  = debug_backtrace(2);
        $sMessage = "Call to undefined method {$sClass}::{$sMethod}() in {$aBTrace[0]['file']} on line {$aBTrace[0]['line']}";
        trigger_error($sMessage, E_USER_ERROR);
    }

    /**
     * ハッシュを取得
     *
     * @param   string  $sInput     取得したい値
     * @return  string  ハッシュ値
     */
    protected function _hash($sInput)
    {
        return \SC\libs\Hash::hash($sInput, $this->sAccessKey, 'hmac-sha1', false, true, 6);
    }
}
