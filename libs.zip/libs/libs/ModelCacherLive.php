<?php
/**
 * ModelCacherLive
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ModelCacherLive
 */
class ModelCacherLive extends ModelCacher
{
    /**
     * 設定ファイルのキャッシュファイル
     *
     * @var string CONFIG_CACHE_NAME
     */
    const CONFIG_CACHE_NAME = 'models-cache-live.php';

    /**
     * 設定ファイルのキャッシュロック
     *
     * @var string CONFIG_CACHE_LOCK
     */
    const CONFIG_CACHE_LOCK = 'models-cache-live.lock';
}
