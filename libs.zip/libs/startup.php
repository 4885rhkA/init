<?php
/**
 * 初期読み込みファイル
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC;

// 基本
require_once __DIR__ . '/base/Base.php';
base\Base::initialize();

// ローダー
require_once __DIR__ . '/base/Loader.php';
base\Loader::regist();

