<?php
/**
 * ShortenUrlGoogle
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * ShortenUrlGoogle
 *
 * シングルトンではないが静的にコールした場合には常に同一のインスタンス
 */
class ShortenUrlGoogle extends AbstractShortenUrl
{
    /**
     * 短縮URL生成サービスURL
     *
     * @var string SHORTENER
     */
    const SHORTENER = 'https://www.googleapis.com/urlshortener/v1/url';

    /**
     * 短縮URLの取得
     *
     * @param   string  $sLongUrl   短縮前URL
     * @return  string  短縮後URL
     */
    public static function shorten($sLongUrl)
    {
        // 短縮URL取得パラメータ
        $aOptions = array(
            'rawpostdata' => JSON::encode(array('longUrl' => $sLongUrl)),
            'headers'     => array(
                'Content-Type' => 'application/json',
            ),
        );
        $oSelf = static::_getInstance();
        return $oSelf->_shorten($aOptions);
    }

    /**
     * 短縮URLの取得
     *
     * @param   array   $aOptions   短縮に必要な情報
     * @return  string  短縮後URL
     * @throw   SC\exception\common\parameter\ZeroByteString
     */
    protected function _shorten(array $aOptions)
    {
        // 短縮URLを取得
        $sJSON     = parent::_shorten($aOptions);
        // JSONを処理
        if ( $sJSON === '' ) {
            // 正常なJSONが返ってこなかった
            return '';
        }
        try {
            $aData = JSON::decode($sJSON, true);
        } catch (\SC\exception\libs\JSON\CantDecode $oException) {
            // 正常なJSONが返ってこなかった
            return '';
        }
        return ArrayUtil::getValue($aData, 'id', '');
    }
}
