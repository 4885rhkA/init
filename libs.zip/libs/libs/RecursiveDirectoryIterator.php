<?php
/**
 * RecursiveDirectoryIterator
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * RecursiveDirectoryIterator
 */
class RecursiveDirectoryIterator extends \RecursiveDirectoryIterator
{
    /**
     * ディレクトリであれば、現在のエントリに対するイテレータを返す
     *
     *  ディレクトリが読めなかった場合には空配列の\RecursiveArrayIteratorを返す
     *
     * @return  SC\libs\RecursiveDirectoryIterator
     */
    public function getChildren()
    {
        try {
            $oChildren = parent::getChildren();
        } catch(\UnexpectedValueException $oException) {
            $oChildren = new \RecursiveArrayIterator(array());
        }
        return $oChildren;
    }
}
