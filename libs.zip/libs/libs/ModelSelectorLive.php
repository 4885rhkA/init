<?php
/**
 * ModelSelectorLive
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 */
namespace SC\libs;

/**
 * ModelSelectorLive
 */
class ModelSelectorLive extends ModelSelector
{
    /**
     * モデルタイプ
     *
     *  production, admin, live, verify, develop
     *
     * @var string TYPE
     */
    const TYPE = 'live';

    /**
     * 環境ディレクトリの指定
     *
     * @var string ENV_DIR
     */
    const ENV_DIR = 'contents/stage.live';
}
