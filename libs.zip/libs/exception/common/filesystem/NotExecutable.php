<?php
/**
 * 実行可能属性がない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\filesystem;

/**
 * 実行可能属性がない場合の例外
 */
class NotExecutable extends \SC\exception\common\filesystem
{
}
