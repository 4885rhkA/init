<?php
/**
 * SmartyPlugins
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\libs;

/**
 * SmartyPlugins
 */
class SmartyPlugins
{
    /**
     * インスタンス
     *
     * @var SC\libs\SmartyPlugins $oInstance
     */
    protected static $oInstance = NULL;

    /**
     * 追加の修飾子
     *
     * @var array(string => callable) $aModifiers
     */
    protected $aModifiers = array();

    /**
     * 追加の関数
     *
     * @var array(string => callable) $aFunctions
     */
    protected $aFunctions = array();

    /**
     * リクエスト
     *
     * @var SC\libs\Request $oRequest
     */
    protected $oRequest = NULL;

    /**
     * コンストラクタ
     */
    final protected function __construct()
    {
        $this->oRequest            = \Request::getInstance();

        // 追加の修飾子
        $sClass                    = get_class($this);
        $this->aModifiers          = array(
            // URLの調整
            'url'                  => array( $sClass, 'resolveUrl'           ),
            'absolute'             => array( $sClass, 'absoluteUrl'          ),
            'relative'             => array( $sClass, 'relativeUrl'          ),
            'stg'                  => array( $sClass, 'resolveUrlForStg'     ),
            'url_adjust'           => array( $sClass, 'adjustURIString'      ),
            'proto'                => array( $sClass, 'http_proto'           ),
            'scheme'               => array( $sClass, 'http_proto'           ),
            // 配列用
            'val'                  => array( $sClass, 'arrayUtilGetValue'    ),
            'array_value'          => array( $sClass, 'arrayUtilGetValue'    ),
            'join'                 => array( $sClass, 'join'                 ),
            'implode'              => array( $sClass, 'join'                 ),
            // 正規表現用
            'regex_match'          => array( $sClass, 'regex_match'          ),
            'regex_match_all'      => array( $sClass, 'regex_match_all'      ),
            // 日本語処理
            'mb_convert_encoding'  => array( $sClass, 'mb_convert_encoding'  ),
            // デバッグ用
            'dump'                 => array( $sClass, 'dump'                 ),
        );
        $this->aFunctions          = array(
            // デバッグ用
            'debug_console'        => array( $sClass, 'debugConsole'         ),
        );
    }

    /**
     * インスタンスを取得する
     *
     * @return  SC\libs\SmartyPlugins
     */
    final public static function getInstance()
    {
        if ( self::$oInstance === NULL ) {
            self::$oInstance = new static();
        }
        return self::$oInstance;
    }

    /**
     * 修飾子指定を返す
     *
     * @return  array   修飾子指定を返す
     */
    public static function getModifiers()
    {
        $oSelf = static::getInstance();
        return $oSelf->aModifiers;
    }

    /**
     * 関数指定を返す
     *
     * @return  array   関数指定
     */
    public static function getFunctions()
    {
        $oSelf = static::getInstance();
        return $oSelf->aFunctions;
    }

    /**
     * 静的メソッドコール
     *
     * @param   string  $sMethod
     * @param   array   $aParams
     * @return  string  整形されたURL
     */
    public static function __callStatic($sMethod, $aParams)
    {
        // メソッドの存在チェック
        $sClass   = get_called_class();
        $bRetCode = method_exists($sClass, "_$sMethod");
        if ( $bRetCode !== true ) {
            // 存在しない → エラートリガーを引く (標準エラーと同様に見せる)
            trigger_error('Call to undefined method ' . $sClass . '::' . $sMethod . '()', E_USER_ERROR);
        }
        // 存在するのでメソッドコール
        $oSelf    = static::getInstance();
        return forward_static_call_array(array($oSelf, "_$sMethod"), $aParams);
    }

    /**
     * ダンプ
     *
     * @param   mixed   $mValue
     * @param   string  $sLabel
     * @return  string  整形されたURL
     */
    protected function _dump($mValue, $sLabel = '')
    {
        if ( $sLabel === '' ) {
            $sLabel = 'Template Value:';
        }
        return \Debug::dump($mValue, $sLabel, false);
    }

    /**
     * URLの整形 for ステージング
     *
     * @param   string  $sRawUri
     * @return  string  整形されたURL
     */
    protected function _resolveUrlForStg($sRawUri)
    {
        // 入力チェック
        $bRetCode = Validate::isString($sRawUri);
        if ( $bRetCode !== true ) {
            return '';
        }
        $sRawUri  = trim($sRawUri);
        if ( $sRawUri === '' ) {
            return '';
        }
        $iCmp     = strncmp('#', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        $iCmp     = strncmp('?', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        try {
            $sUri = Util::adjustURIStagingSource((string) $sRawUri);
            $sUri = Util::adjustURIStagingSP($sUri);
        } catch (\SC\exception\libs\Uri\CantParseUri $oException) {
            // URLとして無効 → そのまま返す
            return $sUri;
        }
        return $sUri;
    }

    /**
     * URLの整形
     *
     *  ホスト名変換
     *      １．ソースサイト        →  SPサイトへ変換して２へ
     *      ２．SPサイト            →  SPサイトステージングへ変換
     *      ３．ローカルサイト      →  変換しない
     *      ４．その他              →  変換しない
     *
     *  パス変換
     *      １ or ２ or ３          →  prefix付与変換
     *      ４                      →  変換しない
     *
     * @param   string          $sRawUri        整形前URL
     * @param   array|string    $aPatterns      処理対象のパターンのリスト(PCRE)
     * @param   array|string    $aExcludes      対象除外ホストのリスト(PCRE)
     * @return  string  整形されたURL
     */
    protected function _resolveUrl($sRawUri, $aPatterns = NULL , $aExcludes = NULL)
    {
        // 入力チェック
        $bRetCode          = Validate::isString($sRawUri);
        if ( $bRetCode !== true ) {
            return '';
        }
        $sRawUri           = trim($sRawUri);
        if ( $sRawUri === '' ) {
            return '';
        }
        $iCmp              = strncmp('#', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        $iCmp              = strncmp('?', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        // 対象除外ホストか？
        $aExcludes         = (array) $aExcludes;
        $aExcludes         = Util::validatePCRE($aExcludes, false);
        $sReplaced         = preg_replace($aExcludes, '$0', $sRawUri, 1, $iCount);
        if ( $iCount > 0 ) {
            // 対象除外にヒット → そのまま返す
            return $sRawUri;
        }
        $aPatterns         = (array) $aPatterns;
        $iCount            = count($aPatterns);
        if ( $iCount > 0 ) {
            // 対象指定あり
            $aPatterns     = Util::validatePCRE($aPatterns, false);
            $sReplaced     = preg_replace($aPatterns, '$0', $sRawUri, 1, $iCount);
            if ( $iCount < 1 ) {
                // 対象にヒットしない → そのまま返す
                return $sRawUri;
            }
        }

        // １．ソースサイト →  SPサイトへ変換 / ２．SPサイト → SPサイトステージングへ変換
        try {
            $sAdjusted     = Util::adjustURIProduction($sRawUri, true);
            // 変換後のURLをオブジェクト化
            $oUri          = new Uri($sAdjusted);
        } catch (\SC\exception\libs\Uri\CantParseUri $oException) {
            // URLとして無効 → そのまま返す
            return $sRawUri;
        }
        // スキームがあるか？
        $sScheme           = $oUri->getScheme();
        if ( $sScheme === '' ) {
            // スキームなし
            $bHasScheme    = false;
        } else {
            // スキームあり
            $bHasScheme    = true;
        }
        // ホスト名があるか？
        $sHost             = $oUri->getHost();
        if ( $sHost === '' ) {
            // ホスト名なし
            $bHasHost      = false;
        } else {
            // ホスト名あり
            $bHasHost      = true;
        }
        // 変換が行われたか？
        if ( $sAdjusted === $sRawUri && $bHasHost === true ) {
            // １・２の変換は行われていない → ローカルか？
            $bIsLocal      = Util::isHostLocal($sHost);
            if ( $bIsLocal !== true ) {
                // ローカルではない → そのまま返す
                return $sRawUri;
            }
        }
        // エントリポイント調整
        $sEntryPoint       = $this->oRequest->getEntryPoint();
        if ( $sEntryPoint !== '' ) {
            // エントリポイントがある場合に置換
            $sPath         = $oUri->getPath();
            $sSearch       = preg_quote($sEntryPoint);
            $sSearch       = Util::validatePCRE("^($sSearch)?/", false, '#', 'u');
            $sAdjusted     = preg_replace($sSearch, $sEntryPoint . '/', $sPath);
            if ( $sAdjusted !== NULL && $sAdjusted !== $sPath ) {
                $oUri->setPath($sAdjusted);
            }
        }
        // ビルド
        $sUri              = $oUri->build();
        return $sUri;
    }

    /**
     * 相対URLを絶対URLに整形
     *
     * @param   string  $sRawUri
     * @param   string  $sCustomHost        付加したいホスト名
     * @param   bool    $bResolveForStg     ステージング用に整形するか否か
     * @return  string  整形済URL
     */
    protected function _absoluteUrl($sRawUri, $sCustomHost = '', $bResolveForStg = true)
    {
        // 入力チェック
        $bRetCode        = Validate::isString($sRawUri);
        if ( $bRetCode !== true ) {
            return '';
        }
        $sRawUri         = trim($sRawUri);
        if ( $sRawUri === '' ) {
            return '';
        }
        $iCmp            = strncmp('#', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        $iCmp            = strncmp('?', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        try {
            $oUri        = new Uri($sRawUri);
        } catch (\SC\exception\libs\Uri\CantParseUri $oException) {
            // URLとして無効 → そのまま返す
            return $sRawUri;
        }
        $sHost           = $oUri->getHost();
        // 絶対パスかどうか
        if ( $sHost !== '' ) {
            // 絶対パス → 何もせずそのまま返す
            return $sRawUri;
        }

        // スキーマを補完
        $oUri->setScheme($this->oRequest->getProto());
        // ホストの指定
        if ( $sCustomHost === '' ) {
            $sCustomHost = $this->oRequest->getServer('HTTP_HOST', '');
        }
        $oUri->setHost($sCustomHost);
        // ビルド
        $sUri            = $oUri->build(Uri::TYPE_ABSOLUTE);
        // URLの整形 for ステージング
        if ( $bResolveForStg !== false ) {
            $sUri        = $this->_resolveUrlForStg($sUri);
        }
        return $sUri;
    }

    /**
     * 絶対URLを相対URLに整形
     *
     * @param   string  $sRawUri
     * @param   string  $sCustomHost        除去したいホスト名
     * @param   bool    $bResolveForStg     ステージング用に整形するか？
     * @return  string  整形済URL
     */
    protected function _relativeUrl($sRawUri, $sCustomHost = '', $bResolveForStg = true)
    {
        // 入力チェック
        $bRetCode       = Validate::isString($sRawUri);
        if ( $bRetCode !== true ) {
            return '';
        }
        $sRawUri        = trim($sRawUri);
        if ( $sRawUri === '' ) {
            return '';
        }
        $iCmp           = strncmp('#', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        $iCmp           = strncmp('?', (string) $sRawUri, 1);
        if ( $iCmp === 0 ) {
            return $sRawUri;
        }
        // 除去したいホスト名があるか？
        if ( $sCustomHost === '' ) {
            return $sRawUri;
        }
        try {
            $oUri       = new Uri($sRawUri);
        } catch (\SC\exception\libs\Uri\CantParseUri $oException) {
            // URLとして無効 → そのまま返す
            return $sRawUri;
        }
        $sHost          = $oUri->getHost();
        $sPath          = $oUri->getPath();
        // 相対パスかどうか
        if ( $sHost === '' ) {
            // 相対パス → 何もせずそのまま返す
            return $sRawUri;
        }

        // 除去したいホスト名のステージング設定があれば，ホスト名をステージングに変換する
        // リクエストとホスト名からURLを組み立てる
        $sCustomUri     = $this->oRequest->getProto() . '://';
        $sCustomUri    .= $sCustomHost;
        // URLの整形 for ステージング
        if ( $bResolveForStg !== false ) {
            $sCustomUri = $this->_resolveUrlForStg($sCustomUri);
        }
        // ビルド
        try {
            $oCustomUri = new Uri($sCustomUri);
        } catch (\SC\exception\libs\Uri\CantParseUri $oException) {
            // URLとして無効 → そのまま返す
            return $sRawUri;
        }
        $sCustomUri->build(Uri::TYPE_ABSOLUTE);
        // 再度，ホスト名を取得する
        $sCustomHost    = $oCustomUri->getHost();

        if ( $sHost !== $sCustomHost ) {
            // ホスト名が除去したいホスト名と異なる → 何もせずそのまま返す
            return $sRawUri;
        }
        // 相対パスにビルド
        $oUri->setPath($this->oRequest->getEntryPoint() . $sPath);
        $sUri           = $oUri->build(Uri::TYPE_RELATIVE);
        return $sUri;
    }

    /**
     * smarty修飾子 for nodefaults
     *
     * Smarty2との互換性のため
     *
     * @param   mixed   $mValue
     * @param   string  $sNodefaults
     * @return  mixed   何もしない
     */
    protected function _smarty_nodefaults($mValue, $sNodefaults)
    {
        return $mValue;
    }

    /**
     * 配列から値を取得
     *
     * @param   array   $aInput
     * @param   string  $sKey
     * @param   string  $sKey ...
     * @return  mixed   値
     */
    public static function arrayUtilGetValue($aInput, $sKey)
    {
        // 全引数を取得
        $aArgs    = func_get_args();
        $iCount   = count($aArgs);
        // 引数がなければ抜ける
        if ( $iCount < 2 ) {
            return NULL;
        }
        // 配列チェック
        $aInput   = array_shift($aArgs);
        $bRetCode = is_array($aInput);
        if ( $bRetCode !== true ) {
            return NULL;
        }
        $sKey     = (string) array_shift($aArgs);
        $mValue   = ArrayUtil::getValue($aInput, $sKey, NULL);
        foreach ( $aArgs as $sKey ) {
            $bRetCode = is_array($mValue);
            if ( $bRetCode !== true ) {
                return NULL;
            }
            $mValue = ArrayUtil::getValue($mValue, $sKey, NULL);
        }
        return $mValue;
    }

    /**
     * 文字コード変換
     *
     * @param   string  $sInput
     * @param   string  $sEncTo
     * @param   string  $sEncFrom
     * @return  string  変換後の文字列
     */
    public static function mb_convert_encoding($sInput, $sEncTo, $sEncFrom = '')
    {
        return Util::mb_convert_encoding((string) $sInput, (string) $sEncTo, (string) $sEncFrom);
    }

    /**
     * 配列の結合
     *
     * @param   mixed   $mInput1
     * @param   mixed   $mInput2
     * @return  string  変換後の文字列
     */
    public static function join($mInput1, $mInput2 = '')
    {
        // 配列を探す
        $bRetCode      = is_array($mInput1);
        if ( $bRetCode === true ) {
            // 1つ目が配列
            $aInput    = $mInput1;
            $bRetCode  = is_scalar($mInput2);
            if ( $bRetCode === true ) {
                $sGlue = (string) $mInput2;
            } else {
                $sGlue = '';
            }
        } else {
            $bRetCode = is_array($mInput2);
            if ( $bRetCode === true ) {
                // 2つ目が配列
                $aInput    = $mInput2;
                $bRetCode  = is_scalar($mInput1);
                if ( $bRetCode === true ) {
                    $sGlue = (string) $mInput1;
                } else {
                    $sGlue = '';
                }
            } else {
                // 配列はない
                $bRetCode  = is_scalar($mInput1);
                if ( $bRetCode === true ) {
                    // 第1引数がスカラーなら文字列にして返す
                    return (string) $mInput1;
                } else {
                    // 第1日引数が不明なら空文字を返す
                    return '';
                }
            }
        }
        // 結合して返す
        return join($sGlue, $aInput);
    }

    /**
     * URIのプロトコルを調整する
     *
     * @param   string  $sRawUri
     * @param   string  $sProto
     * @param   bool    $bAlwaysAddScheme
     * @return  string  変換後のURI
     */
    public static function http_proto($sRawUri, $sProto = '', $bAlwaysAddScheme = true)
    {
        // 入力チェック
        $bRetCode       = Validate::isString($sRawUri);
        if ( $bRetCode !== true ) {
            return '';
        }
        $sRawUri        = trim($sRawUri);
        if ( $sRawUri === '' ) {
            return '';
        }
        // URLをパース
        try {
            $oUri       = new Uri($sRawUri);
        } catch (\SC\exception\libs\Uri\CantParseUri $oException) {
            // URLとして無効 → そのまま返す
            return $sRawUri;
        }
        // ホスト名があるか？
        $sHost          = $oUri->getHost();
        if ( $sHost === '' ) {
            // なければそのまま
            return $sRawUri;
        }
        // スキーマが省略されている場合でも追加するか？
        if ( $bAlwaysAddScheme !== true ) {
            // スキーマが省略されているか？
            $sRawScheme = $oUri->getScheme();
            if ( $sRawScheme === '' ) {
                // 省略されているならそのまま
                return $sRawUri;
            }
        }
        // 入力チェック
        $bRetCode       = Validate::isString($sRawUri);
        if ( $bRetCode !== true ) {
            $sProto     = '';
        } else {
            $sProto     = trim($sProto);
        }
        if ( $sProto === '' ) {
            $sProto     = Request::getProto();
        }
        // あればセット
        $oUri->setScheme($sProto);
        // ビルド
        $sUri           = $oUri->build(Uri::TYPE_ABSOLUTE);
        return $sUri;
    }

    /**
     * regex_match like preg_match
     *
     * @param   string  $sInput
     * @param   string  $sRegEx
     * @param   int     $iFlags
     * @param   int     $iOffset
     * @return  int     0 回（マッチせず）または 1 回 (エラーが発生した場合にFALSE)
     */
    public static function regex_match($sInput, $sRegEx, $iFlags = 0, $iOffset = 0)
    {
        // 正規表現の有効化
        $sRegEx = Util::validatePCRE((string) $sRegEx, true);
        return preg_match($sRegEx, (string) $sInput, $aMatches, (int) $iFlags, (int) $iOffset);
    }

    /**
     * regex_match_all like preg_match_all
     *
     * @param   string  $sInput
     * @param   string  $sRegEx
     * @param   int     $iFlags
     * @param   int     $iOffset
     * @return  int     パターンがマッチした総数(マッチせずで0回，エラーが発生した場合にFALSE)
     */
    public static function regex_match_all($sInput, $sRegEx, $iFlags = PREG_PATTERN_ORDER, $iOffset = 0)
    {
        // 正規表現の有効化
        $sRegEx = Util::validatePCRE((string) $sRegEx, true);
        return preg_match_all($sRegEx, (string) $sInput, $aMatches, (int) $iFlags, (int) $iOffset);
    }

    /**
     * 文字列中にあるURIを調整
     *
     * @param   string  $sInput         調整文字列
     * @param   bool    $bUtf8          UTF-8か否か
     * @param   string  $sPathPrefix    パスの接頭辞
     * @return  string  調整済み文字列
     */
    public static function adjustURIString($sInput, $bUtf8 = true, $sPathPrefix = NULL)
    {
        if ( $sPathPrefix === NULL ) {
            $sPathPrefix = \Request::getPreview();
        }
        $bRetCode        = Validate::isString($sInput);
        if ( $bRetCode !== true ) {
            $sInput      = ArrayUtil::join('', $sInput, true);
        }
        return \Util::adjustURIString($sInput, $bUtf8, $sPathPrefix);
    }

    /**
     * デバッグコンソールを表示する
     *
     * @param   array   $aParams        属性情報
     * @param   Smarty  $oSmarty        Smartyオブジェクト
     * @return  string  調整済み文字列
     */
    protected function _debugConsole($aParams, $oSmarty)
    {
        // コンソール内容を取得
        $sOutput = SmartyDebug::fetch($oSmarty);
        // 代入するか否か
        $sAssign = trim((string) ArrayUtil::getValue($aParams, 'assign', ''));
        if ( $sAssign === '' ) {
            return $sOutput;
        }
        $oSmarty->assign($sAssign, $sOutput);
        return '';
    }
}
