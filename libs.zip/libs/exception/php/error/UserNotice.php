<?php
/**
 * ユーザ注意例外 (E_USER_NOTICE)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * ユーザ注意例外 (E_USER_NOTICE)
 */
class UserNotice extends \SC\exception\php\error
{
}
