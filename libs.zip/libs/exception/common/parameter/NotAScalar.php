<?php
/**
 * パラメータがスカラー型ではなかった場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\common\parameter;

/**
 * パラメータがスカラー型ではなかった場合の例外
 */
class NotAScalar extends \SC\exception\common\parameter
{
}
