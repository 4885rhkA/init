<?php
/**
 * ユーザエラー例外 (E_USER_ERROR)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * ユーザエラー例外 (E_USER_ERROR)
 */
class UserError extends \SC\exception\php\error
{
}
