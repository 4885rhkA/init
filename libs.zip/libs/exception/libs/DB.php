<?php
/**
 * DBの例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs;

/**
 * DBの例外
 */
class DB extends \SC\exception\libs
{
}
