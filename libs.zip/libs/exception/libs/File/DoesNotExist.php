<?php
/**
 * ファイルが存在しない場合の例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\libs\File;

/**
 * ファイルが存在しない場合の例外
 */
class DoesNotExist extends \SC\exception\libs\File
{
}
