<?php
/**
 * ログ出力のための例外
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * ログ出力のための例外
 */
class Log extends \SC\exception\php\error
{
}
