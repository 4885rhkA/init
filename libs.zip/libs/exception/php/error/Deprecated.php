<?php
/**
 * 廃止予定例外 (E_DEPRECATED)
 *
 * @copyright   (C) 2012 i3DESIGN Co., Ltd.
 * @version     $Id$
 */
namespace SC\exception\php\error;

/**
 * 廃止予定例外 (E_DEPRECATED)
 */
class Deprecated extends \SC\exception\php\error
{
}
